(function(){var P$=Clazz.newPackage("com.sun.jna"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Native");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'unregister$Class',  function (cls) {
}, 1);

Clazz.newMeth(C$, 'register$Class$com_sun_jna_NativeLibrary',  function (cls, lib) {

Clazz._loadWasm(cls, lib);
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:53:46 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
