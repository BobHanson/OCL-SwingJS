(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'com.actelion.research.chem.SSSearcherWithIndex','java.util.Random','java.util.ArrayList','com.actelion.research.calc.VectorSOM','com.actelion.research.calc.SelfOrganizedMap','java.util.Collections']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BinarySOM", null, 'com.actelion.research.calc.SelfOrganizedMap');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mMaxKeyCount'],'O',['mKeyFrequency','double[]','mMask','int[]','mKeyMaskMap','int[][]','mRandomizedKeyIndexList','java.util.ArrayList','mBitCount','byte[]','mRandom','java.util.Random']]
,['I',['KEY_COUNT','MASK_COUNT']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (nx, ny, mode) {
;C$.superclazz.c$$I$I$I.apply(this,[nx, ny, mode]);C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.mRandom=Clazz.new_($I$(2,1));
this.mMask=Clazz.array(Integer.TYPE, [32]);
this.mMask[0]=-2147483648;
for (var i=0; i < 31; i++) this.mMask[i + 1]=this.mMask[i] >>> 1;

this.mRandomizedKeyIndexList=Clazz.new_($I$(3,1));
for (var i=0; i < C$.KEY_COUNT; i++) this.mRandomizedKeyIndexList.add$O( new Integer(i));

this.mBitCount=Clazz.array(Byte.TYPE, [65536]);
for (var i=0; i < 65536; i++) this.mBitCount[i]=(Integer.bitCount$I(i)|0);

}, p$1);

Clazz.newMeth(C$, 'initializeNormalization$',  function () {
this.startProgress$S$I$I("Calculating key frequencies...", 0, this.mController.getInputVectorCount$());
this.mKeyFrequency=Clazz.array(Double.TYPE, [C$.KEY_COUNT]);
for (var row=0; row < this.mController.getInputVectorCount$(); row++) {
if (this.threadMustDie$()) break;
this.updateProgress$I(row);
var keyList=this.mController.getInputVector$I(row);
for (var i=0; i < C$.MASK_COUNT; i++) for (var j=0; j < 32; j++) if ((keyList[i] & this.mMask[j]) != 0) ++this.mKeyFrequency[i * 32 + j];


}
if (!this.threadMustDie$()) for (var i=0; i < C$.KEY_COUNT; i++) this.mKeyFrequency[i]/=this.mController.getInputVectorCount$();

});

Clazz.newMeth(C$, 'write$java_io_BufferedWriter',  function (writer) {
C$.superclazz.prototype.write$java_io_BufferedWriter.apply(this, [writer]);
writer.write$S("<keyFrequency=\"" + $I$(4).doubleArrayToString$DA(this.mKeyFrequency) + "\">" );
writer.newLine$();
});

Clazz.newMeth(C$, 'read$java_io_BufferedReader',  function (reader) {
C$.superclazz.prototype.read$java_io_BufferedReader.apply(this, [reader]);
var theLine=reader.readLine$();
var error=!theLine.startsWith$S("<keyFrequency=");
if (!error) {
this.mKeyFrequency=$I$(4,"stringToDoubleArray$S",[$I$(5).extractValue$S(theLine)]);
}if (error) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Invalid SOM file format"]);
});

Clazz.newMeth(C$, 'referenceVectorToString$I$I',  function (x, y) {
return $I$(1).getHexStringFromIndex$IA(this.mReferenceVector[x][y]);
});

Clazz.newMeth(C$, 'setReferenceVector$I$I$S',  function (x, y, ref) {
this.mReferenceVector[x][y]=$I$(1).getIndexFromHexString$S(ref);
});

Clazz.newMeth(C$, 'getDissimilarity$O$O',  function (vector1, vector2) {
var k1=vector1;
var k2=vector2;
var sharedKeys=0;
var allKeys=0;
for (var i=0; i < C$.MASK_COUNT; i++) {
var sk=k1[i] & k2[i];
var ak=k1[i] | k2[i];
sharedKeys+=this.mBitCount[65535 & sk] + this.mBitCount[sk >>> 16];
allKeys+=this.mBitCount[65535 & ak] + this.mBitCount[ak >>> 16];
}
return 1.0 - sharedKeys / allKeys;
});

Clazz.newMeth(C$, 'updateReference$O$O$D',  function (inputVector, referenceVector, influence) {
var mask=this.mKeyMaskMap[(influence|0)];
var inputKeyList=inputVector;
var referenceKeyList=referenceVector;
for (var i=0; i < C$.MASK_COUNT; i++) {
referenceKeyList[i]^=mask[i] & (inputKeyList[i] ^ referenceKeyList[i]);
}
});

Clazz.newMeth(C$, 'getRandomVector$',  function () {
var keyList=Clazz.array(Integer.TYPE, [C$.MASK_COUNT]);
for (var i=0; i < C$.MASK_COUNT; i++) for (var j=0; j < 32; j++) if (this.mRandom.nextDouble$() < this.mKeyFrequency[32 * i + j] ) keyList[i]|=this.mMask[j];


return keyList;
});

Clazz.newMeth(C$, 'getMeanVector$O$O',  function (vector1, vector2) {
var v1=vector1;
var v2=vector2;
var mv=Clazz.array(Integer.TYPE, [v1.length]);
for (var i=0; i < C$.MASK_COUNT; i++) {
mv[i]=v1[i];
for (var j=0; j < 32; j++) {
if ((v1[i] & this.mMask[j]) != (v2[i] & this.mMask[j]) && Math.random() < 0.5  ) {
mv[i]&=~this.mMask[j];
mv[i]|=(v2[i] & this.mMask[j]);
}}
}
return mv;
});

Clazz.newMeth(C$, 'normalizeVector$O',  function (vector) {
return vector;
});

Clazz.newMeth(C$, 'calculateInfluences$D',  function (time) {
C$.superclazz.prototype.calculateInfluences$D.apply(this, [time]);
this.mMaxKeyCount=0;
this.mKeyMaskMap=Clazz.array(Integer.TYPE, [C$.KEY_COUNT, null]);
for (var i=0; i < this.mInfluence.length; i++) {
for (var j=0; j < this.mInfluence[i].length; j++) {
if (this.mInfluence[i][j] != 0.0 ) {
var keyCount=((C$.KEY_COUNT * this.mInfluence[i][j] + 0.5)|0);
if (this.mMaxKeyCount < keyCount) this.mMaxKeyCount=keyCount;
this.mInfluence[i][j]=keyCount;
if (this.mKeyMaskMap[keyCount] == null ) this.mKeyMaskMap[keyCount]=Clazz.array(Integer.TYPE, [C$.MASK_COUNT]);
}}
}
});

Clazz.newMeth(C$, 'applyInfluences$O$java_awt_Point',  function (inputVector, location) {
p$1.randomizeKeyMasks.apply(this, []);
C$.superclazz.prototype.applyInfluences$O$java_awt_Point.apply(this, [inputVector, location]);
});

Clazz.newMeth(C$, 'randomizeKeyMasks',  function () {
var mask=Clazz.array(Integer.TYPE, [C$.MASK_COUNT]);
$I$(6).shuffle$java_util_List(this.mRandomizedKeyIndexList);
for (var keyCount=1; keyCount <= this.mMaxKeyCount; keyCount++) {
var keyIndex=(this.mRandomizedKeyIndexList.get$I(keyCount - 1)).intValue$();
mask[keyIndex >> 5]|=this.mMask[keyIndex & 31];
if (this.mKeyMaskMap[keyCount] != null ) for (var i=0; i < C$.MASK_COUNT; i++) this.mKeyMaskMap[keyCount][i]=mask[i];

}
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.KEY_COUNT=$I$(1).getNoOfKeys$();
C$.MASK_COUNT=(($I$(1).getNoOfKeys$() + 31)/32|0);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
