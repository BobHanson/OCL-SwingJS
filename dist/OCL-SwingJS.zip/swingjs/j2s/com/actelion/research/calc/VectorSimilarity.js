(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'com.actelion.research.util.DoubleVec']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VectorSimilarity");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getTanimotoSimilarity$DA$DA',  function (d1, d2) {
var sum=0;
var dAtB=C$.mult$DA$DA(d1, d2);
var dAtA=C$.mult$DA$DA(d1, d1);
var dBtB=C$.mult$DA$DA(d2, d2);
sum=dAtB / (dAtA + dBtB - dAtB);
return sum;
}, 1);

Clazz.newMeth(C$, 'mult$DA$DA',  function (arr1, arr2) {
var sum=0.0;
for (var i=0; i < arr1.length; i++) {
sum+=arr1[i] * arr2[i];
}
return sum;
}, 1);

Clazz.newMeth(C$, 'getTanimotoSimilarity$FA$FA',  function (d1, d2) {
var sum=0;
var dAtB=C$.mult$FA$FA(d1, d2);
var dAtA=C$.mult$FA$FA(d1, d1);
var dBtB=C$.mult$FA$FA(d2, d2);
sum=dAtB / (dAtA + dBtB - dAtB);
return sum;
}, 1);

Clazz.newMeth(C$, 'mult$FA$FA',  function (arr1, arr2) {
var sum=0.0;
for (var i=0; i < arr1.length; i++) {
sum+=arr1[i] * arr2[i];
}
return sum;
}, 1);

Clazz.newMeth(C$, 'getTanimotoSimilarity$IA$IA',  function (d1, d2) {
var sum=0;
var dAtB=C$.mult$IA$IA(d1, d2);
var dAtA=C$.mult$IA$IA(d1, d1);
var dBtB=C$.mult$IA$IA(d2, d2);
sum=dAtB / (dAtA + dBtB - dAtB);
return sum;
}, 1);

Clazz.newMeth(C$, 'getCosine$IA$IA',  function (d1, d2) {
var dB=Clazz.new_($I$(1,1).c$$IA,[d1]);
var dC=Clazz.new_($I$(1,1).c$$IA,[d2]);
dB.norm2One$();
dC.norm2One$();
return $I$(1).getCosine$com_actelion_research_util_DoubleVec$com_actelion_research_util_DoubleVec(dB, dC);
}, 1);

Clazz.newMeth(C$, 'mult$IA$IA',  function (arr1, arr2) {
var sum=0.0;
for (var i=0; i < arr1.length; i++) {
sum+=arr1[i] * arr2[i];
}
return sum;
}, 1);

Clazz.newMeth(C$, 'getMinMaxSimilarity$IA$IA',  function (d1, d2) {
var sumMin=0;
var sumMax=0;
for (var i=0; i < d1.length; i++) {
var v1=d1[i];
var v2=d2[i];
sumMin+=Math.min(v1, v2);
sumMax+=Math.max(v1, v2);
}
var score=sumMin / sumMax;
return score;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:13 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
