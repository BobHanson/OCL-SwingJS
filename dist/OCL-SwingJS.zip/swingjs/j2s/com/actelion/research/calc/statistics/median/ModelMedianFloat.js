(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics.median"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter','com.actelion.research.util.StringFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelMedianFloat");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['lowerQuartile','median','upperQuartile'],'I',['id','size']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$F$F$F$I$I',  function (lowerQuartile, median, upperQuartile, id, size) {
;C$.$init$.apply(this);
this.lowerQuartile=lowerQuartile;
this.median=median;
this.upperQuartile=upperQuartile;
this.id=id;
this.size=size;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_statistics_median_ModelMedianFloat',  function (m) {
;C$.$init$.apply(this);
this.lowerQuartile=m.lowerQuartile;
this.median=m.median;
this.upperQuartile=m.upperQuartile;
this.id=m.id;
this.size=m.size;
}, 1);

Clazz.newMeth(C$, 'range$',  function () {
return this.upperQuartile - this.lowerQuartile;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S($I$(2,"format4$Double",[Double.valueOf$D(this.lowerQuartile)]));
sb.append$S("\t");
sb.append$S($I$(2,"format4$Double",[Double.valueOf$D(this.median)]));
sb.append$S("\t");
sb.append$S($I$(2,"format4$Double",[Double.valueOf$D(this.upperQuartile)]));
return sb.toString();
});

Clazz.newMeth(C$, 'toString$java_util_List',  function (liModelMedian) {
var sb=Clazz.new_($I$(1,1));
var length=7;
var lengthText=15;
sb.append$S($I$(3).format2DefinedLengthTrailing$S$I("Id", lengthText));
for (var i=0; i < liModelMedian.size$(); i++) {
var m=liModelMedian.get$I(i);
var s=$I$(3,"format2DefinedLengthLeading$S$I",[Integer.toString$I(m.id), length]);
sb.append$S(s);
}
sb.append$S("\n");
sb.append$S($I$(3).format2DefinedLengthTrailing$S$I("Upper quartile", lengthText));
for (var i=0; i < liModelMedian.size$(); i++) {
var m=liModelMedian.get$I(i);
var s=$I$(3,"format2DefinedLengthLeading$S$I",[$I$(2,"format2$Double",[Double.valueOf$D(m.upperQuartile)]), length]);
sb.append$S(s);
}
sb.append$S("\n");
sb.append$S($I$(3).format2DefinedLengthTrailing$S$I("Median", lengthText));
for (var i=0; i < liModelMedian.size$(); i++) {
var m=liModelMedian.get$I(i);
var s=$I$(3,"format2DefinedLengthLeading$S$I",[$I$(2,"format2$Double",[Double.valueOf$D(m.median)]), length]);
sb.append$S(s);
}
sb.append$S("\n");
sb.append$S($I$(3).format2DefinedLengthTrailing$S$I("Lower quartile", lengthText));
for (var i=0; i < liModelMedian.size$(); i++) {
var m=liModelMedian.get$I(i);
var s=$I$(3,"format2DefinedLengthLeading$S$I",[$I$(2,"format2$Double",[Double.valueOf$D(m.lowerQuartile)]), length]);
sb.append$S(s);
}
sb.append$S("\n");
sb.append$S($I$(3).format2DefinedLengthTrailing$S$I("Size", lengthText));
for (var i=0; i < liModelMedian.size$(); i++) {
var m=liModelMedian.get$I(i);
var s=$I$(3,"format2DefinedLengthLeading$S$I",[Integer.toString$I(m.size), length]);
sb.append$S(s);
}
return sb.toString();
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
