(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.knn"),I$=[[0,'com.actelion.research.calc.regression.knn.ParameterKNN','com.actelion.research.chem.descriptor.SimilarityCalculatorDoubleArray','com.actelion.research.calc.SimilarityMulticore','com.actelion.research.calc.MatrixFunctions','java.util.ArrayList','com.actelion.research.calc.Matrix']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "KNNRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['similarityCalculatorDoubleArray','com.actelion.research.chem.descriptor.SimilarityCalculatorDoubleArray','similarityMulticore','com.actelion.research.calc.SimilarityMulticore','liXTrain','java.util.List','XTrain','com.actelion.research.calc.Matrix','+YTrain']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1).c$$I,[3]));
this.similarityCalculatorDoubleArray=Clazz.new_($I$(2,1));
this.similarityMulticore=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_ISimilarityCalculator,[this.similarityCalculatorDoubleArray]);
}, 1);

Clazz.newMeth(C$, 'getNeighbours$',  function () {
return this.getParameter$().getNeighbours$();
});

Clazz.newMeth(C$, 'setNeighbours$I',  function (neighbours) {
this.getParameter$().setNeighbours$I(neighbours);
});

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
this.XTrain=modelXYIndexTrain.X;
this.YTrain=modelXYIndexTrain.Y;
this.liXTrain=$I$(4).createIdentifiedObject$com_actelion_research_calc_Matrix(modelXYIndexTrain.X);
this.similarityMulticore.run$java_util_List$java_util_List(this.liXTrain, this.liXTrain);
var maSimilarity=this.similarityMulticore.getSimilarityMatrix$();
var maYHat=C$.calculateYHat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I(maSimilarity, this.YTrain, this.getParameter$().getNeighbours$());
return maYHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var liX=$I$(4).createIdentifiedObject$com_actelion_research_calc_Matrix(X);
this.similarityMulticore.run$java_util_List$java_util_List(this.liXTrain, liX);
var maSimMatrixTrainTest=this.similarityMulticore.getSimilarityMatrix$();
return C$.calculateYHat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I(maSimMatrixTrainTest, this.YTrain, this.getParameter$().getNeighbours$());
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var k=this.getParameter$().getNeighbours$();
var arrSim=Clazz.array(Double.TYPE, [k]);
var arrIndex=Clazz.array(Integer.TYPE, [k]);
for (var i=0; i < this.liXTrain.size$(); i++) {
var idObj=this.liXTrain.get$I(i);
var arrXTrain=idObj.getData$();
var sim=this.similarityCalculatorDoubleArray.getSimilarity$DA$DA(arrXTrain, arrRow);
for (var j=k - 1; j >= 0; j--) {
if (sim > arrSim[j] ) {
arrSim[j]=sim;
arrIndex[j]=i;
break;
}}
}
var arrNYTrain=Clazz.array(Double.TYPE, [k]);
for (var i=0; i < k; i++) {
var indexTrain=arrIndex[i];
arrNYTrain[i]=this.YTrain.get$I$I(indexTrain, 0);
}
var yHat=C$.calculateYHat$DA$DA(arrSim, arrNYTrain);
return yHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I',  function (maSimMatrixTrainTest, YTrain, neighbours) {
var rowsTrain=maSimMatrixTrainTest.rows$();
var rowsTest=maSimMatrixTrainTest.cols$();
var colsY=YTrain.cols$();
var liSimilarityMostNSimilar=Clazz.new_($I$(5,1).c$$I,[rowsTest]);
var liIndexMostNSimilar=Clazz.new_($I$(5,1).c$$I,[rowsTest]);
for (var i=0; i < rowsTest; i++) {
var arrSimilarityNSimilar=Clazz.array(Double.TYPE, [neighbours]);
var arrNSimilarIndex=Clazz.array(Integer.TYPE, [neighbours]);
var minSim=0;
var indexMinSim=0;
for (var j=0; j < rowsTrain; j++) {
var v=maSimMatrixTrainTest.get$I$I(j, i);
if (v > minSim ) {
arrSimilarityNSimilar[indexMinSim]=v;
arrNSimilarIndex[indexMinSim]=j;
minSim=1.7976931348623157E308;
indexMinSim=-1;
for (var k=0; k < arrSimilarityNSimilar.length; k++) {
if (arrSimilarityNSimilar[k] < minSim ) {
minSim=arrSimilarityNSimilar[k];
indexMinSim=k;
}}
}}
liSimilarityMostNSimilar.add$O(arrSimilarityNSimilar);
liIndexMostNSimilar.add$O(arrNSimilarIndex);
}
var arrYHat=Clazz.array(Double.TYPE, [rowsTest, colsY]);
for (var h=0; h < colsY; h++) {
for (var i=0; i < rowsTest; i++) {
var arrNSimilarIndex=liIndexMostNSimilar.get$I(i);
var arrYN=Clazz.array(Double.TYPE, [neighbours]);
for (var j=0; j < arrNSimilarIndex.length; j++) {
arrYN[j]=YTrain.get$I$I(arrNSimilarIndex[j], h);
}
var yHat=C$.calculateYHat$DA$DA(liSimilarityMostNSimilar.get$I(i), arrYN);
arrYHat[i][h]=yHat;
}
}
return Clazz.new_($I$(6,1).c$$DAA,[arrYHat]);
}, 1);

Clazz.newMeth(C$, 'calculateYHat$DA$DA',  function (arrSimilarityNMostSimilar, arrNYTrain) {
var sumSimilarity=0;
for (var v, $v = 0, $$v = arrSimilarityNMostSimilar; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
sumSimilarity+=v;
}
var yHat=0;
if (sumSimilarity < 1.0E-5 ) {
for (var i=0; i < arrNYTrain.length; i++) {
yHat+=arrNYTrain[i];
}
yHat/=arrNYTrain.length;
} else {
for (var i=0; i < arrNYTrain.length; i++) {
var v=arrSimilarityNMostSimilar[i];
yHat+=arrNYTrain[i] * v;
}
yHat/=sumSimilarity;
}return yHat;
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
