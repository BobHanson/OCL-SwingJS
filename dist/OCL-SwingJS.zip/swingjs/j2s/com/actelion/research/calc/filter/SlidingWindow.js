(function(){var P$=Clazz.newPackage("com.actelion.research.calc.filter"),I$=[[0,'com.actelion.research.util.ArrayUtils']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SlidingWindow");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['l','l_half'],'O',['arrFilter','double[]']]]

Clazz.newMeth(C$, 'c$$DA',  function (arrFilter) {
;C$.$init$.apply(this);
this.arrFilter=arrFilter;
if (arrFilter.length % 2 == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Odd number of filter values needed."]);
}this.l=arrFilter.length;
this.l_half=(arrFilter.length/2|0);
}, 1);

Clazz.newMeth(C$, 'filter$DA',  function (a) {
var aa=Clazz.array(Double.TYPE, [a.length + this.l * 2]);
var aaa=Clazz.array(Double.TYPE, [a.length + this.l * 2]);
System.arraycopy$O$I$O$I$I(a, 0, aa, this.l, a.length);
var end=aa.length - this.l_half;
for (var i=this.l_half; i < end; i++) {
var v=0;
for (var j=0; j < this.arrFilter.length; j++) {
var ind=i - this.l_half + j;
v+=aa[ind] * this.arrFilter[j] + 0.5;
}
aaa[i]=v;
}
aa=Clazz.array(Double.TYPE, [a.length]);
System.arraycopy$O$I$O$I$I(aaa, this.l, aa, 0, aa.length);
return aa;
});

Clazz.newMeth(C$, 'filter$IA',  function (a) {
var aa=Clazz.array(Integer.TYPE, [a.length + this.l * 2]);
var aaa=Clazz.array(Integer.TYPE, [a.length + this.l * 2]);
System.arraycopy$O$I$O$I$I(a, 0, aa, this.l, a.length);
var end=aa.length - this.l_half;
for (var i=this.l_half; i < end; i++) {
var v=0;
for (var j=0; j < this.arrFilter.length; j++) {
var ind=i - this.l_half + j;
v+=((aa[ind] * this.arrFilter[j] + 0.5)|0);
}
aaa[i]=v;
}
aa=Clazz.array(Integer.TYPE, [a.length]);
System.arraycopy$O$I$O$I$I(aaa, this.l, aa, 0, aa.length);
return aa;
});

Clazz.newMeth(C$, 'filter$BA',  function (a) {
var aa=Clazz.array(Byte.TYPE, [a.length + this.l * 2]);
var aaa=Clazz.array(Byte.TYPE, [a.length + this.l * 2]);
System.arraycopy$O$I$O$I$I(a, 0, aa, this.l, a.length);
var end=aa.length - this.l_half;
for (var i=this.l_half; i < end; i++) {
var v=($b$[0] = 0, $b$[0]);
for (var j=0; j < this.arrFilter.length; j++) {
var ind=i - this.l_half + j;
v+=($b$[0] = (aa[ind] * this.arrFilter[j] + 0.5), $b$[0]);
}
aaa[i]=v;
}
aa=Clazz.array(Byte.TYPE, [a.length]);
System.arraycopy$O$I$O$I$I(aaa, this.l, aa, 0, aa.length);
return aa;
});

Clazz.newMeth(C$, 'main$SA',  function (args) {
var a=Clazz.array(Integer.TYPE, -1, [0, 0, 0, 0, 100, 100, 0, 0, 0, 0, 0]);
var f=Clazz.array(Double.TYPE, -1, [0.25, 0.5, 0.25]);
var slidingWindow=Clazz.new_(C$.c$$DA,[f]);
var aa=slidingWindow.filter$IA(a);
System.out.println$S($I$(1).toString$IA(aa));
}, 1);
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:05 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
