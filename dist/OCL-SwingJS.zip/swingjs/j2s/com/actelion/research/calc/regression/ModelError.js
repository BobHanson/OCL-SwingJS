(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter','com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.calc.MatrixFunctions','com.actelion.research.calc.classification.PrecisionAndRecall','java.util.ArrayList','java.util.Random','com.actelion.research.calc.Matrix','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelError");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['classification','failed'],'D',['error','errorMedian','errorRelative','errorRelativeMedian','errorRelativeWeighted','errSumSquared','errMax','errMin','corrSquared','corrSquaredSpearman'],'I',['nNotFiniteRelError'],'O',['precisionAndRecall','com.actelion.research.calc.classification.PrecisionAndRecall']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.failed=false;
}, 1);

Clazz.newMeth(C$, 'setFailed$',  function () {
this.failed=true;
});

Clazz.newMeth(C$, 'isFailed$',  function () {
return this.failed;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1));
if (this.failed) {
sb.append$S("ModelError [error=failed]");
} else {
sb.append$S("ModelError [error=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.error)]));
sb.append$S(", errRelativeMedian=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.errorRelativeMedian)]));
if (this.nNotFiniteRelError != 0) {
sb.append$S(", NotFiniteRelError=");
sb.append$I(this.nNotFiniteRelError);
}sb.append$S(", errMax=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.errMax)]));
sb.append$S(", errMin=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.errMin)]));
sb.append$S(", corrSquared=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.corrSquared)]));
if (this.precisionAndRecall != null ) {
sb.append$S(", Cohen\'s kappa=");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.precisionAndRecall.calculateCohensKappa$())]));
}sb.append$S("]");
}return sb.toString();
});

Clazz.newMeth(C$, 'calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix',  function (Y, YHat) {
var modelError=Clazz.new_(C$);
modelError.errMax=0;
modelError.errMin=2147483647;
var daError=Clazz.new_([Y.rows$() * YHat.cols$()],$I$(3,1).c$$I);
var sumSquared=0;
for (var i=0; i < YHat.cols$(); i++) {
for (var j=0; j < YHat.rows$(); j++) {
var e=Math.abs(Y.get$I$I(j, i) - YHat.get$I$I(j, i));
sumSquared+=e * e;
modelError.errMax=Math.max(modelError.errMax, e);
modelError.errMin=Math.min(modelError.errMin, e);
modelError.error+=e;
daError.add$D(e);
}
}
modelError.error=modelError.error / (YHat.rows$() * YHat.cols$());
modelError.errSumSquared=sumSquared;
modelError.errorMedian=daError.median$();
var daErrorRelative=Clazz.new_([YHat.rows$() * YHat.cols$()],$I$(3,1).c$$I);
modelError.nNotFiniteRelError=0;
for (var i=0; i < YHat.cols$(); i++) {
for (var j=0; j < YHat.rows$(); j++) {
var y=Y.get$I$I(j, i);
var yHat=YHat.get$I$I(j, i);
var er=C$.getRelativeError$D$D(y, yHat);
if (Double.isFinite$D(er)) {
daErrorRelative.add$D(er);
} else {
++modelError.nNotFiniteRelError;
}}
}
if (daErrorRelative.size$() > 0) {
modelError.errorRelative=daErrorRelative.avr$();
modelError.errorRelativeMedian=daErrorRelative.median$();
}var daErrorRelativeWeighted=Clazz.new_([YHat.rows$() * YHat.cols$()],$I$(3,1).c$$I);
for (var i=0; i < YHat.cols$(); i++) {
for (var j=0; j < YHat.rows$(); j++) {
var y=Y.get$I$I(j, i);
var yHat=YHat.get$I$I(j, i);
var w=Math.log10(10 + y);
if (Math.abs(y) > 1.0E-4 ) {
var er=Math.abs((yHat - y) / y) * (1.0 / w);
if (Double.isFinite$D(er)) {
daErrorRelativeWeighted.add$D(er);
}} else {
var er=Math.abs((yHat - y) / 1.0E-4) * (1.0 / w);
if (Double.isFinite$D(er)) {
daErrorRelativeWeighted.add$D(er);
}}}
}
modelError.errorRelativeWeighted=daErrorRelativeWeighted.avr$();
var corr=0;
var corrSpearman=0;
try {
corr=$I$(4).getCorrPearson$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(YHat, Y);
corrSpearman=$I$(4).getCorrSpearman$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(YHat, Y);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
System.err.println$S("YHat");
System.err.println$S(YHat.toString());
System.err.println$S("Y");
System.err.println$S(Y.toString());
} else {
throw e;
}
}
if (!Double.isFinite$D(corr)) {
corr=0;
}if (!Double.isFinite$D(corrSpearman)) {
corrSpearman=0;
}modelError.corrSquared=corr * corr;
modelError.corrSquaredSpearman=corrSpearman * corrSpearman;
return modelError;
}, 1);

Clazz.newMeth(C$, 'getRelativeError$D$D',  function (y, yHat) {
var er=0;
if (Math.abs(y) > 1.0E-4 ) {
er=Math.abs((yHat - y) / y);
} else {
er=Math.abs((yHat - y) / 1.0E-4);
}return er;
}, 1);

Clazz.newMeth(C$, 'calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$D$Z',  function (Y, YHat, threshold, above) {
var me=C$.calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Y, YHat);
me.precisionAndRecall=Clazz.new_($I$(5,1));
for (var i=0; i < YHat.cols$(); i++) {
for (var j=0; j < YHat.rows$(); j++) {
var y=Y.get$I$I(j, i);
var yHat=YHat.get$I$I(j, i);
if (above) {
if (y >= threshold  && yHat >= threshold  ) {
++me.precisionAndRecall.truePositive;
} else if (y < threshold  && yHat < threshold  ) {
++me.precisionAndRecall.trueNegative;
} else if (yHat >= threshold ) {
++me.precisionAndRecall.falsePositive;
} else if (yHat < threshold ) {
++me.precisionAndRecall.falseNegative;
}} else {
if (y <= threshold  && yHat <= threshold  ) {
++me.precisionAndRecall.truePositive;
} else if (y > threshold  && yHat > threshold  ) {
++me.precisionAndRecall.trueNegative;
} else if (yHat <= threshold ) {
++me.precisionAndRecall.falsePositive;
} else if (yHat > threshold ) {
++me.precisionAndRecall.falseNegative;
}}}
}
me.classification=true;
return me;
}, 1);

Clazz.newMeth(C$, 'getError$java_util_List',  function (liME) {
var li=Clazz.new_($I$(6,1));
for (var modelError, $modelError = liME.iterator$(); $modelError.hasNext$()&&((modelError=($modelError.next$())),1);) {
li.add$O(Double.valueOf$D(modelError.error));
}
return li;
}, 1);

Clazz.newMeth(C$, 'getErrorAverage$java_util_List',  function (liME) {
var modelErrorAvr=Clazz.new_(C$);
for (var modelError, $modelError = liME.iterator$(); $modelError.hasNext$()&&((modelError=($modelError.next$())),1);) {
modelErrorAvr.errMax+=modelError.errMax;
modelErrorAvr.errMin+=modelError.errMin;
modelErrorAvr.error+=modelError.error;
modelErrorAvr.corrSquared+=modelError.corrSquared;
}
var n=liME.size$();
modelErrorAvr.errMax/=n;
modelErrorAvr.errMin/=n;
modelErrorAvr.error/=n;
modelErrorAvr.corrSquared/=n;
return modelErrorAvr;
}, 1);

Clazz.newMeth(C$, 'getComparatorError$',  function () {
return ((P$.ModelError$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ModelError$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_calc_regression_ModelError$com_actelion_research_calc_regression_ModelError','compare$O$O'],  function (o1, o2) {
var cmp=0;
if (o1.error > o2.error ) {
cmp=1;
} else if (o1.error < o2.error ) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.ModelError$1.$init$,[this, null]));
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var n=11;
var fracNoise=0.1;
var random=Clazz.new_($I$(7,1));
var a=Clazz.array(Double.TYPE, [n]);
var b=Clazz.array(Double.TYPE, [n]);
for (var i=0; i < n; i++) {
a[i]=random.nextDouble$();
b[i]=random.nextDouble$();
}
var meRaw=C$.calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Clazz.new_($I$(8,1).c$$Z$DA,[false, a]), Clazz.new_($I$(8,1).c$$Z$DA,[false, b]));
System.out.println$S(meRaw.toString());
$I$(9).sort$DA(a);
$I$(9).sort$DA(b);
var meSort=C$.calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Clazz.new_($I$(8,1).c$$Z$DA,[false, a]), Clazz.new_($I$(8,1).c$$Z$DA,[false, b]));
System.out.println$S(meSort.toString());
for (var i=0; i < n; i++) {
if (random.nextDouble$() < fracNoise ) {
a[i]=random.nextDouble$();
}}
var meNoise=C$.calculateError$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Clazz.new_($I$(8,1).c$$Z$DA,[false, a]), Clazz.new_($I$(8,1).c$$Z$DA,[false, b]));
System.out.println$S(meNoise.toString());
}, 1);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:54 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
