(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SVR_Q", null, 'com.actelion.research.calc.regression.svm.Kernel');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['l','next_buffer'],'O',['cache','com.actelion.research.calc.regression.svm.Cache','sign','byte[]','index','int[]','buffer','float[][]','QD','double[]']]]

Clazz.newMeth(C$, 'c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter',  function (prob, param) {
;C$.superclazz.c$$I$org_machinelearning_svm_libsvm_svm_nodeAA$org_machinelearning_svm_libsvm_svm_parameter.apply(this,[prob.l, prob.x, param]);C$.$init$.apply(this);
this.l=prob.l;
this.cache=Clazz.new_([this.l, Clazz.toLong((param.cache_size * (1048576)))],$I$(3,1).c$$I$J);
this.QD=Clazz.array(Double.TYPE, [2 * this.l]);
this.sign=Clazz.array(Byte.TYPE, [2 * this.l]);
this.index=Clazz.array(Integer.TYPE, [2 * this.l]);
for (var k=0; k < this.l; k++) {
this.sign[k]=(1|0);
this.sign[k + this.l]=(-1|0);
this.index[k]=k;
this.index[k + this.l]=k;
this.QD[k]=this.kernel_function$I$I(k, k);
this.QD[k + this.l]=this.QD[k];
}
this.buffer=Clazz.array(Float.TYPE, [2, 2 * this.l]);
this.next_buffer=0;
}, 1);

Clazz.newMeth(C$, 'swap_index$I$I',  function (i, j) {
do {
var tmp=this.sign[i];
this.sign[i]=this.sign[j];
this.sign[j]=tmp;
} while (false);
do {
var tmp=this.index[i];
this.index[i]=this.index[j];
this.index[j]=tmp;
} while (false);
do {
var tmp=this.QD[i];
this.QD[i]=this.QD[j];
this.QD[j]=tmp;
} while (false);
});

Clazz.newMeth(C$, 'get_Q$I$I',  function (i, len) {
var data=Clazz.array(Float.TYPE, [1, null]);
var j;
var real_i=this.index[i];
if (this.cache.get_data$I$FAA$I(real_i, data, this.l) < this.l) {
for (j=0; j < this.l; j++) data[0][j]=this.kernel_function$I$I(real_i, j);

}var buf=this.buffer[this.next_buffer];
this.next_buffer=1 - this.next_buffer;
var si=this.sign[i];
for (j=0; j < len; j++) buf[j]=si * this.sign[j] * data[0][this.index[j]] ;

return buf;
});

Clazz.newMeth(C$, 'get_QD$',  function () {
return this.QD;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:34 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
