(function(){var P$=Clazz.newPackage("com.actelion.research.calc.graph"),p$1={},I$=[[0,'com.actelion.research.calc.Matrix','java.util.ArrayList','java.awt.Point']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MinimumSpanningTree");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['maAdjacency','com.actelion.research.calc.Matrix']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_Matrix',  function (maAdjacency) {
;C$.$init$.apply(this);
this.maAdjacency=maAdjacency;
}, 1);

Clazz.newMeth(C$, 'getMST$',  function () {
var maMST=Clazz.new_([this.maAdjacency.rows$(), this.maAdjacency.cols$()],$I$(1,1).c$$I$I);
var arrNode=Clazz.array(Integer.TYPE, [this.maAdjacency.rows$()]);
var pStart=p$1.getStartEdge.apply(this, []);
arrNode[pStart.x]=1;
arrNode[pStart.y]=1;
var liMST=Clazz.new_($I$(2,1));
liMST.add$O(pStart);
var edgesMinSpanningTree=this.maAdjacency.rows$() - 1;
var ccAddedEdges2MST=0;
while (ccAddedEdges2MST < edgesMinSpanningTree){
var min=1.7976931348623157E308;
var rowMin=-1;
var colMin=-1;
for (var i=0; i < this.maAdjacency.rows$(); i++) {
if (arrNode[i] == 1) {
for (var j=0; j < this.maAdjacency.cols$(); j++) {
if (i == j) {
continue;
}if (arrNode[j] == 1) {
continue;
}if (!Double.isNaN$D(this.maAdjacency.get$I$I(i, j))) {
if (this.maAdjacency.get$I$I(i, j) < min ) {
min=this.maAdjacency.get$I$I(i, j);
rowMin=i;
colMin=j;
}}}
}}
if (rowMin == -1) {
break;
} else {
arrNode[rowMin]=1;
arrNode[colMin]=1;
liMST.add$O(Clazz.new_($I$(3,1).c$$I$I,[rowMin, colMin]));
++ccAddedEdges2MST;
}}
maMST.set$D(NaN);
for (var p, $p = liMST.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
maMST.set$I$I$D(p.x, p.y, this.maAdjacency.get$I$I(p.x, p.y));
maMST.set$I$I$D(p.y, p.x, this.maAdjacency.get$I$I(p.x, p.y));
}
return maMST;
});

Clazz.newMeth(C$, 'getStartEdge',  function () {
var min=1.7976931348623157E308;
var pMin=Clazz.new_($I$(3,1));
for (var i=0; i < this.maAdjacency.rows$(); i++) {
for (var j=i + 1; j < this.maAdjacency.cols$(); j++) {
if (!Double.isNaN$D(this.maAdjacency.get$I$I(i, j))) {
if (this.maAdjacency.get$I$I(i, j) < min ) {
min=this.maAdjacency.get$I$I(i, j);
pMin.x=i;
pMin.y=j;
}}}
}
return pMin;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:02 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
