(function(){var P$=Clazz.newPackage("com.actelion.research.calc.geometry"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Triangle");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getArea$D$D$D',  function (sideA, sideB, sideC) {
var s=(sideA + sideB + sideC ) / 2.0;
var a=Math.sqrt(s * (s - sideA) * (s - sideB) * (s - sideC) );
return a;
}, 1);

Clazz.newMeth(C$, 'getAreaRightTriangle$D$D',  function (sideA, sideB) {
var a=(sideA * sideB) / 2.0;
return a;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:05 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
