(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.randomforest"),I$=[[0,'com.actelion.research.calc.regression.randomforest.ParameterRandomForest','smile.regression.RandomForest','com.actelion.research.calc.Matrix']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RandomForestRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['forest','smile.regression.RandomForest']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1)));
try {
System.setProperty$S$S("smile.threads", "1");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_randomforest_ParameterRandomForest',  function (parameterRandomForest) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterRandomForest);
}, 1);

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
var YHat=null;
try {
var parameterRandomForest=this.getParameter$();
var mTry=((modelXYIndexTrain.X.cols$() * parameterRandomForest.getFractionMTry$() + 0.5)|0);
if (mTry < 3) {
mTry=3;
}this.forest=Clazz.new_([modelXYIndexTrain.X.getArray$(), modelXYIndexTrain.Y.getColAsDouble$I(0), parameterRandomForest.getNumberOfTrees$(), parameterRandomForest.getMaxNodes$(), parameterRandomForest.getNodeSize$(), mTry],$I$(2,1).c$$DAA$DA$I$I$I$I);
YHat=this.calculateYHat$com_actelion_research_calc_Matrix(modelXYIndexTrain.X);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
return YHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var arrY=Clazz.array(Double.TYPE, [X.rows$()]);
for (var i=0; i < X.rows$(); i++) {
var arrRow=X.getRow$I(i);
var y=this.forest.predict$DA(arrRow);
arrY[i]=y;
}
return Clazz.new_($I$(3,1).c$$Z$DA,[false, arrY]);
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var y;
{
y=this.forest.predict$DA(arrRow);
}return y;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_randomforest_RandomForestRegression','compareTo$O'],  function (o) {
return this.getParameter$().compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod(o.getParameter$());
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
