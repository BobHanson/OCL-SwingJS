(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelStatisticsOverview", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['min','avr','max','sdv']]]

Clazz.newMeth(C$, 'c$$D$D$D$D',  function (min, avr, max, sdv) {
;C$.$init$.apply(this);
this.min=min;
this.avr=avr;
this.max=max;
this.sdv=sdv;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'areAllFinite$',  function () {
if (!Double.isFinite$D(this.min)) {
return false;
} else if (!Double.isFinite$D(this.avr)) {
return false;
} else if (!Double.isFinite$D(this.max)) {
return false;
}return true;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ModelStatisticsOverview{"]);
sb.append$S("min=").append$D(this.min);
sb.append$S(", avr=").append$D(this.avr);
sb.append$S(", max=").append$D(this.max);
sb.append$S(", sdv=").append$D(this.sdv);
sb.append$C("}");
return sb.toString();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
