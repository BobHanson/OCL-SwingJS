(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics"),I$=[[0,'StringBuilder','com.actelion.research.calc.statistics.StatisticsOverview']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelStatisticsOverviewMedian");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['percentile05','percentile25','median','percentile75','percentile95']]]

Clazz.newMeth(C$, 'c$$D$D$D$D$D',  function (percentile05, percentile25, median, percentile75, percentile95) {
;C$.$init$.apply(this);
this.percentile05=percentile05;
this.percentile25=percentile25;
this.median=median;
this.percentile75=percentile75;
this.percentile95=percentile95;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'areAllFinite$',  function () {
if (!Double.isFinite$D(this.percentile05)) {
return false;
} else if (!Double.isFinite$D(this.percentile25)) {
return false;
} else if (!Double.isFinite$D(this.median)) {
return false;
} else if (!Double.isFinite$D(this.percentile75)) {
return false;
} else if (!Double.isFinite$D(this.percentile95)) {
return false;
}return true;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ModelStatisticsOverviewMedian{"]);
sb.append$S("percentile05=").append$S($I$(2).DF4.format$D(this.percentile05));
sb.append$S(", percentile25=").append$S($I$(2).DF4.format$D(this.percentile25));
sb.append$S(", median=").append$S($I$(2).DF4.format$D(this.median));
sb.append$S(", percentile75=").append$S($I$(2).DF4.format$D(this.percentile75));
sb.append$S(", percentile95=").append$S($I$(2).DF4.format$D(this.percentile95));
sb.append$C("}");
return sb.toString();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:07 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
