(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.linear.pls.boxcox"),I$=[[0,'com.actelion.research.calc.regression.linear.pls.boxcox.ParameterPLSBoxCox','com.actelion.research.calc.BoxCox','com.actelion.research.util.datamodel.ModelXYColTags']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PLSBoxCoxY", null, 'com.actelion.research.calc.regression.linear.pls.PLSRegressionModelCalculator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['boxCox','com.actelion.research.calc.BoxCox']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1).c$$I,[15]));
(this.getParameter$()).setLambda$D(0.6);
this.boxCox=Clazz.new_([(this.getParameter$()).getLambda$()],$I$(2,1).c$$D);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_linear_pls_boxcox_ParameterPLSBoxCox',  function (parameterPLSBoxCox) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterPLSBoxCox);
(this.getParameter$()).setLambda$D(0.6);
this.boxCox=Clazz.new_([(this.getParameter$()).getLambda$()],$I$(2,1).c$$D);
}, 1);

Clazz.newMeth(C$, 'getLambda$',  function () {
return (this.getParameter$()).getLambda$();
});

Clazz.newMeth(C$, 'setLambda$D',  function (lambda) {
(this.getParameter$()).setLambda$D(lambda);
});

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
C$.superclazz.prototype.setCenterData$Z.apply(this, [true]);
var modelXYColTagsPowerTrans=Clazz.new_($I$(3,1));
modelXYColTagsPowerTrans.X=modelXYIndexTrain.X;
this.boxCox.setLambda$D((this.getParameter$()).getLambda$());
modelXYColTagsPowerTrans.Y=$I$(2).transform$com_actelion_research_calc_Matrix$com_actelion_research_calc_BoxCox(modelXYIndexTrain.Y, this.boxCox);
var yHat=C$.superclazz.prototype.createModel$com_actelion_research_util_datamodel_ModelXYIndex.apply(this, [modelXYColTagsPowerTrans]);
return yHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (Xtest) {
var YHatTest=C$.superclazz.prototype.calculateYHat$com_actelion_research_calc_Matrix.apply(this, [Xtest]);
var YHatTestRe=$I$(2).reTransform$com_actelion_research_calc_Matrix$com_actelion_research_calc_BoxCox(YHatTest, this.boxCox);
return YHatTestRe;
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var yHatUntrans=C$.superclazz.prototype.calculateYHat$DA.apply(this, [arrRow]);
var yHat=this.boxCox.inverse$D(yHatUntrans);
return yHat;
});

Clazz.newMeth(C$, 'getParameter$',  function () {
return C$.superclazz.prototype.getParameter$.apply(this, []);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
