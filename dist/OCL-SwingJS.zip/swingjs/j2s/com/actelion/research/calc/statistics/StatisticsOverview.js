(function(){var P$=Clazz.newPackage("com.actelion.research.calc.statistics"),p$1={},I$=[[0,'java.text.DecimalFormat','java.text.DecimalFormatSymbols','java.util.Locale','com.actelion.research.util.datamodel.DoubleArray','com.actelion.research.calc.statistics.ModelStatisticsOverview','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.calc.histogram.MatrixBasedHistogram','com.actelion.research.calc.Matrix','com.actelion.research.calc.histogram.IntegerHistogram','java.util.Arrays','StringBuilder','com.actelion.research.calc.statistics.ModelStatisticsOverviewMedian']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StatisticsOverview");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['evaluated'],'D',['min','mean','max','sdv','percentile05','leftQuartile','median','rightQuartile','percentile95'],'I',['valsBelowHistMin','valsAboveHistMax','bins'],'S',['name'],'O',['histogram','com.actelion.research.calc.Matrix','data','com.actelion.research.util.datamodel.DoubleArray']]
,['O',['DF1','java.text.NumberFormat','+DF3','+DF4','+DF3Plus']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.data=Clazz.new_($I$(4,1));
this.bins=20;
this.evaluated=false;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_util_datamodel_DoubleArray',  function (da) {
;C$.$init$.apply(this);
this.data=da;
this.bins=20;
this.evaluated=false;
}, 1);

Clazz.newMeth(C$, 'add$D',  function (value) {
this.data.add$D(value);
this.evaluated=false;
});

Clazz.newMeth(C$, 'add$DA',  function (arr) {
for (var i=0; i < arr.length; i++) {
this.data.add$D(arr[i]);
}
this.evaluated=false;
});

Clazz.newMeth(C$, 'add$IA',  function (arr) {
for (var i=0; i < arr.length; i++) {
this.data.add$D(arr[i]);
}
this.evaluated=false;
});

Clazz.newMeth(C$, 'getData$',  function () {
return this.data;
});

Clazz.newMeth(C$, 'getMean$',  function () {
return this.mean;
});

Clazz.newMeth(C$, 'getSdv$',  function () {
return this.sdv;
});

Clazz.newMeth(C$, 'getMedian$',  function () {
return this.median;
});

Clazz.newMeth(C$, 'evaluate$',  function () {
var histMin=this.data.min$() - this.data.min$() * 1.0E-6;
var histMax=this.data.max$() + this.data.max$() * 1.0E-6;
var modelStatisticsOverview=Clazz.new_($I$(5,1));
if (Math.abs(histMin - histMax) > 1.0E-8 ) {
this.evaluate$D$D(histMin, histMax);
modelStatisticsOverview.min=this.data.min$();
modelStatisticsOverview.avr=this.mean;
modelStatisticsOverview.max=this.data.max$();
modelStatisticsOverview.sdv=this.sdv;
} else {
modelStatisticsOverview.min=0;
modelStatisticsOverview.avr=0;
modelStatisticsOverview.max=0;
modelStatisticsOverview.sdv=0;
}return modelStatisticsOverview;
});

Clazz.newMeth(C$, 'evaluate$D$D',  function (histMin, histMax) {
if (Math.abs(histMin - histMax) < 1.0E-8 ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Equal histogram boundaries! histMin " + new Double(histMin).toString() + " histMax" + new Double(histMax).toString() + "." ]);
}p$1.calculateMedianStatistics.apply(this, []);
var arr=this.data.get$();
this.min=$I$(6).min$DA(arr);
this.mean=$I$(6).getMean$DA(arr);
this.max=$I$(6).max$DA(arr);
this.sdv=$I$(6).getStandardDeviation$DA(arr);
var maBins=$I$(7).getHistogramBins$D$D$I(histMin, histMax, this.bins);
var ma=Clazz.new_($I$(8,1).c$$Z$DA,[true, arr]);
this.histogram=$I$(7).getHistogram$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(ma, maBins);
for (var i=0; i < ma.cols$(); i++) {
if (ma.get$I$I(0, i) < histMin ) ++this.valsBelowHistMin;
 else if (ma.get$I$I(0, i) > histMax ) ++this.valsAboveHistMax;
}
this.evaluated=true;
});

Clazz.newMeth(C$, 'evaluateIntegerBins$D$D',  function (histMin, histMax) {
p$1.calculateMedianStatistics.apply(this, []);
var ma=Clazz.new_([true, this.data.get$()],$I$(8,1).c$$Z$DA);
this.mean=ma.getMean$();
this.sdv=ma.getStandardDeviation$();
var arrBins=$I$(9,"getBinsEquallyDistributed$I$I$I",[this.bins, (histMin|0), (histMax|0)]);
var maBins=Clazz.new_($I$(8,1).c$$IAA,[arrBins]);
maBins=maBins.getTranspose$();
this.histogram=$I$(7).getHistogram$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(ma, maBins);
for (var i=0; i < ma.cols$(); i++) {
if (ma.get$I$I(0, i) < histMin ) ++this.valsBelowHistMin;
 else if (ma.get$I$I(0, i) > histMax ) ++this.valsAboveHistMax;
}
this.evaluated=true;
});

Clazz.newMeth(C$, 'calculateMedianStatistics',  function () {
var arr=this.data.get$();
$I$(10).sort$DA(arr);
this.percentile05=C$.getQuartile$DA$D(arr, 0.05);
this.leftQuartile=C$.getQuartile$DA$D(arr, 0.25);
this.median=C$.getQuartile$DA$D(arr, 0.5);
this.rightQuartile=C$.getQuartile$DA$D(arr, 0.75);
this.percentile95=C$.getQuartile$DA$D(arr, 0.95);
return this.median;
}, p$1);

Clazz.newMeth(C$, 'getPercentile05$',  function () {
return this.percentile05;
});

Clazz.newMeth(C$, 'getPercentile95$',  function () {
return this.percentile95;
});

Clazz.newMeth(C$, 'getQuartile$DA$D',  function (arr, q) {
var v=0;
if (q < 0 ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Negative values are not allowed!"]);
}if (arr.length % 2 == 0) {
if ((((q * arr.length)|0)) == 0) {
v=arr[0];
} else {
var p1=(((q * arr.length) - 1)|0);
var p2=((q * arr.length)|0);
v=(arr[p1] + arr[p2]) / 2.0;
}} else {
var p=((arr.length * q)|0);
v=arr[p];
}return v;
}, 1);

Clazz.newMeth(C$, 'getQuartile$D',  function (q) {
var arr=this.data.get$();
$I$(10).sort$DA(arr);
return C$.getQuartile$DA$D(arr, q);
});

Clazz.newMeth(C$, 'getNumData$',  function () {
return this.data.size$();
});

Clazz.newMeth(C$, 'toString',  function () {
if (this.data.size$() == 0) {
return "";
}if (!this.evaluated) this.evaluate$();
var sb=Clazz.new_($I$(11,1));
sb.append$S("Name\t" + this.name);
sb.append$S("\n");
sb.append$S("Values\t" + this.data.size$());
sb.append$S("\n");
sb.append$S("min\t" + new Double(this.min).toString());
sb.append$S("\n");
sb.append$S("Mean\t" + C$.DF3Plus.format$D(this.mean));
sb.append$S("\n");
sb.append$S("max\t" + new Double(this.max).toString());
sb.append$S("\n");
sb.append$S("SDV\t" + C$.DF3Plus.format$D(this.sdv));
sb.append$S("\n");
sb.append$S("Quartile 0.25\t" + C$.DF3Plus.format$D(this.leftQuartile));
sb.append$S("\n");
sb.append$S("Median\t" + C$.DF3Plus.format$D(this.median));
sb.append$S("\n");
sb.append$S("Quartile 0.75\t" + C$.DF3Plus.format$D(this.rightQuartile));
sb.append$S("\n");
sb.append$S("Histogram values below hist min " + this.valsBelowHistMin + ", values above hist max " + this.valsAboveHistMax );
sb.append$S("\n");
sb.append$S($I$(7).histogram2String$com_actelion_research_calc_Matrix$I$I(this.histogram, 2, 8));
var histTrans=this.histogram.getTranspose$();
var dfBins=$I$(8).format$I(2);
sb.append$S("\n");
for (var i=0; i < histTrans.rows$(); i++) {
sb.append$S($I$(8,"format$D$java_text_DecimalFormat$I",[histTrans.get$I$I(i, 0), dfBins, 8]));
sb.append$S("\t");
sb.append$S($I$(8,"format$D$java_text_DecimalFormat$I",[histTrans.get$I$I(i, 1), dfBins, 8]));
sb.append$S("\t");
sb.append$S($I$(8,"format$D$java_text_DecimalFormat$I",[histTrans.get$I$I(i, 2), dfBins, 8]));
sb.append$S("\n");
}
return sb.toString();
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz.newMeth(C$, 'setName$S',  function (name) {
this.name=name;
});

Clazz.newMeth(C$, 'setBins$I',  function (bins) {
this.bins=bins;
});

Clazz.newMeth(C$, 'getValsBelowHistMin$',  function () {
return this.valsBelowHistMin;
});

Clazz.newMeth(C$, 'getValsAboveHistMax$',  function () {
return this.valsAboveHistMax;
});

Clazz.newMeth(C$, 'getHistogram$',  function () {
return this.histogram;
});

Clazz.newMeth(C$, 'get$com_actelion_research_util_datamodel_DoubleArray',  function (da) {
var statisticsOverview=Clazz.new_(C$.c$$com_actelion_research_util_datamodel_DoubleArray,[da]);
return statisticsOverview.evaluate$();
}, 1);

Clazz.newMeth(C$, 'getMedianOverview$com_actelion_research_util_datamodel_DoubleArray',  function (da) {
var statisticsOverview=Clazz.new_(C$.c$$com_actelion_research_util_datamodel_DoubleArray,[da]);
statisticsOverview.evaluate$();
var model=Clazz.new_($I$(12,1).c$$D$D$D$D$D,[statisticsOverview.percentile05, statisticsOverview.leftQuartile, statisticsOverview.median, statisticsOverview.rightQuartile, statisticsOverview.percentile95]);
return model;
}, 1);

Clazz.newMeth(C$, 'toString$com_actelion_research_util_datamodel_DoubleArray$S',  function (da, text1) {
var sb=Clazz.new_($I$(11,1));
var so=Clazz.new_(C$.c$$com_actelion_research_util_datamodel_DoubleArray,[da]);
so.evaluate$();
sb.append$S(text1);
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getMean$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getSdv$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getMedian$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getPercentile05$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getPercentile95$()));
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$com_actelion_research_util_datamodel_IntArray$S',  function (ia, text) {
var sb=Clazz.new_($I$(11,1));
var da=Clazz.new_($I$(4,1).c$$com_actelion_research_util_datamodel_IntArray,[ia]);
var so=Clazz.new_(C$.c$$com_actelion_research_util_datamodel_DoubleArray,[da]);
so.evaluate$();
sb.append$S(text);
sb.append$S("\t");
sb.append$S(C$.DF1.format$D(so.getMean$()));
sb.append$S("\t");
sb.append$S(C$.DF1.format$D(so.getSdv$()));
sb.append$S("\t");
sb.append$S(C$.DF1.format$D(so.getMedian$()));
sb.append$S("\t");
sb.append$S(C$.DF1.format$D(so.getPercentile05$()));
sb.append$S("\t");
sb.append$S(C$.DF1.format$D(so.getPercentile95$()));
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toStringHeader$',  function () {
var sb=Clazz.new_($I$(11,1));
sb.append$S("text");
sb.append$S("\t");
sb.append$S("mean");
sb.append$S("\t");
sb.append$S("sdv");
sb.append$S("\t");
sb.append$S("median");
sb.append$S("\t");
sb.append$S("perc05");
sb.append$S("\t");
sb.append$S("perc95");
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$com_actelion_research_util_datamodel_DoubleArray$S$S',  function (da, text1, text2) {
var sb=Clazz.new_($I$(11,1));
var so=Clazz.new_(C$.c$$com_actelion_research_util_datamodel_DoubleArray,[da]);
so.evaluate$();
sb.append$S(text1);
sb.append$S("\t");
sb.append$S(text2);
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getMean$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getSdv$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getMedian$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getPercentile05$()));
sb.append$S("\t");
sb.append$S(C$.DF3.format$D(so.getPercentile95$()));
return sb.toString();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.DF1=Clazz.new_(["0.0", Clazz.new_([$I$(3).US],$I$(2,1).c$$java_util_Locale)],$I$(1,1).c$$S$java_text_DecimalFormatSymbols);
C$.DF3=Clazz.new_(["0.000", Clazz.new_([$I$(3).US],$I$(2,1).c$$java_util_Locale)],$I$(1,1).c$$S$java_text_DecimalFormatSymbols);
C$.DF4=Clazz.new_(["0.0000", Clazz.new_([$I$(3).US],$I$(2,1).c$$java_util_Locale)],$I$(1,1).c$$S$java_text_DecimalFormatSymbols);
C$.DF3Plus=Clazz.new_(["0.000##", Clazz.new_([$I$(3).US],$I$(2,1).c$$java_util_Locale)],$I$(1,1).c$$S$java_text_DecimalFormatSymbols);
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:13 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
