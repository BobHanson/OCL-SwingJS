(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Cache", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['head_t',18]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['l'],'J',['size'],'O',['head','com.actelion.research.calc.regression.svm.Cache.head_t[]','lru_head','com.actelion.research.calc.regression.svm.Cache.head_t']]]

Clazz.newMeth(C$, 'c$$I$J',  function (l_, size_) {
;C$.$init$.apply(this);
this.l=l_;
this.size=size_;
this.head=Clazz.array($I$(1), [this.l]);
for (var i=0; i < this.l; i++) this.head[i]=Clazz.new_($I$(1,1),[this, null]);

(this.size=Long.$div(this.size,(4)));
(this.size=Long.$sub(this.size,(this.l * (4))));
this.size=Math.max$J$J(this.size, Long.$mul(2,this.l));
this.lru_head=Clazz.new_($I$(1,1),[this, null]);
this.lru_head.next=this.lru_head.prev=this.lru_head;
}, 1);

Clazz.newMeth(C$, 'lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t',  function (h) {
h.prev.next=h.next;
h.next.prev=h.prev;
}, p$1);

Clazz.newMeth(C$, 'lru_insert$com_actelion_research_calc_regression_svm_Cache_head_t',  function (h) {
h.next=this.lru_head;
h.prev=this.lru_head.prev;
h.prev.next=h;
h.next.prev=h;
}, p$1);

Clazz.newMeth(C$, 'get_data$I$FAA$I',  function (index, data, len) {
var h=this.head[index];
if (h.len > 0) p$1.lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [h]);
var more=len - h.len;
if (more > 0) {
while (Long.$lt(this.size,more )){
var old=this.lru_head.next;
p$1.lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [old]);
(this.size=Long.$add(this.size,(old.len)));
old.data=null;
old.len=0;
}
var new_data=Clazz.array(Float.TYPE, [len]);
if (h.data != null ) System.arraycopy$O$I$O$I$I(h.data, 0, new_data, 0, h.len);
h.data=new_data;
(this.size=Long.$sub(this.size,(more)));
do {
var tmp=h.len;
h.len=len;
len=tmp;
} while (false);
}p$1.lru_insert$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [h]);
data[0]=h.data;
return len;
});

Clazz.newMeth(C$, 'swap_index$I$I',  function (i, j) {
if (i == j) return;
if (this.head[i].len > 0) p$1.lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [this.head[i]]);
if (this.head[j].len > 0) p$1.lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [this.head[j]]);
do {
var tmp=this.head[i].data;
this.head[i].data=this.head[j].data;
this.head[j].data=tmp;
} while (false);
do {
var tmp=this.head[i].len;
this.head[i].len=this.head[j].len;
this.head[j].len=tmp;
} while (false);
if (this.head[i].len > 0) p$1.lru_insert$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [this.head[i]]);
if (this.head[j].len > 0) p$1.lru_insert$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [this.head[j]]);
if (i > j) do {
var tmp=i;
i=j;
j=tmp;
} while (false);
for (var h=this.lru_head.next; h !== this.lru_head ; h=h.next) {
if (h.len > i) {
if (h.len > j) do {
var tmp=h.data[i];
h.data[i]=h.data[j];
h.data[j]=tmp;
} while (false);
 else {
p$1.lru_delete$com_actelion_research_calc_regression_svm_Cache_head_t.apply(this, [h]);
(this.size=Long.$add(this.size,(h.len)));
h.data=null;
h.len=0;
}}}
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.Cache, "head_t", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['len'],'O',['prev','com.actelion.research.calc.regression.svm.Cache.head_t','+next','data','float[]']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:13 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
