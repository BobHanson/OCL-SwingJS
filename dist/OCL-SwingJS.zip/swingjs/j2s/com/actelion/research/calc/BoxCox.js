(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'com.actelion.research.calc.Matrix','java.text.DecimalFormat','com.actelion.research.util.ArrayUtils']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BoxCox");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['zero'],'D',['lambda']]]

Clazz.newMeth(C$, 'c$$D',  function (lambda) {
;C$.$init$.apply(this);
this.setLambda$D(lambda);
}, 1);

Clazz.newMeth(C$, 'setLambda$D',  function (lambda) {
this.lambda=lambda;
if (lambda < 1.0E-7 ) {
this.zero=true;
} else {
this.zero=false;
}});

Clazz.newMeth(C$, 'get$D',  function (val) {
var r=0;
var negative=false;
if (val < 0 ) {
val*=-1;
negative=true;
}if (this.zero) {
r=Math.log(val);
} else {
r=(Math.pow(val, this.lambda) - 1.0) / this.lambda;
}if (negative) {
r*=-1;
}return r;
});

Clazz.newMeth(C$, 'inverse$D',  function (v) {
var negative=false;
if (v < 0 ) {
v*=-1;
negative=true;
}var r=0;
if (this.zero) {
r=Math.exp(r);
} else {
r=Math.pow(((v * this.lambda) + 1), 1 / this.lambda);
if (negative) {
r*=-1;
}}return r;
});

Clazz.newMeth(C$, 'getLambda$',  function () {
return this.lambda;
});

Clazz.newMeth(C$, 'transform$com_actelion_research_calc_Matrix$com_actelion_research_calc_BoxCox',  function (A, boxCox) {
var rows=A.rows$();
var cols=A.cols$();
var B=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
var v=A.get$I$I(i, j);
var bc=boxCox.get$D(v);
B.set$I$I$D(i, j, bc);
}
}
return B;
}, 1);

Clazz.newMeth(C$, 'reTransform$com_actelion_research_calc_Matrix$com_actelion_research_calc_BoxCox',  function (A, boxCox) {
var rows=A.rows$();
var cols=A.cols$();
var B=Clazz.new_($I$(1,1).c$$I$I,[rows, cols]);
for (var i=0; i < rows; i++) {
for (var j=0; j < cols; j++) {
var v=A.get$I$I(i, j);
var bc=boxCox.inverse$D(v);
B.set$I$I$D(i, j, bc);
}
}
return B;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.test01$();
}, 1);

Clazz.newMeth(C$, 'test01$',  function () {
var arr=Clazz.array(Double.TYPE, -1, [-64, -32, -16, -8, -4, -2, -1, 0, 1, 2, 4, 8, 16, 32, 64]);
var lambdaStart=-3;
var lambdaEnd=3;
var step=0.1;
var df=Clazz.new_($I$(2,1).c$$S,["0.000"]);
var dfLambda=Clazz.new_($I$(2,1).c$$S,["0.00"]);
for (var lambda=lambdaStart; lambda < lambdaEnd + step ; lambda+=step) {
var boxCox=Clazz.new_(C$.c$$D,[lambda]);
var arrTrans=Clazz.array(Double.TYPE, [arr.length]);
var arrReTrans=Clazz.array(Double.TYPE, [arr.length]);
for (var i=0; i < arr.length; i++) {
arrTrans[i]=boxCox.get$D(arr[i]);
arrReTrans[i]=boxCox.inverse$D(arrTrans[i]);
}
System.out.println$S(dfLambda.format$D(lambda) + "\t" + $I$(3).toString$DA$java_text_DecimalFormat(arrTrans, df) );
System.out.println$S(dfLambda.format$D(lambda) + "\t" + $I$(3).toString$DA$java_text_DecimalFormat(arrReTrans, df) );
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:45 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
