(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},I$=[[0,'com.actelion.research.calc.regression.svm.SVMParameterHelper','org.machinelearning.svm.libsvm.svm_parameter','java.util.Arrays','java.text.DecimalFormat','StringBuilder','com.actelion.research.calc.regression.ParameterRegressionMethod']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterSVM", null, 'com.actelion.research.calc.regression.ParameterRegressionMethod');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['gamma','coef0','cache_size','eps','C','nu','p'],'I',['svmType','kernelType','degree','nr_weight','shrinking','probability'],'O',['weight_label','int[]','weight','double[]']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$org_machinelearning_svm_libsvm_svm_parameter.apply(this, [$I$(1).regressionEpsilonSVR$()]);
p$1.initializeProperties.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$D',  function (nu) {
C$.c$$org_machinelearning_svm_libsvm_svm_parameter.apply(this, [$I$(1).standard$()]);
this.setNu$D(nu);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_svm_ParameterSVM',  function (parameterSVM) {
;C$.superclazz.c$$S.apply(this,["SVM regression"]);C$.$init$.apply(this);
this.svmType=parameterSVM.svmType;
this.kernelType=parameterSVM.kernelType;
this.degree=parameterSVM.degree;
this.gamma=parameterSVM.gamma;
this.coef0=parameterSVM.coef0;
this.cache_size=parameterSVM.cache_size;
this.eps=parameterSVM.eps;
this.C=parameterSVM.C;
this.nr_weight=parameterSVM.nr_weight;
this.weight_label=parameterSVM.weight_label;
this.weight=parameterSVM.weight;
this.nu=parameterSVM.nu;
this.p=parameterSVM.p;
this.shrinking=parameterSVM.shrinking;
this.probability=parameterSVM.probability;
p$1.initializeProperties.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$org_machinelearning_svm_libsvm_svm_parameter',  function (svmParameter) {
;C$.superclazz.c$$S.apply(this,["SVM regression"]);C$.$init$.apply(this);
this.svmType=svmParameter.svm_type;
this.kernelType=svmParameter.kernel_type;
this.degree=svmParameter.degree;
this.gamma=svmParameter.gamma;
this.coef0=svmParameter.coef0;
this.cache_size=svmParameter.cache_size;
this.eps=svmParameter.eps;
this.C=svmParameter.C;
this.nr_weight=svmParameter.nr_weight;
this.weight_label=svmParameter.weight_label;
this.weight=svmParameter.weight;
this.nu=svmParameter.nu;
this.p=svmParameter.p;
this.shrinking=svmParameter.shrinking;
this.probability=svmParameter.probability;
p$1.initializeProperties.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initializeProperties',  function () {
if (this.svmType != 3) {
System.out.println$S("Error: only Epsilon support vector regression possible!");
System.out.println$S("Error: opsilon support vector regression possible!");
System.out.println$S("Error: opsilon support vector regression possible!");
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only Epsilon support vector regression possible!"]);
}this.setSVMRegressionType$I(this.svmType);
this.setKernelType$I(this.kernelType);
this.setEpsilon$D(this.eps);
this.setC$D(this.C);
this.setGamma$D(this.gamma);
}, p$1);

Clazz.newMeth(C$, 'getSvmParameter$',  function () {
var svmParameter=Clazz.new_($I$(2,1));
svmParameter.svm_type=this.svmType;
svmParameter.kernel_type=this.kernelType;
svmParameter.degree=this.degree;
svmParameter.gamma=this.gamma;
svmParameter.coef0=this.coef0;
svmParameter.cache_size=this.cache_size;
svmParameter.eps=this.eps;
svmParameter.C=this.C;
svmParameter.nr_weight=this.nr_weight;
svmParameter.weight_label=this.weight_label;
svmParameter.weight=this.weight;
svmParameter.nu=this.nu;
svmParameter.p=this.p;
svmParameter.shrinking=this.shrinking;
svmParameter.probability=this.probability;
return svmParameter;
});

Clazz.newMeth(C$, 'c$$S',  function (nameRegressionMethod) {
;C$.superclazz.c$$S.apply(this,[nameRegressionMethod]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getGamma$',  function () {
return this.gamma;
});

Clazz.newMeth(C$, 'getNu$',  function () {
return this.nu;
});

Clazz.newMeth(C$, 'setGamma$D',  function (gamma) {
this.gamma=gamma;
this.properties.put$O$O("Gamma", Double.toString$D(gamma));
});

Clazz.newMeth(C$, 'setNu$D',  function (nu) {
this.nu=nu;
this.properties.put$O$O("Nu", Double.toString$D(nu));
});

Clazz.newMeth(C$, 'setSVMRegressionType$I',  function (svmType) {
if (svmType != 3) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only Epsilon support vector regression possible!"]);
}this.svmType=svmType;
this.properties.put$O$O("SVMRegressionType", Integer.toString$I(svmType));
});

Clazz.newMeth(C$, 'setEpsilon$D',  function (eps) {
this.eps=eps;
this.properties.put$O$O("Epsilon", Double.toString$D(eps));
});

Clazz.newMeth(C$, 'setKernelType$I',  function (kernelType) {
this.kernelType=kernelType;
this.properties.put$O$O("Kernel", Integer.toString$I(kernelType));
});

Clazz.newMeth(C$, 'setC$D',  function (C) {
this.C=C;
this.properties.put$O$O("C", Double.toString$D(C));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod','compareTo$O'],  function (o) {
var cmp=0;
var parameterSVM=o;
if (this.svmType > parameterSVM.svmType) {
cmp=1;
} else if (this.svmType < parameterSVM.svmType) {
cmp=-1;
}if (cmp == 0) {
if (this.kernelType > parameterSVM.kernelType) {
cmp=1;
} else if (this.kernelType < parameterSVM.kernelType) {
cmp=-1;
}}if (cmp == 0) {
if (this.degree > parameterSVM.degree) {
cmp=1;
} else if (this.degree < parameterSVM.degree) {
cmp=-1;
}}if (cmp == 0) {
if (this.gamma > parameterSVM.gamma ) {
cmp=1;
} else if (this.gamma < parameterSVM.gamma ) {
cmp=-1;
}}if (cmp == 0) {
if (this.nu > parameterSVM.nu ) {
cmp=1;
} else if (this.nu < parameterSVM.nu ) {
cmp=-1;
}}if (cmp == 0) {
if (this.C > parameterSVM.C ) {
cmp=1;
} else if (this.C < parameterSVM.C ) {
cmp=-1;
}}if (cmp == 0) {
if (this.eps > parameterSVM.eps ) {
cmp=1;
} else if (this.eps < parameterSVM.eps ) {
cmp=-1;
}}return cmp;
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var eq=C$.superclazz.prototype.equals$O.apply(this, [obj]);
if (!eq) {
return false;
}if (!(Clazz.instanceOf(obj, "com.actelion.research.calc.regression.svm.ParameterSVM"))) {
return false;
}var parameter=obj;
if (this.nr_weight != parameter.nr_weight) {
return false;
} else if (Math.abs(this.nr_weight - parameter.nr_weight) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.gamma - parameter.gamma) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.eps - parameter.eps) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.C - parameter.C) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.nu - parameter.nu) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.cache_size - parameter.cache_size) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.coef0 - parameter.coef0) > 1.0E-8 ) {
return false;
} else if (Math.abs(this.p - parameter.p) > 1.0E-8 ) {
return false;
} else if (this.svmType != parameter.svmType) {
return false;
} else if (this.degree != parameter.degree) {
return false;
} else if (this.kernelType != parameter.kernelType) {
return false;
} else if (this.probability != parameter.probability) {
return false;
} else if (this.shrinking != parameter.shrinking) {
return false;
} else if (!$I$(3).equals$DA$DA(this.weight, parameter.weight)) {
return false;
} else if (!$I$(3).equals$IA$IA(this.weight_label, parameter.weight_label)) {
return false;
}return eq;
});

Clazz.newMeth(C$, 'decodeProperties2Parameter$',  function () {
this.svmType=Integer.parseInt$S(this.properties.getProperty$S("SVMRegressionType"));
this.kernelType=Integer.parseInt$S(this.properties.getProperty$S("Kernel"));
this.C=Double.parseDouble$S(this.properties.getProperty$S("C"));
this.gamma=Double.parseDouble$S(this.properties.getProperty$S("Gamma"));
this.eps=Double.parseDouble$S(this.properties.getProperty$S("Epsilon"));
});

Clazz.newMeth(C$, 'toString',  function () {
var df=Clazz.new_($I$(4,1).c$$S,["0.0###"]);
var sb=Clazz.new_($I$(5,1).c$$S,["ParameterSVM{"]);
sb.append$S("name=").append$S(this.getName$());
sb.append$S(" svm type=").append$S($I$(1).getSVMType$I(this.svmType));
sb.append$S(" kernel_type=").append$S($I$(1).getKernelType$I(this.kernelType));
sb.append$S(" degree=").append$I(this.degree);
sb.append$S(" gamma=").append$S(df.format$D(this.gamma));
sb.append$S(" coef0=").append$S(df.format$D(this.coef0));
sb.append$S(" cache_size=").append$S(df.format$D(this.cache_size));
sb.append$S(" eps=").append$S(df.format$D(this.eps));
sb.append$S(" C=").append$S(df.format$D(this.C));
sb.append$S(" nr_weight=").append$I(this.nr_weight);
sb.append$S(" nu=").append$S(df.format$D(this.nu));
sb.append$S(" p=").append$S(df.format$D(this.p));
sb.append$S(" shrinking=").append$I(this.shrinking);
sb.append$S(" probability=").append$I(this.probability);
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=$I$(6).getHeader$();
li.add$O("SVMRegressionType");
li.add$O("Kernel");
li.add$O("Degree");
li.add$O("Gamma");
li.add$O("Coef0");
li.add$O("CacheSize");
li.add$O("Epsilon");
li.add$O("C");
li.add$O("nrWeight");
li.add$O("Nu");
li.add$O("p");
li.add$O("Shrinking");
li.add$O("Probability");
return li;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
