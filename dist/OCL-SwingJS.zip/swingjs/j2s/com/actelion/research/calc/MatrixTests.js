(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'com.actelion.research.util.datamodel.ModelXY','com.actelion.research.calc.Matrix','java.util.Random','com.actelion.research.calc.regression.linear.pls.SimPLS','com.actelion.research.util.IO','com.actelion.research.calc.MatrixFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatrixTests");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getMultivariate$I$I',  function (rows, cols) {
var modelXY=Clazz.new_($I$(1,1));
var X=Clazz.new_($I$(2,1).c$$I$I,[rows, cols]);
var Y=Clazz.new_($I$(2,1).c$$I$I,[rows, 1]);
var max=10;
var rnd=Clazz.new_($I$(3,1));
for (var i=0; i < cols; i++) {
for (var j=0; j < rows; j++) {
var v=rnd.nextDouble$() * max;
X.set$I$I$D(j, i, v);
}
}
for (var i=0; i < rows; i++) {
var y=0;
for (var j=0; j < cols; j++) {
var v=X.get$I$I(i, j);
y+=v * (j + 1);
}
Y.set$I$I$D(i, 0, y);
}
modelXY.X=X;
modelXY.Y=Y;
return modelXY;
}, 1);

Clazz.newMeth(C$, 'test00$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1.001]), Clazz.array(Double.TYPE, -1, [1.002]), Clazz.array(Double.TYPE, -1, [1.003]), Clazz.array(Double.TYPE, -1, [1.004])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test01$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1.004]), Clazz.array(Double.TYPE, -1, [1.003]), Clazz.array(Double.TYPE, -1, [1.002]), Clazz.array(Double.TYPE, -1, [1.001])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test02$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 3, 4]), Clazz.array(Double.TYPE, -1, [2, 3, 4]), Clazz.array(Double.TYPE, -1, [3, 3, 2]), Clazz.array(Double.TYPE, -1, [4, 3, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test03$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test04$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [2, 20, 2, 2]), Clazz.array(Double.TYPE, -1, [2, 20, 2, 2]), Clazz.array(Double.TYPE, -1, [3, 30, 3, 3]), Clazz.array(Double.TYPE, -1, [3, 30, 3, 3]), Clazz.array(Double.TYPE, -1, [4, 40, 40, 4]), Clazz.array(Double.TYPE, -1, [4, 40, 40, 4])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test05$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [1, 2, 1, 1]), Clazz.array(Double.TYPE, -1, [1, 3, 1, 1]), Clazz.array(Double.TYPE, -1, [1, 4, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 5, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 6, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 7, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 8, 1, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test06$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test07$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'test08$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 1, 1, 0]), Clazz.array(Double.TYPE, -1, [1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 0, 0]), Clazz.array(Double.TYPE, -1, [0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 0]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 1, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testMatrix02$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [16, 2, 3, 13]), Clazz.array(Double.TYPE, -1, [5, 11, 10, 8]), Clazz.array(Double.TYPE, -1, [9, 7, 6, 12]), Clazz.array(Double.TYPE, -1, [4, 14, 15, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testMatrix_YWine$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [14, 7, 8]), Clazz.array(Double.TYPE, -1, [10, 7, 6]), Clazz.array(Double.TYPE, -1, [8, 5, 5]), Clazz.array(Double.TYPE, -1, [2, 4, 7]), Clazz.array(Double.TYPE, -1, [6, 2, 4])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testMatrix_XWine$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [7, 7, 13, 7]), Clazz.array(Double.TYPE, -1, [4, 3, 14, 7]), Clazz.array(Double.TYPE, -1, [10, 5, 12, 5]), Clazz.array(Double.TYPE, -1, [16, 7, 11, 3]), Clazz.array(Double.TYPE, -1, [13, 3, 10, 3])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testMatrixHenrion01$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [4, 0]), Clazz.array(Double.TYPE, -1, [0, 8]), Clazz.array(Double.TYPE, -1, [4, 4]), Clazz.array(Double.TYPE, -1, [2, 0]), Clazz.array(Double.TYPE, -1, [0, 8])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testLonglyY$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [60323]), Clazz.array(Double.TYPE, -1, [61122]), Clazz.array(Double.TYPE, -1, [60171]), Clazz.array(Double.TYPE, -1, [61187]), Clazz.array(Double.TYPE, -1, [63221]), Clazz.array(Double.TYPE, -1, [63639]), Clazz.array(Double.TYPE, -1, [64989]), Clazz.array(Double.TYPE, -1, [63761]), Clazz.array(Double.TYPE, -1, [66019]), Clazz.array(Double.TYPE, -1, [67857]), Clazz.array(Double.TYPE, -1, [68169]), Clazz.array(Double.TYPE, -1, [66513]), Clazz.array(Double.TYPE, -1, [68655]), Clazz.array(Double.TYPE, -1, [69564]), Clazz.array(Double.TYPE, -1, [69331]), Clazz.array(Double.TYPE, -1, [70551])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testLonglyX$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [83, 234289, 2356, 1590, 107608, 1947]), Clazz.array(Double.TYPE, -1, [88.5, 259426, 2325, 1456, 108632, 1948]), Clazz.array(Double.TYPE, -1, [88.2, 258054, 3682, 1616, 109773, 1949]), Clazz.array(Double.TYPE, -1, [89.5, 284599, 3351, 1650, 110929, 1950]), Clazz.array(Double.TYPE, -1, [96.2, 328975, 2099, 3099, 112075, 1951]), Clazz.array(Double.TYPE, -1, [98.1, 346999, 1932, 3594, 113270, 1952]), Clazz.array(Double.TYPE, -1, [99, 365385, 1870, 3547, 115094, 1953]), Clazz.array(Double.TYPE, -1, [100, 363112, 3578, 3350, 116219, 1954]), Clazz.array(Double.TYPE, -1, [101.2, 397469, 2904, 3048, 117388, 1955]), Clazz.array(Double.TYPE, -1, [104.6, 419180, 2822, 2857, 118734, 1956]), Clazz.array(Double.TYPE, -1, [108.4, 442769, 2936, 2798, 120445, 1957]), Clazz.array(Double.TYPE, -1, [110.8, 444546, 4681, 2637, 121950, 1958]), Clazz.array(Double.TYPE, -1, [112.6, 482704, 3813, 2552, 123366, 1959]), Clazz.array(Double.TYPE, -1, [114.2, 502601, 3931, 2514, 125368, 1960]), Clazz.array(Double.TYPE, -1, [115.7, 518173, 4806, 2572, 127852, 1961]), Clazz.array(Double.TYPE, -1, [116.9, 554894, 4007, 2827, 130081, 1962])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testDescriptor01X$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [0, 0, 0, 1, 1, 1]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0]), Clazz.array(Double.TYPE, -1, [1, 1, 1, 0, 0, 0])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testDescriptor01Y$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [1, 0]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1]), Clazz.array(Double.TYPE, -1, [0, 1])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testSimple1Y$',  function () {
var A=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [55]), Clazz.array(Double.TYPE, -1, [56]), Clazz.array(Double.TYPE, -1, [57]), Clazz.array(Double.TYPE, -1, [58]), Clazz.array(Double.TYPE, -1, [59]), Clazz.array(Double.TYPE, -1, [60]), Clazz.array(Double.TYPE, -1, [61]), Clazz.array(Double.TYPE, -1, [62])]);
var ma=Clazz.new_($I$(2,1).c$$DAA,[A]);
return ma;
}, 1);

Clazz.newMeth(C$, 'testSimple1X$I',  function (cols) {
var a=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [55]), Clazz.array(Double.TYPE, -1, [56]), Clazz.array(Double.TYPE, -1, [57]), Clazz.array(Double.TYPE, -1, [58]), Clazz.array(Double.TYPE, -1, [59]), Clazz.array(Double.TYPE, -1, [60]), Clazz.array(Double.TYPE, -1, [61]), Clazz.array(Double.TYPE, -1, [62])]);
var Xrnd=$I$(2).getRND$I$I(a.length, cols);
for (var i=0; i < a.length; i++) {
Xrnd.set$I$I$D(i, 0, a[i][0]);
}
return Xrnd;
}, 1);

Clazz.newMeth(C$, 'testSimple2X$I',  function (cols) {
var a=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [55, 0]), Clazz.array(Double.TYPE, -1, [56, 0]), Clazz.array(Double.TYPE, -1, [57, 0]), Clazz.array(Double.TYPE, -1, [58, 0]), Clazz.array(Double.TYPE, -1, [0, 59]), Clazz.array(Double.TYPE, -1, [0, 60]), Clazz.array(Double.TYPE, -1, [0, 61]), Clazz.array(Double.TYPE, -1, [0, 62])]);
var Xrnd=$I$(2).getRND$I$I(a.length, cols);
for (var i=0; i < a.length; i++) {
Xrnd.set$I$I$D(i, 0, a[i][0]);
Xrnd.set$I$I$D(i, 1, a[i][1]);
}
return Xrnd;
}, 1);

Clazz.newMeth(C$, 'checkForEigenvaluesAndEigenvectors$',  function () {
var bCheckOK=true;
var A=C$.testMatrix02$();
var AtA=A.multiply$Z$Z$com_actelion_research_calc_Matrix(true, false, A);
var d=Clazz.new_($I$(2,1).c$$I$I,[1, 1]);
var e=Clazz.new_($I$(2,1).c$$I$I,[1, 1]);
var EV=Clazz.new_([AtA.getArray$()],$I$(2,1).c$$DAA);
$I$(2,"getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix",[EV, EV.getColDim$(), d, e]);
var D=d.diagonalize$();
var C=EV.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, D);
var F=AtA.multiply$Z$Z$com_actelion_research_calc_Matrix(false, false, EV);
bCheckOK=C.equal$com_actelion_research_calc_Matrix$D(F, 1.0E-11);
return bCheckOK;
}, 1);

Clazz.newMeth(C$, 'pls$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$S$I$Z$S',  function (X, Y, sPatternHeaderX, iNumPrincipalComponents, bLogarithm, sFileDataSummaryOut) {
var R=null;
if (bLogarithm) X=X.log$();
var pls=Clazz.new_($I$(4,1));
var Xc=X.getCenteredMatrix$();
var Yc=Y.getCenteredMatrix$();
var sSummary="Xc(standardized):\r\n" + Xc + "\r\n\r\n" ;
sSummary+="Yc:\r\n" + Yc + "\r\n\r\n" ;
$I$(5).write$S$S$Z(sFileDataSummaryOut, sSummary, true);
pls.simPlsSave$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix$I(Xc, Yc, iNumPrincipalComponents);
var P=pls.getP$();
R=pls.getR$();
var U=pls.getU$();
var V=pls.getV$();
var Q=pls.getQ$();
var T=pls.getT$();
sSummary="Matrices from the PLS decomposition of the Training data.\r\n\r\n";
sSummary+="P:\r\n" + P + "\r\n\r\n" ;
sSummary+="R:\r\n" + R + "\r\n\r\n" ;
sSummary+="U:\r\n" + U + "\r\n\r\n" ;
sSummary+="V:\r\n" + V + "\r\n\r\n" ;
sSummary+="Q:\r\n" + Q + "\r\n\r\n" ;
sSummary+="T:\r\n" + T + "\r\n\r\n" ;
$I$(5).write$S$S$Z(sFileDataSummaryOut, sSummary, true);
return R;
}, 1);

Clazz.newMeth(C$, 'testMain01$',  function () {
var repeat=10;
var rowsA=1000;
var colsA=1000;
var colsB=100;
var n=10;
var X=$I$(6).getRandomMatrix$I$I(rowsA, colsA);
var Y=$I$(6).getRandomMatrix$I$I(colsA, colsB);
var Eleft=Clazz.new_($I$(2,1).c$$com_actelion_research_calc_Matrix,[X]);
var Eright=Clazz.new_($I$(2,1));
var D=Clazz.new_($I$(2,1));
var dateStart=Clazz.new_(java.util.Date);
$I$(2).getEigenvector$com_actelion_research_calc_Matrix$I$com_actelion_research_calc_Matrix$com_actelion_research_calc_Matrix(Eleft, n, D, Eright);
var dateEnd=Clazz.new_(java.util.Date);
var delta=Long.$sub(dateEnd.getTime$(),dateStart.getTime$());
System.out.println$S("Time: " + Long.$s(delta));
}, 1);

Clazz.newMeth(C$, 'testMainHenrion$',  function () {
var X=C$.testMatrixHenrion01$();
var Xc=X.getCenteredMatrix$();
System.out.println$O(Xc);
var Xstand=X.getStandardDeviationCols$();
System.out.println$O(Xstand);
var Xs=X.getStandardized$();
System.out.println$O(Xs);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
