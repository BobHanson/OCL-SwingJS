(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.svm"),p$1={},p$2={},p$3={},I$=[[0,['com.actelion.research.calc.regression.svm.Cache','.head_t'],'com.actelion.research.calc.regression.svm.svm','com.actelion.research.calc.regression.svm.Cache','java.util.Random','com.actelion.research.calc.regression.svm.Solver','com.actelion.research.calc.regression.svm.SVC_Q','com.actelion.research.calc.regression.svm.Solver_NU','com.actelion.research.calc.regression.svm.ONE_CLASS_Q','com.actelion.research.calc.regression.svm.SVR_Q',['com.actelion.research.calc.regression.svm.Solver','.SolutionInfo'],['com.actelion.research.calc.regression.svm.svm','.decision_function'],'org.machinelearning.svm.libsvm.svm_problem','org.machinelearning.svm.libsvm.svm_node','org.machinelearning.svm.libsvm.svm_model','com.actelion.research.calc.regression.svm.Kernel','java.io.DataOutputStream','java.io.BufferedOutputStream','java.io.FileOutputStream','org.machinelearning.svm.libsvm.svm_parameter','java.util.StringTokenizer','java.io.BufferedReader','java.io.FileReader']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "svm", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['decision_function',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['rand','java.util.Random','svm_print_stdout','org.machinelearning.svm.libsvm.svm_print_interface','+svm_print_string','svm_type_table','String[]','+kernel_type_table']]]

Clazz.newMeth(C$, 'info$S',  function (s) {
C$.svm_print_string.print$S(s);
}, 1);

Clazz.newMeth(C$, 'solve_c_svc$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$D$D$com_actelion_research_calc_ProgressController',  function (prob, param, alpha, si, Cp, Cn, pg) {
var l=prob.l;
var minus_ones=Clazz.array(Double.TYPE, [l]);
var y=Clazz.array(Byte.TYPE, [l]);
var i;
for (i=0; i < l; i++) {
alpha[i]=0;
minus_ones[i]=-1;
if (prob.y[i] > 0 ) y[i]=(1|0);
 else y[i]=(-1|0);
}
var s=Clazz.new_($I$(5,1));
s.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController(l, Clazz.new_($I$(6,1).c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$BA,[prob, param, y]), minus_ones, y, alpha, Cp, Cn, param.eps, si, param.shrinking, pg);
var sum_alpha=0;
for (i=0; i < l; i++) sum_alpha+=alpha[i];

if (Cp == Cn ) C$.info$S("nu = " + new Double(sum_alpha / (Cp * prob.l)).toString() + "\n");
for (i=0; i < l; i++) alpha[i]*=y[i];

}, 1);

Clazz.newMeth(C$, 'solve_nu_svc$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController',  function (prob, param, alpha, si, pg) {
var i;
var l=prob.l;
var nu=param.nu;
var y=Clazz.array(Byte.TYPE, [l]);
for (i=0; i < l; i++) if (prob.y[i] > 0 ) y[i]=(1|0);
 else y[i]=(-1|0);

var sum_pos=nu * l / 2;
var sum_neg=nu * l / 2;
for (i=0; i < l; i++) if (y[i] == 1) {
alpha[i]=Math.min(1.0, sum_pos);
sum_pos-=alpha[i];
} else {
alpha[i]=Math.min(1.0, sum_neg);
sum_neg-=alpha[i];
}
var zeros=Clazz.array(Double.TYPE, [l]);
for (i=0; i < l; i++) zeros[i]=0;

var s=Clazz.new_($I$(7,1));
s.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController(l, Clazz.new_($I$(6,1).c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$BA,[prob, param, y]), zeros, y, alpha, 1.0, 1.0, param.eps, si, param.shrinking, pg);
var r=si.r;
C$.info$S("C = " + new Double(1 / r).toString() + "\n");
for (i=0; i < l; i++) alpha[i]*=y[i] / r;

si.rho/=r;
si.obj/=(r * r);
si.upper_bound_p=1 / r;
si.upper_bound_n=1 / r;
}, 1);

Clazz.newMeth(C$, 'solve_one_class$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController',  function (prob, param, alpha, si, pg) {
var l=prob.l;
var zeros=Clazz.array(Double.TYPE, [l]);
var ones=Clazz.array(Byte.TYPE, [l]);
var i;
var n=((param.nu * prob.l)|0);
for (i=0; i < n; i++) alpha[i]=1;

if (n < prob.l) alpha[n]=param.nu * prob.l - n;
for (i=n + 1; i < l; i++) alpha[i]=0;

for (i=0; i < l; i++) {
zeros[i]=0;
ones[i]=(1|0);
}
var s=Clazz.new_($I$(5,1));
s.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController(l, Clazz.new_($I$(8,1).c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter,[prob, param]), zeros, ones, alpha, 1.0, 1.0, param.eps, si, param.shrinking, pg);
}, 1);

Clazz.newMeth(C$, 'solve_epsilon_svr$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController',  function (prob, param, alpha, si, pg) {
var l=prob.l;
var alpha2=Clazz.array(Double.TYPE, [2 * l]);
var linear_term=Clazz.array(Double.TYPE, [2 * l]);
var y=Clazz.array(Byte.TYPE, [2 * l]);
var i;
for (i=0; i < l; i++) {
alpha2[i]=0;
linear_term[i]=param.p - prob.y[i];
y[i]=(1|0);
alpha2[i + l]=0;
linear_term[i + l]=param.p + prob.y[i];
y[i + l]=(-1|0);
}
var s=Clazz.new_($I$(5,1));
s.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController(2 * l, Clazz.new_($I$(9,1).c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter,[prob, param]), linear_term, y, alpha2, param.C, param.C, param.eps, si, param.shrinking, pg);
var sum_alpha=0;
for (i=0; i < l; i++) {
alpha[i]=alpha2[i] - alpha2[i + l];
sum_alpha+=Math.abs(alpha[i]);
}
C$.info$S("nu = " + new Double(sum_alpha / (param.C * l)).toString() + "\n");
}, 1);

Clazz.newMeth(C$, 'solve_nu_svr$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController',  function (prob, param, alpha, si, pg) {
var l=prob.l;
var C=param.C;
var alpha2=Clazz.array(Double.TYPE, [2 * l]);
var linear_term=Clazz.array(Double.TYPE, [2 * l]);
var y=Clazz.array(Byte.TYPE, [2 * l]);
var i;
var sum=C * param.nu * l  / 2;
for (i=0; i < l; i++) {
alpha2[i]=alpha2[i + l]=Math.min(sum, C);
sum-=alpha2[i];
linear_term[i]=-prob.y[i];
y[i]=(1|0);
linear_term[i + l]=prob.y[i];
y[i + l]=(-1|0);
}
var s=Clazz.new_($I$(7,1));
s.Solve$I$com_actelion_research_calc_regression_svm_QMatrix$DA$BA$DA$D$D$D$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$I$com_actelion_research_calc_ProgressController(2 * l, Clazz.new_($I$(9,1).c$$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter,[prob, param]), linear_term, y, alpha2, C, C, param.eps, si, param.shrinking, pg);
C$.info$S("epsilon = " + (new Double(-si.r).toString()) + "\n" );
for (i=0; i < l; i++) alpha[i]=alpha2[i] - alpha2[i + l];

}, 1);

Clazz.newMeth(C$, 'svm_train_one$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$D$D$com_actelion_research_calc_ProgressController',  function (prob, param, Cp, Cn, pg) {
var alpha=Clazz.array(Double.TYPE, [prob.l]);
var si=Clazz.new_($I$(10,1));
switch (param.svm_type) {
case 0:
C$.solve_c_svc$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$D$D$com_actelion_research_calc_ProgressController(prob, param, alpha, si, Cp, Cn, pg);
break;
case 1:
C$.solve_nu_svc$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController(prob, param, alpha, si, pg);
break;
case 2:
C$.solve_one_class$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController(prob, param, alpha, si, pg);
break;
case 3:
C$.solve_epsilon_svr$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController(prob, param, alpha, si, pg);
break;
case 4:
C$.solve_nu_svr$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$DA$com_actelion_research_calc_regression_svm_Solver_SolutionInfo$com_actelion_research_calc_ProgressController(prob, param, alpha, si, pg);
break;
}
C$.info$S("obj = " + new Double(si.obj).toString() + ", rho = " + new Double(si.rho).toString() + "\n" );
var nSV=0;
var nBSV=0;
for (var i=0; i < prob.l; i++) {
if (Math.abs(alpha[i]) > 0 ) {
++nSV;
if (prob.y[i] > 0 ) {
if (Math.abs(alpha[i]) >= si.upper_bound_p ) ++nBSV;
} else {
if (Math.abs(alpha[i]) >= si.upper_bound_n ) ++nBSV;
}}}
C$.info$S("nSV = " + nSV + ", nBSV = " + nBSV + "\n" );
var f=Clazz.new_($I$(11,1));
f.alpha=alpha;
f.rho=si.rho;
return f;
}, 1);

Clazz.newMeth(C$, 'sigmoid_train$I$DA$DA$DA',  function (l, dec_values, labels, probAB) {
var A;
var B;
var prior1=0;
var prior0=0;
var i;
for (i=0; i < l; i++) if (labels[i] > 0 ) prior1+=1;
 else prior0+=1;

var max_iter=100;
var min_step=1.0E-10;
var sigma=1.0E-12;
var eps=1.0E-5;
var hiTarget=(prior1 + 1.0) / (prior1 + 2.0);
var loTarget=1 / (prior0 + 2.0);
var t=Clazz.array(Double.TYPE, [l]);
var fApB;
var p;
var q;
var h11;
var h22;
var h21;
var g1;
var g2;
var det;
var dA;
var dB;
var gd;
var stepsize;
var newA;
var newB;
var newf;
var d1;
var d2;
var iter;
A=0.0;
B=Math.log((prior0 + 1.0) / (prior1 + 1.0));
var fval=0.0;
for (i=0; i < l; i++) {
if (labels[i] > 0 ) t[i]=hiTarget;
 else t[i]=loTarget;
fApB=dec_values[i] * A + B;
if (fApB >= 0 ) fval+=t[i] * fApB + Math.log(1 + Math.exp(-fApB));
 else fval+=(t[i] - 1) * fApB + Math.log(1 + Math.exp(fApB));
}
for (iter=0; iter < max_iter; iter++) {
h11=sigma;
h22=sigma;
h21=0.0;
g1=0.0;
g2=0.0;
for (i=0; i < l; i++) {
fApB=dec_values[i] * A + B;
if (fApB >= 0 ) {
p=Math.exp(-fApB) / (1.0 + Math.exp(-fApB));
q=1.0 / (1.0 + Math.exp(-fApB));
} else {
p=1.0 / (1.0 + Math.exp(fApB));
q=Math.exp(fApB) / (1.0 + Math.exp(fApB));
}d2=p * q;
h11+=dec_values[i] * dec_values[i] * d2 ;
h22+=d2;
h21+=dec_values[i] * d2;
d1=t[i] - p;
g1+=dec_values[i] * d1;
g2+=d1;
}
if (Math.abs(g1) < eps  && Math.abs(g2) < eps  ) break;
det=h11 * h22 - h21 * h21;
dA=-(h22 * g1 - h21 * g2) / det;
dB=-(-h21 * g1 + h11 * g2) / det;
gd=g1 * dA + g2 * dB;
stepsize=1;
while (stepsize >= min_step ){
newA=A + stepsize * dA;
newB=B + stepsize * dB;
newf=0.0;
for (i=0; i < l; i++) {
fApB=dec_values[i] * newA + newB;
if (fApB >= 0 ) newf+=t[i] * fApB + Math.log(1 + Math.exp(-fApB));
 else newf+=(t[i] - 1) * fApB + Math.log(1 + Math.exp(fApB));
}
if (newf < fval + 1.0E-4 * stepsize * gd  ) {
A=newA;
B=newB;
fval=newf;
break;
} else stepsize=stepsize / 2.0;
}
if (stepsize < min_step ) {
C$.info$S("Line search fails in two-class probability estimates\n");
break;
}}
if (iter >= max_iter) C$.info$S("Reaching maximal iterations in two-class probability estimates\n");
probAB[0]=A;
probAB[1]=B;
}, 1);

Clazz.newMeth(C$, 'sigmoid_predict$D$D$D',  function (decision_value, A, B) {
var fApB=decision_value * A + B;
if (fApB >= 0 ) return Math.exp(-fApB) / (1.0 + Math.exp(-fApB));
 else return 1.0 / (1 + Math.exp(fApB));
}, 1);

Clazz.newMeth(C$, 'multiclass_probability$I$DAA$DA',  function (k, r, p) {
var t;
var j;
var iter=0;
var max_iter=Math.max(100, k);
var Q=Clazz.array(Double.TYPE, [k, k]);
var Qp=Clazz.array(Double.TYPE, [k]);
var pQp;
var eps=0.005 / k;
for (t=0; t < k; t++) {
p[t]=1.0 / k;
Q[t][t]=0;
for (j=0; j < t; j++) {
Q[t][t]+=r[j][t] * r[j][t];
Q[t][j]=Q[j][t];
}
for (j=t + 1; j < k; j++) {
Q[t][t]+=r[j][t] * r[j][t];
Q[t][j]=-r[j][t] * r[t][j];
}
}
for (iter=0; iter < max_iter; iter++) {
pQp=0;
for (t=0; t < k; t++) {
Qp[t]=0;
for (j=0; j < k; j++) Qp[t]+=Q[t][j] * p[j];

pQp+=p[t] * Qp[t];
}
var max_error=0;
for (t=0; t < k; t++) {
var error=Math.abs(Qp[t] - pQp);
if (error > max_error ) max_error=error;
}
if (max_error < eps ) break;
for (t=0; t < k; t++) {
var diff=(-Qp[t] + pQp) / Q[t][t];
p[t]+=diff;
pQp=(pQp + diff * (diff * Q[t][t] + 2 * Qp[t])) / (1 + diff) / (1 + diff) ;
for (j=0; j < k; j++) {
Qp[j]=(Qp[j] + diff * Q[t][j]) / (1 + diff);
p[j]/=(1 + diff);
}
}
}
if (iter >= max_iter) C$.info$S("Exceeds max_iter in multiclass_prob\n");
}, 1);

Clazz.newMeth(C$, 'svm_binary_svc_probability$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$D$D$DA',  function (prob, param, Cp, Cn, probAB) {
var i;
var nr_fold=5;
var perm=Clazz.array(Integer.TYPE, [prob.l]);
var dec_values=Clazz.array(Double.TYPE, [prob.l]);
for (i=0; i < prob.l; i++) perm[i]=i;

for (i=0; i < prob.l; i++) {
var j=i + C$.rand.nextInt$I(prob.l - i);
do {
var tmp=perm[i];
perm[i]=perm[j];
perm[j]=tmp;
} while (false);
}
for (i=0; i < nr_fold; i++) {
var begin=(i * prob.l/nr_fold|0);
var end=((i + 1) * prob.l/nr_fold|0);
var j;
var k;
var subprob=Clazz.new_($I$(12,1));
subprob.l=prob.l - (end - begin);
subprob.x=Clazz.array($I$(13), [subprob.l, null]);
subprob.y=Clazz.array(Double.TYPE, [subprob.l]);
k=0;
for (j=0; j < begin; j++) {
subprob.x[k]=prob.x[perm[j]];
subprob.y[k]=prob.y[perm[j]];
++k;
}
for (j=end; j < prob.l; j++) {
subprob.x[k]=prob.x[perm[j]];
subprob.y[k]=prob.y[perm[j]];
++k;
}
var p_count=0;
var n_count=0;
for (j=0; j < k; j++) if (subprob.y[j] > 0 ) ++p_count;
 else ++n_count;

if (p_count == 0 && n_count == 0 ) for (j=begin; j < end; j++) dec_values[perm[j]]=0;

 else if (p_count > 0 && n_count == 0 ) for (j=begin; j < end; j++) dec_values[perm[j]]=1;

 else if (p_count == 0 && n_count > 0 ) for (j=begin; j < end; j++) dec_values[perm[j]]=-1;

 else {
var subparam=param.clone$();
subparam.probability=0;
subparam.C=1.0;
subparam.nr_weight=2;
subparam.weight_label=Clazz.array(Integer.TYPE, [2]);
subparam.weight=Clazz.array(Double.TYPE, [2]);
subparam.weight_label[0]=1;
subparam.weight_label[1]=-1;
subparam.weight[0]=Cp;
subparam.weight[1]=Cn;
var submodel=C$.svm_train$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$com_actelion_research_calc_ProgressController(subprob, subparam, null);
for (j=begin; j < end; j++) {
var dec_value=Clazz.array(Double.TYPE, [1]);
C$.svm_predict_values$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA(submodel, prob.x[perm[j]], dec_value);
dec_values[perm[j]]=dec_value[0];
dec_values[perm[j]]*=submodel.label[0];
}
}}
C$.sigmoid_train$I$DA$DA$DA(prob.l, dec_values, prob.y, probAB);
}, 1);

Clazz.newMeth(C$, 'svm_svr_probability$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter',  function (prob, param) {
var i;
var nr_fold=5;
var ymv=Clazz.array(Double.TYPE, [prob.l]);
var mae=0;
var newparam=param.clone$();
newparam.probability=0;
C$.svm_cross_validation$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$I$DA(prob, newparam, nr_fold, ymv);
for (i=0; i < prob.l; i++) {
ymv[i]=prob.y[i] - ymv[i];
mae+=Math.abs(ymv[i]);
}
mae/=prob.l;
var std=Math.sqrt(2 * mae * mae );
var count=0;
mae=0;
for (i=0; i < prob.l; i++) if (Math.abs(ymv[i]) > 5 * std ) count=count + 1;
 else mae+=Math.abs(ymv[i]);

mae/=(prob.l - count);
C$.info$S("Prob. model for test data: target value = predicted value + z,\nz: Laplace distribution e^(-|z|/sigma)/(2sigma),sigma=" + new Double(mae).toString() + "\n" );
return mae;
}, 1);

Clazz.newMeth(C$, 'svm_group_classes$org_machinelearning_svm_libsvm_svm_problem$IA$IAA$IAA$IAA$IA',  function (prob, nr_class_ret, label_ret, start_ret, count_ret, perm) {
var l=prob.l;
var max_nr_class=16;
var nr_class=0;
var label=Clazz.array(Integer.TYPE, [max_nr_class]);
var count=Clazz.array(Integer.TYPE, [max_nr_class]);
var data_label=Clazz.array(Integer.TYPE, [l]);
var i;
for (i=0; i < l; i++) {
var this_label=((prob.y[i])|0);
var j;
for (j=0; j < nr_class; j++) {
if (this_label == label[j]) {
++count[j];
break;
}}
data_label[i]=j;
if (j == nr_class) {
if (nr_class == max_nr_class) {
max_nr_class*=2;
var new_data=Clazz.array(Integer.TYPE, [max_nr_class]);
System.arraycopy$O$I$O$I$I(label, 0, new_data, 0, label.length);
label=new_data;
new_data=Clazz.array(Integer.TYPE, [max_nr_class]);
System.arraycopy$O$I$O$I$I(count, 0, new_data, 0, count.length);
count=new_data;
}label[nr_class]=this_label;
count[nr_class]=1;
++nr_class;
}}
if (nr_class == 2 && label[0] == -1  && label[1] == 1 ) {
do {
var tmp=label[0];
label[0]=label[1];
label[1]=tmp;
} while (false);
do {
var tmp=count[0];
count[0]=count[1];
count[1]=tmp;
} while (false);
for (i=0; i < l; i++) {
if (data_label[i] == 0) data_label[i]=1;
 else data_label[i]=0;
}
}var start=Clazz.array(Integer.TYPE, [nr_class]);
start[0]=0;
for (i=1; i < nr_class; i++) start[i]=start[i - 1] + count[i - 1];

for (i=0; i < l; i++) {
perm[start[data_label[i]]]=i;
++start[data_label[i]];
}
start[0]=0;
for (i=1; i < nr_class; i++) start[i]=start[i - 1] + count[i - 1];

nr_class_ret[0]=nr_class;
label_ret[0]=label;
start_ret[0]=start;
count_ret[0]=count;
}, 1);

Clazz.newMeth(C$, 'svm_train$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$com_actelion_research_calc_ProgressController',  function (prob, param, pg) {
var model=Clazz.new_($I$(14,1));
model.param=param;
if (param.svm_type == 2 || param.svm_type == 3  || param.svm_type == 4 ) {
model.nr_class=2;
model.label=null;
model.nSV=null;
model.probA=null;
model.probB=null;
model.sv_coef=Clazz.array(Double.TYPE, [1, null]);
if (param.probability == 1 && (param.svm_type == 3 || param.svm_type == 4 ) ) {
model.probA=Clazz.array(Double.TYPE, [1]);
model.probA[0]=C$.svm_svr_probability$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter(prob, param);
}var f=C$.svm_train_one$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$D$D$com_actelion_research_calc_ProgressController(prob, param, 0, 0, pg);
model.rho=Clazz.array(Double.TYPE, [1]);
model.rho[0]=f.rho;
var nSV=0;
var i;
for (i=0; i < prob.l; i++) if (Math.abs(f.alpha[i]) > 0 ) ++nSV;

model.l=nSV;
model.SV=Clazz.array($I$(13), [nSV, null]);
model.sv_coef[0]=Clazz.array(Double.TYPE, [nSV]);
model.sv_indices=Clazz.array(Integer.TYPE, [nSV]);
var j=0;
for (i=0; i < prob.l; i++) if (Math.abs(f.alpha[i]) > 0 ) {
model.SV[j]=prob.x[i];
model.sv_coef[0][j]=f.alpha[i];
model.sv_indices[j]=i + 1;
++j;
}
} else {
var l=prob.l;
var tmp_nr_class=Clazz.array(Integer.TYPE, [1]);
var tmp_label=Clazz.array(Integer.TYPE, [1, null]);
var tmp_start=Clazz.array(Integer.TYPE, [1, null]);
var tmp_count=Clazz.array(Integer.TYPE, [1, null]);
var perm=Clazz.array(Integer.TYPE, [l]);
C$.svm_group_classes$org_machinelearning_svm_libsvm_svm_problem$IA$IAA$IAA$IAA$IA(prob, tmp_nr_class, tmp_label, tmp_start, tmp_count, perm);
var nr_class=tmp_nr_class[0];
var label=tmp_label[0];
var start=tmp_start[0];
var count=tmp_count[0];
if (nr_class == 1) C$.info$S("WARNING: training data in only one class. See README for details.\n");
var x=Clazz.array($I$(13), [l, null]);
var i;
for (i=0; i < l; i++) x[i]=prob.x[perm[i]];

var weighted_C=Clazz.array(Double.TYPE, [nr_class]);
for (i=0; i < nr_class; i++) weighted_C[i]=param.C;

for (i=0; i < param.nr_weight; i++) {
var j;
for (j=0; j < nr_class; j++) if (param.weight_label[i] == label[j]) break;

if (j == nr_class) System.err.print$S("WARNING: class label " + param.weight_label[i] + " specified in weight is not found\n" );
 else weighted_C[j]*=param.weight[i];
}
var nonzero=Clazz.array(Boolean.TYPE, [l]);
for (i=0; i < l; i++) nonzero[i]=false;

var f=Clazz.array($I$(11), [(nr_class * (nr_class - 1)/2|0)]);
var probA=null;
var probB=null;
if (param.probability == 1) {
probA=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
probB=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
}var p=0;
for (i=0; i < nr_class; i++) for (var j=i + 1; j < nr_class; j++) {
var sub_prob=Clazz.new_($I$(12,1));
var si=start[i];
var sj=start[j];
var ci=count[i];
var cj=count[j];
sub_prob.l=ci + cj;
sub_prob.x=Clazz.array($I$(13), [sub_prob.l, null]);
sub_prob.y=Clazz.array(Double.TYPE, [sub_prob.l]);
var k;
for (k=0; k < ci; k++) {
sub_prob.x[k]=x[si + k];
sub_prob.y[k]=1;
}
for (k=0; k < cj; k++) {
sub_prob.x[ci + k]=x[sj + k];
sub_prob.y[ci + k]=-1;
}
if (param.probability == 1) {
var probAB=Clazz.array(Double.TYPE, [2]);
C$.svm_binary_svc_probability$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$D$D$DA(sub_prob, param, weighted_C[i], weighted_C[j], probAB);
probA[p]=probAB[0];
probB[p]=probAB[1];
}f[p]=C$.svm_train_one$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$D$D$com_actelion_research_calc_ProgressController(sub_prob, param, weighted_C[i], weighted_C[j], pg);
for (k=0; k < ci; k++) if (!nonzero[si + k] && Math.abs(f[p].alpha[k]) > 0  ) nonzero[si + k]=true;

for (k=0; k < cj; k++) if (!nonzero[sj + k] && Math.abs(f[p].alpha[ci + k]) > 0  ) nonzero[sj + k]=true;

++p;
}

model.nr_class=nr_class;
model.label=Clazz.array(Integer.TYPE, [nr_class]);
for (i=0; i < nr_class; i++) model.label[i]=label[i];

model.rho=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
for (i=0; i < (nr_class * (nr_class - 1)/2|0); i++) model.rho[i]=f[i].rho;

if (param.probability == 1) {
model.probA=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
model.probB=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
for (i=0; i < (nr_class * (nr_class - 1)/2|0); i++) {
model.probA[i]=probA[i];
model.probB[i]=probB[i];
}
} else {
model.probA=null;
model.probB=null;
}var nnz=0;
var nz_count=Clazz.array(Integer.TYPE, [nr_class]);
model.nSV=Clazz.array(Integer.TYPE, [nr_class]);
for (i=0; i < nr_class; i++) {
var nSV=0;
for (var j=0; j < count[i]; j++) if (nonzero[start[i] + j]) {
++nSV;
++nnz;
}
model.nSV[i]=nSV;
nz_count[i]=nSV;
}
C$.info$S("Total nSV = " + nnz + "\n" );
model.l=nnz;
model.SV=Clazz.array($I$(13), [nnz, null]);
model.sv_indices=Clazz.array(Integer.TYPE, [nnz]);
p=0;
for (i=0; i < l; i++) if (nonzero[i]) {
model.SV[p]=x[i];
model.sv_indices[p++]=perm[i] + 1;
}
var nz_start=Clazz.array(Integer.TYPE, [nr_class]);
nz_start[0]=0;
for (i=1; i < nr_class; i++) nz_start[i]=nz_start[i - 1] + nz_count[i - 1];

model.sv_coef=Clazz.array(Double.TYPE, [nr_class - 1, null]);
for (i=0; i < nr_class - 1; i++) model.sv_coef[i]=Clazz.array(Double.TYPE, [nnz]);

p=0;
for (i=0; i < nr_class; i++) for (var j=i + 1; j < nr_class; j++) {
var si=start[i];
var sj=start[j];
var ci=count[i];
var cj=count[j];
var q=nz_start[i];
var k;
for (k=0; k < ci; k++) if (nonzero[si + k]) model.sv_coef[j - 1][q++]=f[p].alpha[k];

q=nz_start[j];
for (k=0; k < cj; k++) if (nonzero[sj + k]) model.sv_coef[i][q++]=f[p].alpha[ci + k];

++p;
}

}return model;
}, 1);

Clazz.newMeth(C$, 'svm_cross_validation$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$I$DA',  function (prob, param, nr_fold, target) {
var i;
var fold_start=Clazz.array(Integer.TYPE, [nr_fold + 1]);
var l=prob.l;
var perm=Clazz.array(Integer.TYPE, [l]);
if ((param.svm_type == 0 || param.svm_type == 1 ) && nr_fold < l ) {
var tmp_nr_class=Clazz.array(Integer.TYPE, [1]);
var tmp_label=Clazz.array(Integer.TYPE, [1, null]);
var tmp_start=Clazz.array(Integer.TYPE, [1, null]);
var tmp_count=Clazz.array(Integer.TYPE, [1, null]);
C$.svm_group_classes$org_machinelearning_svm_libsvm_svm_problem$IA$IAA$IAA$IAA$IA(prob, tmp_nr_class, tmp_label, tmp_start, tmp_count, perm);
var nr_class=tmp_nr_class[0];
var start=tmp_start[0];
var count=tmp_count[0];
var fold_count=Clazz.array(Integer.TYPE, [nr_fold]);
var c;
var index=Clazz.array(Integer.TYPE, [l]);
for (i=0; i < l; i++) index[i]=perm[i];

for (c=0; c < nr_class; c++) for (i=0; i < count[c]; i++) {
var j=i + C$.rand.nextInt$I(count[c] - i);
do {
var tmp=index[start[c] + j];
index[start[c] + j]=index[start[c] + i];
index[start[c] + i]=tmp;
} while (false);
}

for (i=0; i < nr_fold; i++) {
fold_count[i]=0;
for (c=0; c < nr_class; c++) fold_count[i]+=((i + 1) * count[c]/nr_fold|0) - (i * count[c]/nr_fold|0);

}
fold_start[0]=0;
for (i=1; i <= nr_fold; i++) fold_start[i]=fold_start[i - 1] + fold_count[i - 1];

for (c=0; c < nr_class; c++) for (i=0; i < nr_fold; i++) {
var begin=start[c] + (i * count[c]/nr_fold|0);
var end=start[c] + ((i + 1) * count[c]/nr_fold|0);
for (var j=begin; j < end; j++) {
perm[fold_start[i]]=index[j];
++fold_start[i];
}
}

fold_start[0]=0;
for (i=1; i <= nr_fold; i++) fold_start[i]=fold_start[i - 1] + fold_count[i - 1];

} else {
for (i=0; i < l; i++) perm[i]=i;

for (i=0; i < l; i++) {
var j=i + C$.rand.nextInt$I(l - i);
do {
var tmp=perm[i];
perm[i]=perm[j];
perm[j]=tmp;
} while (false);
}
for (i=0; i <= nr_fold; i++) fold_start[i]=(i * l/nr_fold|0);

}for (i=0; i < nr_fold; i++) {
var begin=fold_start[i];
var end=fold_start[i + 1];
var j;
var k;
var subprob=Clazz.new_($I$(12,1));
subprob.l=l - (end - begin);
subprob.x=Clazz.array($I$(13), [subprob.l, null]);
subprob.y=Clazz.array(Double.TYPE, [subprob.l]);
k=0;
for (j=0; j < begin; j++) {
subprob.x[k]=prob.x[perm[j]];
subprob.y[k]=prob.y[perm[j]];
++k;
}
for (j=end; j < l; j++) {
subprob.x[k]=prob.x[perm[j]];
subprob.y[k]=prob.y[perm[j]];
++k;
}
var submodel=C$.svm_train$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter$com_actelion_research_calc_ProgressController(subprob, param, null);
if (param.probability == 1 && (param.svm_type == 0 || param.svm_type == 1 ) ) {
var prob_estimates=Clazz.array(Double.TYPE, [C$.svm_get_nr_class$org_machinelearning_svm_libsvm_svm_model(submodel)]);
for (j=begin; j < end; j++) target[perm[j]]=C$.svm_predict_probability$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA(submodel, prob.x[perm[j]], prob_estimates);

} else for (j=begin; j < end; j++) target[perm[j]]=C$.svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA(submodel, prob.x[perm[j]]);

}
}, 1);

Clazz.newMeth(C$, 'svm_get_svm_type$org_machinelearning_svm_libsvm_svm_model',  function (model) {
return model.param.svm_type;
}, 1);

Clazz.newMeth(C$, 'svm_get_nr_class$org_machinelearning_svm_libsvm_svm_model',  function (model) {
return model.nr_class;
}, 1);

Clazz.newMeth(C$, 'svm_get_labels$org_machinelearning_svm_libsvm_svm_model$IA',  function (model, label) {
if (model.label != null ) for (var i=0; i < model.nr_class; i++) label[i]=model.label[i];

}, 1);

Clazz.newMeth(C$, 'svm_get_sv_indices$org_machinelearning_svm_libsvm_svm_model$IA',  function (model, indices) {
if (model.sv_indices != null ) for (var i=0; i < model.l; i++) indices[i]=model.sv_indices[i];

}, 1);

Clazz.newMeth(C$, 'svm_get_nr_sv$org_machinelearning_svm_libsvm_svm_model',  function (model) {
return model.l;
}, 1);

Clazz.newMeth(C$, 'svm_get_svr_probability$org_machinelearning_svm_libsvm_svm_model',  function (model) {
if ((model.param.svm_type == 3 || model.param.svm_type == 4 ) && model.probA != null  ) return model.probA[0];
 else {
System.err.print$S("Model doesn\'t contain information for SVR probability inference\n");
return 0;
}}, 1);

Clazz.newMeth(C$, 'svm_predict_values$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA',  function (model, x, dec_values) {
var i;
if (model.param.svm_type == 2 || model.param.svm_type == 3  || model.param.svm_type == 4 ) {
var sv_coef=model.sv_coef[0];
var sum=0;
for (i=0; i < model.l; i++) sum+=sv_coef[i] * $I$(15).k_function$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_parameter(x, model.SV[i], model.param);

sum-=model.rho[0];
dec_values[0]=sum;
if (model.param.svm_type == 2) return (sum > 0 ) ? 1 : -1;
 else return sum;
} else {
var nr_class=model.nr_class;
var l=model.l;
var kvalue=Clazz.array(Double.TYPE, [l]);
for (i=0; i < l; i++) kvalue[i]=$I$(15).k_function$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_nodeA$org_machinelearning_svm_libsvm_svm_parameter(x, model.SV[i], model.param);

var start=Clazz.array(Integer.TYPE, [nr_class]);
start[0]=0;
for (i=1; i < nr_class; i++) start[i]=start[i - 1] + model.nSV[i - 1];

var vote=Clazz.array(Integer.TYPE, [nr_class]);
for (i=0; i < nr_class; i++) vote[i]=0;

var p=0;
for (i=0; i < nr_class; i++) for (var j=i + 1; j < nr_class; j++) {
var sum=0;
var si=start[i];
var sj=start[j];
var ci=model.nSV[i];
var cj=model.nSV[j];
var k;
var coef1=model.sv_coef[j - 1];
var coef2=model.sv_coef[i];
for (k=0; k < ci; k++) sum+=coef1[si + k] * kvalue[si + k];

for (k=0; k < cj; k++) sum+=coef2[sj + k] * kvalue[sj + k];

sum-=model.rho[p];
dec_values[p]=sum;
if (dec_values[p] > 0 ) ++vote[i];
 else ++vote[j];
++p;
}

var vote_max_idx=0;
for (i=1; i < nr_class; i++) if (vote[i] > vote[vote_max_idx]) vote_max_idx=i;

return model.label[vote_max_idx];
}}, 1);

Clazz.newMeth(C$, 'svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA',  function (model, x) {
var nr_class=model.nr_class;
var dec_values;
if (model.param.svm_type == 2 || model.param.svm_type == 3  || model.param.svm_type == 4 ) dec_values=Clazz.array(Double.TYPE, [1]);
 else dec_values=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
var pred_result=C$.svm_predict_values$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA(model, x, dec_values);
return pred_result;
}, 1);

Clazz.newMeth(C$, 'svm_predict_probability$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA',  function (model, x, prob_estimates) {
if ((model.param.svm_type == 0 || model.param.svm_type == 1 ) && model.probA != null   && model.probB != null  ) {
var i;
var nr_class=model.nr_class;
var dec_values=Clazz.array(Double.TYPE, [(nr_class * (nr_class - 1)/2|0)]);
C$.svm_predict_values$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA$DA(model, x, dec_values);
var min_prob=1.0E-7;
var pairwise_prob=Clazz.array(Double.TYPE, [nr_class, nr_class]);
var k=0;
for (i=0; i < nr_class; i++) for (var j=i + 1; j < nr_class; j++) {
pairwise_prob[i][j]=Math.min(Math.max(C$.sigmoid_predict$D$D$D(dec_values[k], model.probA[k], model.probB[k]), min_prob), 1 - min_prob);
pairwise_prob[j][i]=1 - pairwise_prob[i][j];
++k;
}

if (nr_class == 2) {
prob_estimates[0]=pairwise_prob[0][1];
prob_estimates[1]=pairwise_prob[1][0];
} else C$.multiclass_probability$I$DAA$DA(nr_class, pairwise_prob, prob_estimates);
var prob_max_idx=0;
for (i=1; i < nr_class; i++) if (prob_estimates[i] > prob_estimates[prob_max_idx] ) prob_max_idx=i;

return model.label[prob_max_idx];
} else return C$.svm_predict$org_machinelearning_svm_libsvm_svm_model$org_machinelearning_svm_libsvm_svm_nodeA(model, x);
}, 1);

Clazz.newMeth(C$, 'svm_save_model$S$org_machinelearning_svm_libsvm_svm_model',  function (model_file_name, model) {
var fp=Clazz.new_([Clazz.new_([Clazz.new_($I$(18,1).c$$S,[model_file_name])],$I$(17,1).c$$java_io_OutputStream)],$I$(16,1).c$$java_io_OutputStream);
var param=model.param;
fp.writeBytes$S("svm_type " + C$.svm_type_table[param.svm_type] + "\n" );
fp.writeBytes$S("kernel_type " + C$.kernel_type_table[param.kernel_type] + "\n" );
if (param.kernel_type == 1) fp.writeBytes$S("degree " + param.degree + "\n" );
if (param.kernel_type == 1 || param.kernel_type == 2  || param.kernel_type == 3 ) fp.writeBytes$S("gamma " + new Double(param.gamma).toString() + "\n" );
if (param.kernel_type == 1 || param.kernel_type == 3 ) fp.writeBytes$S("coef0 " + new Double(param.coef0).toString() + "\n" );
var nr_class=model.nr_class;
var l=model.l;
fp.writeBytes$S("nr_class " + nr_class + "\n" );
fp.writeBytes$S("total_sv " + l + "\n" );
{
fp.writeBytes$S("rho");
for (var i=0; i < (nr_class * (nr_class - 1)/2|0); i++) fp.writeBytes$S(" " + new Double(model.rho[i]).toString());

fp.writeBytes$S("\n");
}if (model.label != null ) {
fp.writeBytes$S("label");
for (var i=0; i < nr_class; i++) fp.writeBytes$S(" " + model.label[i]);

fp.writeBytes$S("\n");
}if (model.probA != null ) {
fp.writeBytes$S("probA");
for (var i=0; i < (nr_class * (nr_class - 1)/2|0); i++) fp.writeBytes$S(" " + new Double(model.probA[i]).toString());

fp.writeBytes$S("\n");
}if (model.probB != null ) {
fp.writeBytes$S("probB");
for (var i=0; i < (nr_class * (nr_class - 1)/2|0); i++) fp.writeBytes$S(" " + new Double(model.probB[i]).toString());

fp.writeBytes$S("\n");
}if (model.nSV != null ) {
fp.writeBytes$S("nr_sv");
for (var i=0; i < nr_class; i++) fp.writeBytes$S(" " + model.nSV[i]);

fp.writeBytes$S("\n");
}fp.writeBytes$S("SV\n");
var sv_coef=model.sv_coef;
var SV=model.SV;
for (var i=0; i < l; i++) {
for (var j=0; j < nr_class - 1; j++) fp.writeBytes$S(new Double(sv_coef[j][i]).toString() + " ");

var p=SV[i];
if (param.kernel_type == 4) fp.writeBytes$S("0:" + ((p[0].value)|0));
 else for (var j=0; j < p.length; j++) fp.writeBytes$S(p[j].index + ":" + new Double(p[j].value).toString() + " " );

fp.writeBytes$S("\n");
}
fp.close$();
}, 1);

Clazz.newMeth(C$, 'atof$S',  function (s) {
return Double.valueOf$S(s).doubleValue$();
}, 1);

Clazz.newMeth(C$, 'atoi$S',  function (s) {
return Integer.parseInt$S(s);
}, 1);

Clazz.newMeth(C$, 'read_model_header$java_io_BufferedReader$org_machinelearning_svm_libsvm_svm_model',  function (fp, model) {
var param=Clazz.new_($I$(19,1));
model.param=param;
param.nr_weight=0;
param.weight_label=null;
param.weight=null;
try {
while (true){
var cmd=fp.readLine$();
var arg=cmd.substring$I(cmd.indexOf$I(" ") + 1);
if (cmd.startsWith$S("svm_type")) {
var i;
for (i=0; i < C$.svm_type_table.length; i++) {
if (arg.indexOf$S(C$.svm_type_table[i]) != -1) {
param.svm_type=i;
break;
}}
if (i == C$.svm_type_table.length) {
System.err.print$S("unknown svm type.\n");
return false;
}} else if (cmd.startsWith$S("kernel_type")) {
var i;
for (i=0; i < C$.kernel_type_table.length; i++) {
if (arg.indexOf$S(C$.kernel_type_table[i]) != -1) {
param.kernel_type=i;
break;
}}
if (i == C$.kernel_type_table.length) {
System.err.print$S("unknown kernel function.\n");
return false;
}} else if (cmd.startsWith$S("degree")) param.degree=C$.atoi$S(arg);
 else if (cmd.startsWith$S("gamma")) param.gamma=C$.atof$S(arg);
 else if (cmd.startsWith$S("coef0")) param.coef0=C$.atof$S(arg);
 else if (cmd.startsWith$S("nr_class")) model.nr_class=C$.atoi$S(arg);
 else if (cmd.startsWith$S("total_sv")) model.l=C$.atoi$S(arg);
 else if (cmd.startsWith$S("rho")) {
var n=(model.nr_class * (model.nr_class - 1)/2|0);
model.rho=Clazz.array(Double.TYPE, [n]);
var st=Clazz.new_($I$(20,1).c$$S,[arg]);
for (var i=0; i < n; i++) model.rho[i]=C$.atof$S(st.nextToken$());

} else if (cmd.startsWith$S("label")) {
var n=model.nr_class;
model.label=Clazz.array(Integer.TYPE, [n]);
var st=Clazz.new_($I$(20,1).c$$S,[arg]);
for (var i=0; i < n; i++) model.label[i]=C$.atoi$S(st.nextToken$());

} else if (cmd.startsWith$S("probA")) {
var n=(model.nr_class * (model.nr_class - 1)/2|0);
model.probA=Clazz.array(Double.TYPE, [n]);
var st=Clazz.new_($I$(20,1).c$$S,[arg]);
for (var i=0; i < n; i++) model.probA[i]=C$.atof$S(st.nextToken$());

} else if (cmd.startsWith$S("probB")) {
var n=(model.nr_class * (model.nr_class - 1)/2|0);
model.probB=Clazz.array(Double.TYPE, [n]);
var st=Clazz.new_($I$(20,1).c$$S,[arg]);
for (var i=0; i < n; i++) model.probB[i]=C$.atof$S(st.nextToken$());

} else if (cmd.startsWith$S("nr_sv")) {
var n=model.nr_class;
model.nSV=Clazz.array(Integer.TYPE, [n]);
var st=Clazz.new_($I$(20,1).c$$S,[arg]);
for (var i=0; i < n; i++) model.nSV[i]=C$.atoi$S(st.nextToken$());

} else if (cmd.startsWith$S("SV")) {
break;
} else {
System.err.print$S("unknown text in model file: [" + cmd + "]\n" );
return false;
}}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return false;
} else {
throw e;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'svm_load_model$S',  function (model_file_name) {
return C$.svm_load_model$java_io_BufferedReader(Clazz.new_([Clazz.new_($I$(22,1).c$$S,[model_file_name])],$I$(21,1).c$$java_io_Reader));
}, 1);

Clazz.newMeth(C$, 'svm_load_model$java_io_BufferedReader',  function (fp) {
var model=Clazz.new_($I$(14,1));
model.rho=null;
model.probA=null;
model.probB=null;
model.label=null;
model.nSV=null;
if (C$.read_model_header$java_io_BufferedReader$org_machinelearning_svm_libsvm_svm_model(fp, model) == false ) {
System.err.print$S("ERROR: failed to read model\n");
return null;
}var m=model.nr_class - 1;
var l=model.l;
model.sv_coef=Clazz.array(Double.TYPE, [m, l]);
model.SV=Clazz.array($I$(13), [l, null]);
for (var i=0; i < l; i++) {
var line=fp.readLine$();
var st=Clazz.new_($I$(20,1).c$$S$S,[line, " \t\n\r\f:"]);
for (var k=0; k < m; k++) model.sv_coef[k][i]=C$.atof$S(st.nextToken$());

var n=(st.countTokens$()/2|0);
model.SV[i]=Clazz.array($I$(13), [n]);
for (var j=0; j < n; j++) {
model.SV[i][j]=Clazz.new_($I$(13,1));
model.SV[i][j].index=C$.atoi$S(st.nextToken$());
model.SV[i][j].value=C$.atof$S(st.nextToken$());
}
}
fp.close$();
return model;
}, 1);

Clazz.newMeth(C$, 'svm_check_parameter$org_machinelearning_svm_libsvm_svm_problem$org_machinelearning_svm_libsvm_svm_parameter',  function (prob, param) {
var svm_type=param.svm_type;
if (svm_type != 0 && svm_type != 1  && svm_type != 2  && svm_type != 3  && svm_type != 4 ) return "unknown svm type";
var kernel_type=param.kernel_type;
if (kernel_type != 0 && kernel_type != 1  && kernel_type != 2  && kernel_type != 3  && kernel_type != 4 ) return "unknown kernel type";
if (param.gamma < 0 ) return "gamma < 0";
if (param.degree < 0) return "degree of polynomial kernel < 0";
if (param.cache_size <= 0 ) return "cache_size <= 0";
if (param.eps <= 0 ) return "eps <= 0";
if (svm_type == 0 || svm_type == 3  || svm_type == 4 ) if (param.C <= 0 ) return "C <= 0";
if (svm_type == 1 || svm_type == 2  || svm_type == 4 ) if (param.nu <= 0  || param.nu > 1  ) return "nu <= 0 or nu > 1";
if (svm_type == 3) if (param.p < 0 ) return "p < 0";
if (param.shrinking != 0 && param.shrinking != 1 ) return "shrinking != 0 and shrinking != 1";
if (param.probability != 0 && param.probability != 1 ) return "probability != 0 and probability != 1";
if (param.probability == 1 && svm_type == 2 ) return "one-class SVM probability output not supported yet";
if (svm_type == 1) {
var l=prob.l;
var max_nr_class=16;
var nr_class=0;
var label=Clazz.array(Integer.TYPE, [max_nr_class]);
var count=Clazz.array(Integer.TYPE, [max_nr_class]);
var i;
for (i=0; i < l; i++) {
var this_label=(prob.y[i]|0);
var j;
for (j=0; j < nr_class; j++) if (this_label == label[j]) {
++count[j];
break;
}
if (j == nr_class) {
if (nr_class == max_nr_class) {
max_nr_class*=2;
var new_data=Clazz.array(Integer.TYPE, [max_nr_class]);
System.arraycopy$O$I$O$I$I(label, 0, new_data, 0, label.length);
label=new_data;
new_data=Clazz.array(Integer.TYPE, [max_nr_class]);
System.arraycopy$O$I$O$I$I(count, 0, new_data, 0, count.length);
count=new_data;
}label[nr_class]=this_label;
count[nr_class]=1;
++nr_class;
}}
for (i=0; i < nr_class; i++) {
var n1=count[i];
for (var j=i + 1; j < nr_class; j++) {
var n2=count[j];
if (param.nu * (n1 + n2) / 2 > Math.min(n1, n2) ) return "specified nu is infeasible";
}
}
}return null;
}, 1);

Clazz.newMeth(C$, 'svm_check_probability_model$org_machinelearning_svm_libsvm_svm_model',  function (model) {
if (((model.param.svm_type == 0 || model.param.svm_type == 1 ) && model.probA != null   && model.probB != null  ) || ((model.param.svm_type == 3 || model.param.svm_type == 4 ) && model.probA != null  ) ) return 1;
 else return 0;
}, 1);

Clazz.newMeth(C$, 'svm_set_print_string_function$org_machinelearning_svm_libsvm_svm_print_interface',  function (print_func) {
if (print_func == null ) C$.svm_print_string=C$.svm_print_stdout;
 else C$.svm_print_string=print_func;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.rand=Clazz.new_($I$(4,1));
C$.svm_print_stdout=((P$.svm$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "svm$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'org.machinelearning.svm.libsvm.svm_print_interface', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]]

Clazz.newMeth(C$, 'print$S',  function (s) {
});
})()
), Clazz.new_(P$.svm$1.$init$,[this, null]));
C$.svm_print_string=C$.svm_print_stdout;
C$.svm_type_table=Clazz.array(String, -1, ["c_svc", "nu_svc", "one_class", "epsilon_svr", "nu_svr"]);
C$.kernel_type_table=Clazz.array(String, -1, ["linear", "polynomial", "rbf", "sigmoid", "precomputed"]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.svm, "decision_function", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['rho'],'O',['alpha','double[]']]]

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
