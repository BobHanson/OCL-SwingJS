(function(){var P$=Clazz.newPackage("com.actelion.research.calc.combinatorics"),I$=[[0,'java.util.ArrayList','java.util.Arrays','java.math.BigInteger','com.actelion.research.util.ListUtils','com.actelion.research.util.StringFunctions']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CombinationGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getAllOutOf$I$I',  function (nObjects, sampleSize) {
var li=Clazz.new_($I$(1,1));
var arrCounters=Clazz.array(Integer.TYPE, [sampleSize]);
if (nObjects == sampleSize) {
var arr=Clazz.array(Integer.TYPE, [sampleSize]);
for (var i=0; i < arr.length; i++) {
arr[i]=i;
}
li.add$O(arr);
return li;
} else if (sampleSize == 1) {
for (var i=0; i < nObjects; i++) {
var arr=Clazz.array(Integer.TYPE, [1]);
arr[0]=i;
li.add$O(arr);
}
return li;
} else if (sampleSize > nObjects) {
return null;
}for (var i=0; i < arrCounters.length; i++) {
arrCounters[i]=i;
}
var proceed=true;
while (proceed){
var arr=Clazz.array(Integer.TYPE, [sampleSize]);
for (var i=0; i < sampleSize; i++) {
arr[i]=arrCounters[i];
}
li.add$O(arr);
var depth=sampleSize - 1;
++arrCounters[depth];
var counterFieldReset=false;
if (arrCounters[depth] >= nObjects) {
counterFieldReset=true;
}while (counterFieldReset){
counterFieldReset=false;
--depth;
++arrCounters[depth];
for (var i=depth + 1; i < sampleSize; i++) {
arrCounters[i]=arrCounters[i - 1] + 1;
if (arrCounters[i] >= nObjects) {
counterFieldReset=true;
}}
if (depth == 0) break;
}
if (counterFieldReset) proceed=false;
}
return li;
}, 1);

Clazz.newMeth(C$, 'getCombinations$IA',  function (arrSizeClass) {
var capacity=1;
for (var sizeClass, $sizeClass = 0, $$sizeClass = arrSizeClass; $sizeClass<$$sizeClass.length&&((sizeClass=($$sizeClass[$sizeClass])),1);$sizeClass++) {
(capacity=Long.$mul(capacity,(sizeClass)));
}
if (Long.$gt(capacity,2147483647 )) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of combinations " + Long.$s(capacity) + " above Integer.MAX_VALUE!" ]);
}var li=Clazz.new_([Long.$ival(capacity)],$I$(1,1).c$$I);
var liTmp=Clazz.new_([Long.$ival(capacity)],$I$(1,1).c$$I);
var index=0;
for (var i=0; i < arrSizeClass[0]; i++) {
var liCombi=Clazz.new_($I$(1,1));
liCombi.add$O(Integer.valueOf$I(i));
li.add$O(liCombi);
}
++index;
while (index < arrSizeClass.length){
liTmp.clear$();
for (var liCombi, $liCombi = li.iterator$(); $liCombi.hasNext$()&&((liCombi=($liCombi.next$())),1);) {
for (var i=0; i < arrSizeClass[index]; i++) {
var liCombiNew=Clazz.new_($I$(1,1).c$$java_util_Collection,[liCombi]);
liCombiNew.add$O(Integer.valueOf$I(i));
liTmp.add$O(liCombiNew);
}
}
li.clear$();
li.addAll$java_util_Collection(liTmp);
++index;
}
return li;
}, 1);

Clazz.newMeth(C$, 'getCombinations$java_util_List',  function (li) {
var nCombinations=1;
for (var arr, $arr = li.iterator$(); $arr.hasNext$()&&((arr=($arr.next$())),1);) {
nCombinations*=arr.length;
}
var liComb=Clazz.new_($I$(1,1).c$$I,[nCombinations]);
for (var i=0; i < nCombinations; i++) {
var arrComb=Clazz.array(Integer.TYPE, [li.size$()]);
liComb.add$O(arrComb);
}
var nCombCol=1;
for (var col=0; col < li.size$(); col++) {
nCombCol*=li.get$I(col).length;
var nRepetitions=(nCombinations/nCombCol|0);
var arr=li.get$I(col);
var indexArr=0;
var row=0;
while (row < nCombinations){
for (var i=0; i < nRepetitions; i++) {
var arrComb=liComb.get$I(row);
arrComb[col]=arr[indexArr];
++row;
}
++indexArr;
if (indexArr == arr.length) {
indexArr=0;
}}
}
return liComb;
}, 1);

Clazz.newMeth(C$, 'swap$IA$I$I',  function (input, a, b) {
var tmp=input[a];
input[a]=input[b];
input[b]=tmp;
}, 1);

Clazz.newMeth(C$, 'getPermutations$IA$I',  function (elements, n) {
var permutations=Clazz.new_($I$(1,1));
var indexes=Clazz.array(Integer.TYPE, [n]);
var i=0;
permutations.add$O($I$(2).copyOf$IA$I(elements, elements.length));
while (i < n){
if (indexes[i] < i) {
C$.swap$IA$I$I(elements, i % 2 == 0 ? 0 : indexes[i], i);
permutations.add$O($I$(2).copyOf$IA$I(elements, elements.length));
++indexes[i];
i=0;
} else {
indexes[i]=0;
++i;
}}
return permutations;
}, 1);

Clazz.newMeth(C$, 'cartesianProduct$java_util_List',  function (lists) {
var resultLists=Clazz.new_($I$(1,1));
if (lists.size$() == 0) {
resultLists.add$O(Clazz.new_($I$(1,1)));
return resultLists;
} else {
var firstList=lists.get$I(0);
var remainingLists=C$.cartesianProduct$java_util_List(lists.subList$I$I(1, lists.size$()));
for (var condition, $condition = firstList.iterator$(); $condition.hasNext$()&&((condition=($condition.next$())),1);) {
for (var remainingList, $remainingList = remainingLists.iterator$(); $remainingList.hasNext$()&&((remainingList=($remainingList.next$())),1);) {
var resultList=Clazz.new_($I$(1,1));
resultList.add$O(condition);
resultList.addAll$java_util_Collection(remainingList);
resultLists.add$O(resultList);
}
}
}return resultLists;
}, 1);

Clazz.newMeth(C$, 'getFactorial$I',  function (n) {
var fact=$I$(3).ONE;
for (var i=n; i > 1; i--) {
fact=fact.multiply$java_math_BigInteger(Clazz.new_([Integer.toString$I(i)],$I$(3,1).c$$S));
}
return fact;
}, 1);

Clazz.newMeth(C$, 'getBinomialCoefficient$I$I',  function (n, k) {
var nFac=C$.getFactorial$I(n);
var kFac=C$.getFactorial$I(k);
var nMinus_k_Fac=C$.getFactorial$I(n - k);
var dev=nMinus_k_Fac.multiply$java_math_BigInteger(kFac);
var bc=nFac.divide$java_math_BigInteger(dev);
return bc;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
C$.exampleGetAllOutOf2$();
}, 1);

Clazz.newMeth(C$, 'examplePermutations$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [4, 7, 9]);
var liComb=C$.getPermutations$IA$I(a, 3);
for (var p, $p = liComb.iterator$(); $p.hasNext$()&&((p=($p.next$())),1);) {
System.out.println$S($I$(2).toString$IA(p));
}
}, 1);

Clazz.newMeth(C$, 'exampleCartesianProduct$',  function () {
var lists=Clazz.new_($I$(1,1));
var l0=Clazz.new_($I$(1,1));
l0.add$O(Integer.valueOf$I(1));
l0.add$O(Integer.valueOf$I(2));
l0.add$O(Integer.valueOf$I(3));
var l1=Clazz.new_($I$(1,1).c$$java_util_Collection,[l0]);
var l2=Clazz.new_($I$(1,1).c$$java_util_Collection,[l0]);
lists.add$O(l0);
lists.add$O(l1);
lists.add$O(l2);
var liComb=C$.cartesianProduct$java_util_List(lists);
for (var li, $li = liComb.iterator$(); $li.hasNext$()&&((li=($li.next$())),1);) {
System.out.println$S($I$(4).toStringInteger$java_util_List(li));
}
}, 1);

Clazz.newMeth(C$, 'exampleCombinations$',  function () {
var a=Clazz.array(Integer.TYPE, -1, [1, 2, 3]);
var liComb=C$.getCombinations$IA(a);
for (var li, $li = liComb.iterator$(); $li.hasNext$()&&((li=($li.next$())),1);) {
System.out.println$S($I$(4).toStringInteger$java_util_List(li));
}
}, 1);

Clazz.newMeth(C$, 'exampleGetAllOutOf$',  function () {
var object=4;
var sampleSize=3;
var liComb=C$.getAllOutOf$I$I(object, sampleSize);
for (var a, $a = liComb.iterator$(); $a.hasNext$()&&((a=($a.next$())),1);) {
System.out.println$S($I$(5).toString$IA$S(a, ","));
}
}, 1);

Clazz.newMeth(C$, 'exampleGetAllOutOf2$',  function () {
var object=4;
for (var sampleSize=1; sampleSize < object; sampleSize++) {
var liComb=C$.getAllOutOf$I$I(object, sampleSize);
for (var a, $a = liComb.iterator$(); $a.hasNext$()&&((a=($a.next$())),1);) {
System.out.println$S($I$(5).toString$IA$S(a, ","));
}
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
