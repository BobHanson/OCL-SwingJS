(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression"),I$=[[0,'java.util.Properties','java.util.ArrayList','java.io.FileWriter','java.io.StringWriter','java.io.FileReader','java.io.StringReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParameterRegressionMethod", null, null, ['Comparable', 'java.io.Serializable']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['properties','java.util.Properties']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.properties=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (name) {
;C$.$init$.apply(this);
this.properties=Clazz.new_($I$(1,1));
this.properties.setProperty$S$S("Name", name);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_ParameterRegressionMethod',  function (p) {
;C$.$init$.apply(this);
this.properties=Clazz.new_($I$(1,1));
this.copy$com_actelion_research_calc_regression_ParameterRegressionMethod(p);
}, 1);

Clazz.newMeth(C$, 'copy$com_actelion_research_calc_regression_ParameterRegressionMethod',  function (orig) {
this.setName$S(orig.getName$());
});

Clazz.newMeth(C$, 'setName$S',  function (name) {
this.properties.setProperty$S$S("Name", name);
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.properties.getProperty$S("Name");
});

Clazz.newMeth(C$, 'getHeader$',  function () {
var li=Clazz.new_($I$(2,1));
li.add$O("Name");
li.add$O("ParameterToString");
return li;
}, 1);

Clazz.newMeth(C$, 'getProperties$',  function () {
return this.properties;
});

Clazz.newMeth(C$, 'write$java_io_File',  function (fiProperties) {
this.properties.store$java_io_Writer$S(Clazz.new_($I$(3,1).c$$java_io_File,[fiProperties]), "");
});

Clazz.newMeth(C$, 'write2String$',  function () {
var stringWriter=Clazz.new_($I$(4,1));
this.properties.store$java_io_Writer$S(stringWriter, "");
return stringWriter.toString();
});

Clazz.newMeth(C$, 'read$java_io_File',  function (fiProperties) {
this.properties.load$java_io_Reader(Clazz.new_($I$(5,1).c$$java_io_File,[fiProperties]));
this.decodeProperties2Parameter$();
});

Clazz.newMeth(C$, 'read$S',  function (s) {
var stringReader=Clazz.new_($I$(6,1).c$$S,[s]);
this.properties.load$java_io_Reader(stringReader);
this.decodeProperties2Parameter$();
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var p=obj;
if (!this.getName$().equals$O(p.getName$())) {
return false;
}return true;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:36 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
