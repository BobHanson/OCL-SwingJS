(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[[0,'com.actelion.research.calc.SelfOrganizedMap','StringBuffer','com.actelion.research.util.DoubleFormat','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VectorSOM", null, 'com.actelion.research.calc.SelfOrganizedMap');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mParameterCount'],'O',['mMeanParameter','double[]','+mStandardDeviation']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (nx, ny, mode) {
;C$.superclazz.c$$I$I$I.apply(this,[nx, ny, mode]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setParameterCount$I',  function (parameterCount) {
this.mParameterCount=parameterCount;
});

Clazz.newMeth(C$, 'initializeNormalization$',  function () {
this.startProgress$S$I$I("Calculating mean parameters...", 0, this.mController.getInputVectorCount$());
if (this.mController.getInputVectorCount$() == -1) {
this.mMeanParameter=Clazz.array(Double.TYPE, [this.mParameterCount]);
this.mStandardDeviation=Clazz.array(Double.TYPE, [this.mParameterCount]);
for (var i=0; i < this.mParameterCount; i++) {
this.mMeanParameter[i]=0.0;
this.mStandardDeviation[i]=1.0;
}
return;
}this.mMeanParameter=Clazz.array(Double.TYPE, [this.mParameterCount]);
for (var row=0; row < this.mController.getInputVectorCount$(); row++) {
if (this.threadMustDie$()) break;
this.updateProgress$I(row);
var vector=this.mController.getInputVector$I(row);
for (var i=0; i < this.mParameterCount; i++) this.mMeanParameter[i]+=vector[i];

}
if (!this.threadMustDie$()) for (var i=0; i < this.mParameterCount; i++) this.mMeanParameter[i]/=this.mController.getInputVectorCount$();

this.startProgress$S$I$I("Calculating variance...", 0, this.mController.getInputVectorCount$());
this.mStandardDeviation=Clazz.array(Double.TYPE, [this.mParameterCount]);
for (var row=0; row < this.mController.getInputVectorCount$(); row++) {
if (this.threadMustDie$()) break;
this.updateProgress$I(row);
var vector=this.mController.getInputVector$I(row);
for (var i=0; i < this.mParameterCount; i++) {
var dif=vector[i] - this.mMeanParameter[i];
this.mStandardDeviation[i]+=dif * dif;
}
}
if (!this.threadMustDie$()) for (var i=0; i < this.mParameterCount; i++) this.mStandardDeviation[i]=Math.sqrt(this.mStandardDeviation[i] / this.mController.getInputVectorCount$());

});

Clazz.newMeth(C$, 'write$java_io_BufferedWriter',  function (writer) {
C$.superclazz.prototype.write$java_io_BufferedWriter.apply(this, [writer]);
writer.write$S("<meanParameter=\"" + C$.doubleArrayToString$DA(this.mMeanParameter) + "\">" );
writer.newLine$();
writer.write$S("<standardDeviation=\"" + C$.doubleArrayToString$DA(this.mStandardDeviation) + "\">" );
writer.newLine$();
});

Clazz.newMeth(C$, 'read$java_io_BufferedReader',  function (reader) {
C$.superclazz.prototype.read$java_io_BufferedReader.apply(this, [reader]);
var theLine=reader.readLine$();
var error=!theLine.startsWith$S("<meanParameter=");
if (!error) {
this.mMeanParameter=C$.stringToDoubleArray$S($I$(1).extractValue$S(theLine));
this.mParameterCount=this.mMeanParameter.length;
theLine=reader.readLine$();
if (theLine.startsWith$S("<variance=")) {
this.mStandardDeviation=C$.stringToDoubleArray$S($I$(1).extractValue$S(theLine));
for (var i=0; i < this.mStandardDeviation.length; i++) this.mStandardDeviation[i]=Math.sqrt(this.mStandardDeviation[i]);

} else if (theLine.startsWith$S("<standardDeviation=")) {
this.mStandardDeviation=C$.stringToDoubleArray$S($I$(1).extractValue$S(theLine));
} else {
error=true;
}}if (error) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Invalid SOM file format"]);
});

Clazz.newMeth(C$, 'referenceVectorToString$I$I',  function (x, y) {
return C$.doubleArrayToString$DA(this.mReferenceVector[x][y]);
});

Clazz.newMeth(C$, 'doubleArrayToString$DA',  function (d) {
var buf=Clazz.new_($I$(2,1));
for (var i=0; i < d.length; i++) {
if (i != 0) buf.append$C("\t");
buf.append$S($I$(3).toString$D(d[i]));
}
return buf.toString();
}, 1);

Clazz.newMeth(C$, 'setReferenceVector$I$I$S',  function (x, y, ref) {
this.mReferenceVector[x][y]=C$.stringToDoubleArray$S(ref);
});

Clazz.newMeth(C$, 'stringToDoubleArray$S',  function (s) {
var size=1;
for (var i=0; i < s.length$(); i++) if (s.charAt$I(i) == "\t") ++size;

var startPosition=0;
var tabPosition=s.indexOf$I("\t");
var d=Clazz.array(Double.TYPE, [size]);
for (var i=0; i < size - 1; i++) {
d[i]=Double.parseDouble$S(s.substring$I$I(startPosition, tabPosition));
startPosition=tabPosition + 1;
tabPosition=s.indexOf$I$I("\t", startPosition);
}
d[size - 1]=Double.parseDouble$S(s.substring$I(startPosition));
return d;
}, 1);

Clazz.newMeth(C$, 'getDissimilarity$O$O',  function (vector1, vector2) {
var v1=vector1;
var v2=vector2;
var sum=0.0;
for (var i=0; i < v1.length; i++) {
var dif=Math.abs(v1[i] - v2[i]);
sum+=dif * dif;
}
return Math.sqrt(sum) / Math.sqrt(v1.length);
});

Clazz.newMeth(C$, 'updateReference$O$O$D',  function (inputVector, referenceVector, influence) {
var input=inputVector;
var reference=referenceVector;
for (var i=0; i < reference.length; i++) reference[i]+=influence * (input[i] - reference[i]);

});

Clazz.newMeth(C$, 'getRandomVector$',  function () {
var random=Clazz.new_($I$(4,1));
var vector=Clazz.array(Double.TYPE, [this.mParameterCount]);
for (var i=0; i < this.mParameterCount; i++) vector[i]=random.nextGaussian$();

return vector;
});

Clazz.newMeth(C$, 'getMeanVector$O$O',  function (vector1, vector2) {
var v1=vector1;
var v2=vector2;
var mv=Clazz.array(Double.TYPE, [v1.length]);
for (var i=0; i < v1.length; i++) mv[i]=0.5 * (v1[i] + v2[i]);

return mv;
});

Clazz.newMeth(C$, 'normalizeVector$O',  function (vector) {
var v=vector;
if (v != null ) for (var i=0; i < v.length; i++) v[i]=(v[i] - this.mMeanParameter[i]) / this.mStandardDeviation[i];

return v;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:05 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
