(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ProgressController", null, null, ['com.actelion.research.calc.ProgressListener', 'com.actelion.research.calc.ThreadMaster']);

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
