(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ProgressController", null, null, ['com.actelion.research.calc.ProgressListener', 'com.actelion.research.calc.ThreadMaster']);

C$.$clinit$=2;
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:09 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
