(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.type"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.type.Bond','java.util.HashSet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Torsion");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (table, mol, a1, a2, a3, a4) {
var bond_jk=mol.getBond$I$I(a2, a3);
var bijt=$I$(1).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a1, a2);
var bjkt=$I$(1).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a2, a3);
var bklt=$I$(1).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, a3, a4);
var tort=bjkt;
if (bjkt == 0 && mol.getBondOrder$I(bond_jk) == 1  && (bijt == 1 || bklt == 1 ) ) tort=2;
var size=C$.inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, a4);
if (size == 4 && mol.getBond$I$I(a1, a3) == -1  && mol.getBond$I$I(a2, a4) == -1 ) return 40 + tort;
if (size == 5 && (mol.getAtomType$I(a1) == 1 || mol.getAtomType$I(a2) == 1  || mol.getAtomType$I(a3) == 1  || mol.getAtomType$I(a4) == 1 ) ) return 50 + tort;
return tort;
}, 1);

Clazz.newMeth(C$, 'inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (mol, a1, a2, a3, a4) {
if (mol.getBond$I$I(a1, a2) == -1 || mol.getBond$I$I(a2, a3) == -1  || mol.getBond$I$I(a3, a4) == -1 ) return 0;
if (mol.getBond$I$I(a4, a1) >= 0) return 4;
var rings=mol.getRingSet$();
var tor=Clazz.new_($I$(2,1));
tor.add$O(Integer.valueOf$I(a1));
tor.add$O(Integer.valueOf$I(a2));
tor.add$O(Integer.valueOf$I(a3));
tor.add$O(Integer.valueOf$I(a4));
for (var r=0; r < rings.getSize$(); r++) if (rings.getRingSize$I(r) == 5) {
var ring=Clazz.new_($I$(2,1));
for (var a, $a = 0, $$a = rings.getRingAtoms$I(r); $a<$$a.length&&((a=($$a[$a])),1);$a++) ring.add$O(Integer.valueOf$I(a));

if (ring.containsAll$java_util_Collection(tor)) return 5;
}
return 0;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
