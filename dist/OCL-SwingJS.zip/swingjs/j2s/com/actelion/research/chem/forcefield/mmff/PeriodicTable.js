(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "PeriodicTable");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'row$I',  function (ano) {
if (ano < 3) return 0;
 else if (ano < 11) return 1;
 else if (ano < 19) return 2;
 else if (ano < 37) return 3;
 else if (ano < 55) return 4;
return 0;
}, 1);

Clazz.newMeth(C$, 'rowtm$I',  function (ano) {
var row=0;
if (ano == 2) row=1;
 else if (ano >= 3 && ano <= 10 ) row=2;
 else if (ano >= 11 && ano <= 18 ) row=3;
 else if (ano >= 19 && ano <= 36 ) row=4;
 else if (ano >= 37 && ano <= 54 ) row=5;
if (ano >= 21 && ano <= 30  || ano >= 39 && ano <= 48  ) row*=10;
return row;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
