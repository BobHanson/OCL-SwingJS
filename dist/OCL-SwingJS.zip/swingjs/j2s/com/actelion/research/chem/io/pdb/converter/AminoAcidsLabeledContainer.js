(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),p$1={},I$=[[0,'com.actelion.research.util.IO','com.actelion.research.chem.IDCodeParser','java.util.HashMap','com.actelion.research.chem.io.pdb.converter.AminoAcidLabeled']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*e*/var C$=Clazz.newClass(P$, "AminoAcidsLabeledContainer", null, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['hmAbbreviation_AminoAcidLabeled','java.util.HashMap']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.read.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'read',  function () {
try {
var inputStream=this.getClass$().getResourceAsStream$S("/resources/pdb/aminoAcidsLabeled.txt");
var li=$I$(1).readLines2List$java_io_InputStream(inputStream);
inputStream.close$();
for (var i=li.size$() - 1; i >= 0; i--) {
if (li.get$I(i).startsWith$S("#")) {
li.remove$I(i);
}}
var parser=Clazz.new_($I$(2,1));
this.hmAbbreviation_AminoAcidLabeled=Clazz.new_($I$(3,1));
for (var line, $line = li.iterator$(); $line.hasNext$()&&((line=($line.next$())),1);) {
var arr=line.split$S("\t");
var mol=parser.getCompactMolecule$S$S(arr[0], arr[1]);
var key=arr[3].toUpperCase$();
var aminoAcidLabeled=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$S$S,[mol, arr[2], key]);
this.hmAbbreviation_AminoAcidLabeled.put$O$O(key, aminoAcidLabeled);
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("no Amino-Acid File detected!");
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'get$S',  function (threeLetterCodeUpperCase) {
return this.hmAbbreviation_AminoAcidLabeled.get$O(threeLetterCodeUpperCase);
});

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "INSTANCE", 0, []);
};
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
