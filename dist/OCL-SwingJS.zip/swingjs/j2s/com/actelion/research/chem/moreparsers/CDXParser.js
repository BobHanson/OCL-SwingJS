(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),p$1={},p$2={},I$=[[0,'java.util.ArrayList',['com.actelion.research.chem.moreparsers.CDXParser','.CDBond'],'StringBuffer','java.util.BitSet','java.util.HashMap','java.util.Stack','com.actelion.research.chem.moreparsers.ParserUtils','com.actelion.research.chem.StereoMolecule','java.io.BufferedReader','java.io.StringReader','com.actelion.research.chem.coords.CoordinateInventor','com.actelion.research.chem.moreparsers.CDX2CDXML',['com.actelion.research.chem.moreparsers.CDXParser','.BracketedGroup'],['com.actelion.research.chem.moreparsers.CDXParser','.CDNode'],'com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXParser", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.chem.moreparsers.XmlReader');
C$.$classes$=[['CDNode',0],['CDBond',0],['BracketedGroup',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.warnings=Clazz.new_($I$(3,1));
this.minX=1.7976931348623157E308;
this.minY=1.7976931348623157E308;
this.maxY=-1.7976931348623157E308;
this.maxX=-1.7976931348623157E308;
this.atoms=Clazz.new_($I$(1,1));
this.bonds=Clazz.new_($I$(1,1));
this.bsAtoms=Clazz.new_($I$(4,1));
this.bsBonds=Clazz.new_($I$(4,1));
this.atomSymbolicMap=Clazz.new_($I$(5,1));
this.fragments=Clazz.new_($I$(6,1));
this.nodes=Clazz.new_($I$(6,1));
this.nostereo=Clazz.new_($I$(1,1));
this.objectsByID=Clazz.new_($I$(5,1));
},1);

C$.$fields$=[['D',['minX','minY','maxY','maxX'],'I',['atomIndex'],'S',['thisFragmentID','textBuffer'],'O',['warnings','StringBuffer','atoms','java.util.List','+bonds','bsAtoms','java.util.BitSet','+bsBonds','atomSymbolicMap','java.util.Map','bracketedGroups','java.util.Stack','+fragments','thisAtom','com.actelion.research.chem.moreparsers.CDXParser.CDNode','+thisNode','nodes','java.util.Stack','nostereo','java.util.List','objectsByID','java.util.Map']]]

Clazz.newMeth(C$, 'parseFile$S',  function (path) {
var cdx=$I$(7).getURLContentsAsBytes$S(path);
var mol=Clazz.new_($I$(8,1));
var isOK;
if (cdx == null  || cdx.length == 0 ) return null;
if (cdx[0] == 86) {
isOK=Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$BA(mol, cdx);
} else {
try {
isOK=Clazz.new_(C$).parse$com_actelion_research_chem_StereoMolecule$S(mol,  String.instantialize(cdx, "utf-8"));
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.UnsupportedEncodingException")){
isOK=false;
} else {
throw e;
}
}
}return (isOK && mol.getAllAtoms$() > 0  ? mol : null);
}, 1);

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, cdxml) {
this.reader=Clazz.new_([Clazz.new_($I$(10,1).c$$S,[cdxml])],$I$(9,1).c$$java_io_Reader);
this.setMyError$S(this.parseXML$());
this.finalizeReader$com_actelion_research_chem_StereoMolecule(mol);
Clazz.new_($I$(11,1).c$$I,[0]).invent$com_actelion_research_chem_StereoMolecule(mol);
return (this.err == null );
});

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$BA',  function (mol, cdx) {
try {
var cdxml=$I$(12).fromCDX$BA(cdx);
return this.parse$com_actelion_research_chem_StereoMolecule$S(mol, cdxml);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return false;
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'processStartElement$S$S',  function (localName, nodeName) {
var id=this.atts.get$O("id");
if ("fragment".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$1.setFragment$S.apply(this, [id]));
return;
}if ("n".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$1.setNode$S.apply(this, [id]));
return;
}if ("b".equals$O(localName)) {
this.objectsByID.put$O$O(id, p$1.setBond$S.apply(this, [id]));
return;
}if ("t".equals$O(localName)) {
this.textBuffer="";
return;
}if ("s".equals$O(localName)) {
this.setKeepChars$Z(true);
return;
}if ("crossingbond".equals$O(localName)) {
var bg=(this.bracketedGroups == null  || this.bracketedGroups.isEmpty$()  ? null : this.bracketedGroups.get$I(this.bracketedGroups.size$() - 1));
if (bg != null  && bg.repeatCount > 0 ) {
bg.innerAtomID=p$1.parseIntStr$S.apply(this, [this.atts.get$O("inneratomid")]);
bg.bondID=p$1.parseIntStr$S.apply(this, [this.atts.get$O("bondid")]);
}return;
}if ("bracketedgroup".equals$O(localName)) {
var usage=this.atts.get$O("bracketusage");
if (this.bracketedGroups == null ) this.bracketedGroups=Clazz.new_($I$(6,1));
var ids=null;
var repeatCount=0;
if ("MultipleGroup".equals$O(usage)) {
var sids=p$1.getTokens$S.apply(this, [this.atts.get$O("bracketedobjectids")]);
ids=Clazz.array(Integer.TYPE, [sids.length]);
for (var i=ids.length; --i >= 0; ) ids[i]=p$1.parseIntStr$S.apply(this, [sids[i]]);

repeatCount=p$1.parseIntStr$S.apply(this, [this.atts.get$O("repeatcount")]);
}this.bracketedGroups.add$O(Clazz.new_($I$(13,1).c$$IA$I,[ids, repeatCount]));
}});

Clazz.newMeth(C$, 'getTokens$S',  function (s) {
return s.split$S("\\s");
}, p$1);

Clazz.newMeth(C$, 'parseIntStr$S',  function (s) {
try {
return Integer.parseInt$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return -2147483648;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'parseDoubleStr$S',  function (s) {
try {
return Double.parseDouble$S(s);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return NaN;
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'setFragment$S',  function (id) {
this.fragments.push$O(this.thisFragmentID=id);
var fragmentNode=(this.thisNode == null  || !this.thisNode.isFragment  ? null : this.thisNode);
if (fragmentNode != null ) {
fragmentNode.setInnerFragmentID$S(id);
}var s=this.atts.get$O("connectionorder");
if (s != null ) {
System.out.println$S(id + " ConnectionOrder is " + s );
this.thisNode.setConnectionOrder$SA(s.trim$().split$S(" "));
}return fragmentNode;
}, p$1);

Clazz.newMeth(C$, 'processEndElement$S',  function (localName) {
if ("fragment".equals$O(localName)) {
this.thisFragmentID=this.fragments.pop$();
return;
}if ("n".equals$O(localName)) {
this.thisNode=(this.nodes.size$() == 0 ? null : this.nodes.pop$());
return;
}if ("BracketedGroup".equals$O(localName)) {
this.bracketedGroups.pop$().process$();
}if ("s".equals$O(localName)) {
this.textBuffer+=this.chars.toString();
}if ("t".equals$O(localName)) {
if (this.thisNode == null ) {
System.out.println$S("CDXMLParser found unassigned 't' text: " + this.textBuffer);
} else {
this.thisNode.text=this.textBuffer;
if (this.thisAtom.elementNumber == 0) {
System.err.println$S("XmlChemDrawReader: Problem with \"" + this.textBuffer + "\"" );
}if (this.thisNode.warning != null ) this.warnings.append$S("Warning: " + this.textBuffer + " " + this.thisNode.warning + "\n" );
}this.textBuffer="";
}this.setKeepChars$Z(false);
});

Clazz.newMeth(C$, 'setNode$S',  function (id) {
var nodeType=this.atts.get$O("nodetype");
if (this.thisNode != null ) this.nodes.push$O(this.thisNode);
if ("_".equals$O(nodeType)) {
this.thisAtom=this.thisNode=null;
return null;
}this.thisAtom=this.thisNode=Clazz.new_($I$(14,1).c$$I$S$S$S$com_actelion_research_chem_moreparsers_CDXParser_CDNode,[this, null, this.atomIndex++, id, nodeType, this.thisFragmentID, this.thisNode]);
p$1.addAtomWithMappedSerialNumber$com_actelion_research_chem_moreparsers_CDXParser_CDNode.apply(this, [this.thisAtom]);
this.bsAtoms.set$I(this.thisAtom.index);
var w=this.atts.get$O("warning");
if (w != null ) {
this.thisNode.warning=w.replace$CharSequence$CharSequence("&apos;", "\'");
this.thisNode.isValid=(w.indexOf$S("ChemDraw can\'t interpret") < 0);
}var element=this.atts.get$O("element");
var s=this.atts.get$O("genericnickname");
if (s != null ) {
element=s;
}this.thisAtom.elementNumber=(!p$1.checkWarningOK$S.apply(this, [w]) ? 0 : element == null  ? 6 : p$1.parseIntStr$S.apply(this, [element]));
this.thisAtom.symbol=$I$(15).cAtomLabel[this.thisAtom.elementNumber];
s=this.atts.get$O("isotope");
if (s != null ) this.thisAtom.isotope=p$1.parseIntStr$S.apply(this, [s]);
s=this.atts.get$O("charge");
if (s != null ) {
this.thisAtom.formalCharge=p$1.parseIntStr$S.apply(this, [s]);
}p$1.setAtom.apply(this, []);
s=this.atts.get$O("attachments");
if (s != null ) {
this.thisNode.setMultipleAttachments$SA(p$1.split$S$S.apply(this, [s.trim$(), " "]));
}s=this.atts.get$O("bondordering");
if (s != null ) {
this.thisNode.setBondOrdering$SA(p$1.split$S$S.apply(this, [s.trim$(), " "]));
}return this.thisNode;
}, p$1);

Clazz.newMeth(C$, 'addAtomWithMappedSerialNumber$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (atom) {
this.atoms.add$O(atom);
var atomSerial=atom.atomSerial;
if (atomSerial != -2147483648) this.atomSymbolicMap.put$O$O("" + atomSerial, atom);
}, p$1);

Clazz.newMeth(C$, 'split$S$S',  function (s, p) {
return s.split$S(p);
}, p$1);

Clazz.newMeth(C$, 'checkWarningOK$S',  function (warning) {
return (warning == null  || warning.indexOf$S("valence") >= 0  || warning.indexOf$S("very close") >= 0  || warning.indexOf$S("two identical colinear bonds") >= 0 );
}, p$1);

Clazz.newMeth(C$, 'setBond$S',  function (id) {
var atom1=this.atts.get$O("b");
var atom2=this.atts.get$O("e");
var a=this.atts.get$O("beginattach");
var beginAttach=(a == null  ? 0 : p$1.parseIntStr$S.apply(this, [a]));
a=this.atts.get$O("endattach");
var endAttach=(a == null  ? 0 : p$1.parseIntStr$S.apply(this, [a]));
var s=this.atts.get$O("order");
var disp=this.atts.get$O("display");
var disp2=this.atts.get$O("display2");
var type=0;
var invertEnds=false;
if (disp == null ) {
if (s == null ) {
type=1;
} else if (s.equals$O("1.5")) {
type=64;
} else {
if (s.indexOf$S(".") > 0 && !"Dash".equals$O(disp2) ) {
s=s.substring$I$I(0, s.indexOf$S("."));
}type=p$1.getBondTypeFromString$S.apply(this, [s]);
}} else if (disp.equals$O("WedgeBegin")) {
type=257;
} else if (disp.equals$O("Hash") || disp.equals$O("WedgedHashBegin") ) {
type=129;
} else if (disp.equals$O("WedgeEnd")) {
invertEnds=true;
type=257;
} else if (disp.equals$O("WedgedHashEnd")) {
invertEnds=true;
type=129;
} else if (disp.equals$O("Bold")) {
type=1;
} else if (disp.equals$O("Wavy")) {
type=-1;
}if (type == 0) {
System.err.println$S("XmlChemDrawReader ignoring bond type " + s);
return null;
}var b=(invertEnds ? Clazz.new_($I$(2,1).c$$S$S$S$I,[this, null, id, atom2, atom1, type]) : Clazz.new_($I$(2,1).c$$S$S$S$I,[this, null, id, atom1, atom2, type]));
var node1=this.atoms.get$I(b.atomIndex1);
var node2=this.atoms.get$I(b.atomIndex2);
if (type == -1) {
if (!this.nostereo.contains$O(node1)) this.nostereo.add$O(node1);
if (!this.nostereo.contains$O(node2)) this.nostereo.add$O(node2);
}if (node1.hasMultipleAttachments) {
node1.attachedAtom=node2;
return b;
} else if (node2.hasMultipleAttachments) {
node2.attachedAtom=node1;
return b;
}if (node1.isFragment && beginAttach == 0 ) beginAttach=1;
if (node2.isFragment && endAttach == 0 ) endAttach=1;
if (beginAttach > 0) {
(invertEnds ? node2 : node1).addAttachedAtom$com_actelion_research_chem_moreparsers_CDXParser_CDBond$I(b, beginAttach);
}if (endAttach > 0) {
(invertEnds ? node1 : node2).addAttachedAtom$com_actelion_research_chem_moreparsers_CDXParser_CDBond$I(b, endAttach);
}if (node1.isExternalPt) {
node1.setInternalAtom$com_actelion_research_chem_moreparsers_CDXParser_CDNode(node2);
}if (node2.isExternalPt) {
node2.setInternalAtom$com_actelion_research_chem_moreparsers_CDXParser_CDNode(node1);
}return p$1.addBond$com_actelion_research_chem_moreparsers_CDXParser_CDBond.apply(this, [b]);
}, p$1);

Clazz.newMeth(C$, 'addBond$com_actelion_research_chem_moreparsers_CDXParser_CDBond',  function (b) {
b.index=this.bonds.size$();
this.bonds.add$O(b);
return b;
}, p$1);

Clazz.newMeth(C$, 'getBondTypeFromString$S',  function (s) {
switch (s) {
case "1":
return 1;
case "2":
return 2;
case "3":
return 4;
default:
return 32;
}
}, p$1);

Clazz.newMeth(C$, 'setAtom',  function () {
var xy=this.atts.get$O("p");
var tokens=p$1.getTokens$S.apply(this, [xy]);
var x=p$1.parseDoubleStr$S.apply(this, [tokens[0]]);
var y=p$1.parseDoubleStr$S.apply(this, [tokens[1]]);
if (x < this.minX ) this.minX=x;
if (x > this.maxX ) this.maxX=x;
if (y < this.minY ) this.minY=y;
if (y > this.maxY ) this.maxY=y;
this.thisAtom.set$D$D(x, y);
}, p$1);

Clazz.newMeth(C$, 'finalizeReader$com_actelion_research_chem_StereoMolecule',  function (mol) {
p$1.fixConnections.apply(this, []);
p$1.fixInvalidAtoms.apply(this, []);
p$1.centerAndScale.apply(this, []);
p$1.createMol$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
});

Clazz.newMeth(C$, 'createMol$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
var a=this.atoms.get$I(i);
var ia=mol.addAtom$D$D(a.x, a.y);
a.index=ia;
mol.setAtomCharge$I$I(ia, a.formalCharge);
mol.setAtomicNo$I$I(ia, a.elementNumber);
if (a.isotope > 0) mol.setAtomMass$I$I(ia, a.isotope);
}
for (var i=this.bsBonds.nextSetBit$I(0); i >= 0; i=this.bsBonds.nextSetBit$I(i + 1)) {
var bond=this.bonds.get$I(i);
var ib=mol.addBond$I$I(bond.atom1.index, bond.atom2.index);
mol.setBondType$I$I(ib, bond.type);
}
}, p$1);

Clazz.newMeth(C$, 'fixConnections',  function () {
for (var i=this.atoms.size$(); --i >= 0; ) {
var a=this.atoms.get$I(i);
if (a.isFragment || a.hasMultipleAttachments ) a.fixAttachments$();
}
for (var i=0, n=this.bonds.size$(); i < n; i++) {
var b=this.bonds.get$I(i);
if (b == null ) {
continue;
}var a1=this.atoms.get$I(b.atomIndex1);
var a2=this.atoms.get$I(b.atomIndex2);
a1.isConnected=true;
a2.isConnected=true;
if (b.type == -1 || this.nostereo.contains$O(a1) != this.nostereo.contains$O(a2)  ) {
b.type=1;
}}
}, p$1);

Clazz.newMeth(C$, 'centerAndScale',  function () {
if (this.minX > this.maxX ) return;
var sum=0;
var n=0;
var lenH=1;
for (var i=this.bonds.size$(); --i >= 0; ) {
var a1=this.atoms.get$I(this.bonds.get$I(i).atomIndex1);
var a2=this.atoms.get$I(this.bonds.get$I(i).atomIndex2);
var d=a1.distance$com_actelion_research_chem_moreparsers_CDXParser_CDNode(a2);
if (a1.elementNumber > 1 && a2.elementNumber > 1 ) {
sum+=d;
++n;
} else {
lenH=d;
}}
var f=(sum > 0  ? 1.45 * n / sum : lenH > 0  ? 1 / lenH : 1);
if (f > 0.5 ) f=1;
f*=10;
var cx=(this.maxX + this.minX) / 2;
var cy=(this.maxY + this.minY) / 2;
for (var i=this.atoms.size$(); --i >= 0; ) {
var a=this.atoms.get$I(i);
a.x=(a.x - cx) * f;
a.y=(a.y - cy) * f;
}
}, p$1);

Clazz.newMeth(C$, 'fixInvalidAtoms',  function () {
for (var i=this.atoms.size$(); --i >= 0; ) {
var a=this.atoms.get$I(i);
a.atomSerial=-2147483648;
if (a.isFragment || a.isExternalPt || !a.isConnected && (!a.isValid || a.elementNumber == 6  || a.elementNumber == 0 )   ) {
this.bsAtoms.clear$I(a.index);
}}
for (var p=0, i=this.bsAtoms.nextSetBit$I(0); i >= 0; i=this.bsAtoms.nextSetBit$I(i + 1)) {
var a=this.atoms.get$I(i);
a.atomSerial=++p;
}
for (var i=this.bonds.size$(); --i >= 0; ) {
var b=this.bonds.get$I(i);
if (b.atom1.atomSerial >= 0 && b.atom2.atomSerial >= 0 ) {
this.bsBonds.set$I(i);
} else {
}}
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXParser, "CDNode", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.isValid=true;
this.atomSerial=-2147483648;
},1);

C$.$fields$=[['Z',['isValid','isConnected','isExternalPt','isFragment','hasMultipleAttachments'],'D',['x','y'],'I',['intID','atomSerial','index','elementNumber','formalCharge','isotope'],'S',['warning','id','nodeType','outerFragmentID','innerFragmentID','text','elementSymbol','symbol'],'O',['parentNode','com.actelion.research.chem.moreparsers.CDXParser.CDNode','orderedConnectionBonds','java.util.List','internalAtom','com.actelion.research.chem.moreparsers.CDXParser.CDNode','orderedExternalPoints','java.util.List','attachments','String[]','+bondOrdering','+connectionOrder','attachedAtom','com.actelion.research.chem.moreparsers.CDXParser.CDNode']]]

Clazz.newMeth(C$, 'c$$I$S$S$S$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (index, id, nodeType, fragmentID, parent) {
;C$.$init$.apply(this);
this.id=id;
this.index=index;
this.outerFragmentID=fragmentID;
this.atomSerial=this.intID=Integer.parseInt$S(id);
this.nodeType=nodeType;
this.parentNode=parent;
this.isFragment="Fragment".equals$O(nodeType) || "Nickname".equals$O(nodeType) ;
this.isExternalPt="ExternalConnectionPoint".equals$O(nodeType);
}, 1);

Clazz.newMeth(C$, 'set$D$D',  function (x, y) {
this.x=x;
this.y=y;
});

Clazz.newMeth(C$, 'setInnerFragmentID$S',  function (id) {
this.innerFragmentID=id;
});

Clazz.newMeth(C$, 'setBondOrdering$SA',  function (bondOrdering) {
this.bondOrdering=bondOrdering;
});

Clazz.newMeth(C$, 'setConnectionOrder$SA',  function (connectionOrder) {
this.connectionOrder=connectionOrder;
});

Clazz.newMeth(C$, 'setMultipleAttachments$SA',  function (attachments) {
this.attachments=attachments;
this.hasMultipleAttachments=true;
});

Clazz.newMeth(C$, 'addExternalPoint$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (externalPoint) {
if (this.orderedExternalPoints == null ) this.orderedExternalPoints=Clazz.new_($I$(1,1));
var i=this.orderedExternalPoints.size$();
while (--i >= 0 && this.orderedExternalPoints.get$I(i).intID >= externalPoint.internalAtom.intID ){
}
this.orderedExternalPoints.add$I$O(++i, externalPoint);
});

Clazz.newMeth(C$, 'setInternalAtom$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (a) {
this.internalAtom=a;
if (this.parentNode != null ) {
this.parentNode.addExternalPoint$com_actelion_research_chem_moreparsers_CDXParser_CDNode(this);
}});

Clazz.newMeth(C$, 'addAttachedAtom$com_actelion_research_chem_moreparsers_CDXParser_CDBond$I',  function (bond, pt) {
if (this.orderedConnectionBonds == null ) this.orderedConnectionBonds=Clazz.new_($I$(1,1));
var i=this.orderedConnectionBonds.size$();
while (--i >= 0 && (this.orderedConnectionBonds.get$I(i)[0]).intValue$() > pt ){
}
this.orderedConnectionBonds.add$I$O(++i, Clazz.array(java.lang.Object, -1, [Integer.valueOf$I(pt), bond]));
});

Clazz.newMeth(C$, 'fixAttachments$',  function () {
if (this.hasMultipleAttachments && this.attachedAtom != null  ) {
var order=32;
var a1=this.attachedAtom;
for (var i=this.attachments.length; --i >= 0; ) {
var a=this.b$['com.actelion.research.chem.moreparsers.CDXParser'].objectsByID.get$O(this.attachments[i]);
if (a != null ) {
this.b$['com.actelion.research.chem.moreparsers.CDXParser'].bsBonds.set$I(this.b$['com.actelion.research.chem.moreparsers.CDXParser'].bonds.size$());
p$1.addBond$com_actelion_research_chem_moreparsers_CDXParser_CDBond.apply(this.b$['com.actelion.research.chem.moreparsers.CDXParser'], [Clazz.new_($I$(2,1).c$$S$S$S$I,[this, null, null, a1.id, a.id, order])]);
}}
}if (this.orderedExternalPoints == null  || this.text == null  ) return;
var n=this.orderedExternalPoints.size$();
if (n != this.orderedConnectionBonds.size$()) {
System.err.println$S("CDXMLParser cannot fix attachments for fragment " + this.text);
return;
}if (this.bondOrdering == null ) {
this.bondOrdering=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.bondOrdering[i]=(this.orderedConnectionBonds.get$I(i)[1]).id;
}
}if (this.connectionOrder == null ) {
this.connectionOrder=Clazz.array(String, [n]);
for (var i=0; i < n; i++) {
this.connectionOrder[i]=this.orderedExternalPoints.get$I(i).id;
}
}for (var i=0; i < n; i++) {
var b=this.b$['com.actelion.research.chem.moreparsers.CDXParser'].objectsByID.get$O(this.bondOrdering[i]);
var a=(this.b$['com.actelion.research.chem.moreparsers.CDXParser'].objectsByID.get$O(this.connectionOrder[i])).internalAtom;
p$2.updateExternalBond$com_actelion_research_chem_moreparsers_CDXParser_CDBond$com_actelion_research_chem_moreparsers_CDXParser_CDNode.apply(this, [b, a]);
}
});

Clazz.newMeth(C$, 'updateExternalBond$com_actelion_research_chem_moreparsers_CDXParser_CDBond$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (bond2f, intAtom) {
this.b$['com.actelion.research.chem.moreparsers.CDXParser'].bsBonds.set$I(bond2f.index);
if (bond2f.atomIndex2 == this.index) {
bond2f.atomIndex2=intAtom.index;
bond2f.atom2=intAtom;
} else if (bond2f.atomIndex1 == this.index) {
bond2f.atomIndex1=intAtom.index;
bond2f.atom1=intAtom;
} else {
System.err.println$S("CDXMLParser attachment failed! " + intAtom + " " + bond2f );
}}, p$2);

Clazz.newMeth(C$, 'toString',  function () {
return "[CDNode " + this.id + " " + this.elementSymbol + " " + this.elementNumber + " index=" + this.index + " ext=" + this.isExternalPt + " frag=" + this.isFragment + " " + this.elementSymbol + " " + new Double(this.x).toString() + " " + new Double(this.y).toString() + "]" ;
});

Clazz.newMeth(C$, 'distance$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (a2) {
return Math.sqrt(this.x * a2.x + this.y * a2.y);
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXParser, "CDBond", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['index','atomIndex1','atomIndex2','type'],'S',['id','id1','id2'],'O',['atom1','com.actelion.research.chem.moreparsers.CDXParser.CDNode','+atom2']]]

Clazz.newMeth(C$, 'c$$S$S$S$I',  function (id, id1, id2, type) {
;C$.$init$.apply(this);
this.atomIndex1=(this.atom1=this.b$['com.actelion.research.chem.moreparsers.CDXParser'].objectsByID.get$O(id1)).index;
this.atomIndex2=(this.atom2=this.b$['com.actelion.research.chem.moreparsers.CDXParser'].objectsByID.get$O(id2)).index;
this.type=type;
this.id=id;
this.id1=id1;
this.id2=id2;
}, 1);

Clazz.newMeth(C$, 'getOtherNode$com_actelion_research_chem_moreparsers_CDXParser_CDNode',  function (a) {
return this.b$['com.actelion.research.chem.moreparsers.CDXParser'].atoms.get$I(this.atomIndex1 == a.index ? this.atomIndex2 : this.atomIndex1);
});

Clazz.newMeth(C$, 'toString',  function () {
return "[CDBond " + this.id + " id1=" + this.id1 + " id2=" + this.id2 + C$.superclazz.prototype.toString.apply(this, []) + "]" ;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.CDXParser, "BracketedGroup", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['bondID','innerAtomID','repeatCount'],'O',['ids','int[]']]]

Clazz.newMeth(C$, 'c$$IA$I',  function (ids, repeatCount) {
;C$.$init$.apply(this);
this.ids=ids;
this.repeatCount=repeatCount;
}, 1);

Clazz.newMeth(C$, 'process$',  function () {
System.out.println$S("bracketed groups not implmented");
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
