(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.entity"),I$=[[0,'com.actelion.research.util.datamodel.IntArray','java.util.ArrayList','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FlexophorePoint");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id','hash'],'S',['idcode'],'O',['iaInteractionType','com.actelion.research.util.datamodel.IntArray','+iaOriginalAtomIndex','liAtomIndexLinkerId','java.util.List']]]

Clazz.newMeth(C$, 'c$$I',  function (id) {
;C$.$init$.apply(this);
this.id=id;
this.hash=-1;
this.iaInteractionType=Clazz.new_($I$(1,1).c$$I,[6]);
this.iaOriginalAtomIndex=Clazz.new_($I$(1,1).c$$I,[12]);
this.liAtomIndexLinkerId=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getId$',  function () {
return this.id;
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var equal=true;
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.descriptor.flexophore.entity.FlexophorePoint"))) {
return false;
}var a=obj;
if (!this.idcode.equals$O(a.idcode)) {
equal=false;
} else if (!this.iaInteractionType.equals$O(a.iaInteractionType)) {
equal=false;
}return equal;
});

Clazz.newMeth(C$, 'calculateHashCode$',  function () {
if (this.idcode == null ) {
this.hash=-1;
return;
}var hashIdCode=this.idcode.hashCode$();
var hashArrayInteractionType=this.iaInteractionType.hashCode$();
this.hash=hashArrayInteractionType ^ hashIdCode;
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return this.hash;
});

Clazz.newMeth(C$, 'setInteractionType$BA',  function (arrInteractionType) {
this.iaInteractionType.clear$();
this.iaInteractionType.add$BA(arrInteractionType);
this.iaInteractionType.calculateHashCode$();
this.calculateHashCode$();
});

Clazz.newMeth(C$, 'getInteractionTypes$',  function () {
return this.iaInteractionType;
});

Clazz.newMeth(C$, 'getOriginalAtomIndex$',  function () {
return this.iaOriginalAtomIndex.toList$();
});

Clazz.newMeth(C$, 'clearOriginalAtomIndex$',  function () {
this.iaOriginalAtomIndex.clear$();
});

Clazz.newMeth(C$, 'addOriginalAtomIndex$I',  function (originalAtomIndex) {
this.iaOriginalAtomIndex.add$I(originalAtomIndex);
});

Clazz.newMeth(C$, 'getAtomIndexLinkerId$',  function () {
return this.liAtomIndexLinkerId;
});

Clazz.newMeth(C$, 'addArrOriginalAtomIndexRGroups$com_actelion_research_chem_descriptor_flexophore_entity_AtomIndexLinkerId',  function (atomIndexLinkerId) {
this.liAtomIndexLinkerId.add$O(atomIndexLinkerId);
});

Clazz.newMeth(C$, 'getIdCode$',  function () {
return this.idcode;
});

Clazz.newMeth(C$, 'setIdCode$S',  function (idcode) {
this.idcode=idcode;
this.calculateHashCode$();
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(3,1));
sb.append$S("FlexophorePoint [iaInteractionType=");
sb.append$O(this.iaInteractionType);
sb.append$S(", iaOriginalAtomIndex=");
sb.append$O(this.iaOriginalAtomIndex);
sb.append$S(", liAtomIndexLinkerId=");
sb.append$O(this.liAtomIndexLinkerId);
sb.append$S(", idcode=");
sb.append$S(this.idcode);
sb.append$S(", id=");
sb.append$I(this.id);
sb.append$S(", hash=");
sb.append$I(this.hash);
sb.append$S("]");
return sb.toString();
});

Clazz.newMeth(C$, 'toStringInteractionTypes$',  function () {
var types=this.iaInteractionType.length$();
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < types; i++) {
sb.append$I(this.iaInteractionType.get$I(i));
if (i < types - 1) {
sb.append$S("; ");
}}
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
