(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SortedPair", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['a','b']]]

Clazz.newMeth(C$, 'c$$I$I',  function (a, b) {
;C$.$init$.apply(this);
this.a=a > b ? a : b;
this.b=a > b ? b : a;
}, 1);

Clazz.newMeth(C$, 'hashCode$',  function () {
return  new Integer(this.a).hashCode$() ^  new Integer(this.b).hashCode$();
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (obj === this ) return true;
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.forcefield.mmff.SortedPair"))) return false;
var that=obj;
return this.a == that.a && this.b == that.b ;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_forcefield_mmff_SortedPair','compareTo$O'],  function (that) {
if (this.a > that.a) return 1;
if (this.a < that.a) return -1;
if (this.b > that.b) return 1;
if (this.b < that.b) return -1;
return 0;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.a + "," + this.b ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
