(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.PeriodicTable','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Dfsb", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var a1r=$I$(2,"row$I",[mol.getAtomicNo$I(a1)]);
var a2r=$I$(2,"row$I",[mol.getAtomicNo$I(a2)]);
var a3r=$I$(2,"row$I",[mol.getAtomicNo$I(a3)]);
if (a1r > a3r) a1r=($I$(3,"s$O$O",[Integer.valueOf$I(a3r), Integer.valueOf$I(a3r=a1r)])).$c();
return $I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [1, 0, 2]), Clazz.array(Integer.TYPE, -1, [a2r, a1r, a3r]), this]);
});

Clazz.newMeth(C$, 'kb$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var a1r=$I$(2,"row$I",[mol.getAtomicNo$I(a1)]);
var a3r=$I$(2,"row$I",[mol.getAtomicNo$I(a3)]);
var at=a1r > a3r ? 4 : 3;
var idx=this.index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
return idx >= 0 ? (this.table[idx][at]).doubleValue$() : 0.0;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-01 14:15:20 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
