(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'com.actelion.research.chem.mcs.PossibleMappingsFrag2Mol','java.util.LinkedList','java.util.ArrayList','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubStructSearchExhaustiveTreeWalker");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['maxCapacityMatchListContainerReached'],'I',['maxCapacity'],'O',['mol','com.actelion.research.chem.StereoMolecule','+frag','arrTotalFormularMol','int[]','+arrTotalFormularFrag','+arrCardinalityFragment','arrVisited','boolean[]','arrMapMolecule','int[]','liMatches','java.util.List','arrProcessingArray','com.actelion.research.chem.mcs.PossibleMappingsFrag2Mol[]','arrFragIndexConnected','int[]','+arrMapFrag2ProcessingArray','liQueue','java.util.LinkedList','liFragmentAtomNeighbours','java.util.List']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.arrTotalFormularMol=Clazz.array(Integer.TYPE, [83]);
this.arrTotalFormularFrag=Clazz.array(Integer.TYPE, [83]);
this.arrCardinalityFragment=Clazz.array(Integer.TYPE, [256]);
this.arrFragIndexConnected=Clazz.array(Integer.TYPE, [256]);
this.arrMapFrag2ProcessingArray=Clazz.array(Integer.TYPE, [256]);
this.arrMapMolecule=Clazz.array(Integer.TYPE, [256]);
this.arrVisited=Clazz.array(Boolean.TYPE, [256]);
this.arrProcessingArray=Clazz.array($I$(1), [256]);
this.liQueue=Clazz.new_($I$(2,1));
this.liFragmentAtomNeighbours=Clazz.new_($I$(3,1));
this.maxCapacity=64;
p$1.initProcessingArray.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'setMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.mol=mol;
});

Clazz.newMeth(C$, 'setFragment$com_actelion_research_chem_StereoMolecule',  function (frag) {
this.frag=frag;
p$1.calculateCardinalityFragment.apply(this, []);
});

Clazz.newMeth(C$, 'findFragmentInMolecule$',  function () {
if (!p$1.isFulfillPrechecks.apply(this, [])) {
return 0;
}this.maxCapacityMatchListContainerReached=false;
var atomsFragment=this.frag.getAtoms$();
var atomsMolecule=this.mol.getAtoms$();
$I$(4).fill$IA$I$I$I(this.arrMapMolecule, 0, atomsMolecule, -1);
var arrMapFragment=Clazz.array(Integer.TYPE, [atomsFragment]);
this.liMatches=Clazz.new_($I$(3,1));
$I$(4).fill$IA$I(arrMapFragment, -1);
var liSortedMoleculeAtomNeighbours=Clazz.new_($I$(3,1));
p$1.determineProcessingArray.apply(this, []);
var openEnds=true;
var indexProcessingArray=0;
 searchcompleted :  maxCapacityMatchListContainerReached : while (openEnds){
var possMapFrag2MolCurrent=this.arrProcessingArray[indexProcessingArray];
while (possMapFrag2MolCurrent.empty$()){
if (false) {
System.err.println$S("possMapFrag2MolCurrent empty");
System.out.println$();
}--indexProcessingArray;
if (indexProcessingArray < 0) {
openEnds=false;
break searchcompleted;
} else {
possMapFrag2MolCurrent=this.arrProcessingArray[indexProcessingArray];
var indexAtomFragment=this.arrProcessingArray[indexProcessingArray].getIndexAtomFrag$();
var indexMappedAtomMolecule=arrMapFragment[indexAtomFragment];
arrMapFragment[indexAtomFragment]=-1;
this.arrMapMolecule[indexMappedAtomMolecule]=-1;
}}
var indexMappedAtomMolecule=possMapFrag2MolCurrent.pollIndexMappingAtomMolecule$();
var indexAtomFragment=possMapFrag2MolCurrent.getIndexAtomFrag$();
arrMapFragment[indexAtomFragment]=indexMappedAtomMolecule;
this.arrMapMolecule[indexMappedAtomMolecule]=indexAtomFragment;
if (false) {
System.out.println$S("indexProcessingArray " + indexProcessingArray + " indexAtomFragment " + indexAtomFragment + " indexMappedAtomMolecule " + indexMappedAtomMolecule );
}++indexProcessingArray;
if (indexProcessingArray == atomsFragment) {
if (this.liMatches.size$() == this.maxCapacity) {
this.maxCapacityMatchListContainerReached=true;
break maxCapacityMatchListContainerReached;
}this.liMatches.add$O(arrMapFragment);
var arrMapFragmentNew=Clazz.array(Integer.TYPE, [atomsFragment]);
if (false) {
System.arraycopy$O$I$O$I$I(arrMapFragment, 0, arrMapFragmentNew, 0, indexProcessingArray);
arrMapFragment=arrMapFragmentNew;
--indexProcessingArray;
arrMapFragment[indexAtomFragment]=-1;
this.arrMapMolecule[indexMappedAtomMolecule]=-1;
} else {
indexProcessingArray=0;
arrMapFragmentNew[0]=arrMapFragment[0];
for (var i=1; i < atomsFragment; i++) {
arrMapFragmentNew[i]=-1;
this.arrProcessingArray[i].resetMappingMolecules$();
}
arrMapFragment=arrMapFragmentNew;
}} else {
var possMapFrag2MolNext=this.arrProcessingArray[indexProcessingArray];
p$1.getAvailableMoleculeAtomNeighbours$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol$IA$IA$java_util_List.apply(this, [possMapFrag2MolNext, arrMapFragment, this.arrMapMolecule, liSortedMoleculeAtomNeighbours]);
for (var indexAtomMoleculeAvailableNeighbour, $indexAtomMoleculeAvailableNeighbour = liSortedMoleculeAtomNeighbours.iterator$(); $indexAtomMoleculeAvailableNeighbour.hasNext$()&&((indexAtomMoleculeAvailableNeighbour=($indexAtomMoleculeAvailableNeighbour.next$()).intValue$()),1);) {
possMapFrag2MolNext.addIndexMappingAtomMolecule$I(indexAtomMoleculeAvailableNeighbour);
}
}}
return this.liMatches.size$();
});

Clazz.newMeth(C$, 'getMatches$',  function () {
return this.liMatches;
});

Clazz.newMeth(C$, 'determineProcessingArray',  function () {
for (var i=0; i < this.frag.getAtoms$(); i++) {
this.arrProcessingArray[i].reset$();
this.arrVisited[i]=false;
}
p$1.determinePossibleMappingsFrag2MolStart.apply(this, []);
var possMapFrag2MolStart=this.arrProcessingArray[0];
var indexProcessingArray=0;
++indexProcessingArray;
this.arrVisited[possMapFrag2MolStart.getIndexAtomFrag$()]=true;
this.liQueue.clear$();
this.liQueue.add$O(possMapFrag2MolStart);
this.liFragmentAtomNeighbours.clear$();
while (!this.liQueue.isEmpty$()){
var possibleMappingsFrag2MolParent=this.liQueue.pollLast$();
var indexAtomFragParent=possibleMappingsFrag2MolParent.getIndexAtomFrag$();
p$1.getFragmentAtomNeighbours$I$java_util_List.apply(this, [indexAtomFragParent, this.liFragmentAtomNeighbours]);
for (var indexAtomFragNeighbour, $indexAtomFragNeighbour = this.liFragmentAtomNeighbours.iterator$(); $indexAtomFragNeighbour.hasNext$()&&((indexAtomFragNeighbour=($indexAtomFragNeighbour.next$()).intValue$()),1);) {
if (!this.arrVisited[indexAtomFragNeighbour]) {
this.arrVisited[indexAtomFragNeighbour]=true;
var possibleMappingsFrag2Mol=this.arrProcessingArray[indexProcessingArray];
possibleMappingsFrag2Mol.setIndexAtomFrag$I(indexAtomFragNeighbour);
possibleMappingsFrag2MolParent.addChild$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol(possibleMappingsFrag2Mol);
++indexProcessingArray;
this.liQueue.push$O(possibleMappingsFrag2Mol);
}}
}
p$1.addRingClosures$com_actelion_research_chem_mcs_PossibleMappingsFrag2MolA.apply(this, [this.arrProcessingArray]);
}, p$1);

Clazz.newMeth(C$, 'addRingClosures$com_actelion_research_chem_mcs_PossibleMappingsFrag2MolA',  function (arrProcessingArray) {
var atomsFrag=this.frag.getAtoms$();
for (var i=0; i < atomsFrag; i++) {
this.arrMapFrag2ProcessingArray[arrProcessingArray[i].getIndexAtomFrag$()]=i;
}
for (var i=atomsFrag - 1; i >= 0; i--) {
var possibleMappingsFrag2Mol=arrProcessingArray[i];
var indexAtomFragment=possibleMappingsFrag2Mol.getIndexAtomFrag$();
var nNeighboursInTree=0;
if (possibleMappingsFrag2Mol.getParent$() != null ) {
++nNeighboursInTree;
}var childs=possibleMappingsFrag2Mol.getChilds$();
nNeighboursInTree+=childs;
var nConnected=this.frag.getConnAtoms$I(indexAtomFragment);
if (nNeighboursInTree != nConnected) {
$I$(4).fill$IA$I$I$I(this.arrFragIndexConnected, 0, atomsFrag, 0);
if (possibleMappingsFrag2Mol.getParent$() != null ) {
this.arrFragIndexConnected[possibleMappingsFrag2Mol.getParent$().getIndexAtomFrag$()]=1;
}for (var j=0; j < childs; j++) {
var possMapFrag2MolChild=possibleMappingsFrag2Mol.getChild$I(j);
this.arrFragIndexConnected[possMapFrag2MolChild.getIndexAtomFrag$()]=1;
}
for (var j=0; j < nConnected; j++) {
var indexAtomFragConnected=this.frag.getConnAtom$I$I(indexAtomFragment, j);
if (this.arrFragIndexConnected[indexAtomFragConnected] == 0) {
var positionInProcessingArrayConnectedFragmentAtom=this.arrMapFrag2ProcessingArray[indexAtomFragConnected];
var positionInProcessingArrayFragmentAtom=possibleMappingsFrag2Mol.getIndexProcessingArray$();
if (positionInProcessingArrayConnectedFragmentAtom < positionInProcessingArrayFragmentAtom) {
possibleMappingsFrag2Mol.addIndexCounterAtomFragmentRingClosure$I(indexAtomFragConnected);
}}}
}}
}, p$1);

Clazz.newMeth(C$, 'getFragmentAtomNeighbours$I$java_util_List',  function (indexAtomFragment, liSortedFragmentAtomNeighbours) {
liSortedFragmentAtomNeighbours.clear$();
var nConnectedFrag=this.frag.getConnAtoms$I(indexAtomFragment);
for (var i=0; i < nConnectedFrag; i++) {
var indexConnAtomFrag=this.frag.getConnAtom$I$I(indexAtomFragment, i);
liSortedFragmentAtomNeighbours.add$O(Integer.valueOf$I(indexConnAtomFrag));
}
}, p$1);

Clazz.newMeth(C$, 'getAvailableMoleculeAtomNeighbours$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol$IA$IA$java_util_List',  function (possMapFrag2MolNext, arrMapFragment, arrMapMolecule, liSortedMoleculeAtomNeighbours) {
var possMapFrag2MolParent=possMapFrag2MolNext.getParent$();
var indexAtomMoleculeParent=arrMapFragment[possMapFrag2MolParent.getIndexAtomFrag$()];
var indexAtomFragment=possMapFrag2MolNext.getIndexAtomFrag$();
var indexAtomFragmentParent=possMapFrag2MolParent.getIndexAtomFrag$();
liSortedMoleculeAtomNeighbours.clear$();
var nConnectedMol=this.mol.getConnAtoms$I(indexAtomMoleculeParent);
var indexBondFrag=this.frag.getBond$I$I(indexAtomFragmentParent, indexAtomFragment);
for (var i=0; i < nConnectedMol; i++) {
var indexConnAtomMol=this.mol.getConnAtom$I$I(indexAtomMoleculeParent, i);
if (arrMapMolecule[indexConnAtomMol] != -1) {
continue;
}if (p$1.areAtomsSimilar$I$I.apply(this, [indexConnAtomMol, indexAtomFragment])) {
var indexBondMol=this.mol.getBond$I$I(indexAtomMoleculeParent, indexConnAtomMol);
if (p$1.areBondsSimilar$I$I.apply(this, [indexBondMol, indexBondFrag])) {
var ringsOk=true;
if (possMapFrag2MolNext.getRingClosures$() > 0) {
if (!p$1.isRingClosureBondMatch$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol$I$IA.apply(this, [possMapFrag2MolNext, indexConnAtomMol, arrMapFragment])) {
ringsOk=false;
}}if (ringsOk) {
liSortedMoleculeAtomNeighbours.add$O(Integer.valueOf$I(indexConnAtomMol));
}}}}
}, p$1);

Clazz.newMeth(C$, 'isRingClosureBondMatch$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol$I$IA',  function (possMapFrag2MolNext, indexConnAtomMol, arrMapFragment) {
var ringClosuresMatch=true;
var ringClosures=possMapFrag2MolNext.getRingClosures$();
var indexAtomFragment=possMapFrag2MolNext.getIndexAtomFrag$();
for (var i=0; i < ringClosures; i++) {
var indexCounterAtomFragmentRingClosure=possMapFrag2MolNext.getIndexCounterAtomFragmentRingClosure$I(i);
var indexCounterAtomMoleculeRingClosure=arrMapFragment[indexCounterAtomFragmentRingClosure];
var indexBondFrag=this.frag.getBond$I$I(indexCounterAtomFragmentRingClosure, indexAtomFragment);
var indexBondMol=this.mol.getBond$I$I(indexCounterAtomMoleculeRingClosure, indexConnAtomMol);
if (indexBondMol == -1) {
ringClosuresMatch=false;
break;
}if (!p$1.areBondsSimilar$I$I.apply(this, [indexBondMol, indexBondFrag])) {
ringClosuresMatch=false;
break;
}}
return ringClosuresMatch;
}, p$1);

Clazz.newMeth(C$, 'areAtomsSimilar$I$I',  function (atomMolecule, atomFragment) {
var moleculeConnAtoms=this.mol.getConnAtoms$I(atomMolecule);
var fragmentConnAtoms=this.frag.getConnAtoms$I(atomFragment);
if (fragmentConnAtoms > moleculeConnAtoms) return false;
if (this.frag.getAtomicNo$I(atomFragment) == 0) return true;
if (this.mol.getAtomicNo$I(atomMolecule) == 0) return false;
if (this.mol.getAtomicNo$I(atomMolecule) != this.frag.getAtomicNo$I(atomFragment)) {
return false;
}return true;
}, p$1);

Clazz.newMeth(C$, 'areBondsSimilar$I$I',  function (moleculeBond, fragmentBond) {
var similar=false;
if (this.mol.isDelocalizedBond$I(moleculeBond) && this.frag.isDelocalizedBond$I(fragmentBond) ) {
similar=true;
} else if (this.mol.getBondType$I(moleculeBond) == this.frag.getBondType$I(fragmentBond)) {
similar=true;
}if (!similar) {
return false;
}return similar;
}, p$1);

Clazz.newMeth(C$, 'isFulfillPrechecks',  function () {
var precheck=true;
if (this.frag.getAtoms$() > this.mol.getAtoms$()) {
return false;
} else if (this.frag.getBonds$() > this.mol.getBonds$()) {
return false;
}if (false) {
for (var i=0; i < this.arrTotalFormularMol.length; i++) {
if (this.arrTotalFormularMol[i] - this.arrTotalFormularFrag[i] < 0) {
precheck=false;
break;
}}
}return precheck;
}, p$1);

Clazz.newMeth(C$, 'initProcessingArray',  function () {
var possMapFrag2MolStart=Clazz.new_($I$(1,1).c$$I$I,[0, 256]);
this.arrProcessingArray[0]=possMapFrag2MolStart;
for (var i=1; i < this.arrProcessingArray.length; i++) {
this.arrProcessingArray[i]=Clazz.new_($I$(1,1).c$$I,[i]);
}
}, p$1);

Clazz.newMeth(C$, 'determinePossibleMappingsFrag2MolStart',  function () {
var maxCardinality=-1;
var indexAtomFragMaxCard=-1;
for (var i=0; i < this.frag.getAtoms$(); i++) {
if (this.arrCardinalityFragment[i] > maxCardinality) {
maxCardinality=this.arrCardinalityFragment[i];
indexAtomFragMaxCard=i;
}}
var possMapFrag2MolStart=this.arrProcessingArray[0];
possMapFrag2MolStart.setIndexAtomFrag$I(indexAtomFragMaxCard);
for (var i=0; i < this.mol.getAtoms$(); i++) {
if (p$1.areAtomsSimilar$I$I.apply(this, [i, indexAtomFragMaxCard])) {
possMapFrag2MolStart.addIndexMappingAtomMolecule$I(i);
}}
if (false) {
if (possMapFrag2MolStart.empty$()) {
System.out.println$S("No mapping start atom found in molecule.");
}}}, p$1);

Clazz.newMeth(C$, 'calculateCardinalityFragment',  function () {
for (var i=0; i < this.frag.getAtoms$(); i++) {
this.arrCardinalityFragment[i]=C$.calculateCardinality$com_actelion_research_chem_StereoMolecule$I(this.frag, i);
}
}, p$1);

Clazz.newMeth(C$, 'calculateCardinality$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var cardinality=0;
var atomicNo=mol.getAtomicNo$I(atom);
if ((atomicNo != 1) && (atomicNo != 6) ) {
cardinality+=32;
}if (mol.isRingAtom$I(atom)) {
cardinality+=16;
}return cardinality;
}, 1);

Clazz.newMeth(C$, 'isMaxCapacityMatchListContainerReached$',  function () {
return this.maxCapacityMatchListContainerReached;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
