(function(){var P$=Clazz.newPackage("com.actelion.research.chem.coords"),I$=[[0,'com.actelion.research.chem.coords.InventorFragment']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FragmentAssociation");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mFragment','com.actelion.research.chem.coords.InventorFragment[]','mX','double[]','+mY','mCount','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_coords_InventorFragment$com_actelion_research_chem_coords_InventorFragment$I$I',  function (f1, f2, atomIndex1, atomIndex2) {
;C$.$init$.apply(this);
this.mFragment=Clazz.array($I$(1), [2]);
this.mFragment[0]=f1;
this.mFragment[1]=f2;
this.mX=Clazz.array(Double.TYPE, [2]);
this.mY=Clazz.array(Double.TYPE, [2]);
this.mX[0]=this.mFragment[0].getAtomX$I(atomIndex1);
this.mY[0]=this.mFragment[0].getAtomY$I(atomIndex1);
this.mX[1]=this.mFragment[1].getAtomX$I(atomIndex2);
this.mY[1]=this.mFragment[1].getAtomY$I(atomIndex2);
this.mCount=Clazz.array(Integer.TYPE, [2]);
this.mCount[0]=1;
this.mCount[1]=1;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_coords_InventorFragment$com_actelion_research_chem_coords_InventorFragment',  function (f1, f2) {
;C$.$init$.apply(this);
this.mFragment=Clazz.array($I$(1), [2]);
this.mFragment[0]=f1;
this.mFragment[1]=f2;
this.mX=Clazz.array(Double.TYPE, [2]);
this.mY=Clazz.array(Double.TYPE, [2]);
this.mCount=Clazz.array(Integer.TYPE, [2]);
for (var i=0; i < 2; i++) {
for (var j=0; j < this.mFragment[i].size$(); j++) {
this.mX[i]+=this.mFragment[i].getAtomX$I(j);
this.mY[i]+=this.mFragment[i].getAtomY$I(j);
}
this.mCount[i]=this.mFragment[i].size$();
}
}, 1);

Clazz.newMeth(C$, 'add$I$I',  function (atomIndex1, atomIndex2) {
this.mX[0]+=this.mFragment[0].getAtomX$I(atomIndex1);
this.mY[0]+=this.mFragment[0].getAtomY$I(atomIndex1);
this.mX[1]+=this.mFragment[1].getAtomX$I(atomIndex2);
this.mY[1]+=this.mFragment[1].getAtomY$I(atomIndex2);
++this.mCount[0];
++this.mCount[1];
});

Clazz.newMeth(C$, 'getFragment$I',  function (i) {
return this.mFragment[i];
});

Clazz.newMeth(C$, 'getPriority$',  function () {
return this.mFragment[0].size$() * this.mFragment[1].size$();
});

Clazz.newMeth(C$, 'arrange$D$Z',  function (minDistance, keepFirstFragment) {
var angle=Clazz.array(Double.TYPE, [2]);
for (var i=0; i < 2; i++) {
this.mX[i]/=this.mCount[i];
this.mY[i]/=this.mCount[i];
angle[i]=this.mFragment[i].calculatePreferredAttachmentAngle$D$D$I$D(this.mX[i], this.mY[i], this.mFragment[1 - i].size$(), minDistance);
}
this.mFragment[0].rotate$D$D$D(this.mX[0], this.mY[0], 1.5707963267948966 - angle[0]);
this.mFragment[1].rotate$D$D$D(this.mX[1], this.mY[1], 4.71238898038469 - angle[1]);
var yMin=1.7976931348623157E308;
var yMax=-1.7976931348623157E308;
var dy=this.mY[0] - this.mY[1];
for (var i=0; i < this.mFragment[1].mAtomY.length; i++) {
this.mFragment[1].mAtomY[i]+=dy;
if (yMin > this.mFragment[1].mAtomY[i] ) yMin=this.mFragment[1].mAtomY[i];
if (yMax < this.mFragment[1].mAtomY[i] ) yMax=this.mFragment[1].mAtomY[i];
}
var range=yMax - yMin + 2 * minDistance;
var binCount=(Math.ceil(range)|0);
yMin+=(range - binCount) / 2 - minDistance;
var leftX=Clazz.array(Double.TYPE, [binCount]);
for (var i=0; i < binCount; i++) leftX[i]=this.mX[1] + minDistance;

for (var i=0; i < this.mFragment[1].mAtomY.length; i++) {
var relY=this.mFragment[1].mAtomY[i] - yMin;
var low=((relY - minDistance)|0);
var high=Math.min(((relY + minDistance)|0), binCount - 1);
for (var j=low; j <= high; j++) {
if (leftX[j] > this.mFragment[1].mAtomX[i] ) leftX[j]=this.mFragment[1].mAtomX[i];
}
}
for (var i=0; i < binCount; i++) leftX[i]-=minDistance;

var dx=this.mX[0] - this.mX[1];
for (var i=0; i < this.mFragment[0].mAtomX.length; i++) {
var index=((this.mFragment[0].mAtomY[i] - yMin)|0);
if (index >= 0 && index < leftX.length  && dx < this.mFragment[0].mAtomX[i] - leftX[index]  ) dx=this.mFragment[0].mAtomX[i] - leftX[index];
}
for (var i=0; i < this.mFragment[1].mAtomX.length; i++) this.mFragment[1].mAtomX[i]+=dx;

if (keepFirstFragment) {
this.mFragment[0].rotate$D$D$D(this.mX[0], this.mY[0], angle[0] - 1.5707963267948966);
this.mFragment[1].rotate$D$D$D(this.mX[0], this.mY[0], angle[0] - 1.5707963267948966);
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:13 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
