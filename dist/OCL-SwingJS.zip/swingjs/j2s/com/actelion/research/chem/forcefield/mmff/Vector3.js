(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Vector3");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['x','y','z']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.x=0.0;
this.y=0.0;
this.z=0.0;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D',  function (x, y, z) {
;C$.$init$.apply(this);
this.x=x;
this.y=y;
this.z=z;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
;C$.$init$.apply(this);
this.x=that.x;
this.y=that.y;
this.z=that.z;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
;C$.$init$.apply(this);
this.x=mol.getAtomX$I(atom);
this.y=mol.getAtomY$I(atom);
this.z=mol.getAtomZ$I(atom);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, atom) {
;C$.$init$.apply(this);
this.x=mol.getAtomX$I(atom);
this.y=mol.getAtomY$I(atom);
this.z=mol.getAtomZ$I(atom);
}, 1);

Clazz.newMeth(C$, 'c$$DA$I',  function (pos, offset) {
;C$.$init$.apply(this);
this.x=pos[3 * offset];
this.y=pos[3 * offset + 1];
this.z=pos[3 * offset + 2];
}, 1);

Clazz.newMeth(C$, 'c$$DA$I$I',  function (pos, atom1, atom2) {
C$.c$$com_actelion_research_chem_forcefield_mmff_Vector3.apply(this, [Clazz.new_(C$.c$$DA$I,[pos, atom1]).to$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_(C$.c$$DA$I,[pos, atom2]))]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (mol, atom1, atom2) {
C$.c$$com_actelion_research_chem_forcefield_mmff_Vector3.apply(this, [Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I,[mol, atom1]).to$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I,[mol, atom2]))]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$I$I',  function (mol, atom1, atom2) {
C$.c$$com_actelion_research_chem_forcefield_mmff_Vector3.apply(this, [Clazz.new_(C$.c$$com_actelion_research_chem_ExtendedMolecule$I,[mol, atom1]).to$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_(C$.c$$com_actelion_research_chem_ExtendedMolecule$I,[mol, atom2]))]);
}, 1);

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (obj === this ) return true;
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.forcefield.mmff.Vector3"))) return false;
var that=obj;
return Math.abs(this.x - that.x) < 0.01  && Math.abs(this.y - that.y) < 0.01   && Math.abs(this.z - that.z) < 0.01  ;
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return  new Double(this.x).hashCode$() +  new Double(this.y).hashCode$() +  new Double(this.z).hashCode$() ;
});

Clazz.newMeth(C$, 'write$DA$I',  function (pos, offset) {
pos[3 * offset]=this.x;
pos[3 * offset + 1]=this.y;
pos[3 * offset + 2]=this.z;
});

Clazz.newMeth(C$, 'negate$',  function () {
return Clazz.new_(C$.c$$D$D$D,[-this.x, -this.y, -this.z]);
});

Clazz.newMeth(C$, 'to$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Clazz.new_(C$.c$$D$D$D,[that.x - this.x, that.y - this.y, that.z - this.z]);
});

Clazz.newMeth(C$, 'length$',  function () {
return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
});

Clazz.newMeth(C$, 'normalise$',  function () {
if (this.length$() > 0.0 ) return Clazz.new_(C$.c$$D$D$D,[this.x / this.length$(), this.y / this.length$(), this.z / this.length$()]);
return Clazz.new_(C$.c$$D$D$D,[0.0, 0.0, 0.0]);
});

Clazz.newMeth(C$, 'add$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Clazz.new_(C$.c$$D$D$D,[this.x + that.x, this.y + that.y, this.z + that.z]);
});

Clazz.newMeth(C$, 'sub$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Clazz.new_(C$.c$$D$D$D,[this.x - that.x, this.y - that.y, this.z - that.z]);
});

Clazz.newMeth(C$, 'distance$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Math.sqrt((this.x - that.x) * (this.x - that.x) + (this.y - that.y) * (this.y - that.y) + (this.z - that.z) * (this.z - that.z));
});

Clazz.newMeth(C$, 'dot$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return this.x * that.x + this.y * that.y + this.z * that.z;
});

Clazz.newMeth(C$, 'cross$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Clazz.new_(C$.c$$D$D$D,[this.y * that.z - this.z * that.y, this.z * that.x - this.x * that.z, this.x * that.y - this.y * that.x]);
});

Clazz.newMeth(C$, 'angle$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return Math.acos(this.dot$com_actelion_research_chem_forcefield_mmff_Vector3(that) / (this.length$() * that.length$()));
});

Clazz.newMeth(C$, 'cosAngle$com_actelion_research_chem_forcefield_mmff_Vector3',  function (that) {
return this.dot$com_actelion_research_chem_forcefield_mmff_Vector3(that) / (this.length$() * that.length$());
});

Clazz.newMeth(C$, 'toString',  function () {
return "(" + String.format$S$OA("%.3f", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(this.x)])) + "," + String.format$S$OA("%.3f", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(this.y)])) + "," + String.format$S$OA("%.3f", Clazz.array(java.lang.Object, -1, [Double.valueOf$D(this.z)])) + ")" ;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
