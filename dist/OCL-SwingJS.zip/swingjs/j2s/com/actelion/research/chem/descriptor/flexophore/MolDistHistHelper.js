(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.MolDistHist','java.util.Arrays','java.util.ArrayList','java.util.Collections','StringBuilder','com.actelion.research.util.ArrayUtils','com.actelion.research.chem.descriptor.flexophore.PPNode','com.actelion.research.chem.descriptor.flexophore.DistHistHelper','com.actelion.research.chem.descriptor.flexophore.generator.SubFlexophoreGenerator','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.chem.descriptor.flexophore.PPNodeViz']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getNumNodesNotEmpty$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
if (mdh == null ) return 0;
if (C$.isEmptyMolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist(mdh)) return 0;
return mdh.getNumPPNodes$();
}, 1);

Clazz.newMeth(C$, 'assemble$com_actelion_research_chem_descriptor_flexophore_MolDistHistA',  function (arr) {
var nNodesSum=0;
var maxNumNodes=0;
for (var mdhFrag, $mdhFrag = 0, $$mdhFrag = arr; $mdhFrag<$$mdhFrag.length&&((mdhFrag=($$mdhFrag[$mdhFrag])),1);$mdhFrag++) {
var nNodes=mdhFrag.getNumPPNodes$();
nNodesSum+=nNodes;
if (nNodes > maxNumNodes) maxNumNodes=nNodes;
}
var mdh=Clazz.new_($I$(1,1).c$$I,[nNodesSum]);
var arrMapIndexNew=Clazz.array(Integer.TYPE, [arr.length, maxNumNodes]);
var indexNew=0;
for (var i=0; i < arr.length; i++) {
var n=arr[i].getNumPPNodes$();
for (var j=0; j < n; j++) {
arrMapIndexNew[i][j]=indexNew;
++indexNew;
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(arr[i].getNode$I(j));
}
}
for (var i=0; i < arr.length; i++) {
var n=arr[i].getNumPPNodes$();
var mdhFrag=arr[i];
for (var j=0; j < n; j++) {
for (var k=j + 1; k < n; k++) {
var arrDistHist=mdhFrag.getDistHist$I$I(j, k);
var index1=arrMapIndexNew[i][j];
var index2=arrMapIndexNew[i][k];
mdh.setDistHist$I$I$BA(index1, index2, arrDistHist);
}
}
}
for (var i=0; i < nNodesSum; i++) {
for (var j=i + 1; j < nNodesSum; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
if (C$.isZero$BA(arrDistHist)) {
$I$(2).fill$BA$B(arrDistHist, 1);
mdh.setDistHist$I$I$BA(i, j, arrDistHist);
}}
}
return mdh;
}, 1);

Clazz.newMeth(C$, 'assembleNoDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHistA',  function (arr) {
var liPPNode=Clazz.new_($I$(3,1));
for (var mdhFrag, $mdhFrag = 0, $$mdhFrag = arr; $mdhFrag<$$mdhFrag.length&&((mdhFrag=($$mdhFrag[$mdhFrag])),1);$mdhFrag++) {
var nNodes=mdhFrag.getNumPPNodes$();
for (var i=0; i < nNodes; i++) {
var node=mdhFrag.getNode$I(i);
if (node.getInteractionTypeCount$() > 0) {
liPPNode.add$O(node);
}}
}
if (liPPNode.size$() == 0) {
return null;
}$I$(4).sort$java_util_List(liPPNode);
var mdh=Clazz.new_([liPPNode.size$()],$I$(1,1).c$$I);
for (var ppNode, $ppNode = liPPNode.iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) {
mdh.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(ppNode);
}
mdh.realize$();
return mdh;
}, 1);

Clazz.newMeth(C$, 'isZero$BA',  function (b) {
var z=true;
for (var v, $v = 0, $$v = b; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
if (v != 0) {
z=false;
break;
}}
return z;
}, 1);

Clazz.newMeth(C$, 'toStringDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var sb=Clazz.new_($I$(5,1));
var nNodes=mdh.getNumPPNodes$();
for (var i=0; i < nNodes; i++) {
for (var j=i + 1; j < nNodes; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
sb.append$S($I$(6).toString$BA(arrDistHist));
sb.append$S("\n");
}
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'setDistHistToOne$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var nNodes=mdh.getNumPPNodes$();
for (var i=0; i < nNodes; i++) {
for (var j=i + 1; j < nNodes; j++) {
var arrDistHist=mdh.getDistHist$I$I(i, j);
$I$(2).fill$BA$B(arrDistHist, 1);
mdh.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
}, 1);

Clazz.newMeth(C$, 'getEmptyMolDistHist$',  function () {
var ppNode0=Clazz.new_($I$(7,1));
ppNode0.realize$();
var mdhEmpty=Clazz.new_($I$(1,1).c$$I,[1]);
mdhEmpty.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(ppNode0);
mdhEmpty.realize$();
return mdhEmpty;
}, 1);

Clazz.newMeth(C$, 'isEmptyMolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var empty=true;
if (mdh.getNumPPNodes$() > 1) {
empty=false;
} else if (mdh.getNumPPNodes$() == 1) {
if (mdh.getNode$I(0).getInteractionTypeCount$() > 0) {
empty=false;
}}return empty;
}, 1);

Clazz.newMeth(C$, 'getMostDistantPairOfNodes$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var n=mdh.getNumPPNodes$();
var maxMedBinIndex=0;
var indexNode1=-1;
var indexNode2=-1;
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
var arr=mdh.getDistHist$I$I(i, j);
var medBinInd=$I$(8).getMedianBin$BA(arr);
if (medBinInd > maxMedBinIndex) {
maxMedBinIndex=medBinInd;
indexNode1=i;
indexNode2=j;
}}
}
var arrIndexNodes=Clazz.array(Integer.TYPE, [2]);
arrIndexNodes[0]=indexNode1;
arrIndexNodes[1]=indexNode2;
var mdhSub=$I$(9).getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndexNodes);
return mdhSub;
}, 1);

Clazz.newMeth(C$, 'getMostDistantPairOfNodesOneHeteroAtom$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
var n=mdh.getNumPPNodes$();
var maxMedBinIndex=0;
var indexNode1=-1;
var indexNode2=-1;
var arrHetero=Clazz.array(Boolean.TYPE, [n]);
for (var i=0; i < n; i++) {
arrHetero[i]=mdh.getNode$I(i).containsHetero$();
}
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
if (arrHetero[i] || arrHetero[j] ) {
var arr=mdh.getDistHist$I$I(i, j);
var medBinInd=$I$(8).getMedianBin$BA(arr);
if (medBinInd > maxMedBinIndex) {
maxMedBinIndex=medBinInd;
indexNode1=i;
indexNode2=j;
}}}
}
var arrIndexNodes=Clazz.array(Integer.TYPE, [2]);
arrIndexNodes[0]=indexNode1;
arrIndexNodes[1]=indexNode2;
var mdhSub=$I$(9).getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA(mdh, arrIndexNodes);
return mdhSub;
}, 1);

Clazz.newMeth(C$, 'areNodesEqual$com_actelion_research_chem_descriptor_flexophore_MolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh1, mdh2) {
var eq=true;
if (mdh1.getNumPPNodes$() != mdh2.getNumPPNodes$()) {
eq=false;
} else {
for (var i=0; i < mdh1.getNumPPNodes$(); i++) {
if (!mdh1.getNode$I(i).equals$O(mdh2.getNode$I(i))) {
eq=false;
break;
}}
}return eq;
}, 1);

Clazz.newMeth(C$, 'createFromNodes$java_util_Collection',  function (col) {
var molDistHistViz=Clazz.new_([col.size$()],$I$(10,1).c$$I);
for (var ppNode, $ppNode = col.iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) {
var ppNodeViz=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode,[ppNode]);
molDistHistViz.addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(ppNodeViz);
}
molDistHistViz.realize$();
return molDistHistViz.getMolDistHist$();
}, 1);

Clazz.newMeth(C$, 'toArray$java_util_List',  function (li) {
var a=Clazz.array($I$(1), [li.size$()]);
for (var i=0; i < li.size$(); i++) {
a[i]=li.get$I(i);
}
return a;
}, 1);

Clazz.newMeth(C$, 'reNormalizeDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist$I',  function (mdh, margin) {
var n=mdh.getNumPPNodes$();
for (var i=0; i < n; i++) {
for (var j=i + 1; j < n; j++) {
var b=mdh.getDistHist$I$I(i, j);
var c=$I$(8).count$BA(b);
if (Math.abs(100.0 - c) > margin ) {
var distHistNew=$I$(8).normalize$BA(b);
mdh.setDistHist$I$I$BA(i, j, distHistNew);
}}
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
