(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "CanonizerRankListComparator", null, null, 'java.util.Comparator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$IA$IA','compare$O$O'],  function (o1, o2) {
if (o1 == null ) return (o2 == null ) ? 0 : 1;
if (o2 == null ) return -1;
var count=Math.min(o1.length, o2.length);
for (var i=0; i < count; i++) if ((o1[i] & -65536) != (o2[i] & -65536)) return ((o1[i] & -65536) < (o2[i] & -65536)) ? -1 : 1;

return (o1.length == o2.length) ? 0 : (o1.length < o2.length) ? -1 : 1;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
