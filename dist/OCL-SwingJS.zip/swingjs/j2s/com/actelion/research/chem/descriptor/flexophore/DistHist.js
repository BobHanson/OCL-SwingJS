(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.ClusterNode','java.util.Collections','StringBuffer','com.actelion.research.calc.ArrayUtilsCalc']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DistHist", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['numPPNodes','identifier'],'O',['arrDistHists','byte[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.arrDistHists=Clazz.array(Byte.TYPE, [0]);
this.numPPNodes=0;
this.identifier=-1;
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (nPPNodes) {
;C$.$init$.apply(this);
this.initHistogramArray$I(nPPNodes);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_DistHist',  function (distHist) {
;C$.$init$.apply(this);
distHist.copy$com_actelion_research_chem_descriptor_flexophore_DistHist(this);
}, 1);

Clazz.newMeth(C$, 'copy$com_actelion_research_chem_descriptor_flexophore_DistHist',  function (copy) {
copy.identifier=this.identifier;
if (copy.numPPNodes != this.numPPNodes) {
copy.numPPNodes=this.numPPNodes;
copy.arrDistHists=Clazz.array(Byte.TYPE, [this.arrDistHists.length]);
}System.arraycopy$O$I$O$I$I(this.arrDistHists, 0, copy.arrDistHists, 0, this.arrDistHists.length);
});

Clazz.newMeth(C$, 'getBonds$',  function () {
return (((this.numPPNodes * this.numPPNodes) - this.numPPNodes)/2|0);
});

Clazz.newMeth(C$, 'getNumPPNodes$',  function () {
return this.numPPNodes;
});

Clazz.newMeth(C$, 'getSizeBytes$',  function () {
var s=0;
if (this.getNumPPNodes$() > 1) {
s+=this.arrDistHists.length;
}s+=8;
return s;
});

Clazz.newMeth(C$, 'initHistogramArray$I',  function (nPPNodes) {
this.numPPNodes=nPPNodes;
var nBonds=(((this.numPPNodes * this.numPPNodes) - this.numPPNodes)/2|0);
this.arrDistHists=Clazz.array(Byte.TYPE, [nBonds * 80]);
});

Clazz.newMeth(C$, 'getIndex$I$I$I',  function (indexNode1, indexNode2, size) {
var i1=Math.min(indexNode1, indexNode2);
var i2=Math.max(indexNode1, indexNode2);
var h=i1 + 1;
var index=(i1 * size + i2) - (((h * h - h)/2|0)) - h ;
return index;
}, 1);

Clazz.newMeth(C$, 'getMinDist$I$I',  function (indexAt1, indexAt2) {
var arr=this.getDistHist$I$I(indexAt1, indexAt2);
var dist=0;
for (var i=0; i < arr.length; i++) {
if (arr[i] > 0) {
dist=i;
break;
}}
return dist;
});

Clazz.newMeth(C$, 'getClusterCenter$I',  function (maxDistance) {
var liCluster=Clazz.new_($I$(1,1));
for (var i=0; i < this.getNumPPNodes$(); i++) {
var cluster=Clazz.new_($I$(2,1).c$$I,[i]);
for (var j=0; j < this.getNumPPNodes$(); j++) {
if (i != j) {
var hist=this.getDistHist$I$I(i, j);
var bInCluster=false;
for (var k=0; k < maxDistance + 1; k++) {
if (hist[k] > 0) {
bInCluster=true;
break;
}}
if (bInCluster) {
cluster.add$I(j);
}}}
if (cluster.isCluster$()) liCluster.add$O(cluster);
}
for (var i=0; i < liCluster.size$(); i++) {
var cl=liCluster.get$I(i);
var rmsd=$I$(2).getRMSD$com_actelion_research_chem_descriptor_flexophore_ClusterNode$com_actelion_research_chem_descriptor_flexophore_DistHist(cl, this);
cl.setRMSD$I(rmsd);
}
var liClusterNodeMinRMSD=Clazz.new_($I$(1,1));
for (var i=0; i < liCluster.size$() - 1; i++) {
var cl=liCluster.get$I(i);
var liEqCluster=Clazz.new_($I$(1,1));
liEqCluster.add$O(cl);
for (var j=liCluster.size$() - 1; j > i; j--) {
if (cl.equals$O(liCluster.get$I(j))) {
liEqCluster.add$O(liCluster.remove$I(j));
}}
$I$(3).sort$java_util_List(liEqCluster);
liClusterNodeMinRMSD.add$O(liEqCluster.get$I(0));
}
return liClusterNodeMinRMSD;
});

Clazz.newMeth(C$, 'setDistHist$I$I$BA',  function (indexAt1, indexAt2, arrHist) {
if (indexAt1 >= this.numPPNodes) {
throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$I,[indexAt1]);
} else if (indexAt2 >= this.numPPNodes) throw Clazz.new_(Clazz.load('ArrayIndexOutOfBoundsException').c$$I,[indexAt2]);
var index=C$.getIndex$I$I$I(indexAt1, indexAt2, this.numPPNodes);
var posStart=index * 80;
System.arraycopy$O$I$O$I$I(arrHist, 0, this.arrDistHists, posStart, 80);
});

Clazz.newMeth(C$, 'getDistHists$',  function () {
return this.arrDistHists;
});

Clazz.newMeth(C$, 'setDistHists$BA$I$I',  function (arr, size, identifier) {
this.arrDistHists=arr;
this.numPPNodes=size;
this.identifier=identifier;
});

Clazz.newMeth(C$, 'getDistHist$I$I',  function (indexAt1, indexAt2) {
var index=C$.getIndex$I$I$I(indexAt1, indexAt2, this.numPPNodes);
var posStart=index * 80;
var arr=Clazz.array(Byte.TYPE, [80]);
System.arraycopy$O$I$O$I$I(this.arrDistHists, posStart, arr, 0, 80);
return arr;
});

Clazz.newMeth(C$, 'getIndexPosStartForDistHist$I$I',  function (indexAt1, indexAt2) {
var index=C$.getIndex$I$I$I(indexAt1, indexAt2, this.numPPNodes);
var posStart=index * 80;
return posStart;
});

Clazz.newMeth(C$, 'getValueAtAbsolutePosition$I',  function (indexAbsolutePosition) {
return this.arrDistHists[indexAbsolutePosition];
});

Clazz.newMeth(C$, 'getDistHist$I$I$BA',  function (indexAt1, indexAt2, arr) {
var index=C$.getIndex$I$I$I(indexAt1, indexAt2, this.numPPNodes);
var posStart=index * 80;
System.arraycopy$O$I$O$I$I(this.arrDistHists, posStart, arr, 0, 80);
return arr;
});

Clazz.newMeth(C$, 'getRelMaxDistInHist$I$I',  function (indexAt1, indexAt2) {
var arr=this.getDistHist$I$I(indexAt1, indexAt2);
var max=-2147483648;
for (var i=arr.length - 1; i >= 0; i--) {
if (arr[i] > 0) {
max=i;
break;
}}
return max / arr.length;
});

Clazz.newMeth(C$, 'getMaxDistInHist$I$I',  function (indexAt1, indexAt2) {
var arr=this.getDistHist$I$I(indexAt1, indexAt2);
var max=-2147483648;
for (var i=arr.length - 1; i >= 0; i--) {
if (arr[i] > 0) {
max=i;
break;
}}
return max;
});

Clazz.newMeth(C$, 'getRelMaxDistInHist$',  function () {
var size=this.getNumPPNodes$();
var max=0;
for (var i=0; i < size; i++) {
for (var j=i + 1; j < size; j++) {
var dist=this.getRelMaxDistInHist$I$I(i, j);
if (dist > max ) max=dist;
}
}
return max;
});

Clazz.newMeth(C$, 'toStringHistsIndexed$',  function () {
var b=Clazz.new_($I$(4,1));
for (var i=0; i < this.numPPNodes; i++) {
for (var j=i + 1; j < this.numPPNodes; j++) {
var arrHist=this.getDistHist$I$I(i, j);
if (arrHist != null ) b.append$S(i + "\t" + j + "\t[" + $I$(5).toString$BA(arrHist) + "]\n" );
}
}
return b.toString();
});

Clazz.newMeth(C$, 'getIdentifier$',  function () {
return this.identifier;
});

Clazz.newMeth(C$, 'setIdentifier$I',  function (identifier) {
this.identifier=identifier;
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
