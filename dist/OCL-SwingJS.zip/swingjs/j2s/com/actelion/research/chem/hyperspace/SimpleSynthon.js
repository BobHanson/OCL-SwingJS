(function(){var P$=Clazz.newPackage("com.actelion.research.chem.hyperspace"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "SimpleSynthon", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['idcode','synthonId','rxnId','synthonSet']]]

Clazz.newMeth(C$, 'c$$S$S$S$S',  function (idcode, id, rxn_id, synthonSet) {
;C$.$init$.apply(this);
this.idcode=idcode;
this.synthonId=id;
this.rxnId=rxn_id;
this.synthonSet=synthonSet;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
