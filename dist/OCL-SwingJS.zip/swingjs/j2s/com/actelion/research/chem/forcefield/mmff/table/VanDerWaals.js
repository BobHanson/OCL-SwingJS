(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),p$1={},I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VanDerWaals", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.power=0.25;
this.b=0.2;
this.beta=12.0;
this.darad=0.8;
this.daeps=0.5;
},1);

C$.$fields$=[['D',['power','b','beta','darad','daeps'],'O',['table','Object[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'alpha_i$I',  function (type) {
return (this.table[p$1.index$I.apply(this, [type])][1]).doubleValue$();
});

Clazz.newMeth(C$, 'n_i$I',  function (type) {
return (this.table[p$1.index$I.apply(this, [type])][2]).doubleValue$();
});

Clazz.newMeth(C$, 'a_i$I',  function (type) {
return (this.table[p$1.index$I.apply(this, [type])][3]).doubleValue$();
});

Clazz.newMeth(C$, 'g_i$I',  function (type) {
return (this.table[p$1.index$I.apply(this, [type])][4]).doubleValue$();
});

Clazz.newMeth(C$, 'da$I',  function (type) {
return (this.table[p$1.index$I.apply(this, [type])][5]).charValue$();
});

Clazz.newMeth(C$, 'r_star$I',  function (type) {
var idx=p$1.index$I.apply(this, [type]);
return (this.table[idx][3]).doubleValue$() * Math.pow((this.table[idx][1]).doubleValue$(), 0.25);
});

Clazz.newMeth(C$, 'index$I',  function (type) {
return $I$(2).binary$I$I$com_actelion_research_chem_forcefield_mmff_Searchable(0, type, this);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
