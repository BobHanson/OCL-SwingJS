(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InChIKeyParser", null, 'com.actelion.research.chem.moreparsers.InChIParser');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (mode) {
;C$.superclazz.c$$I$S.apply(this,[mode, "inchikey"]);C$.$init$.apply(this);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
