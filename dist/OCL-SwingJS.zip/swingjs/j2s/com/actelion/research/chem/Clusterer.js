(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.concurrent.atomic.AtomicInteger','Runtime','java.util.concurrent.Executors',['com.actelion.research.chem.Clusterer','.ClusterWorker'],'Thread','java.util.concurrent.CountDownLatch']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Clusterer", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.calc.DataProcessor');
C$.$classes$=[['ClusterWorker',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mNoOfCompounds','mNoOfClusters','mThreadCount'],'O',['mClusterNo','int[]','+mNoOfMembers','mSimilarityMatrix','float[][]','mDescriptor','_.T[]','mDescriptorHandler','com.actelion.research.chem.descriptor.DescriptorHandler','mSMPCompoundIndex','java.util.concurrent.atomic.AtomicInteger','mIsRepresentative','boolean[]','mExecutor','java.util.concurrent.ExecutorService','mClusterWorker','com.actelion.research.chem.Clusterer.ClusterWorker[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_DescriptorHandler$OA',  function (descriptorHandler, descriptor) {
Clazz.super_(C$, this);
this.mDescriptorHandler=descriptorHandler;
this.mDescriptor=descriptor;
this.mNoOfCompounds=this.mDescriptor.length;
this.mSimilarityMatrix=Clazz.array(Float.TYPE, [this.mNoOfCompounds, null]);
for (var i=1; i < this.mNoOfCompounds; i++) this.mSimilarityMatrix[i]=Clazz.array(Float.TYPE, [i]);

this.mThreadCount=$I$(2).getRuntime$().availableProcessors$();
if (this.mThreadCount != 1) {
this.mExecutor=$I$(3).newFixedThreadPool$I(this.mThreadCount);
this.mClusterWorker=Clazz.array($I$(4), [this.mThreadCount]);
for (var t=0; t < this.mThreadCount; t++) this.mClusterWorker[t]=Clazz.new_($I$(4,1),[this, null]);

}}, 1);

Clazz.newMeth(C$, 'cluster$D$I',  function (similarityLimit, clusterCountLimit) {
p$1.calculateSimilarityMatrix$Z.apply(this, [false]);
if (this.threadMustDie$()) {
this.stopProgress$S("clustering cancelled");
return;
}this.mNoOfMembers=Clazz.array(Integer.TYPE, [this.mNoOfCompounds]);
this.mClusterNo=Clazz.array(Integer.TYPE, [this.mNoOfCompounds]);
for (var i=0; i < this.mNoOfCompounds; i++) {
this.mNoOfMembers[i]=1;
this.mClusterNo[i]=i;
}
if (clusterCountLimit < 1) clusterCountLimit=1;
if (similarityLimit != 0.0 ) this.startProgress$S$I$I("Clustering Compounds...", 0, ((5000.0 * (1.0 - similarityLimit))|0));
 else this.startProgress$S$I$I("Clustering Compounds...", 0, this.mNoOfCompounds - clusterCountLimit);
this.mNoOfClusters=this.mNoOfCompounds;
while (this.mNoOfClusters > clusterCountLimit){
var maxSimValue=0;
var maxCluster1=-1;
var maxCluster2=-1;
if (this.mThreadCount == 1) {
for (var cluster2=1; cluster2 < this.mNoOfCompounds; cluster2++) {
if (this.mNoOfMembers[cluster2] > 0) {
for (var cluster1=0; cluster1 < cluster2; cluster1++) {
if (this.mNoOfMembers[cluster1] != 0) {
if (maxSimValue < this.mSimilarityMatrix[cluster2][cluster1] ) {
maxSimValue=this.mSimilarityMatrix[cluster2][cluster1];
maxCluster1=cluster1;
maxCluster2=cluster2;
}}}
}}
} else {
p$1.runInParallel$I.apply(this, [3]);
for (var worker, $worker = 0, $$worker = this.mClusterWorker; $worker<$$worker.length&&((worker=($$worker[$worker])),1);$worker++) {
if (maxSimValue < worker.getMaxSimilarity$() ) {
maxSimValue=worker.getMaxSimilarity$();
maxCluster1=worker.getCluster1$();
maxCluster2=worker.getCluster2$();
}}
}if (maxSimValue < similarityLimit ) break;
for (var i=0; i < maxCluster1; i++) if (this.mNoOfMembers[i] != 0) this.mSimilarityMatrix[maxCluster1][i]=(this.mNoOfMembers[maxCluster1] * this.mSimilarityMatrix[maxCluster1][i] + this.mNoOfMembers[maxCluster2] * this.mSimilarityMatrix[maxCluster2][i]) / (this.mNoOfMembers[maxCluster1] + this.mNoOfMembers[maxCluster2]);

for (var i=maxCluster1 + 1; i < maxCluster2; i++) if (this.mNoOfMembers[i] != 0) this.mSimilarityMatrix[i][maxCluster1]=(this.mNoOfMembers[maxCluster1] * this.mSimilarityMatrix[i][maxCluster1] + this.mNoOfMembers[maxCluster2] * this.mSimilarityMatrix[maxCluster2][i]) / (this.mNoOfMembers[maxCluster1] + this.mNoOfMembers[maxCluster2]);

for (var i=maxCluster2 + 1; i < this.mNoOfCompounds; i++) if (this.mNoOfMembers[i] != 0) this.mSimilarityMatrix[i][maxCluster1]=(this.mNoOfMembers[maxCluster1] * this.mSimilarityMatrix[i][maxCluster1] + this.mNoOfMembers[maxCluster2] * this.mSimilarityMatrix[i][maxCluster2]) / (this.mNoOfMembers[maxCluster1] + this.mNoOfMembers[maxCluster2]);

this.mNoOfMembers[maxCluster1]+=this.mNoOfMembers[maxCluster2];
this.mNoOfMembers[maxCluster2]=0;
for (var i=0; i < this.mNoOfCompounds; i++) if (this.mClusterNo[i] == maxCluster2) this.mClusterNo[i]=maxCluster1;

--this.mNoOfClusters;
if (this.threadMustDie$()) {
this.stopProgress$S("clustering cancelled");
return;
}if (similarityLimit != 0.0 ) this.updateProgress$I(((5000.0 * (1.0 - maxSimValue))|0));
 else this.updateProgress$I(this.mNoOfCompounds - this.mNoOfClusters);
}
p$1.findRepresentatives.apply(this, []);
this.mExecutor.shutdown$();
while (!this.mExecutor.isTerminated$()){
try {
$I$(5).sleep$J(500);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
}
this.stopProgress$S("clustering finished");
});

Clazz.newMeth(C$, 'isRepresentative$I',  function (compound) {
return this.mIsRepresentative[compound];
});

Clazz.newMeth(C$, 'getClusterNo$I',  function (compound) {
return this.mClusterNo[compound];
});

Clazz.newMeth(C$, 'getClusterCount$',  function () {
return this.mNoOfClusters;
});

Clazz.newMeth(C$, 'regenerateClusterNos$',  function () {
var newClusterNo=Clazz.array(Integer.TYPE, [this.mNoOfCompounds]);
var clusterNo=1;
for (var i=0; i < this.mNoOfCompounds; i++) {
if (newClusterNo[this.mClusterNo[i]] == 0) newClusterNo[i]=clusterNo++;
this.mClusterNo[i]=newClusterNo[this.mClusterNo[i]];
}
});

Clazz.newMeth(C$, 'calculateSimilarityMatrix$Z',  function (withinClustersOnly) {
this.startProgress$S$I$I("Calculating Similaries...", 0, 1000);
if (this.mThreadCount == 1) {
for (var compound2=1; compound2 < this.mNoOfCompounds && !this.threadMustDie$() ; compound2++) {
for (var compound1=0; compound1 < compound2; compound1++) if (!withinClustersOnly || this.mClusterNo[compound1] == this.mClusterNo[compound2] ) this.mSimilarityMatrix[compound2][compound1]=this.mDescriptorHandler.getSimilarity$O$O(this.mDescriptor[compound1], this.mDescriptor[compound2]);

this.updateProgress$I(((1000.0 * compound2 * compound2  / this.mNoOfCompounds / this.mNoOfCompounds)|0));
}
} else {
if (withinClustersOnly) p$1.runInParallel$I.apply(this, [2]);
 else p$1.runInParallel$I.apply(this, [1]);
}}, p$1);

Clazz.newMeth(C$, 'getSimilarity$I$I',  function (index1, index2) {
if (index1 == index2) return 1.0;
return this.mSimilarityMatrix[Math.max(index1, index2)][Math.min(index1, index2)];
});

Clazz.newMeth(C$, 'findRepresentatives',  function () {
p$1.calculateSimilarityMatrix$Z.apply(this, [true]);
if (this.threadMustDie$()) return;
var lowSim=Clazz.array(Float.TYPE, [this.mNoOfCompounds]);
var simSum=Clazz.array(Float.TYPE, [this.mNoOfCompounds]);
for (var i=0; i < this.mNoOfCompounds; i++) {
lowSim[i]=1;
simSum[i]=0;
}
this.startProgress$S$I$I("Locating Representatives...", 0, this.mNoOfCompounds);
for (var cluster2=1; cluster2 < this.mNoOfCompounds; cluster2++) {
if (this.threadMustDie$()) return;
this.updateProgress$I(cluster2);
for (var cluster1=0; cluster1 < cluster2; cluster1++) {
if (this.mClusterNo[cluster1] == this.mClusterNo[cluster2]) {
if (lowSim[this.mClusterNo[cluster1]] > this.mSimilarityMatrix[cluster2][cluster1] ) lowSim[this.mClusterNo[cluster1]]=this.mSimilarityMatrix[cluster2][cluster1];
simSum[cluster1]+=this.mSimilarityMatrix[cluster2][cluster1];
simSum[cluster2]+=this.mSimilarityMatrix[cluster2][cluster1];
}}
}
var representative=Clazz.array(Integer.TYPE, [this.mNoOfCompounds]);
for (var i=0; i < this.mNoOfCompounds; i++) representative[i]=-1;

for (var index=0; index < this.mNoOfCompounds; index++) if (representative[this.mClusterNo[index]] == -1 || simSum[representative[this.mClusterNo[index]]] < simSum[index]  ) representative[this.mClusterNo[index]]=index;

this.mIsRepresentative=Clazz.array(Boolean.TYPE, [this.mNoOfCompounds]);
for (var index=0; index < this.mNoOfCompounds; index++) if (representative[this.mClusterNo[index]] == index) this.mIsRepresentative[index]=true;

}, p$1);

Clazz.newMeth(C$, 'runInParallel$I',  function (whatToDo) {
var doneSignal=Clazz.new_($I$(6,1).c$$I,[this.mThreadCount]);
for (var worker, $worker = 0, $$worker = this.mClusterWorker; $worker<$$worker.length&&((worker=($$worker[$worker])),1);$worker++) {
worker.initJob$I$java_util_concurrent_CountDownLatch(whatToDo, doneSignal);
this.mExecutor.execute$Runnable(worker);
}
try {
doneSignal.await$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
}, p$1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.Clusterer, "ClusterWorker", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['mMaxSimilarity'],'I',['mWhatToDo','mCluster1','mCluster2'],'O',['mDoneSignal','java.util.concurrent.CountDownLatch','mThreadSafeDH','com.actelion.research.chem.descriptor.DescriptorHandler']]]

Clazz.newMeth(C$, 'initJob$I$java_util_concurrent_CountDownLatch',  function (whatToDo, doneSignal) {
this.mWhatToDo=whatToDo;
this.mDoneSignal=doneSignal;
this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex=Clazz.new_($I$(1,1).c$$I,[this.b$['com.actelion.research.chem.Clusterer'].mNoOfCompounds]);
this.mThreadSafeDH=this.b$['com.actelion.research.chem.Clusterer'].mDescriptorHandler.getThreadSafeCopy$();
});

Clazz.newMeth(C$, 'run$',  function () {
switch (this.mWhatToDo) {
case 1:
var compound2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
while (compound2 >= 1 && !this.b$['com.actelion.research.calc.DataProcessor'].threadMustDie$.apply(this.b$['com.actelion.research.calc.DataProcessor'], []) ){
for (var compound1=0; compound1 < compound2; compound1++) this.b$['com.actelion.research.chem.Clusterer'].mSimilarityMatrix[compound2][compound1]=this.mThreadSafeDH.getSimilarity$O$O(this.b$['com.actelion.research.chem.Clusterer'].mDescriptor[compound1], this.b$['com.actelion.research.chem.Clusterer'].mDescriptor[compound2]);

compound2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
this.b$['com.actelion.research.calc.DataProcessor'].updateProgress$I.apply(this.b$['com.actelion.research.calc.DataProcessor'], [1000 - ((1000.0 * compound2 * compound2  / this.b$['com.actelion.research.chem.Clusterer'].mNoOfCompounds / this.b$['com.actelion.research.chem.Clusterer'].mNoOfCompounds)|0)]);
}
break;
case 2:
compound2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
while (compound2 >= 1 && !this.b$['com.actelion.research.calc.DataProcessor'].threadMustDie$.apply(this.b$['com.actelion.research.calc.DataProcessor'], []) ){
for (var compound1=0; compound1 < compound2; compound1++) if (this.b$['com.actelion.research.chem.Clusterer'].mClusterNo[compound1] == this.b$['com.actelion.research.chem.Clusterer'].mClusterNo[compound2]) this.b$['com.actelion.research.chem.Clusterer'].mSimilarityMatrix[compound2][compound1]=this.mThreadSafeDH.getSimilarity$O$O(this.b$['com.actelion.research.chem.Clusterer'].mDescriptor[compound1], this.b$['com.actelion.research.chem.Clusterer'].mDescriptor[compound2]);

compound2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
this.b$['com.actelion.research.calc.DataProcessor'].updateProgress$I.apply(this.b$['com.actelion.research.calc.DataProcessor'], [1000 - ((1000.0 * compound2 * compound2  / this.b$['com.actelion.research.chem.Clusterer'].mNoOfCompounds / this.b$['com.actelion.research.chem.Clusterer'].mNoOfCompounds)|0)]);
}
break;
case 3:
this.mMaxSimilarity=0;
this.mCluster1=-1;
this.mCluster2=-1;
var cluster2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
while (cluster2 >= 1 && !this.b$['com.actelion.research.calc.DataProcessor'].threadMustDie$.apply(this.b$['com.actelion.research.calc.DataProcessor'], []) ){
if (this.b$['com.actelion.research.chem.Clusterer'].mNoOfMembers[cluster2] > 0) {
for (var cluster1=0; cluster1 < cluster2; cluster1++) {
if (this.b$['com.actelion.research.chem.Clusterer'].mNoOfMembers[cluster1] != 0) {
if (this.mMaxSimilarity < this.b$['com.actelion.research.chem.Clusterer'].mSimilarityMatrix[cluster2][cluster1] ) {
this.mMaxSimilarity=this.b$['com.actelion.research.chem.Clusterer'].mSimilarityMatrix[cluster2][cluster1];
this.mCluster1=cluster1;
this.mCluster2=cluster2;
}}}
}cluster2=this.b$['com.actelion.research.chem.Clusterer'].mSMPCompoundIndex.decrementAndGet$();
}
break;
}
this.mDoneSignal.countDown$();
});

Clazz.newMeth(C$, 'getMaxSimilarity$',  function () {
return this.mMaxSimilarity;
});

Clazz.newMeth(C$, 'getCluster1$',  function () {
return this.mCluster1;
});

Clazz.newMeth(C$, 'getCluster2$',  function () {
return this.mCluster2;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
