(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.Vector','com.actelion.research.chem.Canonizer','com.actelion.research.chem.IDCodeParser','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HoseCodeCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getHoseCodes$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, maxSphereSize, type) {
var ids=Clazz.array(String, [mol.getAtoms$(), maxSphereSize]);
mol.ensureHelperArrays$I(7);
for (var rootAtom=0; rootAtom < mol.getAtoms$(); rootAtom++) {
ids[rootAtom]=C$.getHoseCodesForAtom$com_actelion_research_chem_StereoMolecule$I$I$I(mol, rootAtom, maxSphereSize, type);
}
return ids;
}, 1);

Clazz.newMeth(C$, 'isCsp3$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, atomID) {
if (mol.getAtomicNo$I(atomID) != 6) return false;
if (mol.getAtomCharge$I(atomID) != 0) return false;
if ((mol.getImplicitHydrogens$I(atomID) + mol.getConnAtoms$I(atomID)) != 4) return false;
return true;
}, 1);

Clazz.newMeth(C$, 'getHoseCodesForAtom$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, rootAtom, maxSphereSize, type) {
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(1,1).c$$I$I);
var ids=Clazz.new_($I$(2,1));
var min=0;
var max=0;
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var atomList=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
for (var sphere=0; sphere < maxSphereSize && max < mol.getAtoms$() ; sphere++) {
if (max == 0) {
atomList[0]=rootAtom;
atomMask[rootAtom]=true;
max=1;
} else {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < mol.getConnAtoms$I(atom); j++) {
var connAtom=mol.getConnAtom$I$I(atom, j);
if (false) System.out.println$S("---> " + atom + " to " + connAtom );
if (!atomMask[connAtom]) {
switch (type) {
case 0:
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
break;
case 1:
if (!(C$.isCsp3$com_actelion_research_chem_ExtendedMolecule$I(mol, atom) && C$.isCsp3$com_actelion_research_chem_ExtendedMolecule$I(mol, connAtom) )) {
if (false) System.out.println$S("NO SKIP");
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
} else {
if (false) System.out.println$S("SKIP");
}break;
}
}}
}
min=max;
max=newMax;
}mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, atomMask, true, null);
ids.add$O(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[fragment, 8]).getIDCode$());
}
return ids.toArray$OA(Clazz.array(String, [ids.size$()]));
}, 1);

Clazz.newMeth(C$, 'getHoseCodesFromDiaID$S$I$I',  function (diastereotopicID, maxSphereSize, type) {
var molecule=Clazz.new_($I$(4,1).c$$Z,[true]).getCompactMolecule$S(diastereotopicID);
var atomID=-1;
for (var i=0; i < molecule.getAllAtoms$(); i++) {
var atomCustomLabel=molecule.getAtomCustomLabel$I(i);
if (atomCustomLabel != null  && atomCustomLabel.endsWith$S("*") ) {
atomID=i;
break;
};}
if (atomID >= 0) {
return C$.getHoseCodesForAtom$com_actelion_research_chem_StereoMolecule$I$I$I(molecule, atomID, maxSphereSize, type);
}return Clazz.array(String, [0]);
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var molecule=Clazz.new_($I$(4,1).c$$Z,[false]).getCompactMolecule$S("deT@@DjU_k``b`@@");
var otherMolecule=Clazz.new_([molecule.getAtoms$(), molecule.getBonds$()],$I$(1,1).c$$I$I);
var atomMask=Clazz.array(Boolean.TYPE, [molecule.getAtoms$()]);
$I$(5).fill$ZA$Z(atomMask, true);
molecule.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(otherMolecule, atomMask, true, null);
System.out.println$S(Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule$I,[otherMolecule, 8]).getIDCode$());
var id="fi{qa@DyZkQPSI`cHhhdhdhddhekF\\\\fNXBBjfjjjaXTh@RB@QJh";
var hoses=C$.getHoseCodesFromDiaID$S$I$I(id, 20, 0);
for (var i=0; i < hoses.length; i++) {
System.out.println$S(hoses[i]);
}
hoses=C$.getHoseCodesFromDiaID$S$I$I(id, 8, 1);
for (var i=0; i < hoses.length; i++) {
System.out.println$S(hoses[i]);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
