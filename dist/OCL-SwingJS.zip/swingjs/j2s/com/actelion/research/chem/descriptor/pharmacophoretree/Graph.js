(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),I$=[[0,['com.actelion.research.chem.descriptor.pharmacophoretree.Graph','.Edge'],'java.util.ArrayList','java.util.LinkedList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Graph", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['Edge',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['V'],'O',['adj','java.util.Map','bccs','java.util.List','+bcc']]
,['I',['count','time']]]

Clazz.newMeth(C$, 'c$$java_util_Map',  function (adj) {
;C$.$init$.apply(this);
this.adj=adj;
this.V=adj.size$();
}, 1);

Clazz.newMeth(C$, 'bccutil$I$IA$IA$java_util_LinkedList$IA',  function (u, disc, low, st, parent) {
disc[u]=low[u]=++C$.time;
var children=0;
var it=this.adj.get$O(Integer.valueOf$I(u)).iterator$();
while (it.hasNext$()){
var v=(it.next$()).$c();
if (disc[v] == -1) {
++children;
parent[v]=u;
st.add$O(Clazz.new_($I$(1,1).c$$I$I,[this, null, u, v]));
this.bccutil$I$IA$IA$java_util_LinkedList$IA(v, disc, low, st, parent);
if (low[u] > low[v]) low[u]=low[v];
if ((disc[u] == 1 && children > 1 ) || (disc[u] > 1 && low[v] >= disc[u] ) ) {
while (st.getLast$().u != u || st.getLast$().v != v ){
this.bcc.add$O(Clazz.array(Integer.TYPE, -1, [st.getLast$().u, st.getLast$().v]));
st.removeLast$();
}
this.bcc.add$O(Clazz.array(Integer.TYPE, -1, [st.getLast$().u, st.getLast$().v]));
this.bccs.add$O(this.bcc);
this.bcc=Clazz.new_($I$(2,1));
st.removeLast$();
++C$.count;
}} else if (v != parent[u] && disc[v] < disc[u] ) {
if (low[u] > disc[v]) low[u]=disc[v];
st.add$O(Clazz.new_($I$(1,1).c$$I$I,[this, null, u, v]));
}}
});

Clazz.newMeth(C$, 'bcc$',  function () {
this.bccs=Clazz.new_($I$(2,1));
this.bcc=Clazz.new_($I$(2,1));
var disc=Clazz.array(Integer.TYPE, [this.V]);
var low=Clazz.array(Integer.TYPE, [this.V]);
var parent=Clazz.array(Integer.TYPE, [this.V]);
var st=Clazz.new_($I$(3,1));
for (var i=0; i < this.V; i++) {
disc[i]=-1;
low[i]=-1;
parent[i]=-1;
}
for (var i=0; i < this.V; i++) {
if (disc[i] == -1) this.bccutil$I$IA$IA$java_util_LinkedList$IA(i, disc, low, st, parent);
var j=0;
while (st.size$() > 0){
j=1;
this.bcc.add$O(Clazz.array(Integer.TYPE, -1, [st.getLast$().u, st.getLast$().v]));
st.removeLast$();
}
if (j == 1) {
this.bccs.add$O(this.bcc);
this.bcc=Clazz.new_($I$(2,1));
++C$.count;
}}
return this.bccs;
});

C$.$static$=function(){C$.$static$=0;
C$.count=0;
C$.time=0;
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.Graph, "Edge", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['u','v']]]

Clazz.newMeth(C$, 'c$$I$I',  function (u, v) {
;C$.$init$.apply(this);
this.u=u;
this.v=v;
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:41 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
