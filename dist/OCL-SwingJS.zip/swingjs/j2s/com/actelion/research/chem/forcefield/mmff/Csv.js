(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Csv");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'readFile$S',  function (path) {
var br=null;
try {
var line;
br=Clazz.new_([Clazz.new_([Clazz.getClass(C$).getResourceAsStream$S(path), $I$(3).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
var size=Integer.parseInt$S(br.readLine$().trim$());
var format=br.readLine$().trim$().split$S(",");
var table=Clazz.array(java.lang.Object, [size, format.length]);
for (var ln=0; (line=br.readLine$()) != null  && ln < size ; ln++) {
var row=line.trim$().split$S(",");
for (var c=0; c < format.length; c++) {
switch ((format[c].charCodeAt$I(0))) {
case 105:
table[ln][c]=Integer.valueOf$I(Integer.parseInt$S(row[c].trim$()));
break;
case 102:
table[ln][c]=Double.valueOf$D(Double.parseDouble$S(row[c].trim$()));
break;
case 99:
table[ln][c]=Character.valueOf$C((row[c].trim$().replace$CharSequence$CharSequence("\'", "").replace$CharSequence$CharSequence("\"", "")).charAt$I(0));
break;
}
}
}
return table;
} catch (e$$) {
if (Clazz.exceptionOf(e$$,"java.io.FileNotFoundException")){
var e = e$$;
{
System.out.println$S("Could not find file: '" + path + "'" );
}
} else if (Clazz.exceptionOf(e$$,"java.io.IOException")){
var e = e$$;
{
System.out.println$S("IO Exception!");
}
} else {
throw e$$;
}
} finally {
try {
if (br != null ) br.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
System.out.println$S("Couldn\'t close buffered reader!");
} else {
throw e;
}
}
}
return Clazz.array(java.lang.Object, [1, 1]);
}, 1);

Clazz.newMeth(C$, 'readIntsFile$S',  function (path) {
var table=C$.readFile$S(path);
var rows=table.length;
var cols=table[0].length;
var newtable=Clazz.array(Integer.TYPE, [rows, cols]);
for (var i=0; i < rows; i++) for (var j=0; j < cols; j++) newtable[i][j]=(table[i][j]).intValue$();


return newtable;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
