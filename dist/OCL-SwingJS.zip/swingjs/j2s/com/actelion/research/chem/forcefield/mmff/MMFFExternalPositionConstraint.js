(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "MMFFExternalPositionConstraint", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['k','d'],'I',['constrainedAtom'],'O',['refPos','double[]']]]

Clazz.newMeth(C$, 'c$$I$DA$D$D',  function (atom, refPos, k, d) {
;C$.$init$.apply(this);
this.refPos=refPos;
this.constrainedAtom=atom;
this.k=k;
this.d=d;
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var energy=0.0;
var dx=pos[3 * this.constrainedAtom] - this.refPos[0];
var dy=pos[3 * this.constrainedAtom + 1] - this.refPos[1];
var dz=pos[3 * this.constrainedAtom + 2] - this.refPos[2];
var dist=Math.sqrt(dx * dx + dy * dy + dz * dz);
var prefactor=0.0;
if (dist > this.d ) prefactor=dist - this.d;
 else prefactor=0.0;
energy+=0.5 * this.k * prefactor * prefactor ;
return energy;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var a=this.constrainedAtom;
var dx=pos[3 * a] - this.refPos[0];
var dy=pos[3 * a + 1] - this.refPos[1];
var dz=pos[3 * a + 2] - this.refPos[2];
var dist=Math.sqrt(dx * dx + dy * dy + dz * dz);
var prefactor=0.0;
if (dist > this.d ) prefactor=dist - this.d;
 else prefactor=0.0;
grad[a]+=prefactor * dx / Math.max(dist, 1.0E-8);
grad[a + 1]+=prefactor * dy / Math.max(dist, 1.0E-8);
grad[a + 2]+=prefactor * dz / Math.max(dist, 1.0E-8);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
