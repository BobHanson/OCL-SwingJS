(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimpleCanonizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mGraphGenerated','mZCoordinatesAvailable'],'I',['mGraphRings','mEncodingBitsAvail','mEncodingTempData'],'S',['mIDCode','mCoordinates'],'O',['mMol','com.actelion.research.chem.ExtendedMolecule','mCanRank','int[]','mCanBaseValue','long[]','mGraphAtom','int[]','+mGraphBond','+mGraphFrom','+mGraphClosure','mEncodingBuffer','StringBuffer']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMol.ensureHelperArrays$I(7);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomZ$I(atom) != 0.0 ) {
this.mZCoordinatesAvailable=true;
break;
}}
this.mCanRank=Clazz.array(Integer.TYPE, [this.mMol.getAllAtoms$()]);
this.mCanBaseValue=Clazz.array(Long.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) this.mCanBaseValue[atom]=6;
 else this.mCanBaseValue[atom]=this.mMol.getAtomicNo$I(atom);
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(8)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(this.mMol.getAtomMass$I(atom))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(2)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(this.mMol.getAtomPi$I(atom))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(3)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(this.mMol.getConnAtoms$I(atom))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(4)));
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) (this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(8)));
 else (this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],((8 + this.mMol.getAtomCharge$I(atom)))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(5)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(this.mMol.getAtomRingSize$I(atom))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(4)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],((this.mMol.getAtomAbnormalValence$I(atom) + 1))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(46)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(this.mMol.getAtomQueryFeatures$I(atom))));
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(1)));
if (this.mMol.getAtomList$I(atom) != null ) (Clazz.incrAN(this.mCanBaseValue,atom,1,false));
}
var noOfRanks=p$1.canPerformFullRanking.apply(this, []);
while (noOfRanks < this.mMol.getAtoms$()){
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) this.mCanBaseValue[atom]=2 * this.mCanRank[atom];

var rank;
for (rank=1; rank <= noOfRanks; rank++) {
var rankAtoms=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] == rank) ++rankAtoms;

if (rankAtoms > 1) break;
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mCanRank[atom] == rank) {
(Clazz.incrAN(this.mCanBaseValue,atom,1,false));
break;
}}
noOfRanks=p$1.canPerformFullRanking.apply(this, []);
}
}, 1);

Clazz.newMeth(C$, 'canPerformFullRanking',  function () {
var oldNoOfRanks;
var newNoOfRanks;
newNoOfRanks=p$1.canConsolidate.apply(this, []);
do {
oldNoOfRanks=newNoOfRanks;
p$1.canCalcNextBaseValues.apply(this, []);
newNoOfRanks=p$1.canConsolidate.apply(this, []);
} while (oldNoOfRanks != newNoOfRanks);
return newNoOfRanks;
}, p$1);

Clazz.newMeth(C$, 'canCalcNextBaseValues',  function () {
var connRank=Clazz.array(Integer.TYPE, [16]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var rank=2 * this.mCanRank[this.mMol.getConnAtom$I$I(atom, i)];
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.getBondOrder$I(connBond) == 2) if (!this.mMol.isAromaticBond$I(connBond)) ++rank;
var j;
for (j=0; j < i; j++) if (rank < connRank[j]) break;

for (var k=i; k > j; k--) connRank[k]=connRank[k - 1];

connRank[j]=rank;
}
this.mCanBaseValue[atom]=0;
for (var i=0; i < Math.min(6, this.mMol.getConnAtoms$I(atom)); i++) {
(this.mCanBaseValue[$k$=atom]=Long.$sl(this.mCanBaseValue[$k$],(9)));
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],(connRank[i])));
}
(this.mCanBaseValue[$k$=atom]=Long.$add(this.mCanBaseValue[$k$],((this.mCanRank[atom] << 55))));
}
}, p$1);

Clazz.newMeth(C$, 'canConsolidate',  function () {
var canRank=0;
var lowest;
while (true){
lowest=[16777215,549755813887,1];
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$gt(lowest,this.mCanBaseValue[atom] )) lowest=this.mCanBaseValue[atom];

if (Long.$ne(lowest,[16777215,549755813887,1] )) {
++canRank;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$eq(this.mCanBaseValue[atom],lowest )) {
this.mCanBaseValue[atom]=[16777215,549755813887,1];
this.mCanRank[atom]=canRank;
}
continue;
}break;
}
return canRank;
}, p$1);

Clazz.newMeth(C$, 'generateGraph',  function () {
if (this.mMol.getAtoms$() == 0) return;
if (this.mGraphGenerated) return;
var startAtom=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) if (this.mCanRank[atom] > this.mCanRank[startAtom]) startAtom=atom;

var atomHandled=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var bondHandled=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
var newAtomNo=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphFrom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mGraphBond=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
this.mGraphAtom[0]=startAtom;
atomHandled[startAtom]=true;
var atomsWithoutParents=1;
var firstUnhandled=0;
var firstUnused=1;
var graphBonds=0;
while (firstUnhandled < this.mMol.getAtoms$()){
if (firstUnhandled < firstUnused) {
while (true){
var highestRankingConnAtom=0;
var highestRankingConnBond=0;
var highestRank=-1;
for (var i=0; i < this.mMol.getConnAtoms$I(this.mGraphAtom[firstUnhandled]); i++) {
var connAtom=this.mMol.getConnAtom$I$I(this.mGraphAtom[firstUnhandled], i);
if (!atomHandled[connAtom] && this.mCanRank[connAtom] > highestRank ) {
highestRankingConnAtom=connAtom;
highestRankingConnBond=this.mMol.getConnBond$I$I(this.mGraphAtom[firstUnhandled], i);
highestRank=this.mCanRank[connAtom];
}}
if (highestRank == -1) break;
newAtomNo[highestRankingConnAtom]=firstUnused;
this.mGraphFrom[firstUnused]=firstUnhandled;
this.mGraphAtom[firstUnused++]=highestRankingConnAtom;
this.mGraphBond[graphBonds++]=highestRankingConnBond;
atomHandled[highestRankingConnAtom]=true;
bondHandled[highestRankingConnBond]=true;
}
++firstUnhandled;
} else {
var highestRankingAtom=0;
var highestRank=-1;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (!atomHandled[atom] && this.mCanRank[atom] > highestRank ) {
highestRankingAtom=atom;
highestRank=this.mCanRank[atom];
}}
++atomsWithoutParents;
newAtomNo[highestRankingAtom]=firstUnused;
this.mGraphFrom[firstUnused]=-1;
this.mGraphAtom[firstUnused++]=highestRankingAtom;
atomHandled[highestRankingAtom]=true;
}}
this.mGraphClosure=Clazz.array(Integer.TYPE, [2 * (this.mMol.getBonds$() - graphBonds)]);
this.mGraphRings=0;
while (true){
var lowAtomNo1=this.mMol.getMaxAtoms$();
var lowAtomNo2=this.mMol.getMaxAtoms$();
var lowBond=-1;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var loAtom;
var hiAtom;
if (!bondHandled[bond]) {
if (newAtomNo[this.mMol.getBondAtom$I$I(0, bond)] < newAtomNo[this.mMol.getBondAtom$I$I(1, bond)]) {
loAtom=newAtomNo[this.mMol.getBondAtom$I$I(0, bond)];
hiAtom=newAtomNo[this.mMol.getBondAtom$I$I(1, bond)];
} else {
loAtom=newAtomNo[this.mMol.getBondAtom$I$I(1, bond)];
hiAtom=newAtomNo[this.mMol.getBondAtom$I$I(0, bond)];
}if (loAtom < lowAtomNo1 || (loAtom == lowAtomNo1 && hiAtom < lowAtomNo2 ) ) {
lowAtomNo1=loAtom;
lowAtomNo2=hiAtom;
lowBond=bond;
}}}
if (lowBond == -1) break;
bondHandled[lowBond]=true;
this.mGraphBond[graphBonds++]=lowBond;
this.mGraphClosure[2 * this.mGraphRings]=lowAtomNo1;
this.mGraphClosure[2 * this.mGraphRings + 1]=lowAtomNo2;
++this.mGraphRings;
}
this.mGraphGenerated=true;
}, p$1);

Clazz.newMeth(C$, 'getIDCode$',  function () {
p$1.generateGraph.apply(this, []);
p$1.idCodeCreate.apply(this, []);
return this.mIDCode.toString();
});

Clazz.newMeth(C$, 'idCodeCreate',  function () {
p$1.encodeBitsStart.apply(this, []);
p$1.encodeBits$J$I.apply(this, [9, 4]);
var nbits=Math.max(p$1.idGetNeededBits$I.apply(this, [this.mMol.getAtoms$()]), p$1.idGetNeededBits$I.apply(this, [this.mMol.getBonds$()]));
p$1.encodeBits$J$I.apply(this, [nbits, 4]);
if (nbits == 0) {
p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
return;
}var nitrogens;
var oxygens;
var otherAtoms;
var chargedAtoms;
nitrogens=oxygens=otherAtoms=chargedAtoms=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 )) {
switch (this.mMol.getAtomicNo$I(atom)) {
case 6:
break;
case 7:
++nitrogens;
break;
case 8:
++oxygens;
break;
default:
++otherAtoms;
break;
}
if (this.mMol.getAtomCharge$I(atom) != 0) ++chargedAtoms;
}}
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtoms$(), nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getBonds$(), nbits]);
p$1.encodeBits$J$I.apply(this, [nitrogens, nbits]);
p$1.encodeBits$J$I.apply(this, [oxygens, nbits]);
p$1.encodeBits$J$I.apply(this, [otherAtoms, nbits]);
p$1.encodeBits$J$I.apply(this, [chargedAtoms, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 7 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) == 8 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) p$1.encodeBits$J$I.apply(this, [atom, nbits]);

for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 6 && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 7  && this.mMol.getAtomicNo$I(this.mGraphAtom[atom]) != 8  && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomicNo$I(this.mGraphAtom[atom]), 8]);
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomCharge$I(this.mGraphAtom[atom]) != 0 && Long.$eq((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),1)),0 ) ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [8 + this.mMol.getAtomCharge$I(this.mGraphAtom[atom]), 4]);
}
var maxdif=0;
var base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}if (maxdif < dif) maxdif=dif;
}
var dbits=p$1.idGetNeededBits$I.apply(this, [maxdif]);
p$1.encodeBits$J$I.apply(this, [dbits, 4]);
base=0;
for (var atom=1; atom < this.mMol.getAtoms$(); atom++) {
var dif;
if (this.mGraphFrom[atom] == -1) {
dif=0;
} else {
dif=1 + this.mGraphFrom[atom] - base;
base=this.mGraphFrom[atom];
}p$1.encodeBits$J$I.apply(this, [dif, dbits]);
}
for (var i=0; i < 2 * this.mGraphRings; i++) p$1.encodeBits$J$I.apply(this, [this.mGraphClosure[i], nbits]);

for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var bondOrder=((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & 130560) != 0 || this.mMol.getBondType$I(this.mGraphBond[bond]) == 16 ) ? 1 : (this.mMol.isDelocalizedBond$I(this.mGraphBond[bond])) ? 0 : this.mMol.getBondOrder$I(this.mGraphBond[bond]);
p$1.encodeBits$J$I.apply(this, [bondOrder, 2]);
}
p$1.encodeBits$J$I.apply(this, [0, nbits]);
p$1.encodeBits$J$I.apply(this, [0, 1]);
p$1.encodeBits$J$I.apply(this, [0, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.isFragment$() ? 1 : 0, 1]);
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [1, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomMass$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomMass$I(this.mGraphAtom[atom]), 8]);
}}
}var isSecondFeatureBlock=false;
if (this.mMol.isFragment$()) {
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [0, false, nbits, 2048, 1, -1]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [3, false, nbits, 4096, 1, -1]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [4, false, nbits, 120, 4, 3]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [5, false, nbits, 70368744177670, 2, 1]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [6, false, nbits, 1, 1, -1]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [7, false, nbits, 1920, 4, 7]);
count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomList$I(this.mGraphAtom[atom]) != null ) ++count;

if (count > 0) {
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [8, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var atomList=this.mMol.getAtomList$I(this.mGraphAtom[atom]);
if (atomList != null ) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [atomList.length, 4]);
for (var i=0; i < atomList.length; i++) p$1.encodeBits$J$I.apply(this, [atomList[i], 8]);

}}
}p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [9, false, nbits, 384, 2, 7]);
p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [10, false, nbits, 31, 5, 0]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [11, false, nbits, 8192, 1, -1]);
p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [12, false, nbits, 130560, 8, 9]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [13, false, nbits, 114688, 3, 14]);
p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [14, false, nbits, 4063232, 5, 17]);
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [16, isSecondFeatureBlock, nbits, 29360128, 3, 22])));
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomAbnormalValence$I(this.mGraphAtom[atom]) != -1) ++count;

if (count != 0) {
isSecondFeatureBlock=p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [1, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomAbnormalValence$I(this.mGraphAtom[atom]) != -1) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomAbnormalValence$I(this.mGraphAtom[atom]), 4]);
}}
}if (this.mMol.isFragment$()) {
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [19, isSecondFeatureBlock, nbits, 234881024, 3, 25])));
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [20, isSecondFeatureBlock, nbits, 917504, 3, 17])));
}count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) ++count;

if (count != 0) {
isSecondFeatureBlock=p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [5, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) != 0) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
p$1.encodeBits$J$I.apply(this, [this.mMol.getAtomRadical$I(this.mGraphAtom[atom]) >> 4, 2]);
}}
}if (this.mMol.isFragment$()) {
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [22, isSecondFeatureBlock, nbits, 268435456, 1, -1])));
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [23, isSecondFeatureBlock, nbits, 1048576, 1, -1])));
isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addBondQueryFeatures$I$Z$I$I$I$I.apply(this, [24, isSecondFeatureBlock, nbits, 6291456, 2, 21])));
}var isAromaticSPBond=p$1.getAromaticSPBonds.apply(this, []);
if (isAromaticSPBond != null ) {
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) ++count;

isSecondFeatureBlock=p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [10, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (isAromaticSPBond[this.mGraphBond[bond]]) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

}if (this.mMol.isFragment$()) isSecondFeatureBlock=!!(isSecondFeatureBlock|(p$1.addAtomQueryFeatures$I$Z$I$J$I$I.apply(this, [27, isSecondFeatureBlock, nbits, 536870912, 1, -1])));
count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 16) ++count;

isSecondFeatureBlock=p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [12, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if (this.mMol.getBondType$I(this.mGraphBond[bond]) == 16) p$1.encodeBits$J$I.apply(this, [bond, nbits]);

p$1.encodeBits$J$I.apply(this, [0, 1]);
this.mIDCode=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'ensureSecondFeatureBlock$Z',  function (isSecondFeatureBlock) {
if (!isSecondFeatureBlock) {
p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [15, 4]);
}return true;
}, p$1);

Clazz.newMeth(C$, 'addAtomQueryFeatures$I$Z$I$J$I$I',  function (codeNo, isSecondFeatureBlock, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask)),0 )) ++count;

if (count == 0) return false;
if (codeNo > 15) {
p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
codeNo-=16;
}p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [codeNo, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var feature=Long.$and(this.mMol.getAtomQueryFeatures$I(this.mGraphAtom[atom]),qfMask);
if (Long.$ne(feature,0 )) {
p$1.encodeBits$J$I.apply(this, [atom, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [Long.$sr(feature,qfShift), qfBits]);
}}
return true;
}, p$1);

Clazz.newMeth(C$, 'addBondQueryFeatures$I$Z$I$I$I$I',  function (codeNo, isSecondFeatureBlock, nbits, qfMask, qfBits, qfShift) {
var count=0;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask) != 0) ++count;

if (count == 0) return false;
if (codeNo > 15) {
p$1.ensureSecondFeatureBlock$Z.apply(this, [isSecondFeatureBlock]);
codeNo-=16;
}p$1.encodeBits$J$I.apply(this, [1, 1]);
p$1.encodeBits$J$I.apply(this, [codeNo, 4]);
p$1.encodeBits$J$I.apply(this, [count, nbits]);
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
var feature=this.mMol.getBondQueryFeatures$I(this.mGraphBond[bond]) & qfMask;
if (feature != 0) {
p$1.encodeBits$J$I.apply(this, [bond, nbits]);
if (qfBits != 1) p$1.encodeBits$J$I.apply(this, [feature >> qfShift, qfBits]);
}}
return true;
}, p$1);

Clazz.newMeth(C$, 'getAromaticSPBonds',  function () {
var isAromaticSPBond=null;
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getAtomPi$I(this.mMol.getBondAtom$I$I(0, bond)) == 2 && this.mMol.getAtomPi$I(this.mMol.getBondAtom$I$I(1, bond)) == 2 ) {
if (isAromaticSPBond == null ) isAromaticSPBond=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
isAromaticSPBond[bond]=true;
}}
return isAromaticSPBond;
}, p$1);

Clazz.newMeth(C$, 'getEncodedCoordinates$',  function () {
if (this.mCoordinates == null ) {
p$1.generateGraph.apply(this, []);
p$1.encodeCoordinates$Z.apply(this, [this.mZCoordinatesAvailable]);
}return this.mCoordinates;
});

Clazz.newMeth(C$, 'encodeCoordinates$Z',  function (keepAbsoluteValues) {
if (this.mMol.getAtoms$() == 0) {
this.mCoordinates="";
return;
}var resolutionBits=this.mZCoordinatesAvailable ? 16 : 8;
p$1.encodeBitsStart.apply(this, []);
this.mEncodingBuffer.append$C("!");
p$1.encodeBits$J$I.apply(this, [this.mZCoordinatesAvailable ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [keepAbsoluteValues ? 1 : 0, 1]);
p$1.encodeBits$J$I.apply(this, [(resolutionBits/2|0), 4]);
var maxDelta=0.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
var from=(this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]];
var deltaX=(from == -1) ? Math.abs(this.mMol.getAtomX$I(atom) - this.mMol.getAtomX$I(this.mGraphAtom[0])) / 8.0 : Math.abs(this.mMol.getAtomX$I(atom) - this.mMol.getAtomX$I(from));
if (maxDelta < deltaX ) maxDelta=deltaX;
var deltaY=(from == -1) ? Math.abs(this.mMol.getAtomY$I(atom) - this.mMol.getAtomY$I(this.mGraphAtom[0])) / 8.0 : Math.abs(this.mMol.getAtomY$I(atom) - this.mMol.getAtomY$I(from));
if (maxDelta < deltaY ) maxDelta=deltaY;
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? Math.abs(this.mMol.getAtomZ$I(atom) - this.mMol.getAtomZ$I(this.mGraphAtom[0])) / 8.0 : Math.abs(this.mMol.getAtomZ$I(atom) - this.mMol.getAtomZ$I(from));
if (maxDelta < deltaZ ) maxDelta=deltaZ;
}}
if (maxDelta == 0.0 ) {
this.mCoordinates="";
return;
}var binCount=(1 << resolutionBits);
var increment=maxDelta / (binCount / 2.0 - 1);
var halfIncrement=increment / 2.0;
for (var i=1; i < this.mMol.getAtoms$(); i++) {
var atom=this.mGraphAtom[i];
var from=(this.mGraphFrom[i] == -1) ? -1 : this.mGraphAtom[this.mGraphFrom[i]];
var deltaX=(from == -1) ? (this.mMol.getAtomX$I(atom) - this.mMol.getAtomX$I(this.mGraphAtom[0])) / 8.0 : this.mMol.getAtomX$I(atom) - this.mMol.getAtomX$I(from);
var deltaY=(from == -1) ? (this.mMol.getAtomY$I(atom) - this.mMol.getAtomY$I(this.mGraphAtom[0])) / 8.0 : this.mMol.getAtomY$I(atom) - this.mMol.getAtomY$I(from);
p$1.encodeBits$J$I.apply(this, [(((maxDelta + deltaX + halfIncrement ) / increment)|0), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [(((maxDelta + deltaY + halfIncrement ) / increment)|0), resolutionBits]);
if (this.mZCoordinatesAvailable) {
var deltaZ=(from == -1) ? (this.mMol.getAtomZ$I(atom) - this.mMol.getAtomZ$I(this.mGraphAtom[0])) / 8.0 : this.mMol.getAtomZ$I(atom) - this.mMol.getAtomZ$I(from);
p$1.encodeBits$J$I.apply(this, [(((maxDelta + deltaZ + halfIncrement ) / increment)|0), resolutionBits]);
}}
if (keepAbsoluteValues) {
p$1.encodeBits$J$I.apply(this, [p$1.encodeABVL$D$I.apply(this, [this.mMol.getAverageBondLength$Z(true), binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [this.mMol.getAtomX$I(this.mGraphAtom[0]), binCount]), resolutionBits]);
p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [this.mMol.getAtomY$I(this.mGraphAtom[0]), binCount]), resolutionBits]);
if (this.mZCoordinatesAvailable) p$1.encodeBits$J$I.apply(this, [p$1.encodeShift$D$I.apply(this, [this.mMol.getAtomZ$I(this.mGraphAtom[0]), binCount]), resolutionBits]);
}this.mCoordinates=p$1.encodeBitsEnd.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'encodeABVL$D$I',  function (value, binCount) {
return Math.min(binCount - 1, Math.max(0, ((0.5 + Math.log10(value / 0.1) / Math.log10(2000.0) * (binCount - 1))|0)));
}, p$1);

Clazz.newMeth(C$, 'encodeShift$D$I',  function (value, binCount) {
var halfBinCount=(binCount/2|0);
var isNegative=(value < 0 );
value=Math.abs(value);
var steepness=binCount / 100.0;
var intValue=((0.5 + value * (halfBinCount - 1) / (value + steepness))|0);
return isNegative ? halfBinCount + intValue : intValue;
}, p$1);

Clazz.newMeth(C$, 'encodeBitsStart',  function () {
this.mEncodingBuffer=Clazz.new_($I$(1,1));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
}, p$1);

Clazz.newMeth(C$, 'encodeBits$J$I',  function (data, bits) {
while (bits != 0){
if (this.mEncodingBitsAvail == 0) {
this.mEncodingBuffer.append$C(String.fromCharCode((this.mEncodingTempData + 64)));
this.mEncodingBitsAvail=6;
this.mEncodingTempData=0;
}this.mEncodingTempData<<=1;
this.mEncodingTempData=Long.$ival(Long.$or(this.mEncodingTempData,((Long.$and(data,1)))));
(data=Long.$sr(data,(1)));
--bits;
--this.mEncodingBitsAvail;
}
}, p$1);

Clazz.newMeth(C$, 'encodeBitsEnd',  function () {
this.mEncodingTempData<<=this.mEncodingBitsAvail;
this.mEncodingBuffer.append$C(String.fromCharCode((this.mEncodingTempData + 64)));
return this.mEncodingBuffer.toString();
}, p$1);

Clazz.newMeth(C$, 'idGetNeededBits$I',  function (no) {
var bits=0;
while (no > 0){
no>>=1;
++bits;
}
return bits;
}, p$1);
var $k$;

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
