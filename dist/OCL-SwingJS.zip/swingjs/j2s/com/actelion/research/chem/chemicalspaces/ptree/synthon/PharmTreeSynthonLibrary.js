(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.ptree.synthon"),I$=[[0,'com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmTreeSynthonLibrary");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['reactionID'],'O',['synthons','java.util.List','rxnHelper','com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper']]]

Clazz.newMeth(C$, 'c$$java_util_List',  function (synthons) {
;C$.$init$.apply(this);
this.synthons=synthons;
this.rxnHelper=Clazz.new_([this.getGenericReactants$()],$I$(1,1).c$$java_util_List);
}, 1);

Clazz.newMeth(C$, 'getSynthons$',  function () {
return this.synthons;
});

Clazz.newMeth(C$, 'getReactionHelper$',  function () {
return this.rxnHelper;
});

Clazz.newMeth(C$, 'setReactionHelper$com_actelion_research_chem_chemicalspaces_ptree_PharmTreeSynthonReactionHelper',  function (reactor) {
this.rxnHelper=reactor;
});

Clazz.newMeth(C$, 'getGenericReactants$',  function () {
var genericReactants=Clazz.new_($I$(2,1));
for (var synthonList, $synthonList = this.synthons.iterator$(); $synthonList.hasNext$()&&((synthonList=($synthonList.next$())),1);) {
var minimalSynthon=synthonList.get$I(0).createMinimalSynthon$();
try {
genericReactants.add$O(minimalSynthon);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S(minimalSynthon.getIDCode$());
e.printStackTrace$();
} else {
throw e;
}
}
}
return genericReactants;
});

Clazz.newMeth(C$, 'getReactionID$',  function () {
return this.reactionID;
});

Clazz.newMeth(C$, 'setReactionID$S',  function (reactionID) {
this.reactionID=reactionID;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
