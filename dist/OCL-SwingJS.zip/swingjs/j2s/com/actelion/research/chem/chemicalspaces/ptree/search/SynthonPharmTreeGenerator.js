(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.ptree.search"),p$1={},I$=[[0,'java.util.stream.Collectors','java.util.ArrayList','java.util.HashSet','com.actelion.research.chem.descriptor.pharmacophoretree.FeatureCalculator','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTreeGenerator','java.util.stream.IntStream','java.util.HashMap','com.actelion.research.chem.SSSearcher','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.chemicalspaces.ptree.synthon.PharmTreeSynthon','java.util.Arrays','com.actelion.research.chem.Canonizer','com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['synthonLib','com.actelion.research.chem.chemicalspaces.ptree.synthon.PharmTreeSynthonLibrary','genericSynthons','java.util.List','rxnHelper','com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_chemicalspaces_ptree_synthon_PharmTreeSynthonLibrary',  function (synthonLib) {
;C$.$init$.apply(this);
this.synthonLib=synthonLib;
this.genericSynthons=synthonLib.getGenericReactants$();
this.rxnHelper=synthonLib.getReactionHelper$();
p$1.furtherProcessGenericSynthons.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'processBuildingBlocks$',  function () {
var ringReactantIndeces=this.rxnHelper.getRingReactantIndeces$();
var ringWithLinks=this.rxnHelper.getRingWithLinks$();
var genericProduct=this.rxnHelper.getGenericProduct$();
var reactantsWithLinkers=this.rxnHelper.getReactantsWithLinkers$().entrySet$().stream$().collect$java_util_stream_Collector($I$(1,"toMap$java_util_function_Function$java_util_function_Function",[((P$.SynthonPharmTreeGenerator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (e.getKey$.apply(e, []));});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda1.$init$,[this, null])), ((P$.SynthonPharmTreeGenerator$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (Clazz.new_([e.getValue$.apply(e, [])],$I$(2,1).c$$java_util_Collection));});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda2.$init$,[this, null]))]));
var linkersToDelete=Clazz.new_($I$(3,1));
for (var ring, $ring = ringReactantIndeces.keySet$().iterator$(); $ring.hasNext$()&&((ring=($ring.next$()).intValue$()),1);) {
var nLinkers=ringReactantIndeces.get$O(Integer.valueOf$I(ring)).size$() - 1;
var toDelete=ringWithLinks.get$O(Integer.valueOf$I(ring)).size$() - nLinkers;
var iterator=ringWithLinks.get$O(Integer.valueOf$I(ring)).iterator$();
for (var i=0; i < toDelete; i++) {
var del=(iterator.next$()).$c();
linkersToDelete.add$O(Integer.valueOf$I(del));
reactantsWithLinkers.forEach$java_util_function_BiConsumer(((P$.SynthonPharmTreeGenerator$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) { return (v.remove$O.apply(v, [Integer.valueOf$I(this.$finals$.del)]));});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda3.$init$,[this, {del:del}])));
}
}
for (var i=0; i < this.synthonLib.getSynthons$().size$(); i++) {
var synthonList=this.synthonLib.getSynthons$().get$I(i);
for (var bb=0; bb < synthonList.size$(); bb++) {
var buildingBlock=synthonList.get$I(bb).getStructure$();
for (var a=0; a < buildingBlock.getAtoms$(); a++) {
if (buildingBlock.getAtomLabel$I(a).equals$O("U")) {
var bond=buildingBlock.getConnBond$I$I(a, 0);
buildingBlock.setBondOrder$I$I(bond, this.rxnHelper.getBondOrders$()[0]);
} else if (buildingBlock.getAtomLabel$I(a).equals$O("Np")) {
var bond=buildingBlock.getConnBond$I$I(a, 0);
buildingBlock.setBondOrder$I$I(bond, this.rxnHelper.getBondOrders$()[1]);
} else if (buildingBlock.getAtomLabel$I(a).equals$O("Pu")) {
var bond=buildingBlock.getConnBond$I$I(a, 0);
buildingBlock.setBondOrder$I$I(bond, this.rxnHelper.getBondOrders$()[2]);
} else if (buildingBlock.getAtomLabel$I(a).equals$O("Am")) {
var bond=buildingBlock.getConnBond$I$I(a, 0);
buildingBlock.setBondOrder$I$I(bond, this.rxnHelper.getBondOrders$()[3]);
}}
var bbTree=this.calculatePTree$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$java_util_Map$java_util_Map(buildingBlock, genericProduct, i, ringReactantIndeces, reactantsWithLinkers);
if (bbTree == null ) continue;
var nodesToBeDeleted=Clazz.new_($I$(2,1));
for (var node, $node = bbTree.getNodes$().iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
if (node.isLinkNode$()) {
if (linkersToDelete.contains$O(Integer.valueOf$I(node.getFunctionalities$()[0]))) nodesToBeDeleted.add$O(node);
}}
nodesToBeDeleted.forEach$java_util_function_Consumer(((P$.SynthonPharmTreeGenerator$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode','accept$O'],  function (e) {
this.$finals$.bbTree.removeNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode.apply(this.$finals$.bbTree, [e]);
});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda4.$init$,[this, {bbTree:bbTree}])));
synthonList.get$I(bb).setPharmacophoreTree$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree(bbTree);
}
}
});

Clazz.newMeth(C$, 'calculatePTree$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$I$java_util_Map$java_util_Map',  function (bb, genericProduct, synthonID, ringReactantIndeces, reactantsWithLinkers) {
var calculator=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[genericProduct]);
calculator.calculate$();
var productAtomFunctionalities=calculator.getAtomFunctionalities$();
var productAtomVolumes=$I$(5).getAtomVolumes$com_actelion_research_chem_StereoMolecule(genericProduct);
var ringFunctionalities=Clazz.new_($I$(2,1));
var ringVolumes=Clazz.new_($I$(2,1));
for (var ring, $ring = this.rxnHelper.getFormedRings$().iterator$(); $ring.hasNext$()&&((ring=($ring.next$())),1);) {
var func=Clazz.array(Integer.TYPE, [6]);
var volumes=Clazz.new_($I$(2,1));
for (var ringAtom, $ringAtom = ring.iterator$(); $ringAtom.hasNext$()&&((ringAtom=($ringAtom.next$()).intValue$()),1);) {
var atomFunc=productAtomFunctionalities[ringAtom];
$I$(6).range$I$I(0, func.length).forEach$java_util_function_IntConsumer(((P$.SynthonPharmTreeGenerator$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) { return (this.$finals$.func[e]+=this.$finals$.atomFunc[e]);});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda5.$init$,[this, {func:func,atomFunc:atomFunc}])));
volumes.add$O(Double.valueOf$D(productAtomVolumes[ringAtom]));
}
ringFunctionalities.add$O(func);
ringVolumes.add$O(volumes);
}
var reactantToBBMap=Clazz.array(Integer.TYPE, [0]);
var rings=Clazz.new_($I$(7,1));
if (this.rxnHelper.getFormedRings$().size$() > 0) {
var searcher=Clazz.new_($I$(8,1));
searcher.setFragment$com_actelion_research_chem_StereoMolecule(this.genericSynthons.get$I(synthonID));
searcher.setMolecule$com_actelion_research_chem_StereoMolecule(bb);
searcher.findFragmentInMolecule$();
var matches=searcher.getMatchList$();
if (matches.size$() != 1) {
System.err.println$S("could not match generic reactant to building block");
System.err.println$S(this.genericSynthons.get$I(synthonID).getIDCode$());
System.err.println$S(bb.getIDCode$());
return null;
} else {
reactantToBBMap=matches.get$I(0);
}for (var a=0; a < bb.getAtoms$(); a++) {
if (bb.getAtomicNo$I(a) >= 92) continue;
for (var i=0; i < reactantToBBMap.length; i++) {
if (reactantToBBMap[i] == a) {
var reactantIndex=i;
var productIndex=this.rxnHelper.mapSynthonToGenericProductIndex$I$I(synthonID, reactantIndex);
for (var l=0; l < this.rxnHelper.getFormedRings$().size$(); l++) {
if (this.rxnHelper.getFormedRings$().get$I(l).contains$O(Integer.valueOf$I(productIndex))) {
var ringIndex=l;
rings.putIfAbsent$O$O(Integer.valueOf$I(ringIndex), Clazz.new_($I$(3,1)));
rings.get$O(Integer.valueOf$I(ringIndex)).add$O(Integer.valueOf$I(a));
}}
}}
}
}var atomToNodes=Clazz.new_($I$(7,1));
var bbTree=$I$(5,"generate$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List",[bb, atomToNodes, rings.values$().stream$().collect$java_util_stream_Collector($I$(1).toList$())]);
var ringMainReactants=Clazz.new_($I$(7,1));
for (var ring, $ring = ringReactantIndeces.keySet$().iterator$(); $ring.hasNext$()&&((ring=($ring.next$()).intValue$()),1);) {
var reactants=ringReactantIndeces.get$O(Integer.valueOf$I(ring));
var iterator=reactants.iterator$();
var maxLinkers=0;
var mainReactant=-1;
while (iterator.hasNext$()){
var reactant=(iterator.next$()).$c();
if (reactantsWithLinkers.get$O(Integer.valueOf$I(reactant)).size$() > maxLinkers) {
maxLinkers=reactantsWithLinkers.get$O(Integer.valueOf$I(reactant)).size$();
mainReactant=reactant;
}}
ringMainReactants.put$O$O(Integer.valueOf$I(ring), Integer.valueOf$I(mainReactant));
}
for (var node, $node = bbTree.getNodes$().iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
if (node.isLinkNode$()) continue;
 else {
var nodeProcessed=false;
for (var index=0; index < node.getAtoms$().size$() && !nodeProcessed ; index++) {
var a=(node.getAtoms$().get$I(index)).$c();
for (var i=0; i < reactantToBBMap.length; i++) {
if (reactantToBBMap[i] == a) {
var reactantIndex=i;
var productIndex=this.rxnHelper.mapSynthonToGenericProductIndex$I$I(synthonID, reactantIndex);
for (var l=0; l < this.rxnHelper.getFormedRings$().size$(); l++) {
var formedRing=this.rxnHelper.getFormedRings$().get$I(l);
if (formedRing.contains$O(Integer.valueOf$I(productIndex))) {
nodeProcessed=true;
var ringIndex=l;
var mainReactantSynthonID=(ringMainReactants.get$O(Integer.valueOf$I(ringIndex))).$c();
if (synthonID == mainReactantSynthonID) {
var dummyAtomsToAdd=formedRing.size$() - node.getAtoms$().size$();
for (var da=0; da < dummyAtomsToAdd; da++) {
node.getAtoms$().add$O(Integer.valueOf$I(-1));
node.getWeights$().add$O(Double.valueOf$D(1.0));
}
var weights=Clazz.new_($I$(2,1));
$I$(6,"range$I$I",[0, node.getAtoms$().size$()]).forEach$java_util_function_IntConsumer(((P$.SynthonPharmTreeGenerator$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonPharmTreeGenerator$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) { return (this.$finals$.weights.add$O.apply(this.$finals$.weights, [Double.valueOf$D(1.0)]));});
})()
), Clazz.new_(P$.SynthonPharmTreeGenerator$lambda6.$init$,[this, {weights:weights}])));
node.setFunctionalities$IA(ringFunctionalities.get$I(l));
node.setVolumes$java_util_List(ringVolumes.get$I(l));
} else {
node.setFunctionalities$IA(Clazz.array(Integer.TYPE, [6]));
node.setVolumes$java_util_List(Clazz.new_($I$(2,1)));
node.setWeights$java_util_List(Clazz.new_($I$(2,1)));
node.setAtoms$java_util_List(Clazz.new_($I$(2,1)));
node.setRole$I(1);
}node.calculate$();
}}
}}
}
}}
return bbTree;
});

Clazz.newMeth(C$, 'furtherProcessGenericSynthons',  function () {
var newGenericSynthons=Clazz.new_($I$(2,1));
var ringWithLinks=this.rxnHelper.getRingWithLinks$();
var reactantsWithRings=Clazz.new_($I$(7,1));
var ringsWithReactants=this.rxnHelper.getRingReactantIndeces$();
for (var s=0; s < this.genericSynthons.size$(); s++) {
reactantsWithRings.put$O$O(Integer.valueOf$I(s), Clazz.new_($I$(3,1)));
for (var entry, $entry = ringsWithReactants.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
if (entry.getValue$().contains$O(Integer.valueOf$I(s))) {
reactantsWithRings.get$O(Integer.valueOf$I(s)).add$O(entry.getKey$());
}}
var ringFormationSynthon=Clazz.new_($I$(9,1));
var mol=this.genericSynthons.get$I(s);
if (reactantsWithRings.get$O(Integer.valueOf$I(s)).size$() == 0) ringFormationSynthon.addMolecule$com_actelion_research_chem_Molecule(mol);
 else {
var synthon=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var allConnectorAtoms=Clazz.new_([synthon.getConnectorLabels$().values$()],$I$(2,1).c$$java_util_Collection);
var usedConnectorAtoms=Clazz.new_($I$(2,1));
for (var ring, $ring = reactantsWithRings.get$O(Integer.valueOf$I(s)).iterator$(); $ring.hasNext$()&&((ring=($ring.next$()).intValue$()),1);) {
synthon=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var connectorAtomsToKeep=Clazz.new_($I$(2,1));
for (var entry, $entry = synthon.getConnectorLabels$().entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var linkerNo=synthon.getLinkerNoFromConnectorLabel$S(entry.getKey$());
var ringLinks=ringWithLinks.get$O(Integer.valueOf$I(ring));
if (ringLinks.contains$O(Integer.valueOf$I(linkerNo))) {
connectorAtomsToKeep.add$O(entry.getValue$());
}}
usedConnectorAtoms.addAll$java_util_Collection(connectorAtomsToKeep);
ringFormationSynthon.addMolecule$com_actelion_research_chem_Molecule(synthon.cutConnectorPaths$com_actelion_research_chem_StereoMolecule$java_util_List(synthon.getStructure$(), connectorAtomsToKeep));
}
for (var connAtom, $connAtom = allConnectorAtoms.iterator$(); $connAtom.hasNext$()&&((connAtom=($connAtom.next$()).intValue$()),1);) {
if (!usedConnectorAtoms.contains$O(Integer.valueOf$I(connAtom))) {
var atomPath=$I$(11,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(connAtom), Integer.valueOf$I(mol.getConnAtom$I$I(connAtom, 0))])]);
ringFormationSynthon.addMolecule$com_actelion_research_chem_Molecule(synthon.cutConnectorPaths$com_actelion_research_chem_StereoMolecule$java_util_List(synthon.getStructure$(), atomPath));
}}
}ringFormationSynthon.ensureHelperArrays$I(15);
newGenericSynthons.add$O(Clazz.new_($I$(12,1).c$$com_actelion_research_chem_StereoMolecule,[ringFormationSynthon]).getCanMolecule$());
}
this.genericSynthons.clear$();
for (var gs, $gs = newGenericSynthons.iterator$(); $gs.hasNext$()&&((gs=($gs.next$())),1);) {
gs.ensureHelperArrays$I(15);
this.genericSynthons.add$O(gs);
}
this.rxnHelper=Clazz.new_($I$(13,1).c$$java_util_List,[this.genericSynthons]);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
