(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),p$1={},I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.type.Angle','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Angle", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]','t','com.actelion.research.chem.forcefield.mmff.Tables']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
this.t=t;
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'ka$I',  function (index) {
return (this.table[index][4]).doubleValue$();
});

Clazz.newMeth(C$, 'theta$I',  function (index) {
return (this.table[index][5]).doubleValue$();
});

Clazz.newMeth(C$, 'index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var a1t=mol.getAtomType$I(a1);
var a2t=mol.getAtomType$I(a2);
var a3t=mol.getAtomType$I(a3);
var angt=$I$(2).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(this.t, mol, a1, a2, a3);
var a1tf;
var a3tf;
var index=-1;
for (var i=0; i < 5 && index < 0 ; i++) {
a1tf=this.t.def.table[a1t - 1][i];
a3tf=this.t.def.table[a3t - 1][i];
if (a1tf > a3tf) a1tf=($I$(3,"s$O$O",[Integer.valueOf$I(a3tf), Integer.valueOf$I(a3tf=a1tf)])).$c();
index=$I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [2, 1, 3, 0]), Clazz.array(Integer.TYPE, -1, [a2t, a1tf, a3tf, angt]), this]);
}
return index;
});

Clazz.newMeth(C$, 'theta$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var index=this.index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
if (index < 0) return p$1.getEmpiricalTheta0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I.apply(this, [mol, a1, a2, a3]);
 else return this.theta$I(index);
});

Clazz.newMeth(C$, 'ka$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
var index=this.index$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I(mol, a1, a2, a3);
if (index < 0) return p$1.getEmpiricalKa$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$D.apply(this, [mol, a1, a2, a3, p$1.getEmpiricalTheta0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I.apply(this, [mol, a1, a2, a3])]);
 else {
if (Math.abs(this.ka$I(index)) < 0.001 ) return p$1.getEmpiricalKa$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$D.apply(this, [mol, a1, a2, a3, this.theta$I(index)]);
 else return this.ka$I(index);
}});

Clazz.newMeth(C$, 'getEmpiricalTheta0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I',  function (mol, a1, a2, a3) {
if ($I$(2).inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 3)) return 60.0;
 else if ($I$(2).inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 4)) return 90.0;
var a2t=mol.getAtomType$I(a2);
switch (this.t.atom.crd$I(a2t)) {
case 2:
if (mol.getAtomicNo$I(a2) == 8) return 105.0;
 else if (this.t.atom.linear$I(a2t)) return 180.0;
break;
case 3:
if (this.t.atom.val$I(a2t) == 3 && this.t.atom.mltb$I(a2t) == 0 ) {
if (mol.getAtomicNo$I(a2) == 7) return 107.0;
 else return 92.0;
}break;
case 4:
return 109.45;
}
return 120.0;
}, p$1);

Clazz.newMeth(C$, 'getEmpiricalKa$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$D',  function (mol, a1, a2, a3, theta0) {
var z=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0]);
var c=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0]);
var atno=Clazz.array(Integer.TYPE, -1, [mol.getAtomicNo$I(a1), mol.getAtomicNo$I(a2), mol.getAtomicNo$I(a3)]);
var beta=1.75;
for (var i=0; i < 3; i++) {
switch (atno[i]) {
case 1:
z[i]=1.395;
break;
case 6:
z[i]=2.494;
c[i]=1.016;
break;
case 7:
z[i]=2.711;
c[i]=1.113;
break;
case 8:
z[i]=3.045;
c[i]=1.337;
break;
case 9:
z[i]=2.847;
break;
case 14:
z[i]=2.35;
c[i]=0.811;
break;
case 15:
z[i]=2.35;
c[i]=1.068;
break;
case 16:
z[i]=2.98;
c[i]=1.249;
break;
case 17:
z[i]=2.909;
c[i]=1.078;
break;
case 35:
z[i]=3.017;
break;
case 53:
z[i]=3.086;
break;
}
}
var r0_ij=this.t.bond.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a1, a2);
var r0_jk=this.t.bond.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a2, a3);
var D=(r0_ij - r0_jk) * (r0_ij - r0_jk) / ((r0_ij + r0_jk) * (r0_ij + r0_jk));
var theta0_rad=0.017453292519943295 * theta0;
if ($I$(2).inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 4)) beta*=0.85;
 else if ($I$(2).inRingOfSize$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, a1, a2, a3, 3)) beta*=0.05;
return beta * z[0] * c[1] * z[2]  / ((r0_ij + r0_jk) * theta0_rad * theta0_rad * Math.exp(2.0 * D) );
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
