(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.io.BufferedReader','java.io.InputStreamReader','java.io.FileInputStream','java.nio.charset.StandardCharsets','com.actelion.research.io.BOMSkipper','StringBuilder','com.actelion.research.chem.UniqueStringList','com.actelion.research.chem.MolfileParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SDFileParser", null, 'com.actelion.research.chem.io.CompoundFileParser');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mAssumeChiralTrue'],'I',['mNoOfRecords','mIDFieldIndex'],'O',['mMolfileBuffer','StringBuilder','+mDataBuffer','$mMol','com.actelion.research.chem.StereoMolecule','mFieldName','String[]','+mFieldData']]
,['O',['cIDFieldNames','String[]']]]

Clazz.newMeth(C$, 'c$$S',  function (fileName) {
C$.c$$S$SA.apply(this, [fileName, null]);
}, 1);

Clazz.newMeth(C$, 'c$$S$SA',  function (fileName, fieldName) {
Clazz.super_(C$, this);
this.mNoOfRecords=-1;
this.mFieldName=fieldName;
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File',  function (file) {
C$.c$$java_io_File$SA.apply(this, [file, null]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File$SA',  function (file, fieldName) {
Clazz.super_(C$, this);
this.mNoOfRecords=-1;
this.mFieldName=fieldName;
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$java_io_File,[file]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader',  function (reader) {
C$.c$$java_io_Reader$SA.apply(this, [reader, null]);
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader$SA',  function (reader, fieldName) {
Clazz.super_(C$, this);
this.mNoOfRecords=-1;
this.mFieldName=fieldName;
this.mReader=(Clazz.instanceOf(reader, "java.io.BufferedReader")) ? reader : Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'setAssumeChiralTrue$Z',  function (b) {
this.mAssumeChiralTrue=b;
});

Clazz.newMeth(C$, 'init',  function () {
this.mMolfileBuffer=Clazz.new_($I$(6,1).c$$I,[10240]);
this.mDataBuffer=Clazz.new_($I$(6,1).c$$I,[10240]);
}, p$1);

Clazz.newMeth(C$, 'extractAllFieldNames$I',  function (recordsToInspect) {
var records=0;
var fieldNameList=Clazz.new_($I$(7,1));
while (records < recordsToInspect){
var line;
try {
line=this.mReader.readLine$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
if (records < recordsToInspect) this.mNoOfRecords=records;
break;
} else {
throw e;
}
}
if (line == null ) {
if (records < recordsToInspect) this.mNoOfRecords=records;
break;
}if (line.startsWith$S("$$$$")) ++records;
if (line.startsWith$S(">")) {
var fieldName=this.extractFieldName$S(line);
if (fieldName != null ) fieldNameList.addString$S(fieldName);
}}
try {
this.mReader.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
this.mFieldName=fieldNameList.toArray$();
}, p$1);

Clazz.newMeth(C$, 'getRowCount$',  function () {
return this.mNoOfRecords;
});

Clazz.newMeth(C$, 'advanceToNext$',  function () {
if (this.mReader == null ) return false;
this.mMolfileBuffer.setLength$I(0);
this.mDataBuffer.setLength$I(0);
this.$mMol=null;
var molfileComplete=false;
var fieldIndex=-1;
var fieldName=null;
var line;
this.mFieldData=(this.mFieldName == null ) ? null : Clazz.array(String, [this.mFieldName.length]);
this.mIDFieldIndex=-1;
do {
try {
line=this.mReader.readLine$();
if (line == null ) {
this.mMolfileBuffer.setLength$I(0);
this.mReader.close$();
return false;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mMolfileBuffer.setLength$I(0);
return false;
} else {
throw e;
}
}
if (!molfileComplete) {
if (line.startsWith$S(">")) {
molfileComplete=true;
this.mMolfileBuffer.append$S("M  END");
this.mMolfileBuffer.append$C("\n");
this.mDataBuffer.append$S(line);
this.mDataBuffer.append$C("\n");
} else {
this.mMolfileBuffer.append$S(line);
this.mMolfileBuffer.append$C("\n");
if (line.startsWith$S("M  END")) molfileComplete=true;
continue;
}} else {
this.mDataBuffer.append$S(line);
this.mDataBuffer.append$C("\n");
}if (this.mFieldName != null ) {
if (line.length$() == 0) {
fieldIndex=-1;
} else if (fieldIndex == -1) {
fieldName=this.extractFieldName$S(line);
if (fieldName != null ) {
fieldIndex=-1;
for (var field=0; field < this.mFieldName.length; field++) {
if (fieldName.equals$O(this.mFieldName[field])) {
fieldIndex=field;
break;
}}
if (this.mIDFieldIndex == -1) {
for (var idName, $idName = 0, $$idName = C$.cIDFieldNames; $idName<$$idName.length&&((idName=($$idName[$idName])),1);$idName++) {
if (fieldName.equals$O(idName)) {
this.mIDFieldIndex=fieldIndex;
break;
}}
}}} else {
if (this.mFieldData[fieldIndex] == null ) {
this.mFieldData[fieldIndex]=line;
} else {
this.mFieldData[fieldIndex]=this.mFieldData[fieldIndex].concat$S("\n").concat$S(line);
}}}} while (!line.startsWith$S("$$$$"));
return true;
});

Clazz.newMeth(C$, 'getMolecule$',  function () {
if (this.$mMol != null ) return this.$mMol;
var molfileParser=Clazz.new_($I$(8,1));
if (this.mAssumeChiralTrue) molfileParser.setAssumeChiralTrue$Z(true);
this.$mMol=molfileParser.getCompactMolecule$S(this.getNextMolFile$());
if (this.$mMol != null  && (this.$mMol.getName$() == null  || this.$mMol.getName$().length$() == 0 ) ) this.$mMol.setName$S(this.getMoleculeName$());
return this.$mMol;
});

Clazz.newMeth(C$, 'getMoleculeName$',  function () {
return (this.mIDFieldIndex != -1 && this.mFieldData != null  ) ? this.mFieldData[this.mIDFieldIndex] : (this.$mMol != null ) ? this.$mMol.getName$() : null;
});

Clazz.newMeth(C$, 'getNextMolFile$',  function () {
var molfile=this.mMolfileBuffer.toString();
return molfile;
});

Clazz.newMeth(C$, 'getNextFieldData$',  function () {
var fieldData=this.mDataBuffer.toString();
return fieldData;
});

Clazz.newMeth(C$, 'getFieldNames$',  function () {
if (this.mFieldName == null ) p$1.extractAllFieldNames$I.apply(this, [10240]);
return this.mFieldName;
});

Clazz.newMeth(C$, 'getFieldNames$I',  function (recordsToInspect) {
if (this.mFieldName == null ) p$1.extractAllFieldNames$I.apply(this, [recordsToInspect]);
return this.mFieldName;
});

Clazz.newMeth(C$, 'getFieldData$I',  function (index) {
if (this.mFieldData == null ) return null;
return this.mFieldData[index];
});

Clazz.newMeth(C$, 'extractFieldName$S',  function (line) {
if (line.length$() == 0 || line.charAt$I(0) != ">" ) return null;
var index=1;
var openBracket=0;
var closeBracket=0;
while (index < line.length$()){
if (line.charAt$I(index) == "<") {
if (openBracket != 0) return null;
openBracket=index;
} else if (line.charAt$I(index) == ">") {
if (closeBracket != 0) return null;
closeBracket=index;
}++index;
}
if (openBracket != 0 && openBracket < closeBracket ) return line.substring$I$I(openBracket + 1, closeBracket);
index=line.indexOf$S$I("DT", 1);
if (index == -1) return null;
var i=index + 2;
while (line.length$() > i && Character.isDigit$C(line.charAt$I(i)) )++i;

return (i == index + 2) ? null : line.substring$I$I(index, i);
});

C$.$static$=function(){C$.$static$=0;
C$.cIDFieldNames=Clazz.array(String, -1, ["Idorsia No", "Actelion No", "ID", "IDNUMBER", "COMPOUND_ID", "NAME", "COMPND"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
