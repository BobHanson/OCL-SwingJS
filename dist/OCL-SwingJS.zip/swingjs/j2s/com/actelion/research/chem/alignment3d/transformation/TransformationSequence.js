(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'com.actelion.research.chem.alignment3d.transformation.Rotation','com.actelion.research.chem.alignment3d.transformation.Scaling','java.util.ArrayList','java.util.stream.Collectors','com.actelion.research.chem.alignment3d.transformation.Translation','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TransformationSequence", null, null, 'com.actelion.research.chem.alignment3d.transformation.Transformation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['transformationSequence','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_alignment3d_transformation_Quaternion',  function (rotor) {
C$.c$.apply(this, []);
var rot=Clazz.new_([rotor.getRotMatrix$().getArray$()],$I$(1,1).c$$DAA);
var normFactor=1 / rotor.normSquared$();
var scaling=Clazz.new_($I$(2,1).c$$D,[normFactor]);
this.transformationSequence.add$O(rot);
this.transformationSequence.add$O(scaling);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.transformationSequence=Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$, 'addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (transformation) {
this.transformationSequence.add$O(transformation);
});

Clazz.newMeth(C$, 'getTransformations$',  function () {
return this.transformationSequence;
});

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_Coordinates',  function (coords) {
for (var transformation, $transformation = this.transformationSequence.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
transformation.apply$com_actelion_research_chem_Coordinates(coords);
}
});

Clazz.newMeth(C$, 'apply$DA',  function (coords) {
for (var transformation, $transformation = this.transformationSequence.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
transformation.apply$DA(coords);
}
});

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var transformation, $transformation = this.transformationSequence.iterator$(); $transformation.hasNext$()&&((transformation=($transformation.next$())),1);) {
transformation.apply$com_actelion_research_chem_StereoMolecule(mol);
}
});

Clazz.newMeth(C$, 'processSubstring$java_util_List',  function (chars) {
var transforms=Clazz.new_($I$(3,1));
var s=chars.stream$().map$java_util_function_Function((P$.TransformationSequence$lambda1$||(P$.TransformationSequence$lambda1$=((function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "TransformationSequence$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return $$.valueOf$O.apply(null,[t])});
})()
)); return Clazz.new_(P$.TransformationSequence$lambda1.$init$,[this, null])})(String))))).collect$java_util_stream_Collector($I$(4).joining$());
var st=s.split$S(String.valueOf$C(","));
for (var substring, $substring = 0, $$substring = st; $substring<$$substring.length&&((substring=($$substring[$substring])),1);$substring++) {
var substrings=substring.split$S(" ");
var identifier=substrings[0];
if (identifier.equals$O("r")) {
transforms.add$O($I$(1).decode$S(substrings[1]));
} else if (identifier.equals$O("s")) {
transforms.add$O($I$(2).decode$S(substrings[1]));
} else if (identifier.equals$O("t")) {
transforms.add$O($I$(5).decode$S(substrings[1]));
}}
return transforms;
}, 1);

Clazz.newMeth(C$, 'decode$S',  function (s) {
var chars=s.toCharArray$();
var charsList=Clazz.new_($I$(3,1));
for (var c, $c = 0, $$c = chars; $c<$$c.length&&((c=($$c[$c])),1);$c++) {
charsList.add$O(Character.valueOf$C(c));
}
var iterator=charsList.iterator$();
iterator.next$();
return C$.decode$java_util_Iterator(iterator);
}, 1);

Clazz.newMeth(C$, 'decode$java_util_Iterator',  function (s) {
var sequence=Clazz.new_(C$);
var chars=Clazz.new_($I$(3,1));
while (s.hasNext$()){
var c=(s.next$()).valueOf();
if (c == "}") {
var transforms=C$.processSubstring$java_util_List(chars);
transforms.stream$().forEach$java_util_function_Consumer(((P$.TransformationSequence$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "TransformationSequence$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_alignment3d_transformation_Transformation','accept$O'],  function (e) { return (this.$finals$.sequence.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation.apply(this.$finals$.sequence, [e]));});
})()
), Clazz.new_(P$.TransformationSequence$lambda2.$init$,[this, {sequence:sequence}])));
chars.clear$();
return sequence;
} else if (c == "{") {
var transforms=C$.processSubstring$java_util_List(chars);
transforms.stream$().forEach$java_util_function_Consumer(((P$.TransformationSequence$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "TransformationSequence$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_alignment3d_transformation_Transformation','accept$O'],  function (e) { return (this.$finals$.sequence.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation.apply(this.$finals$.sequence, [e]));});
})()
), Clazz.new_(P$.TransformationSequence$lambda3.$init$,[this, {sequence:sequence}])));
chars.clear$();
sequence.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(C$.decode$java_util_Iterator(s));
} else {
chars.add$O(Character.valueOf$C(c));
}}
return sequence;
}, 1);

Clazz.newMeth(C$, 'encode$',  function () {
var sb=Clazz.new_($I$(6,1));
sb.append$C("{");
for (var t, $t = this.transformationSequence.iterator$(); $t.hasNext$()&&((t=($t.next$())),1);) {
sb.append$S(t.encode$());
sb.append$C(",");
}
sb.deleteCharAt$I(sb.length$() - 1);
sb.append$C("}");
return sb.toString();
});
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:21 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
