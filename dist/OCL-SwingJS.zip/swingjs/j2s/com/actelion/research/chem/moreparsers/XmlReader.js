(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),p$1={},I$=[[0,'org.xml.sax.InputSource','java.util.Hashtable','StringBuffer',['com.actelion.research.chem.moreparsers.XmlReader','.XmlHandler']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "XmlReader", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['NVPair',2],['XmlHandler',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.atts=Clazz.new_($I$(2,1));
this.chars=Clazz.new_($I$(3,1));
this.domObj=Clazz.array(java.lang.Object, [1]);
},1);

C$.$fields$=[['Z',['keepChars'],'S',['err'],'O',['atts','java.util.Map','reader','java.io.BufferedReader','chars','StringBuffer','domObj','Object[]','+attribs']]]

Clazz.newMeth(C$, 'parseXML$',  function () {
var saxReader=null;
{

}
try {
this.processXml$O(saxReader);
return null;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return "Error reading XML: " + (e.getMessage$());
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'processXml$O',  function (saxReader) {
var rdr=this.previewXML$java_io_BufferedReader(this.reader);
if (saxReader == null ) {
p$1.parseJSDOM$java_io_BufferedReader.apply(this, [rdr]);
} else {
Clazz.new_($I$(4,1)).parseXML$com_actelion_research_chem_moreparsers_XmlReader$O$java_io_BufferedReader(this, saxReader, rdr);
}});

Clazz.newMeth(C$, 'parseJSDOM$java_io_BufferedReader',  function (rdr) {
this.attribs=Clazz.array(java.lang.Object, [1]);
this.domObj=Clazz.array(java.lang.Object, [1]);
var o="";
var data=null;
{
o = rdr.lock.lock;
if (o && o.$in) { data = o.$in.buf;
} else if ((o=rdr.$in.str) != null) { } else if (rdr.$in.$in.$in.fd) { // may need to adjust this;
o = rdr.$in.$in;
data = o.$in.fd._file.秘bytes;
} else { data = (o=rdr.$in.$in).$in.buf;
}
}
if (Clazz.instanceOf(o, "java.io.BufferedInputStream")) o= String.instantialize(data, "utf-8");
var isjs=false;
{
isjs = true;
}
if (isjs) {
this.domObj[0]=this.createDomNodeJS$S$O("xmlReader", o);
p$1.walkDOMTree.apply(this, []);
this.createDomNodeJS$S$O("xmlReader", null);
}}, p$1);

Clazz.newMeth(C$, 'previewXML$java_io_BufferedReader',  function (reader) {
return reader;
});

Clazz.newMeth(C$, 'createDomNodeJS$S$O',  function (id, data) {
var d=null;
{
if (!data) return null;
if (data.indexOf("<?") == 0) data = data.substring(data.indexOf("<", 1));
if (data.indexOf("/>") >= 0) { var D = data.split("/>");
for (var i = D.length - 1; --i >= 0;) { var s = D[i];
var pt = s.lastIndexOf("<") + 1;
var pt2 = pt;
var len = s.length;
var name = "";
while (++pt2 < len) { if (" \t\n\r".indexOf(s.charAt(pt2))>= 0) { var name = s.substring(pt, pt2);
D[i] = s + "></"+name+">";
break;
} } } data = D.join('');
} d = document.createElement("_xml");
d.innerHTML = data;
}
return d;
});

Clazz.newMeth(C$, 'setKeepChars$Z',  function (TF) {
this.keepChars=TF;
this.chars.setLength$I(0);
});

Clazz.newMeth(C$, 'walkDOMTree',  function () {
var localName;
{
localName = "nodeName";
}
var nodeName=(p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, localName]));
localName=p$1.fixLocal$S.apply(this, [nodeName]);
if (localName == null ) return;
if (localName.equals$O("#text")) {
if (this.keepChars) this.chars.append$S(p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "data"]));
return;
}localName=localName.toLowerCase$();
nodeName=nodeName.toLowerCase$();
this.attribs[0]=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "attributes"]);
p$1.getDOMAttributesA$OA.apply(this, [this.attribs]);
this.processStartElement$S$S(localName, nodeName);
var haveChildren=false;
{
haveChildren = this.domObj[0].hasChildNodes;
}
if (haveChildren) {
var nextNode=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "firstChild"]);
while (nextNode != null ){
this.domObj[0]=nextNode;
p$1.walkDOMTree.apply(this, []);
this.domObj[0]=nextNode;
nextNode=p$1.jsObjectGetMember$OA$S.apply(this, [this.domObj, "nextSibling"]);
}
}this.processEndElement$S(localName);
}, p$1);

Clazz.newMeth(C$, 'fixLocal$S',  function (name) {
{
var pt = (name== null ? -1 : name.indexOf(":")); return (pt >= 0 ? name.substring(pt+1) : name);
}
}, p$1);

Clazz.newMeth(C$, 'getDOMAttributesA$OA',  function (attributes) {
this.atts.clear$();
if (attributes == null ) return;
var nodes=null;
{
nodes = attributes[0];
}
for (var i=nodes.length; --i >= 0; ) this.atts.put$O$O(p$1.fixLocal$S.apply(this, [nodes[i].name]).toLowerCase$(), nodes[i].value);

}, p$1);

Clazz.newMeth(C$, 'jsObjectGetMember$OA$S',  function (jsObject, name) {
{
return jsObject[0][name];
}
}, p$1);

Clazz.newMeth(C$, 'endDocument$',  function () {
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlReader, "NVPair", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['S',['name','value']]]

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.XmlReader, "XmlHandler", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'org.xml.sax.helpers.DefaultHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['xmlReader','com.actelion.research.chem.moreparsers.XmlReader']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'parseXML$com_actelion_research_chem_moreparsers_XmlReader$O$java_io_BufferedReader',  function (xmlReader, saxReaderObj, reader) {
this.xmlReader=xmlReader;
var saxReader=saxReaderObj;
saxReader.setFeature$S$Z("http://xml.org/sax/features/validation", false);
saxReader.setFeature$S$Z("http://xml.org/sax/features/namespaces", true);
saxReader.setEntityResolver$org_xml_sax_EntityResolver(this);
saxReader.setContentHandler$org_xml_sax_ContentHandler(this);
saxReader.setErrorHandler$org_xml_sax_ErrorHandler(this);
var is=Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
is.setSystemId$S("foo");
saxReader.parse$org_xml_sax_InputSource(is);
});

Clazz.newMeth(C$, 'startDocument$',  function () {
});

Clazz.newMeth(C$, 'endDocument$',  function () {
this.xmlReader.endDocument$();
});

Clazz.newMeth(C$, 'startElement$S$S$S$org_xml_sax_Attributes',  function (namespaceURI, localName, nodeName, attributes) {
this.xmlReader.atts.clear$();
for (var i=attributes.getLength$(); --i >= 0; ) this.xmlReader.atts.put$O$O(attributes.getLocalName$I(i).toLowerCase$(), attributes.getValue$I(i));

this.xmlReader.processStartElement$S$S(localName.toLowerCase$(), nodeName.toLowerCase$());
});

Clazz.newMeth(C$, 'endElement$S$S$S',  function (uri, localName, qName) {
this.xmlReader.processEndElement$S(localName.toLowerCase$());
});

Clazz.newMeth(C$, 'characters$CA$I$I',  function (ch, start, length) {
if (this.xmlReader.keepChars) this.xmlReader.chars.append$CA$I$I(ch, start, length);
});

Clazz.newMeth(C$, 'resolveEntity$S$S$S$S',  function (name, publicId, baseURI, systemId) {
return null;
});

Clazz.newMeth(C$, 'error$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX ERROR:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'fatalError$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX FATAL:" + exception.getMessage$());
});

Clazz.newMeth(C$, 'warning$org_xml_sax_SAXParseException',  function (exception) {
System.err.println$S("SAX WARNING:" + exception.getMessage$());
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-19 22:45:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
