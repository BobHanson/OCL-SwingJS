(function(){var P$=Clazz.newPackage("com.actelion.research.chem.dnd"),I$=[[0,'javafx.scene.input.DataFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemistryDataFormats");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['DF_SERIALIZED_OBJECT','javafx.scene.input.DataFormat','+DF_MDLMOLFILE','+DF_MDLMOLFILEV3','+DF_SMILES','+DF_IDCODE']]]

Clazz.newMeth(C$, 'get$S',  function (mimetype) {
var df=$I$(1).lookupMimeType$S(mimetype);
if (df == null ) df=Clazz.new_([Clazz.array(String, -1, [mimetype])],$I$(1,1).c$$SA);
return df;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.DF_SERIALIZED_OBJECT=C$.get$S("application/x-java-serialized-object");
C$.DF_MDLMOLFILE=C$.get$S("chemical/x-mdl-molfile");
C$.DF_MDLMOLFILEV3=C$.get$S("chemical/x-mdl-molfilev3");
C$.DF_SMILES=C$.get$S("chemical/x-daylight-smiles");
C$.DF_IDCODE=C$.get$S("chemical/x-openmolecules-idcode");
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
