(function(){var P$=Clazz.newPackage("com.actelion.research.chem.dnd"),I$=[[0,'Thread',['com.actelion.research.chem.dnd.ChemistryFlavors','.SerializedClassFlavor'],'com.actelion.research.chem.StereoMolecule','java.awt.datatransfer.DataFlavor','com.actelion.research.chem.reaction.Reaction']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ChemistryFlavors", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SerializedClassFlavor',8]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['DF_SERIALIZED_MOLECULE','java.awt.datatransfer.DataFlavor','+DF_MDLMOLFILE','+DF_MDLMOLFILEV3','+DF_SMILES','+DF_IDCODE','MOLECULE_FLAVORS','java.awt.datatransfer.DataFlavor[]','DF_SERIALIZED_REACTION','java.awt.datatransfer.DataFlavor','+DF_REACTION_SMILES','REACTION_FLAVORS','java.awt.datatransfer.DataFlavor[]']]]

C$.$static$=function(){C$.$static$=0;
C$.DF_SERIALIZED_MOLECULE=Clazz.new_([Clazz.getClass($I$(3)), "Native OpenChemLib Molecule"],$I$(2,1).c$$Class$S);
C$.DF_MDLMOLFILE=Clazz.new_(["chemical/x-mdl-molfile;class=java.lang.String", "MDL Molfile"],$I$(4,1).c$$S$S);
C$.DF_MDLMOLFILEV3=Clazz.new_(["chemical/x-mdl-molfilev3;class=java.lang.String", "MDL Molfile V3"],$I$(4,1).c$$S$S);
C$.DF_SMILES=Clazz.new_(["chemical/x-daylight-smiles;class=java.lang.String", "Daylight Smiles"],$I$(4,1).c$$S$S);
C$.DF_IDCODE=Clazz.new_(["chemical/x-openmolecules-idcode;class=java.lang.String", "OpenChemLib ID-Code"],$I$(4,1).c$$S$S);
C$.MOLECULE_FLAVORS=Clazz.array($I$(4), -1, [C$.DF_SERIALIZED_MOLECULE, C$.DF_MDLMOLFILE, C$.DF_MDLMOLFILEV3, C$.DF_SMILES, C$.DF_IDCODE, $I$(4).stringFlavor]);
C$.DF_SERIALIZED_REACTION=Clazz.new_([Clazz.getClass($I$(5)), "Native OpenChemLib Reaction"],$I$(2,1).c$$Class$S);
C$.DF_REACTION_SMILES=Clazz.new_(["chemical/x-daylight-reactionsmiles;class=java.lang.String", "Daylight Reaction Smiles"],$I$(4,1).c$$S$S);
C$.REACTION_FLAVORS=Clazz.array($I$(4), -1, [C$.DF_SERIALIZED_REACTION, C$.DF_REACTION_SMILES]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.ChemistryFlavors, "SerializedClassFlavor", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'java.awt.datatransfer.DataFlavor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$$Class$S',  function (representationClass, humanPresentableName) {
;C$.superclazz.c$$Class$S.apply(this,[representationClass, humanPresentableName]);C$.$init$.apply(this);
try {
var cl=this.getClass$().getClassLoader$();
$I$(1).currentThread$().setContextClassLoader$ClassLoader(cl);
} catch (ex) {
}
}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
