(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.SSSearcherWithIndex','com.actelion.research.chem.descriptor.DescriptorHandlerStandard2DFactory','com.actelion.research.chem.descriptor.DescriptorHandlerLongFFP512','java.util.concurrent.atomic.AtomicInteger','com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IDCodeParser','com.actelion.research.util.ByteArrayComparator','com.actelion.research.chem.CanonizerUtil',['com.actelion.research.chem.CanonizerUtil','.IDCODE_TYPE'],'java.nio.charset.StandardCharsets','java.util.concurrent.ConcurrentLinkedQueue','Runtime',['com.actelion.research.chem.StructureSearch','.SearchThread'],'Thread']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureSearch", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['SearchThread',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mDescriptorColumn','mMaxSSSMatches','mMaxNonSSSMatches','mStatus'],'J',['mStopTime','mMaxMillis'],'O',['mSpecification','com.actelion.research.chem.StructureSearchSpecification','mDataSource','com.actelion.research.chem.StructureSearchDataSource','mSearchController','com.actelion.research.chem.StructureSearchController','mProgressController','com.actelion.research.calc.ProgressController','mQueryFragment','com.actelion.research.chem.StereoMolecule[]','+mDoubleQueryFragment','mIDCodeComparator','com.actelion.research.util.ByteArrayComparator','mDescriptorHandler','com.actelion.research.chem.descriptor.DescriptorHandler','mQueryDescriptor','Object[]','mQueryHashCode','long[]','mQueryIDCode','byte[][]','mResultQueue','java.util.concurrent.ConcurrentLinkedQueue','mSMPIndex','java.util.concurrent.atomic.AtomicInteger','+mMatchCount']]
,['O',['COMPLETION_TEXT','String[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StructureSearchSpecification$com_actelion_research_chem_StructureSearchDataSource$com_actelion_research_chem_StructureSearchController$com_actelion_research_calc_ProgressController$com_actelion_research_chem_descriptor_DescriptorHandlerFactory',  function (specification, dataSource, searchController, progressController, dhFactory) {
;C$.$init$.apply(this);
this.mSpecification=specification;
this.mDataSource=dataSource;
this.mSearchController=searchController;
this.mProgressController=progressController;
this.mStatus=0;
if (this.mSpecification != null ) {
if (this.mSpecification.isSimilaritySearch$()) {
var factory=(dhFactory != null ) ? dhFactory : $I$(2).getFactory$();
this.mDescriptorHandler=factory.getDefaultDescriptorHandler$S(specification.getDescriptorShortName$());
} else if (this.mSpecification.isSubstructureSearch$()) {
this.mDescriptorHandler=$I$(3).getDefaultInstance$();
}}}, 1);

Clazz.newMeth(C$, 'setMatchLimit$I$I',  function (maxSSSMatches, maxNonSSSMatches) {
this.mMaxSSSMatches=maxSSSMatches;
this.mMaxNonSSSMatches=maxNonSSSMatches;
});

Clazz.newMeth(C$, 'setTimeLimit$J',  function (maxMillis) {
this.mMaxMillis=maxMillis;
});

Clazz.newMeth(C$, 'getCompletionStatus$',  function () {
return C$.COMPLETION_TEXT[this.mStatus];
});

Clazz.newMeth(C$, 'start$',  function () {
if (!this.mDataSource.isSupportedSearchType$com_actelion_research_chem_StructureSearchSpecification(this.mSpecification)) {
this.mStatus=3;
return null;
}this.mMatchCount=Clazz.new_($I$(4,1).c$$I,[0]);
if (!this.mSpecification.isNoStructureSearch$()) {
var queryStructureCount=this.mSpecification.getStructureCount$();
if (queryStructureCount == 0) {
this.mStatus=2;
return null;
}this.mDescriptorColumn=-1;
var largestFragmentOnly=this.mSpecification.isLargestFragmentOnly$();
if (this.mSpecification.isSubstructureSearch$() || this.mSpecification.isSimilaritySearch$() ) {
if (this.mSpecification.isSubstructureSearch$()) {
this.mDescriptorColumn=this.mDataSource.getDescriptorColumn$S($I$(5).DESCRIPTOR_FFP512.shortName);
this.mQueryFragment=Clazz.array($I$(6), [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) {
this.mQueryFragment[i]=Clazz.new_($I$(7,1).c$$Z,[false]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i));
this.mQueryFragment[i].ensureHelperArrays$I(15);
}
if (this.mSpecification.isSingleMatchOnly$()) {
this.mDoubleQueryFragment=Clazz.array($I$(6), [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) {
this.mDoubleQueryFragment[i]=Clazz.new_([this.mQueryFragment[i].getAtoms$(), this.mQueryFragment[i].getBonds$()],$I$(6,1).c$$I$I);
this.mDoubleQueryFragment[i].addMolecule$com_actelion_research_chem_Molecule(this.mQueryFragment[i]);
this.mDoubleQueryFragment[i].addMolecule$com_actelion_research_chem_Molecule(this.mQueryFragment[i]);
this.mDoubleQueryFragment[i].ensureHelperArrays$I(15);
}
}} else {
var descriptorShortName=this.mSpecification.getDescriptorShortName$();
this.mDescriptorColumn=(descriptorShortName == null ) ? -1 : this.mDataSource.getDescriptorColumn$S(descriptorShortName);
}this.mQueryDescriptor=Clazz.array(java.lang.Object, [queryStructureCount]);
var missingDescriptorFound=false;
for (var i=0; i < queryStructureCount; i++) {
this.mQueryDescriptor[i]=this.mSpecification.getDescriptor$I(i);
if (this.mQueryDescriptor[i] == null ) missingDescriptorFound=true;
}
if (missingDescriptorFound) p$1.calculateQueryDescriptorsAndWait.apply(this, []);
} else if (this.mSpecification.isExactSearch$()) {
this.mIDCodeComparator=Clazz.new_($I$(8,1));
this.mQueryIDCode=Clazz.array(Byte.TYPE, [queryStructureCount, null]);
for (var i=0; i < queryStructureCount; i++) {
if (largestFragmentOnly) {
var query=Clazz.new_($I$(7,1).c$$Z,[true]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i));
this.mQueryIDCode[i]=$I$(9,"getIDCode$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CanonizerUtil_IDCODE_TYPE$Z",[query, $I$(10).NORMAL, largestFragmentOnly]).getBytes$java_nio_charset_Charset($I$(11).UTF_8);
} else {
this.mQueryIDCode[i]=this.mSpecification.getIDCode$I(i);
}}
} else if (this.mSpecification.isNoStereoSearch$()) {
this.mQueryHashCode=Clazz.array(Long.TYPE, [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) this.mQueryHashCode[i]=$I$(9,"getNoStereoHash$com_actelion_research_chem_StereoMolecule$Z",[Clazz.new_($I$(7,1).c$$Z,[false]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i)), largestFragmentOnly]);

} else if (this.mSpecification.isTautomerSearch$()) {
this.mQueryHashCode=Clazz.array(Long.TYPE, [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) this.mQueryHashCode[i]=$I$(9,"getTautomerHash$com_actelion_research_chem_StereoMolecule$Z",[Clazz.new_($I$(7,1).c$$Z,[true]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i)), largestFragmentOnly]);

} else if (this.mSpecification.isNoStereoTautomerSearch$()) {
this.mQueryHashCode=Clazz.array(Long.TYPE, [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) this.mQueryHashCode[i]=$I$(9,"getNoStereoTautomerHash$com_actelion_research_chem_StereoMolecule$Z",[Clazz.new_($I$(7,1).c$$Z,[false]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i)), largestFragmentOnly]);

} else if (this.mSpecification.isBackboneSearch$()) {
this.mQueryHashCode=Clazz.array(Long.TYPE, [queryStructureCount]);
for (var i=0; i < queryStructureCount; i++) this.mQueryHashCode[i]=$I$(9,"getBackboneHash$com_actelion_research_chem_StereoMolecule$Z",[Clazz.new_($I$(7,1).c$$Z,[false]).getCompactMolecule$BA(this.mSpecification.getIDCode$I(i)), largestFragmentOnly]);

}}this.mSMPIndex=Clazz.new_([this.mDataSource.getRowCount$()],$I$(4,1).c$$I);
this.mResultQueue=Clazz.new_($I$(12,1));
if (this.mProgressController != null  && this.mSpecification.getStructureCount$() > 1023 ) this.mProgressController.startProgress$S$I$I("Searching structures", 0, this.mSpecification.getStructureCount$());
this.mStopTime=(Long.$eq(this.mMaxMillis,0 )) ? [16777215,549755813887,1] : Long.$add(System.currentTimeMillis$(),this.mMaxMillis);
this.mStatus=-1;
var threadCount=$I$(13).getRuntime$().availableProcessors$();
var t=Clazz.array($I$(14), [threadCount]);
for (var i=0; i < threadCount; i++) {
t[i]=Clazz.new_([this, null, "Structure Search " + (i + 1)],$I$(14,1).c$$S);
t[i].setPriority$I(1);
t[i].start$();
}
for (var i=0; i < threadCount; i++) try {
t[i].join$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}

if (this.mStatus == -1) this.mStatus=4;
var result=Clazz.array(Integer.TYPE, [this.mResultQueue.size$()]);
var i=0;
for (var integer, $integer = this.mResultQueue.iterator$(); $integer.hasNext$()&&((integer=($integer.next$())),1);) result[i++]=(integer).$c();

return result;
});

Clazz.newMeth(C$, 'calculateQueryDescriptorsAndWait',  function () {
this.mSMPIndex=Clazz.new_($I$(4,1).c$$I,[this.mQueryDescriptor.length]);
var threadCount=Math.min(this.mQueryDescriptor.length, $I$(13).getRuntime$().availableProcessors$());
var t=Clazz.array($I$(15), [threadCount]);
for (var i=0; i < threadCount; i++) {
t[i]=((P$.StructureSearch$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "StructureSearch$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('Thread'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'run$',  function () {
while (true){
var index=this.b$['com.actelion.research.chem.StructureSearch'].mSMPIndex.decrementAndGet$();
if (index < 0) break;
var mol=Clazz.new_($I$(7,1).c$$Z,[false]).getCompactMolecule$BA(this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.getIDCode$I(index));
this.b$['com.actelion.research.chem.StructureSearch'].mQueryDescriptor[index]=this.b$['com.actelion.research.chem.StructureSearch'].mDescriptorHandler.createDescriptor$O(mol);
}
});
})()
), Clazz.new_([this, null, "Query Descriptor Calculation " + (i + 1)],$I$(15,1).c$$S,P$.StructureSearch$1));
t[i].setPriority$I(1);
t[i].start$();
}
for (var i=0; i < threadCount; i++) try {
t[i].join$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}

}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.COMPLETION_TEXT=Clazz.array(String, -1, ["not started", "stopped", "query missing", "unsupported search type", "successful", "count limit hit", "time limit hit"]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.StructureSearch, "SearchThread", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, 'Thread');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mSSSearcher','com.actelion.research.chem.SSSearcherWithIndex']]]

Clazz.newMeth(C$, 'c$$S',  function (name) {
;C$.superclazz.c$$S.apply(this,[name]);C$.$init$.apply(this);
if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isSubstructureSearch$()) this.mSSSearcher=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
var row=this.b$['com.actelion.research.chem.StructureSearch'].mSMPIndex.decrementAndGet$();
while (row >= 0){
if ((this.b$['com.actelion.research.chem.StructureSearch'].mProgressController != null  && this.b$['com.actelion.research.chem.StructureSearch'].mProgressController.threadMustDie$() )) {
this.b$['com.actelion.research.chem.StructureSearch'].mStatus=1;
break;
}if (Long.$gt(System.currentTimeMillis$(),this.b$['com.actelion.research.chem.StructureSearch'].mStopTime )) {
this.b$['com.actelion.research.chem.StructureSearch'].mStatus=6;
break;
}if (this.b$['com.actelion.research.chem.StructureSearch'].mProgressController != null  && row % 1024 == 1023 ) this.b$['com.actelion.research.chem.StructureSearch'].mProgressController.updateProgress$I(this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.getStructureCount$() - row);
if (this.b$['com.actelion.research.chem.StructureSearch'].mSearchController == null  || this.b$['com.actelion.research.chem.StructureSearch'].mSearchController.rowQualifies$I(row) ) {
var isMatch=false;
if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isSubstructureSearch$()) {
if (this.b$['com.actelion.research.chem.StructureSearch'].mMaxSSSMatches != 0 && this.b$['com.actelion.research.chem.StructureSearch'].mMatchCount.get$() > this.b$['com.actelion.research.chem.StructureSearch'].mMaxSSSMatches ) {
this.b$['com.actelion.research.chem.StructureSearch'].mStatus=5;
break;
}for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
this.mSSSearcher.setMolecule$BA$JA(this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getIDCode$I$I$Z(row, s, false), this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getDescriptor$I$I$I$Z(this.b$['com.actelion.research.chem.StructureSearch'].mDescriptorColumn, row, s, false));
for (var i=0; i < this.b$['com.actelion.research.chem.StructureSearch'].mQueryFragment.length; i++) {
this.mSSSearcher.setFragment$com_actelion_research_chem_StereoMolecule$JA(this.b$['com.actelion.research.chem.StructureSearch'].mQueryFragment[i], this.b$['com.actelion.research.chem.StructureSearch'].mQueryDescriptor[i]);
if (this.mSSSearcher.isFragmentInMolecule$()) {
if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isSingleMatchOnly$()) {
this.mSSSearcher.setFragment$com_actelion_research_chem_StereoMolecule$JA(this.b$['com.actelion.research.chem.StructureSearch'].mDoubleQueryFragment[i], this.b$['com.actelion.research.chem.StructureSearch'].mQueryDescriptor[i]);
if (!this.mSSSearcher.isFragmentInMolecule$()) {
isMatch=true;
break;
}} else {
isMatch=true;
break;
}}}
}
} else {
if (this.b$['com.actelion.research.chem.StructureSearch'].mMaxNonSSSMatches != 0 && this.b$['com.actelion.research.chem.StructureSearch'].mMatchCount.get$() > this.b$['com.actelion.research.chem.StructureSearch'].mMaxNonSSSMatches ) {
this.b$['com.actelion.research.chem.StructureSearch'].mStatus=5;
break;
}if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isNoStructureSearch$()) {
isMatch=true;
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isSimilaritySearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var o, $o = 0, $$o = this.b$['com.actelion.research.chem.StructureSearch'].mQueryDescriptor; $o<$$o.length&&((o=($$o[$o])),1);$o++) {
if (this.b$['com.actelion.research.chem.StructureSearch'].mDescriptorHandler.getSimilarity$O$O(o, this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getDescriptor$I$I$I$Z(this.b$['com.actelion.research.chem.StructureSearch'].mDescriptorColumn, row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$())) >= this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.getSimilarityThreshold$() ) {
isMatch=true;
break;
}}
}
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isExactSearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var bytes, $bytes = 0, $$bytes = this.b$['com.actelion.research.chem.StructureSearch'].mQueryIDCode; $bytes<$$bytes.length&&((bytes=($$bytes[$bytes])),1);$bytes++) {
if (this.b$['com.actelion.research.chem.StructureSearch'].mIDCodeComparator.compare$BA$BA(bytes, this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getIDCode$I$I$Z(row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$())) == 0) {
isMatch=true;
break;
}}
}
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isNoStereoSearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var i=0; i < this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode.length; i++) {
if (Long.$ne(this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode[i],0 ) && Long.$eq(this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode[i],this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getNoStereoCode$I$I$Z(row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$()) ) ) {
isMatch=true;
break;
}}
}
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isTautomerSearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var l, $l = 0, $$l = this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode; $l<$$l.length&&((l=($$l[$l])),1);$l++) {
if (Long.$ne(l,0 ) && Long.$eq(l,this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getTautomerCode$I$I$Z(row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$()) ) ) {
isMatch=true;
break;
}}
}
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isNoStereoTautomerSearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var l, $l = 0, $$l = this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode; $l<$$l.length&&((l=($$l[$l])),1);$l++) {
if (Long.$ne(l,0 ) && Long.$eq(l,this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getNoStereoTautomerCode$I$I$Z(row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$()) ) ) {
isMatch=true;
break;
}}
}
} else if (this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isBackboneSearch$()) {
for (var s=0; !isMatch && s < this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getStructureCount$I(row) ; s++) {
for (var l, $l = 0, $$l = this.b$['com.actelion.research.chem.StructureSearch'].mQueryHashCode; $l<$$l.length&&((l=($$l[$l])),1);$l++) {
if (Long.$ne(l,0 ) && Long.$eq(l,this.b$['com.actelion.research.chem.StructureSearch'].mDataSource.getBackboneCode$I$I$Z(row, s, this.b$['com.actelion.research.chem.StructureSearch'].mSpecification.isLargestFragmentOnly$()) ) ) {
isMatch=true;
break;
}}
}
}}if (isMatch) {
this.b$['com.actelion.research.chem.StructureSearch'].mResultQueue.add$O(Integer.valueOf$I(row));
this.b$['com.actelion.research.chem.StructureSearch'].mMatchCount.incrementAndGet$();
}}row=this.b$['com.actelion.research.chem.StructureSearch'].mSMPIndex.decrementAndGet$();
}
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
