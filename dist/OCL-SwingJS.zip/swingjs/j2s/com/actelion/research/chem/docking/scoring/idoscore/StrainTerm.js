(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.idoscore"),I$=[[0,'java.util.ArrayList','com.actelion.research.chem.conf.TorsionDB','java.util.stream.IntStream']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StrainTerm");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['torsions','int[][]','atomPairs','java.util.List','mol','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
this.atomPairs=Clazz.new_($I$(1,1));
this.init$();
}, 1);

Clazz.newMeth(C$, 'init$',  function () {
var isRotatableBond=Clazz.array(Boolean.TYPE, [this.mol.getBonds$()]);
$I$(2).findRotatableBonds$com_actelion_research_chem_StereoMolecule$Z$ZA(this.mol, true, isRotatableBond);
var rotBonds=Clazz.new_($I$(1,1));
$I$(3).range$I$I(0, isRotatableBond.length).forEach$java_util_function_IntConsumer(((P$.StrainTerm$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "StrainTerm$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) {
if (this.$finals$.isRotatableBond[e]) this.$finals$.rotBonds.add$O.apply(this.$finals$.rotBonds, [Integer.valueOf$I(e)]);
});
})()
), Clazz.new_(P$.StrainTerm$lambda1.$init$,[this, {rotBonds:rotBonds,isRotatableBond:isRotatableBond}])));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
