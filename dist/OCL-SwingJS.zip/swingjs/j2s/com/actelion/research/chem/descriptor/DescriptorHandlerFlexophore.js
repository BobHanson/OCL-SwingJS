(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.flexophore.MolDistHist','com.actelion.research.util.CommandLineParser','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','java.util.concurrent.ConcurrentLinkedQueue','com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.ObjectiveBlurFlexophoreHardMatchUncovered','com.actelion.research.chem.descriptor.flexophore.MolDistHistEncoder','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz','com.actelion.research.util.graph.complete.CompleteGraphMatcher','com.actelion.research.chem.descriptor.DescriptorConstants','StringBuilder','java.util.Arrays','com.actelion.research.chem.descriptor.DescriptorHandler','com.actelion.research.util.ArrayUtils','com.actelion.research.chem.Canonizer','com.actelion.research.chem.descriptor.flexophore.ModelSolutionSimilarity']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerFlexophore", null, null, 'com.actelion.research.chem.descriptor.flexophore.IDescriptorHandlerFlexophore');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['singleConformationModeQuery','includeNodeAtoms'],'D',['threshSimilarityHardMatch','threshHistogramSimilarity'],'I',['versionInteractionTable','modePPNodeSimilarityComparison'],'O',['queueCGM','java.util.concurrent.ConcurrentLinkedQueue','molDistHistEncoder','com.actelion.research.chem.descriptor.flexophore.MolDistHistEncoder','creatorMolDistHistViz','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz','objectiveCompleteGraphHard','com.actelion.research.chem.descriptor.flexophore.completegraphmatcher.ObjectiveBlurFlexophoreHardMatchUncovered','recentException','Exception','solution','com.actelion.research.util.graph.complete.SolutionCompleteGraph','threadMaster','com.actelion.research.calc.ThreadMaster']]
,['O',['FAILED_OBJECT','com.actelion.research.chem.descriptor.flexophore.MolDistHist','INSTANCE','com.actelion.research.chem.descriptor.DescriptorHandlerFlexophore']]]

Clazz.newMeth(C$, 'c$$S',  function (parameter) {
;C$.$init$.apply(this);
var cmd=Clazz.new_($I$(2,1).c$$S$S,[parameter, ","]);
var versionInteractionTable=-1;
var modePPNodeSimilarityComparison=1;
var threshSimilarityHardMatch=0.9;
var threshHistogramSimilarity=0.15;
var singleConformationModeQuery=false;
if (cmd.contains$S("ThreshNodeSimilarity")) {
threshSimilarityHardMatch=cmd.getAsDouble$S("ThreshNodeSimilarity");
}if (cmd.contains$S("PPNodeMatchMode")) {
modePPNodeSimilarityComparison=cmd.getAsInt$S("PPNodeMatchMode");
}if (cmd.contains$S("ThreshHistogramSimilarity")) {
threshHistogramSimilarity=cmd.getAsDouble$S("ThreshHistogramSimilarity");
}if (cmd.contains$S("SingleConfQuery")) {
singleConformationModeQuery=cmd.getAsBoolean$S("SingleConfQuery");
}p$1.init$I$I$D$D$Z.apply(this, [versionInteractionTable, modePPNodeSimilarityComparison, threshSimilarityHardMatch, threshHistogramSimilarity, singleConformationModeQuery]);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.init$I$I$D$D$Z.apply(this, [-1, 1, 0.9, 0.15, false]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$D$D$Z',  function (versionInteractionTable, modePPNodeSimilarityComparison, threshSimilarityHardMatch, threshHistogramSimilarity, singleConformationModeQuery) {
;C$.$init$.apply(this);
p$1.init$I$I$D$D$Z.apply(this, [versionInteractionTable, modePPNodeSimilarityComparison, threshSimilarityHardMatch, threshHistogramSimilarity, singleConformationModeQuery]);
}, 1);

Clazz.newMeth(C$, 'init$I$I$D$D$Z',  function (versionInteractionTable, modePPNodeSimilarityComparison, threshSimilarityHardMatch, threshHistogramSimilarity, singleConformationModeQuery) {
this.versionInteractionTable=versionInteractionTable;
this.modePPNodeSimilarityComparison=modePPNodeSimilarityComparison;
this.threshSimilarityHardMatch=threshSimilarityHardMatch;
this.threshHistogramSimilarity=threshHistogramSimilarity;
this.singleConformationModeQuery=singleConformationModeQuery;
$I$(3).createIndexTables$();
this.queueCGM=Clazz.new_($I$(4,1));
this.objectiveCompleteGraphHard=Clazz.new_($I$(5,1).c$$I$I$D$D,[versionInteractionTable, modePPNodeSimilarityComparison, threshSimilarityHardMatch, threshHistogramSimilarity]);
this.queueCGM.add$O(this.getNewCompleteGraphMatcher$());
this.molDistHistEncoder=Clazz.new_($I$(6,1));
this.creatorMolDistHistViz=Clazz.new_($I$(7,1));
}, p$1);

Clazz.newMeth(C$, 'setIncludeNodeAtoms$Z',  function (b) {
this.includeNodeAtoms=b;
});

Clazz.newMeth(C$, 'setModeQuery$Z',  function (modeQuery) {
this.objectiveCompleteGraphHard.setModeQuery$Z(modeQuery);
this.queueCGM.clear$();
});

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (threadMaster) {
this.threadMaster=threadMaster;
this.creatorMolDistHistViz.setThreadMaster$com_actelion_research_calc_ThreadMaster(threadMaster);
});

Clazz.newMeth(C$, 'isSingleConformationModeQuery$',  function () {
return this.singleConformationModeQuery;
});

Clazz.newMeth(C$, 'setSingleConformationModeQuery$Z',  function (singleConformationModeQuery) {
this.singleConformationModeQuery=singleConformationModeQuery;
});

Clazz.newMeth(C$, 'getNewCompleteGraphMatcher$',  function () {
var objective=Clazz.new_($I$(5,1).c$$I$I$D$D,[this.versionInteractionTable, this.modePPNodeSimilarityComparison, this.threshSimilarityHardMatch, this.threshHistogramSimilarity]);
objective.setModeQuery$Z(this.objectiveCompleteGraphHard.isModeQuery$());
var cgMatcher=Clazz.new_($I$(8,1).c$$com_actelion_research_util_graph_complete_IObjectiveCompleteGraph,[objective]);
cgMatcher.setMaxNumSolutions$I(1000);
return cgMatcher;
});

Clazz.newMeth(C$, 'getObjectiveCompleteGraph$',  function () {
return this.objectiveCompleteGraphHard;
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(9).DESCRIPTOR_Flexophore;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(9).DESCRIPTOR_Flexophore.version;
});

Clazz.newMeth(C$, 'toStringParameter$',  function () {
var sb=Clazz.new_($I$(10,1));
sb.append$S("DescriptorHandlerFlexophoreV5");
sb.append$S(" ");
if (this.singleConformationModeQuery) {
sb.append$S("singleConformationModeQuery=true");
} else {
sb.append$S("singleConformationModeQuery=false");
}sb.append$S(", ");
sb.append$S(this.objectiveCompleteGraphHard.toStringParameter$());
return sb.toString();
});

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
if (C$.INSTANCE == null ) {
{
C$.INSTANCE=Clazz.new_(C$);
}}return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'encode$O',  function (o) {
if (this.calculationFailed$O(o)) {
return "Calculation Failed";
}var mdh=null;
if (Clazz.instanceOf(o, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
mdh=o;
} else if (Clazz.instanceOf(o, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
mdh=(o).getMolDistHist$();
} else {
return "Calculation Failed";
}return this.molDistHistEncoder.encode$com_actelion_research_chem_descriptor_flexophore_MolDistHist(mdh);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
try {
return bytes == null  || bytes.length == 0  ? null : $I$(11,"equals$BA$BA",[bytes, $I$(12).FAILED_BYTES]) ? C$.FAILED_OBJECT : this.molDistHistEncoder.decode$BA(bytes);
} catch (e1) {
if (Clazz.exceptionOf(e1,"RuntimeException")){
return C$.FAILED_OBJECT;
} else {
throw e1;
}
}
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
try {
return s == null  || s.length$() == 0  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : this.molDistHistEncoder.decode$S(s);
} catch (e1) {
if (Clazz.exceptionOf(e1,"RuntimeException")){
return C$.FAILED_OBJECT;
} else {
throw e1;
}
}
});

Clazz.newMeth(C$, 'createDescriptorSingleConf$com_actelion_research_chem_StereoMolecule',  function (mol) {
var mdhv=this.creatorMolDistHistViz.createFromGivenConformation$com_actelion_research_chem_StereoMolecule(mol);
return mdhv.getMolDistHist$();
});

Clazz.newMeth(C$, 'createDescriptorSingleConf$com_actelion_research_chem_conf_ConformerSet',  function (conformerSet) {
if (conformerSet == null ) {
return C$.FAILED_OBJECT;
}var mdhv=this.createVisualDescriptorSingleConf$com_actelion_research_chem_conf_ConformerSet(conformerSet);
return mdhv.getMolDistHist$();
});

Clazz.newMeth(C$, 'createVisualDescriptorSingleConf$com_actelion_research_chem_conf_ConformerSet',  function (conformerSet) {
if (conformerSet == null ) {
return Clazz.new_($I$(3,1));
}var mol=conformerSet.first$().toMolecule$();
var mdhv=this.creatorMolDistHistViz.createFromGivenConformation$com_actelion_research_chem_StereoMolecule(mol);
return mdhv;
});

Clazz.newMeth(C$, 'createDescriptor$O',  function (mol) {
var fragBiggest=mol;
var oldToNewAtom=fragBiggest.stripSmallFragments$();
fragBiggest.ensureHelperArrays$I(31);
if (fragBiggest.getAtoms$() < 6) {
return C$.FAILED_OBJECT;
} else if (fragBiggest.getAtoms$() > 70) {
return C$.FAILED_OBJECT;
}var mdhv=this.createVisualDescriptor$com_actelion_research_chem_StereoMolecule(fragBiggest);
var mdh=(mdhv == null ) ? null : mdhv.getMolDistHist$();
this.recentException=null;
if (mdh == null ) {
mdh=C$.FAILED_OBJECT;
} else if (mdh.getNumPPNodes$() > 64) {
var msg="Flexophore exceeded maximum number of nodes.";
this.recentException=Clazz.new_(Clazz.load('RuntimeException').c$$S,[msg]);
mdh=C$.FAILED_OBJECT;
} else if (this.includeNodeAtoms) {
var nodeList=mdhv.getNodes$();
var nodeAtom=Clazz.array(Integer.TYPE, [nodeList.size$(), null]);
for (var i=0; i < nodeList.size$(); i++) {
nodeAtom[i]=$I$(13,"toIntArray$java_util_Collection",[nodeList.get$I(i).getListIndexOriginalAtoms$()]);
if (oldToNewAtom != null ) {
var newToOldAtom=Clazz.array(Integer.TYPE, [fragBiggest.getAtoms$()]);
for (var j=0; j < oldToNewAtom.length; j++) if (oldToNewAtom[j] != -1) newToOldAtom[oldToNewAtom[j]]=j;

for (var j=0; j < nodeAtom[i].length; j++) nodeAtom[i][j]=newToOldAtom[nodeAtom[i][j]];

}}
mdh.setNodeAtoms$IAA(nodeAtom);
}return mdh;
});

Clazz.newMeth(C$, 'createVisualDescriptor$com_actelion_research_chem_StereoMolecule',  function (fragBiggest) {
var mdhv=null;
this.recentException=null;
try {
mdhv=this.creatorMolDistHistViz.create$com_actelion_research_chem_StereoMolecule(fragBiggest);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
try {
if (false) {
var can=Clazz.new_($I$(14,1).c$$com_actelion_research_chem_StereoMolecule,[fragBiggest]);
var msg="DescriptorHandlerFlexophore Impossible to generate conformer for\n" + can.getIDCode$();
System.err.println$S(msg);
}} catch (e2) {
if (Clazz.exceptionOf(e2,"Exception")){
e2.printStackTrace$();
this.recentException=e;
} else {
throw e2;
}
}
} else {
throw e;
}
}
return mdhv;
});

Clazz.newMeth(C$, 'createVisualDescriptor$com_actelion_research_chem_conf_ConformerSet',  function (cs) {
return this.creatorMolDistHistViz.createFromConformerSet$com_actelion_research_chem_conf_ConformerSet(cs);
});

Clazz.newMeth(C$, 'getRecentException$',  function () {
return this.recentException;
});

Clazz.newMeth(C$, 'getSimilarity$O$O',  function (query, base) {
var sc=0;
if (base == null  || query == null   || (base).getNumPPNodes$() == 0  || (query).getNumPPNodes$() == 0 ) {
sc=0;
} else {
var mdhvBase=base;
var mdhvQuery=query;
if (mdhvBase.getNumPPNodes$() > 64) {
System.out.println$S("DescriptorHandlerFlexophore getSimilarity(...) mdhvBase.getNumPPNodes() " + mdhvBase.getNumPPNodes$());
return 0;
} else if (mdhvQuery.getNumPPNodes$() > 64) {
System.out.println$S("DescriptorHandlerFlexophore getSimilarity(...) mdhvQuery.getNumPPNodes() " + mdhvQuery.getNumPPNodes$());
return 0;
}sc=p$1.getSimilarity$com_actelion_research_chem_descriptor_flexophore_IMolDistHist$com_actelion_research_chem_descriptor_flexophore_IMolDistHist.apply(this, [mdhvBase, mdhvQuery]);
}return C$.normalizeValue$D(sc);
});

Clazz.newMeth(C$, 'getSimilarity$com_actelion_research_chem_descriptor_flexophore_IMolDistHist$com_actelion_research_chem_descriptor_flexophore_IMolDistHist',  function (iBase, iQuery) {
var mdhvBase=null;
if (Clazz.instanceOf(iBase, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
mdhvBase=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iBase]);
} else if (Clazz.instanceOf(iBase, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
mdhvBase=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz,[iBase]);
}var mdhvQuery=null;
if (Clazz.instanceOf(iQuery, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
mdhvQuery=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[iQuery]);
} else if (Clazz.instanceOf(iQuery, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
mdhvQuery=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz,[iQuery]);
}var cgMatcher=this.queueCGM.poll$();
if (cgMatcher == null ) {
cgMatcher=this.getNewCompleteGraphMatcher$();
}cgMatcher.set$com_actelion_research_util_graph_complete_ICompleteGraph$com_actelion_research_util_graph_complete_ICompleteGraph(mdhvBase, mdhvQuery);
var sc=cgMatcher.calculateSimilarity$();
this.solution=cgMatcher.getBestMatchingSolution$();
this.queueCGM.add$O(cgMatcher);
return sc;
}, p$1);

Clazz.newMeth(C$, 'getRecentSolution$',  function () {
return this.solution;
});

Clazz.newMeth(C$, 'getBestMatch$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhvBase, mdhvQuery) {
var cgMatcher=this.queueCGM.poll$();
if (cgMatcher == null ) {
cgMatcher=this.getNewCompleteGraphMatcher$();
}cgMatcher.set$com_actelion_research_util_graph_complete_ICompleteGraph$com_actelion_research_util_graph_complete_ICompleteGraph(mdhvBase, mdhvQuery);
cgMatcher.calculateSimilarity$();
var scgBest=cgMatcher.getBestMatchingSolution$();
var n=scgBest.getSizeHeap$();
if (n == 0) return null;
var arrSimNode=Clazz.array(Float.TYPE, [scgBest.getNodesQuery$()]);
$I$(11).fill$FA$F(arrSimNode, -1);
var objectiveCompleteGraphHard=cgMatcher.getObjectiveCompleteGraph$();
objectiveCompleteGraphHard.setMatchingInfoInQueryAndBase$com_actelion_research_util_graph_complete_SolutionCompleteGraph(scgBest);
for (var indexHeap=0; indexHeap < n; indexHeap++) {
var indexQuery=scgBest.getIndexQueryFromHeap$I(indexHeap);
arrSimNode[indexQuery]=mdhvQuery.getNode$I(indexQuery).getSimilarityMappingNodes$();
}
var mss=Clazz.new_($I$(15,1).c$$com_actelion_research_util_graph_complete_SolutionCompleteGraph$FA,[scgBest, arrSimNode]);
return mss;
});

Clazz.newMeth(C$, 'getBestMatch$com_actelion_research_chem_descriptor_flexophore_MolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdhBase, mdhQuery) {
var mdhvBase=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[mdhBase]);
var mdhvQuery=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_descriptor_flexophore_MolDistHist,[mdhQuery]);
var cgMatcher=this.queueCGM.poll$();
if (cgMatcher == null ) {
cgMatcher=this.getNewCompleteGraphMatcher$();
}cgMatcher.set$com_actelion_research_util_graph_complete_ICompleteGraph$com_actelion_research_util_graph_complete_ICompleteGraph(mdhvBase, mdhvQuery);
cgMatcher.calculateSimilarity$();
var scgBest=cgMatcher.getBestMatchingSolution$();
var n=scgBest.getSizeHeap$();
if (n == 0) return null;
var arrSimNode=Clazz.array(Float.TYPE, [scgBest.getNodesQuery$()]);
$I$(11).fill$FA$F(arrSimNode, -1);
var objectiveCompleteGraphHard=cgMatcher.getObjectiveCompleteGraph$();
objectiveCompleteGraphHard.setMatchingInfoInQueryAndBase$com_actelion_research_util_graph_complete_SolutionCompleteGraph(scgBest);
for (var indexHeap=0; indexHeap < n; indexHeap++) {
var indexQuery=scgBest.getIndexQueryFromHeap$I(indexHeap);
arrSimNode[indexQuery]=mdhvQuery.getNode$I(indexQuery).getSimilarityMappingNodes$();
}
var mss=Clazz.new_($I$(15,1).c$$com_actelion_research_util_graph_complete_SolutionCompleteGraph$FA,[scgBest, arrSimNode]);
return mss;
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.4), 2.5));
}, 1);

Clazz.newMeth(C$, 'calculationFailed$O',  function (o) {
if (Clazz.instanceOf(o, "com.actelion.research.chem.descriptor.flexophore.MolDistHist")) {
return (o).getNumPPNodes$() == 0;
} else if (Clazz.instanceOf(o, "com.actelion.research.chem.descriptor.flexophore.MolDistHistViz")) {
return (o).getNumPPNodes$() == 0;
}return true;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
var dh=Clazz.new_(C$.c$$I$I$D$D$Z,[this.versionInteractionTable, this.modePPNodeSimilarityComparison, this.threshSimilarityHardMatch, this.threshHistogramSimilarity, this.singleConformationModeQuery]);
dh.setModeQuery$Z(this.objectiveCompleteGraphHard.isModeQuery$());
dh.setIncludeNodeAtoms$Z(this.includeNodeAtoms);
return dh;
});

Clazz.newMeth(C$, 'setObjectiveQueryBiased$Z',  function (enable) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["setObjectiveQueryBiased(...) is not implemented"]);
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.new_($I$(1,1));
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:20 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
