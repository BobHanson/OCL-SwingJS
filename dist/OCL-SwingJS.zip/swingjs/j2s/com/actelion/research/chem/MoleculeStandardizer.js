(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.AtomFunctionAnalyzer','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MoleculeStandardizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getStandardized$S$S$I',  function (idcode, coordinates, mode) {
var mol=Clazz.new_($I$(1,1)).getCompactMolecule$S$S(idcode, coordinates);
C$.standardize$com_actelion_research_chem_StereoMolecule$I(mol, mode);
return mol;
}, 1);

Clazz.newMeth(C$, 'standardize$com_actelion_research_chem_StereoMolecule$I',  function (mol, mode) {
if ((mode & 1) != 0) mol.stripSmallFragments$();
if ((mode & 2) != 0) mol.stripIsotopInfo$();
C$.repairAndUnify$com_actelion_research_chem_StereoMolecule(mol);
mol.normalizeAmbiguousBonds$();
var remainingCharge=mol.canonizeCharge$Z$Z(true, true);
if (remainingCharge != 0) C$.neutralizeCharges$com_actelion_research_chem_StereoMolecule$I$I(mol, mode, remainingCharge);
mol.validateAtomQueryFeatures$();
mol.validateBondQueryFeatures$();
}, 1);

Clazz.newMeth(C$, 'repairAndUnify$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
C$.repairCovalentBoundChargedAlkaliAndHalogen$com_actelion_research_chem_StereoMolecule(mol);
C$.chargeTrivalentOxygen$com_actelion_research_chem_StereoMolecule(mol);
C$.repairBadAmideTautomer$com_actelion_research_chem_StereoMolecule(mol);
C$.repairQuaternaryNitrogen$com_actelion_research_chem_StereoMolecule(mol);
C$.unifyIsoCyano$com_actelion_research_chem_StereoMolecule(mol);
C$.unifyAzido$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'neutralizeCharges$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, mode, totalCharge) {
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAllAtoms$() && totalCharge > 0 ; atom++) {
if ($I$(2).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
mol.setAtomCharge$I$I(atom, -1);
--totalCharge;
}}
for (var atom=0; atom < mol.getAllAtoms$() && totalCharge < 0 ; atom++) {
if ($I$(2).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
mol.setAtomCharge$I$I(atom, 1);
++totalCharge;
}}
if (totalCharge != 0 && (mode & 4) != 0 ) {
for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.setAtomMarker$I$Z(atom, true);

while (totalCharge > 0){
var ind=mol.addAtom$I(17);
mol.setAtomCharge$I$I(ind, -1);
--totalCharge;
}
while (totalCharge < 0){
var ind=mol.addAtom$I(11);
mol.setAtomCharge$I$I(ind, 1);
++totalCharge;
}
Clazz.new_($I$(3,1).c$$I,[6]).invent$com_actelion_research_chem_StereoMolecule(mol);
}}, 1);

Clazz.newMeth(C$, 'repairCovalentBoundChargedAlkaliAndHalogen$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.isHalogene$I(atom)) {
if (mol.getOccupiedValence$I(atom) == 1 && mol.getAtomCharge$I(atom) == -1 ) {
mol.setAtomCharge$I$I(atom, 0);
mol.setAtomAbnormalValence$I$I(atom, -1);
}continue;
}if (mol.isAlkaliMetal$I(atom)) {
if (mol.getOccupiedValence$I(atom) == 1 && mol.getAtomCharge$I(atom) == 1 ) {
mol.setAtomCharge$I$I(atom, 0);
mol.setAtomAbnormalValence$I$I(atom, -1);
}continue;
}if (mol.isEarthAlkaliMetal$I(atom)) {
if (mol.getOccupiedValence$I(atom) == 2 && mol.getAtomCharge$I(atom) == 2 ) {
mol.setAtomCharge$I$I(atom, 0);
mol.setAtomAbnormalValence$I$I(atom, -1);
}continue;
}}
}, 1);

Clazz.newMeth(C$, 'chargeTrivalentOxygen$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var atom=0; atom < mol.getAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) == 8 || mol.getAtomicNo$I(atom) == 16 ) && mol.getOccupiedValence$I(atom) == 3  && mol.getAtomCharge$I(atom) != 1 ) mol.setAtomCharge$I$I(atom, 1);

}, 1);

Clazz.newMeth(C$, 'repairBadAmideTautomer$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var oxygen=0; oxygen < mol.getAtoms$(); oxygen++) {
if (mol.getAtomicNo$I(oxygen) == 8 && mol.getConnAtoms$I(oxygen) == 1  && mol.getConnBondOrder$I$I(oxygen, 0) == 1 ) {
var carbon=mol.getConnAtom$I$I(oxygen, 0);
if (mol.getAtomicNo$I(carbon) == 6 && mol.getAtomPi$I(carbon) == 1 ) {
for (var i=0; i < mol.getConnAtoms$I(carbon); i++) {
if (mol.getConnBondOrder$I$I(carbon, i) == 2) {
var nitrogen=mol.getConnAtom$I$I(carbon, i);
if (mol.getAtomicNo$I(nitrogen) == 7 && !mol.isRingAtom$I(nitrogen) ) {
var hasResonance=false;
for (var j=0; j < mol.getConnAtoms$I(nitrogen); j++) {
var connAtom=mol.getConnAtom$I$I(nitrogen, j);
if (connAtom != carbon && mol.getAtomPi$I(connAtom) != 0 ) {
hasResonance=true;
break;
}}
if (!hasResonance) {
mol.setBondType$I$I(mol.getConnBond$I$I(oxygen, 0), 2);
mol.setBondType$I$I(mol.getConnBond$I$I(carbon, i), 1);
break;
}}}}
}}}
}, 1);

Clazz.newMeth(C$, 'unifyIsoCyano$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondType$I(bond) == 4) {
for (var i=0; i < 2; i++) {
var atom1=mol.getBondAtom$I$I(i, bond);
var atom2=mol.getBondAtom$I$I(1 - i, bond);
if (mol.getAtomicNo$I(atom1) == 7 && mol.getConnAtoms$I(atom1) == 2  && mol.getAtomicNo$I(atom2) == 6  && mol.getConnAtoms$I(atom2) == 1 ) {
if (mol.getAtomCharge$I(atom1) != 1) mol.setAtomCharge$I$I(atom1, 1);
if (mol.getAtomCharge$I(atom2) != -1) mol.setAtomCharge$I$I(atom2, -1);
break;
}}
}}
}, 1);

Clazz.newMeth(C$, 'unifyAzido$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == 7 && mol.getConnAtoms$I(atom) == 2  && mol.getConnBondOrder$I$I(atom, 0) == 2  && mol.getConnBondOrder$I$I(atom, 1) == 2  && mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, 0)) == 7  && mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, 1)) == 7 ) {
for (var i=0; i < 2; i++) {
var atom1=mol.getConnAtom$I$I(atom, i);
var atom2=mol.getConnAtom$I$I(atom, 1 - i);
if (mol.getConnAtoms$I(atom1) == 1 && mol.getConnAtoms$I(atom2) == 2 ) {
if (mol.getAtomCharge$I(atom) != 1) mol.setAtomCharge$I$I(atom, 1);
if (mol.getAtomCharge$I(atom1) != -1) mol.setAtomCharge$I$I(atom1, -1);
if (mol.getAtomCharge$I(atom2) != 0) mol.setAtomCharge$I$I(atom2, 0);
break;
}}
}}
}, 1);

Clazz.newMeth(C$, 'repairQuaternaryNitrogen$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAllAtoms$(); i++) if (mol.getAtomicNo$I(i) == 7 && mol.getOccupiedValence$I(i) == 4  && mol.getAtomCharge$I(i) != 1 ) mol.setAtomCharge$I$I(i, 1);

}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
