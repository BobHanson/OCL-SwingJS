(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.util.DoubleFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Mutation");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mProbability'],'I',['mMutationType','mWhere1','mWhere2','mSpecifier1','mSpecifier2'],'O',['mAtomList','int[]']]
,['O',['cAllowedAtomicNo','int[][]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$I$D',  function (mutationType, where1, where2, specifier1, specifier2, probability) {
;C$.$init$.apply(this);
this.mMutationType=mutationType;
this.mWhere1=where1;
this.mWhere2=where2;
this.mSpecifier1=specifier1;
this.mSpecifier2=specifier2;
this.mProbability=probability;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I$I$IA$D',  function (mutationType, where1, where2, specifier1, atomList, probability) {
;C$.$init$.apply(this);
this.mMutationType=mutationType;
this.mWhere1=where1;
this.mWhere2=where2;
this.mSpecifier1=specifier1;
this.mAtomList=atomList;
this.mProbability=probability;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
switch (this.mMutationType) {
case 1:
return "Atom Addition; AtAtom:" + this.mWhere1 + " AtomicNo:" + this.mSpecifier1 + " BondType:" + this.mSpecifier2 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 2:
return "Atom Insertion; AtBond:" + this.mWhere1 + " AtomicNo:" + this.mSpecifier1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 4:
return "Atom Change; Atom:" + this.mWhere1 + " AtomicNo:" + this.mSpecifier1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 16:
return "Atom Deletion; Atom:" + this.mWhere1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 8:
return "Atom CutOut; Atom:" + this.mWhere1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 32:
return "Bond Addition; FromAtom:" + this.mWhere1 + " ToAtom:" + this.mWhere2 + " BondType:" + this.mSpecifier1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 64:
return "Bond Change; Bond:" + this.mWhere1 + " BondType:" + this.mSpecifier1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 128:
return "Bond Deletion; Bond:" + this.mWhere1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 256:
return "Ring Change; Ring:" + this.mWhere1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 512:
return "Close Ring And Aromatize; FromAtom:" + this.mWhere1 + " ToAtom:" + this.mWhere2 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 1024:
return "Toggle Amid-Sulfonamid; Atom:" + this.mWhere1 + " Oxygen:" + this.mWhere1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 2048:
return "Group Migration; Bond:" + this.mWhere1 + " originalAtom:" + this.mSpecifier1 + " newAtom:" + this.mSpecifier2 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 4096:
return "Swap Substituent; coreAtom1:" + this.mWhere1 + " firstAtom1:" + this.mSpecifier1 + " coreAtom2:" + this.mWhere2 + " firstAtom2:" + this.mSpecifier2 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 8192:
return "Delete Substituent; coreAtom:" + this.mWhere1 + " firstAtom:" + this.mSpecifier1 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 16384:
return "CutOut Fragment; rootAtom:" + this.mWhere1 + " new bond from atom1:" + this.mSpecifier1 + " to atom2:" + this.mSpecifier2 + " Probability:" + $I$(1).toString$D(this.mProbability) ;
case 32768:
return "Invert Parity; " + (this.mWhere1 != -1 ? "atom:" + this.mWhere1 : "bond:" + this.mWhere2) + " Probability:" + $I$(1).toString$D(this.mProbability) ;
}
return "Unknown Mutation";
});

C$.$static$=function(){C$.$static$=0;
C$.cAllowedAtomicNo=Clazz.array(Integer.TYPE, -2, [Clazz.array(Integer.TYPE, -1, [5, 6, 7, 8, 9, 15, 16, 17, 35, 53]), Clazz.array(Integer.TYPE, -1, [6, 7, 8, 15, 16]), Clazz.array(Integer.TYPE, -1, [6, 7])]);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
