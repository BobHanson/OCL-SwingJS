(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'StringBuilder','com.actelion.research.chem.Canonizer','java.util.ArrayList','com.actelion.research.chem.SmilesAtom','java.util.Arrays','com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IsomericSmilesCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mMode'],'S',['mSmiles'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mCanonizer','com.actelion.research.chem.Canonizer','mAtomRank','int[]','+mClosureNumber','+mSmilesIndex','mKnownTHCountInESRGroup','int[][]','mGraphAtomList','java.util.List','mAtomUsed','boolean[]','+mBondUsed','+mPseudoStereoGroupInversion','+mPseudoStereoGroupInitialized','mEZHalfParity','int[]']]]

Clazz.newMeth(C$, 'createSmiles$com_actelion_research_chem_StereoMolecule',  function (mol) {
return Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$I,[mol, 0]).getSmiles$();
}, 1);

Clazz.newMeth(C$, 'createSmarts$com_actelion_research_chem_StereoMolecule',  function (mol) {
return Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$I,[mol, 1]).getSmiles$();
}, 1);

Clazz.newMeth(C$, 'createReactionSmarts$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
return C$.createReactionSmiles$com_actelion_research_chem_reaction_Reaction$I(rxn, 3);
}, 1);

Clazz.newMeth(C$, 'createReactionSmiles$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
return C$.createReactionSmiles$com_actelion_research_chem_reaction_Reaction$I(rxn, 2);
}, 1);

Clazz.newMeth(C$, 'createReactionSmiles$com_actelion_research_chem_reaction_Reaction$I',  function (rxn, mode) {
var sb=Clazz.new_($I$(1,1));
for (var i=0; i < rxn.getReactants$(); i++) {
if (i != 0) sb.append$C(".");
sb.append$S(Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$I,[rxn.getReactant$I(i), mode]).getSmiles$());
}
sb.append$C(">");
for (var i=0; i < rxn.getCatalysts$(); i++) {
if (i != 0) sb.append$C(".");
sb.append$S(Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule,[rxn.getCatalyst$I(i)]).getSmiles$());
}
sb.append$C(">");
for (var i=0; i < rxn.getProducts$(); i++) {
if (i != 0) sb.append$C(".");
sb.append$S(Clazz.new_(C$.c$$com_actelion_research_chem_StereoMolecule$I,[rxn.getProduct$I(i), mode]).getSmiles$());
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$Z.apply(this, [mol, false]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, mode) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mMode=mode;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z',  function (mol, includeAtomMapping) {
C$.c$$com_actelion_research_chem_StereoMolecule$I.apply(this, [mol, includeAtomMapping ? 2 : 0]);
}, 1);

Clazz.newMeth(C$, 'getSmiles$',  function () {
if (this.mSmiles == null ) this.mSmiles=p$1.createSmiles.apply(this, []);
return this.mSmiles;
});

Clazz.newMeth(C$, 'createSmiles',  function () {
if (this.mMol == null  || this.mMol.getAllAtoms$() == 0 ) return "";
this.mMol.ensureHelperArrays$I(15);
this.mCanonizer=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule$I,[this.mMol, 129]);
var groupCount=this.mCanonizer.getPseudoStereoGroupCount$();
this.mPseudoStereoGroupInversion=Clazz.array(Boolean.TYPE, [groupCount + 1]);
this.mPseudoStereoGroupInitialized=Clazz.array(Boolean.TYPE, [groupCount + 1]);
this.mKnownTHCountInESRGroup=Clazz.array(Integer.TYPE, [2, 32]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var type=this.mMol.getAtomESRType$I(atom) - 1;
if (type != -1) ++this.mKnownTHCountInESRGroup[type][this.mMol.getAtomESRGroup$I(atom)];
}
p$1.generateCanonicalTree.apply(this, []);
p$1.findRingClosures.apply(this, []);
p$1.calculateEZBonds.apply(this, []);
var builder=Clazz.new_($I$(1,1));
var buffer=Clazz.new_($I$(1,1));
var isFirst=true;
for (var smilesAtom, $smilesAtom = this.mGraphAtomList.iterator$(); $smilesAtom.hasNext$()&&((smilesAtom=($smilesAtom.next$())),1);) {
if (smilesAtom.parent == -1) {
if (isFirst) isFirst=false;
 else builder.append$C(".");
}p$1.addAtomString$com_actelion_research_chem_SmilesAtom$StringBuilder$StringBuilder.apply(this, [smilesAtom, builder, buffer]);
}
return builder.toString();
}, p$1);

Clazz.newMeth(C$, 'generateCanonicalTree',  function () {
this.mAtomRank=this.mCanonizer.getFinalRank$();
this.mAtomUsed=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mBondUsed=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mGraphAtomList=Clazz.new_($I$(3,1));
var atom=p$1.findUnusedStartAtom.apply(this, []);
while (atom != -1){
var graphIndex=this.mGraphAtomList.size$();
p$1.addToGraph$com_actelion_research_chem_SmilesAtom$I.apply(this, [Clazz.new_($I$(4,1).c$$I$I$I$Z$Z,[atom, -1, -1, false, false]), graphIndex]);
if (this.mMol.getConnAtoms$I(atom) != 0) {
p$1.addHighestRankingChain$I$Z.apply(this, [graphIndex, false]);
while (graphIndex < this.mGraphAtomList.size$() - 1){
while (p$1.hasUnusedNeighborAtom$I.apply(this, [this.mGraphAtomList.get$I(graphIndex).atom]))p$1.addHighestRankingChain$I$Z.apply(this, [graphIndex, true]);

++graphIndex;
}
}atom=p$1.findUnusedStartAtom.apply(this, []);
}
this.mSmilesIndex=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var index=0;
for (var smilesAtom, $smilesAtom = this.mGraphAtomList.iterator$(); $smilesAtom.hasNext$()&&((smilesAtom=($smilesAtom.next$())),1);) this.mSmilesIndex[smilesAtom.atom]=index++;

}, p$1);

Clazz.newMeth(C$, 'findRingClosures',  function () {
for (var smilesAtom, $smilesAtom = this.mGraphAtomList.iterator$(); $smilesAtom.hasNext$()&&((smilesAtom=($smilesAtom.next$())),1);) {
var closureCount=0;
for (var i=0; i < this.mMol.getConnAtoms$I(smilesAtom.atom); i++) if (!this.mBondUsed[this.mMol.getConnBond$I$I(smilesAtom.atom, i)]) ++closureCount;

if (closureCount != 0) {
smilesAtom.closureNeighbour=Clazz.array(Integer.TYPE, [closureCount]);
closureCount=0;
for (var i=0; i < this.mMol.getConnAtoms$I(smilesAtom.atom); i++) {
if (!this.mBondUsed[this.mMol.getConnBond$I$I(smilesAtom.atom, i)]) {
var neighbour=this.mMol.getConnAtom$I$I(smilesAtom.atom, i);
smilesAtom.closureNeighbour[closureCount++]=(this.mSmilesIndex[neighbour] << 16) | neighbour;
}}
$I$(5).sort$IA(smilesAtom.closureNeighbour);
for (var i=0; i < smilesAtom.closureNeighbour.length; i++) smilesAtom.closureNeighbour[i]=65535 & smilesAtom.closureNeighbour[i];

}}
var closureNumberUsed=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mClosureNumber=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
for (var smilesAtom, $smilesAtom = this.mGraphAtomList.iterator$(); $smilesAtom.hasNext$()&&((smilesAtom=($smilesAtom.next$())),1);) {
if (smilesAtom.closureNeighbour != null ) {
smilesAtom.closureOpens=Clazz.array(Boolean.TYPE, [smilesAtom.closureNeighbour.length]);
for (var i=0; i < smilesAtom.closureNeighbour.length; i++) {
for (var j=0; j < this.mMol.getConnAtoms$I(smilesAtom.atom); j++) {
if (smilesAtom.closureNeighbour[i] == this.mMol.getConnAtom$I$I(smilesAtom.atom, j)) {
var bond=this.mMol.getConnBond$I$I(smilesAtom.atom, j);
if (!this.mBondUsed[bond]) {
this.mBondUsed[bond]=true;
smilesAtom.closureOpens[i]=true;
this.mClosureNumber[bond]=1;
while (closureNumberUsed[this.mClosureNumber[bond]])++this.mClosureNumber[bond];

closureNumberUsed[this.mClosureNumber[bond]]=true;
} else {
closureNumberUsed[this.mClosureNumber[bond]]=false;
}}}
}
}}
}, p$1);

Clazz.newMeth(C$, 'calculateEZBonds',  function () {
var relativeBondParityList=Clazz.new_($I$(3,1));
for (var currentSA, $currentSA = this.mGraphAtomList.iterator$(); $currentSA.hasNext$()&&((currentSA=($currentSA.next$())),1);) {
if (currentSA.parent != -1) {
var ezBond=this.mMol.getBond$I$I(currentSA.atom, currentSA.parent);
if (!this.mMol.isBINAPChiralityBond$I(ezBond) && !this.mMol.isSmallRingBond$I(ezBond) && (this.mMol.getBondParity$I(ezBond) == 1 || this.mMol.getBondParity$I(ezBond) == 2 )  ) {
var parentSA=this.mGraphAtomList.get$I(this.mSmilesIndex[currentSA.parent]);
var bondWithHalfParity=Clazz.array(Integer.TYPE, [this.mMol.getConnAtoms$I(currentSA.atom) + this.mMol.getConnAtoms$I(parentSA.atom) - 2]);
var halfParityIndex=0;
var parity=false;
if (parentSA.parent != -1) {
bondWithHalfParity[halfParityIndex++]=parentSA.bond;
} else {
var firstNeighbourIndex=-1;
var secondNeighbourIndex=-1;
;var firstSmilesIndex=2147483647;
for (var i=0; i < this.mMol.getConnAtoms$I(parentSA.atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(parentSA.atom, i);
if (connAtom != currentSA.atom) {
if (firstNeighbourIndex == -1) {
firstNeighbourIndex=i;
firstSmilesIndex=this.mSmilesIndex[connAtom];
} else {
if (firstSmilesIndex < this.mSmilesIndex[connAtom]) {
secondNeighbourIndex=i;
} else {
secondNeighbourIndex=firstNeighbourIndex;
firstNeighbourIndex=i;
}}}}
if (secondNeighbourIndex == -1) {
var neighbourAtom=this.mMol.getConnAtom$I$I(parentSA.atom, firstNeighbourIndex);
var neighbourBond=this.mMol.getConnBond$I$I(parentSA.atom, firstNeighbourIndex);
bondWithHalfParity[halfParityIndex++]=neighbourBond | (p$1.isBondFromTo$I$I.apply(this, [parentSA.atom, neighbourAtom]) ? 1073741824 : 0);
} else {
var connAtom1=this.mMol.getConnAtom$I$I(parentSA.atom, firstNeighbourIndex);
var connBond1=this.mMol.getConnBond$I$I(parentSA.atom, firstNeighbourIndex);
var connAtom2=this.mMol.getConnAtom$I$I(parentSA.atom, secondNeighbourIndex);
var connBond2=this.mMol.getConnBond$I$I(parentSA.atom, secondNeighbourIndex);
bondWithHalfParity[halfParityIndex++]=connBond1 | (p$1.isBondFromTo$I$I.apply(this, [parentSA.atom, connAtom1]) ? 1073741824 : 0);
bondWithHalfParity[halfParityIndex++]=connBond2 | (p$1.isBondFromTo$I$I.apply(this, [parentSA.atom, connAtom2]) ? 0 : 1073741824);
}}if (this.mMol.getConnAtoms$I(parentSA.atom) == 3 && parentSA.parent != -1 ) {
for (var i=0; i < this.mMol.getConnAtoms$I(parentSA.atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(parentSA.atom, i);
if (connAtom != parentSA.parent && connAtom != currentSA.atom ) {
var branchBond=this.mMol.getConnBond$I$I(parentSA.atom, i);
bondWithHalfParity[halfParityIndex++]=branchBond | (p$1.isBondFromTo$I$I.apply(this, [parentSA.atom, connAtom]) ? 1073741824 : 0);
if (connAtom < parentSA.parent) parity=!parity;
break;
}}
}if (this.mMol.getBondParity$I(ezBond) == 2) parity=!parity;
for (var i=0; i < this.mMol.getConnAtoms$I(currentSA.atom); i++) {
var childAtom=this.mMol.getConnAtom$I$I(currentSA.atom, i);
if (childAtom != currentSA.parent) {
var halfParity2=parity;
if (this.mMol.getConnAtoms$I(currentSA.atom) == 3) {
for (var j=0; j < this.mMol.getConnAtoms$I(currentSA.atom); j++) {
var connAtom=this.mMol.getConnAtom$I$I(currentSA.atom, j);
if (connAtom != currentSA.parent && connAtom != childAtom ) {
if (connAtom < childAtom) halfParity2=!halfParity2;
break;
}}
}if (this.mMol.isBondParityPseudo$I(ezBond)) {
var group=this.mCanonizer.getPseudoEZGroup$I(ezBond);
if (!this.mPseudoStereoGroupInitialized[group]) {
this.mPseudoStereoGroupInitialized[group]=true;
this.mPseudoStereoGroupInversion[group]=halfParity2;
}if (this.mPseudoStereoGroupInversion[group]) halfParity2=!halfParity2;
}var childBond=this.mMol.getBond$I$I(currentSA.atom, childAtom);
bondWithHalfParity[halfParityIndex++]=childBond | (!!(halfParity2 ^ p$1.isBondFromTo$I$I.apply(this, [currentSA.atom, childAtom])) ? 0 : 1073741824);
}}
relativeBondParityList.add$O(bondWithHalfParity);
}}}
this.mEZHalfParity=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
if (relativeBondParityList.size$() != 0) p$1.addRelativeBondHalfParities$IA$Z.apply(this, [relativeBondParityList.remove$I(0), false]);
while (relativeBondParityList.size$() != 0){
var startSize=relativeBondParityList.size$();
for (var i=relativeBondParityList.size$() - 1; i >= 0; i--) {
var bondWithHalfParity=relativeBondParityList.get$I(i);
var overlapCount=0;
var inverted=false;
var collides=false;
for (var bwhp, $bwhp = 0, $$bwhp = bondWithHalfParity; $bwhp<$$bwhp.length&&((bwhp=($$bwhp[$bwhp])),1);$bwhp++) {
var bond=bwhp & 1073741823;
if (this.mEZHalfParity[bond] != 0) {
var differs=!!(((bwhp & 1073741824) != 0) ^ (this.mEZHalfParity[bond] == 2));
if (overlapCount == 0) inverted=differs;
 else if (inverted != differs ) collides=true;
++overlapCount;
}}
if (overlapCount != 0) {
bondWithHalfParity=relativeBondParityList.remove$I(i);
if (!collides) p$1.addRelativeBondHalfParities$IA$Z.apply(this, [bondWithHalfParity, inverted]);
}}
if (startSize == relativeBondParityList.size$()) p$1.addRelativeBondHalfParities$IA$Z.apply(this, [relativeBondParityList.remove$I(0), false]);
}
}, p$1);

Clazz.newMeth(C$, 'addRelativeBondHalfParities$IA$Z',  function (bondWithHalfParity, inverted) {
for (var bwhp, $bwhp = 0, $$bwhp = bondWithHalfParity; $bwhp<$$bwhp.length&&((bwhp=($$bwhp[$bwhp])),1);$bwhp++) {
this.mEZHalfParity[bwhp & 1073741823]=!!(((bwhp & 1073741824) != 0) ^ inverted) ? 2 : 1;
}
}, p$1);

Clazz.newMeth(C$, 'isBondFromTo$I$I',  function (atom1, atom2) {
var sa1=this.mGraphAtomList.get$I(this.mSmilesIndex[atom1]);
if (sa1.parent == atom2) return false;
var sa2=this.mGraphAtomList.get$I(this.mSmilesIndex[atom2]);
if (sa2.parent == atom1) return true;
return sa2.isOpeningClosureTo$I(atom1);
}, p$1);

Clazz.newMeth(C$, 'findUnusedStartAtom',  function () {
var startAtom=-1;
var startRank=2147483647;
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (!this.mAtomUsed[atom]) {
var rank=this.mAtomRank[atom];
if (Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),536870912)),0 )) rank+=1073741824;
if (this.mMol.getConnAtoms$I(atom) == 0) rank+=1056964608;
 else rank+=this.mMol.getConnAtoms$I(atom) << 24;
if (startRank > rank) {
startRank=rank;
startAtom=atom;
}}}
return startAtom;
}, p$1);

Clazz.newMeth(C$, 'hasUnusedNeighborAtom$I',  function (atom) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (!this.mAtomUsed[this.mMol.getConnAtom$I$I(atom, i)]) return true;

return false;
}, p$1);

Clazz.newMeth(C$, 'addHighestRankingChain$I$Z',  function (graphIndex, isSideChain) {
var isFirst=true;
var parent=this.mGraphAtomList.get$I(graphIndex).atom;
var neighborIndex=p$1.getUnusedConnAtomIndex$I.apply(this, [parent]);
while (neighborIndex != -1){
var atom=this.mMol.getConnAtom$I$I(parent, neighborIndex);
var bond=this.mMol.getConnBond$I$I(parent, neighborIndex);
neighborIndex=p$1.getUnusedConnAtomIndex$I.apply(this, [atom]);
p$1.addToGraph$com_actelion_research_chem_SmilesAtom$I.apply(this, [Clazz.new_([atom, bond, parent, isSideChain && isFirst , isSideChain && neighborIndex == -1 ],$I$(4,1).c$$I$I$I$Z$Z), ++graphIndex]);
parent=atom;
isFirst=false;
}
}, p$1);

Clazz.newMeth(C$, 'getUnusedConnAtomIndex$I',  function (atom) {
var bestIndex=-1;
var bestRank=-1;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var rank=(this.mMol.getConnBondOrder$I$I(atom, i) << 24) + this.mAtomRank[connAtom];
if (!this.mAtomUsed[connAtom] && (bestIndex == -1 || bestRank < rank ) ) {
bestIndex=i;
bestRank=rank;
}}
return bestIndex;
}, p$1);

Clazz.newMeth(C$, 'addToGraph$com_actelion_research_chem_SmilesAtom$I',  function (smilesAtom, listIndex) {
this.mGraphAtomList.add$I$O(listIndex, smilesAtom);
this.mAtomUsed[smilesAtom.atom]=true;
if (smilesAtom.parent != -1) this.mBondUsed[this.mMol.getBond$I$I(smilesAtom.atom, smilesAtom.parent)]=true;
}, p$1);

Clazz.newMeth(C$, 'addAtomString$com_actelion_research_chem_SmilesAtom$StringBuilder$StringBuilder',  function (smilesAtom, builder, buffer) {
var atom=smilesAtom.atom;
var parent=smilesAtom.parent;
var isAnyAtom=Long.$ne((Long.$and(this.mMol.getAtomQueryFeatures$I(atom),1)),0 );
var atomList=this.mMol.getAtomList$I(atom);
var label=(atomList != null ) ? p$1.createMultiAtomLabel$I$IA$StringBuilder.apply(this, [atom, atomList, buffer]) : isAnyAtom ? "*" : this.mMol.getAtomLabel$I(atom);
if (!isAnyAtom && atomList == null   && this.mMol.isAromaticAtom$I(atom)  && (this.mMode & 4) == 0  && (this.mMol.getAtomPi$I(atom) != 0 || (this.mMol.getAtomAbnormalValence$I(atom) == -1 && this.mMol.getAtomRadical$I(atom) == 0 ) ) ) label=label.toLowerCase$();
if (smilesAtom.isSideChainStart) builder.append$C("(");
if (parent != -1) p$1.appendBondOrderSymbol$I$I$StringBuilder.apply(this, [this.mMol.getBond$I$I(smilesAtom.atom, smilesAtom.parent), smilesAtom.parent, builder]);
var charge=this.mMol.getAtomCharge$I(atom);
if (charge == 0 && (this.mMode & 1) != 0 ) {
var chargeFeatures=Long.$and(this.mMol.getAtomQueryFeatures$I(atom),234881024);
if (Long.$eq(chargeFeatures,(201326592) )) charge=-1;
 else if (Long.$eq(chargeFeatures,(100663296) )) charge=1;
}var isotop=this.mMol.getAtomMass$I(atom);
var mapNo=(this.mMode & 2) != 0 ? this.mMol.getAtomMapNo$I(atom) : 0;
var smartsFeatures=(this.mMode & 1) != 0 ? p$1.getAtomSMARTSFeatures$I$StringBuilder.apply(this, [atom, buffer]) : null;
var useBrackets=(!isAnyAtom && !p$1.isOrganic$I.apply(this, [this.mMol.getAtomicNo$I(atom)]) ) || atomList != null   || p$1.qualifiesForAtomParity$I.apply(this, [atom])  || (this.mMol.isAromaticAtom$I(atom) && this.mMol.getAtomPi$I(atom) == 0  && (this.mMode & 4) == 0 )  || charge != 0  || isotop != 0  || mapNo != 0  || this.mMol.getAtomAbnormalValence$I(atom) != -1  || this.mMol.getAtomRadical$I(atom) != 0  || smartsFeatures != null  ;
if (useBrackets) builder.append$C("[");
if (isotop != 0) builder.append$I(isotop);
builder.append$S(label);
if (p$1.qualifiesForAtomParity$I.apply(this, [atom])) builder.append$S(p$1.getAtomParitySymbol$I$I.apply(this, [atom, parent]));
if ((this.mMode & 1) == 0 && useBrackets ) {
var hCount=this.mMol.getPlainHydrogens$I(atom);
if (hCount == 1) builder.append$S("H");
 else if (hCount > 1) builder.append$S("H" + hCount);
}if (charge != 0) {
builder.append$C(charge > 0 ? "+" : "-");
if (Math.abs(charge) > 1) builder.append$I(Math.abs(charge));
}if (smartsFeatures != null ) builder.append$S(smartsFeatures);
if (mapNo != 0) {
builder.append$C(":");
builder.append$I(mapNo);
}if (useBrackets) builder.append$C("]");
p$1.appendClosureBonds$com_actelion_research_chem_SmilesAtom$StringBuilder.apply(this, [smilesAtom, builder]);
if (smilesAtom.isSideChainEnd) builder.append$C(")");
}, p$1);

Clazz.newMeth(C$, 'createMultiAtomLabel$I$IA$StringBuilder',  function (atom, atomicNo, buffer) {
buffer.setLength$I(0);
var isLowerCase=this.mMol.isAromaticAtom$I(atom) && (this.mMode & 4) == 0 ;
for (var a, $a = 0, $$a = atomicNo; $a<$$a.length&&((a=($$a[$a])),1);$a++) {
if (buffer.length$() != 0) buffer.append$C(",");
var label=$I$(6).cAtomLabel[a];
buffer.append$S(isLowerCase ? label.toLowerCase$() : label);
}
return buffer.toString();
}, p$1);

Clazz.newMeth(C$, 'getAtomSMARTSFeatures$I$StringBuilder',  function (atom, buffer) {
buffer.setLength$I(0);
var queryFeatures=this.mMol.getAtomQueryFeatures$I(atom);
var chargeFeatures=Long.$ival((Long.$sr((Long.$and(queryFeatures,234881024)),3)));
switch (chargeFeatures) {
case Long.$ival((20971520)):
buffer.append$S("+0");
break;
case Long.$ival((25165824)):
if (this.mMol.getAtomCharge$I(atom) == 0) buffer.append$S("-");
break;
case Long.$ival((12582912)):
if (this.mMol.getAtomCharge$I(atom) == 0) buffer.append$S("+");
break;
}
var aromState=Long.$and(queryFeatures,70368744177670);
if (Long.$eq(aromState,2 )) buffer.append$S(";a");
 else if (Long.$eq(aromState,4 )) buffer.append$S(";A");
var hydrogenQueryFeatures=Long.$and(queryFeatures,1920);
if (Long.$ne(hydrogenQueryFeatures,0 )) {
if (Long.$eq(hydrogenQueryFeatures,(1792) )) buffer.append$S(";H0");
 else if (Long.$eq(hydrogenQueryFeatures,(1664) )) buffer.append$S(";H1");
 else if (Long.$eq(hydrogenQueryFeatures,(1408) )) buffer.append$S(";H2");
 else if (Long.$eq(hydrogenQueryFeatures,(896) )) buffer.append$S(";H3");
 else if (Long.$eq(hydrogenQueryFeatures,128 )) buffer.append$S(";!H0");
 else if (Long.$eq(hydrogenQueryFeatures,(384) )) buffer.append$S(";!H0;!H1");
 else if (Long.$eq(hydrogenQueryFeatures,(1536) )) buffer.append$S(";!H2;!H3");
 else if (Long.$eq(hydrogenQueryFeatures,1024 )) buffer.append$S(";!H3");
}var ringState=Long.$and(queryFeatures,120);
if (Long.$eq(ringState,8 )) buffer.append$S(";!R0");
 else if (Long.$eq(ringState,16 )) buffer.append$S(";!R1");
 else if (Long.$eq(ringState,32 )) buffer.append$S(";!R2");
 else if (Long.$eq(ringState,64 )) buffer.append$S(";!R3");
 else if (Long.$eq(ringState,(112) )) buffer.append$S(";R0");
 else if (Long.$eq(ringState,(104) )) buffer.append$S(";R1");
 else if (Long.$eq(ringState,(88) )) buffer.append$S(";R2");
 else if (Long.$eq(ringState,(56) )) buffer.append$S(";R3");
var ringSize=Long.$and(queryFeatures,545460846592);
if (Long.$eq(ringSize,4294967296 )) buffer.append$S(";!r" + Long.$s(ringSize));
 else if (Long.$eq(ringSize,(541165879296) )) buffer.append$S(";r" + Long.$s(ringSize));
 else if (Long.$ne(ringSize,0 )) {
if (Long.$ne((Long.$and(ringSize,274877906944)),0 )) {
if (Long.$eq((Long.$and(ringSize,4294967296)),0 )) buffer.append$S(";!r0" + Long.$s(ringSize));
if (Long.$eq((Long.$and(ringSize,8589934592)),0 )) buffer.append$S(";!r3" + Long.$s(ringSize));
if (Long.$eq((Long.$and(ringSize,17179869184)),0 )) buffer.append$S(";!r4" + Long.$s(ringSize));
if (Long.$eq((Long.$and(ringSize,34359738368)),0 )) buffer.append$S(";!r5" + Long.$s(ringSize));
if (Long.$eq((Long.$and(ringSize,68719476736)),0 )) buffer.append$S(";!r6" + Long.$s(ringSize));
if (Long.$eq((Long.$and(ringSize,137438953472)),0 )) buffer.append$S(";!r7" + Long.$s(ringSize));
} else {
buffer.append$S(";");
if (Long.$ne((Long.$and(ringSize,4294967296)),0 )) buffer.append$S("r0," + Long.$s(ringSize));
if (Long.$ne((Long.$and(ringSize,8589934592)),0 )) buffer.append$S("r3," + Long.$s(ringSize));
if (Long.$ne((Long.$and(ringSize,17179869184)),0 )) buffer.append$S("r4," + Long.$s(ringSize));
if (Long.$ne((Long.$and(ringSize,34359738368)),0 )) buffer.append$S("r5," + Long.$s(ringSize));
if (Long.$ne((Long.$and(ringSize,68719476736)),0 )) buffer.append$S("r6," + Long.$s(ringSize));
if (Long.$ne((Long.$and(ringSize,137438953472)),0 )) buffer.append$S("r7," + Long.$s(ringSize));
buffer.setLength$I(buffer.length$() - 1);
}}if (Long.$eq(ringSize,0 )) {
ringSize=Long.$sr((Long.$and(queryFeatures,29360128)),22);
if (Long.$ne(ringSize,0 )) buffer.append$S(";r" + Long.$s(ringSize));
}var neighbourFeatures=Long.$and(queryFeatures,4063232);
if (Long.$eq(neighbourFeatures,(3801088) )) buffer.append$S(";D1");
if (Long.$eq(neighbourFeatures,(3538944) )) buffer.append$S(";D2");
if (Long.$eq(neighbourFeatures,(3014656) )) buffer.append$S(";D3");
if (Long.$eq(neighbourFeatures,(3145728) )) buffer.append$S(";!D3;!D4");
if (Long.$eq(neighbourFeatures,2097152 )) buffer.append$S(";!D4");
if (Long.$eq(neighbourFeatures,(393216) )) buffer.append$S(";!D0;!D1");
if (Long.$eq(neighbourFeatures,(917504) )) buffer.append$S(";!D0;!D1;!D2");
if (Long.$eq(neighbourFeatures,(1966080) )) buffer.append$S(";!D0;!D1;!D2;!D3");
if (Long.$ne((Long.$and(queryFeatures,2048)),0 )) buffer.append$S(";D" + this.mMol.getConnAtoms$I(atom));
if (Long.$ne((Long.$and(queryFeatures,4096)),0 )) buffer.append$S(";!D" + this.mMol.getConnAtoms$I(atom));
return buffer.length$() == 0 ? null : buffer.toString();
}, p$1);

Clazz.newMeth(C$, 'qualifiesForAtomParity$I',  function (atom) {
return (this.mMol.getAtomParity$I(atom) == 1 || this.mMol.getAtomParity$I(atom) == 2 ) && !p$1.isSingleKnownStereoCenterInESRGroup$I.apply(this, [atom]) && (this.mMol.getAtomicNo$I(atom) != 7 || this.mMol.getAtomCharge$I(atom) > 0 )  ;
}, p$1);

Clazz.newMeth(C$, 'isSingleKnownStereoCenterInESRGroup$I',  function (atom) {
var type=this.mMol.getAtomESRType$I(atom) - 1;
return type == -1 ? false : this.mKnownTHCountInESRGroup[type][this.mMol.getAtomESRGroup$I(atom)] <= 1;
}, p$1);

Clazz.newMeth(C$, 'appendClosureBonds$com_actelion_research_chem_SmilesAtom$StringBuilder',  function (smilesAtom, builder) {
if (smilesAtom.closureNeighbour != null ) {
for (var i=0; i < smilesAtom.closureNeighbour.length; i++) {
for (var j=0; j < this.mMol.getConnAtoms$I(smilesAtom.atom); j++) {
if (smilesAtom.closureNeighbour[i] == this.mMol.getConnAtom$I$I(smilesAtom.atom, j)) {
var bond=this.mMol.getConnBond$I$I(smilesAtom.atom, j);
if (!smilesAtom.closureOpens[i]) p$1.appendBondOrderSymbol$I$I$StringBuilder.apply(this, [bond, smilesAtom.atom, builder]);
if (this.mClosureNumber[bond] > 9) builder.append$C("%");
builder.append$I(this.mClosureNumber[bond]);
}}
}
}}, p$1);

Clazz.newMeth(C$, 'appendBondOrderSymbol$I$I$StringBuilder',  function (bond, parentAtom, builder) {
var startLength=builder.length$();
if (this.mEZHalfParity[bond] != 0) builder.append$C(this.mEZHalfParity[bond] == 1 ? "/" : "\\");
if (this.mMode == 1) {
var bondQFTypes=this.mMol.getBondQueryFeatures$I(bond) & (127);
if (bondQFTypes != 0) {
if ((bondQFTypes & 1) != 0 && this.mEZHalfParity[bond] == 0 ) {
builder.append$C("-");
}if ((bondQFTypes & 2) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$C("=");
}if ((bondQFTypes & 4) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$C("#");
}if ((bondQFTypes & 32) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$C("$");
}if ((bondQFTypes & 64) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$C("$");
}if ((bondQFTypes & 8) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$C(":");
}if ((bondQFTypes & 16) != 0) {
if (builder.length$() != startLength) builder.append$C(",");
builder.append$S(this.mMol.isMetalAtom$I(parentAtom) ? "<-" : "->");
}}}if (startLength == builder.length$() && (!this.mMol.isAromaticBond$I(bond) || (this.mMode & 4) != 0 ) ) {
var bondType=this.mMol.getBondType$I(bond) & 127;
if (bondType == 1) {
if (this.mMol.isAromaticAtom$I(this.mMol.getBondAtom$I$I(0, bond)) && this.mMol.isAromaticAtom$I(this.mMol.getBondAtom$I$I(1, bond)) && (this.mMode & 4) == 0   && this.mEZHalfParity[bond] == 0 ) builder.append$C("-");
} else if (bondType == 2) builder.append$C("=");
 else if (bondType == 4) builder.append$C("#");
 else if (bondType == 32) builder.append$C("$");
 else if (bondType == 64) builder.append$C("$");
 else if (bondType == 8) builder.append$C(":");
 else if (bondType == 16) builder.append$S(this.mMol.isMetalAtom$I(parentAtom) ? "<-" : "->");
}if (this.mMode == 1) {
var gap=(startLength == builder.length$()) ? "" : ";";
var ringState=this.mMol.getBondQueryFeatures$I(bond) & 384;
if (ringState == 256) builder.append$S(gap + "@");
 else if (ringState == 128) builder.append$S(gap + "!@");
}}, p$1);

Clazz.newMeth(C$, 'getAtomParitySymbol$I$I',  function (atom, parent) {
var inversion=false;
if (this.mMol.getAtomPi$I(atom) != 0 && this.mMol.getConnAtoms$I(atom) == 2  && this.mMol.getConnBondOrder$I$I(atom, 0) == 2  && this.mMol.getConnBondOrder$I$I(atom, 1) == 2 ) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var neighbours=0;
var neighbour=Clazz.array(Integer.TYPE, [3]);
for (var j=0; j < this.mMol.getConnAtoms$I(connAtom); j++) {
neighbour[neighbours]=this.mMol.getConnAtom$I$I(connAtom, j);
if (neighbour[neighbours] != atom) ++neighbours;
}
if (neighbours == 2 && (!!((this.mSmilesIndex[neighbour[0]] < this.mSmilesIndex[neighbour[1]]) ^ (neighbour[0] < neighbour[1]))) ) inversion=!inversion;
}
} else {
var neighborAtom=Clazz.array(Integer.TYPE, [4]);
var neighborRank=Clazz.array(Integer.TYPE, [4]);
var index=0;
if (parent != -1) {
neighborAtom[index]=parent;
neighborRank[index++]=8 * this.mSmilesIndex[parent];
}if (this.mMol.getImplicitHydrogens$I(atom) != 0) {
neighborAtom[index]=2147483647;
neighborRank[index++]=8 * this.mSmilesIndex[atom];
} else if (this.mMol.getConnAtoms$I(atom) == 3) {
neighborAtom[index]=2147483647;
neighborRank[index++]=8 * this.mSmilesIndex[atom];
}for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
if (connAtom != parent) {
neighborAtom[index]=connAtom;
neighborRank[index++]=p$1.getSmilesRank$I$I.apply(this, [atom, i]);
}}
inversion=p$1.isInverseOrder$IA$IA.apply(this, [neighborAtom, neighborRank]);
}var isClockwise=(!!((this.mMol.getAtomParity$I(atom) == 1) ^ inversion));
if (this.mMol.isAtomParityPseudo$I(atom)) {
var group=this.mCanonizer.getPseudoTHGroup$I(atom);
if (!this.mPseudoStereoGroupInitialized[group]) {
this.mPseudoStereoGroupInitialized[group]=true;
this.mPseudoStereoGroupInversion[group]=isClockwise;
}if (this.mPseudoStereoGroupInversion[group]) isClockwise=!isClockwise;
}return isClockwise ? "@@" : "@";
}, p$1);

Clazz.newMeth(C$, 'isInverseOrder$IA$IA',  function (neighborAtom, neighborRank) {
var inversion=false;
for (var i=1; i < 4; i++) {
for (var j=0; j < i; j++) {
if (neighborAtom[j] > neighborAtom[i]) inversion=!inversion;
if (neighborRank[j] > neighborRank[i]) inversion=!inversion;
}
}
return inversion;
}, p$1);

Clazz.newMeth(C$, 'getSmilesRank$I$I',  function (atom, neighbourIndex) {
var bond=this.mMol.getConnBond$I$I(atom, neighbourIndex);
var neighbour=this.mMol.getConnAtom$I$I(atom, neighbourIndex);
if (this.mClosureNumber[bond] != 0) {
var rank=8 * this.mSmilesIndex[atom] + 1;
var closureNeighbour=this.mGraphAtomList.get$I(this.mSmilesIndex[atom]).closureNeighbour;
for (var i=0; i < closureNeighbour.length && neighbour != closureNeighbour[i] ; i++) ++rank;

return rank;
}return 8 * this.mSmilesIndex[neighbour];
}, p$1);

Clazz.newMeth(C$, 'isOrganic$I',  function (atomicNo) {
return (atomicNo >= 5 && atomicNo <= 9 ) || (atomicNo >= 15 && atomicNo <= 17 ) || atomicNo == 35   || atomicNo == 53 ;
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:48 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
