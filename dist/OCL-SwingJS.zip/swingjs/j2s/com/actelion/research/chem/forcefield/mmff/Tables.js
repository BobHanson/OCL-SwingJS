(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.table.Angle','com.actelion.research.chem.forcefield.mmff.table.Charge','com.actelion.research.chem.forcefield.mmff.table.Atom','com.actelion.research.chem.forcefield.mmff.table.Bndk','com.actelion.research.chem.forcefield.mmff.table.Bond','com.actelion.research.chem.forcefield.mmff.table.CovRad','com.actelion.research.chem.forcefield.mmff.table.Dfsb','com.actelion.research.chem.forcefield.mmff.table.Def','com.actelion.research.chem.forcefield.mmff.table.HerschbachLaurie','com.actelion.research.chem.forcefield.mmff.table.OutOfPlane','com.actelion.research.chem.forcefield.mmff.table.Stbn','com.actelion.research.chem.forcefield.mmff.table.Torsion','com.actelion.research.chem.forcefield.mmff.table.VanDerWaals']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Tables");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['angle','com.actelion.research.chem.forcefield.mmff.table.Angle','atom','com.actelion.research.chem.forcefield.mmff.table.Atom','bndk','com.actelion.research.chem.forcefield.mmff.table.Bndk','bond','com.actelion.research.chem.forcefield.mmff.table.Bond','covrad','com.actelion.research.chem.forcefield.mmff.table.CovRad','dfsb','com.actelion.research.chem.forcefield.mmff.table.Dfsb','def','com.actelion.research.chem.forcefield.mmff.table.Def','hblaurie','com.actelion.research.chem.forcefield.mmff.table.HerschbachLaurie','oop','com.actelion.research.chem.forcefield.mmff.table.OutOfPlane','chge','com.actelion.research.chem.forcefield.mmff.table.Charge','stbn','com.actelion.research.chem.forcefield.mmff.table.Stbn','torsion','com.actelion.research.chem.forcefield.mmff.table.Torsion','vdws','com.actelion.research.chem.forcefield.mmff.table.VanDerWaals']]]

Clazz.newMeth(C$, 'c$$S$S$S$S$S$S$S$S$S$S$S$S$S$S',  function (csv_angle, csv_atom, csv_bci, csv_bndk, csv_bond, csv_covrad, csv_dfsb, csv_def, csv_hblaurie, csv_oop, csv_pbci, csv_stbn, csv_torsion, csv_vdws) {
;C$.$init$.apply(this);
this.angle=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_angle]);
this.chge=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S$S,[this, csv_pbci, csv_bci]);
this.atom=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_atom]);
this.bndk=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_bndk]);
this.bond=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_bond]);
this.covrad=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_covrad]);
this.dfsb=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_dfsb]);
this.def=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_def]);
this.hblaurie=Clazz.new_($I$(9,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_hblaurie]);
this.oop=Clazz.new_($I$(10,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_oop]);
this.stbn=Clazz.new_($I$(11,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_stbn]);
this.torsion=Clazz.new_($I$(12,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_torsion]);
this.vdws=Clazz.new_($I$(13,1).c$$com_actelion_research_chem_forcefield_mmff_Tables$S,[this, csv_vdws]);
}, 1);

Clazz.newMeth(C$, 'newMMFF94$S',  function (tableSet) {
return Clazz.new_(C$.c$$S$S$S$S$S$S$S$S$S$S$S$S$S$S,["/resources/forcefield/mmff94/angle.csv", "/resources/forcefield/mmff94/atom.csv", "/resources/forcefield/mmff94/bci.csv", "/resources/forcefield/mmff94/bndk.csv", "/resources/forcefield/mmff94/bond.csv", "/resources/forcefield/mmff94/covrad.csv", "/resources/forcefield/mmff94/dfsb.csv", "/resources/forcefield/mmff94/def.csv", "/resources/forcefield/mmff94/herschbachlaurie.csv", "/resources/forcefield/mmff94/" + (tableSet.equals$O("MMFF94s") || tableSet.equals$O("MMFF94s+")  ? "94s/outofplane.csv" : "outofplane.csv"), "/resources/forcefield/mmff94/pbci.csv", "/resources/forcefield/mmff94/stbn.csv", "/resources/forcefield/mmff94/" + (tableSet.equals$O("MMFF94s") ? "94s/torsion.csv" : tableSet.equals$O("MMFF94s+") ? "94s/torsionPlus.csv" : "torsion.csv"), "/resources/forcefield/mmff94/vanderwaals.csv"]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
