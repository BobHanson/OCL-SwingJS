(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.StereoMolecule','java.util.Arrays','com.actelion.research.chem.Canonizer','com.actelion.research.util.BurtleHasher','com.actelion.research.chem.SSSearcherWithIndex']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerLongCFP", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerLongFP');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerLongCFP']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) {
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_HashedCFp;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(1).DESCRIPTOR_HashedCFp.version;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
if (mol == null ) return null;
mol.ensureHelperArrays$I(7);
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(2,1).c$$I$I);
var len=16;
var data=Clazz.array(Long.TYPE, [16]);
var atomList=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var rootAtom=0; rootAtom < mol.getAtoms$(); rootAtom++) {
if (rootAtom != 0) $I$(3).fill$ZA$Z(atomMask, false);
var min=0;
var max=0;
for (var sphere=0; sphere < 5 && max < mol.getAtoms$() ; sphere++) {
if (max == 0) {
atomList[0]=rootAtom;
atomMask[rootAtom]=true;
max=1;
} else {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < mol.getConnAtoms$I(atom); j++) {
var connAtom=mol.getConnAtom$I$I(atom, j);
if (!atomMask[connAtom]) {
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
}}
}
min=max;
max=newMax;
}mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, atomMask, true, null);
var idcode=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$();
var h=$I$(5).hashlittle$S$J(idcode, 13);
h=(h & $I$(5).hashmask$I(10));
var index=16 - (h/64|0) - 1;
var bitNo=h % 32;
if (h % 64 >= 32) bitNo+=32;
(data[$k$=index]=Long.$or(data[$k$],((Long.$sl(1,bitNo)))));
}
}
return data;
});

Clazz.newMeth(C$, ['getSimilarity$JA$JA','getSimilarity$O$O'],  function (o1, o2) {
return o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0  ? 0.0 : p$1.normalizeValue$D.apply(this, [$I$(6).getSimilarityTanimoto$JA$JA(o1, o2)]);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.6), 1.6666666666666667));
}, p$1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});
var $k$;

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
