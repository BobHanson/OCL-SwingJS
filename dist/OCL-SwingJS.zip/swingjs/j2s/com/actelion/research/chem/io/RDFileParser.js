(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.io.BufferedReader','java.io.InputStreamReader','java.io.FileInputStream','java.nio.charset.StandardCharsets','com.actelion.research.io.BOMSkipper','java.util.TreeMap','com.actelion.research.chem.reaction.Reaction','com.actelion.research.chem.io.RXNFileParser','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.MolfileParser','com.actelion.research.chem.UniqueStringList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RDFileParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mNoOfRecords'],'S',['mLine','mIRegNo','mERegNo'],'O',['mReader','java.io.BufferedReader','mFieldName','String[]','+mFieldData','mDataMap','java.util.TreeMap']]]

Clazz.newMeth(C$, 'c$$S',  function (fileName) {
;C$.$init$.apply(this);
this.mNoOfRecords=0;
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$S,[fileName]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
p$1.readHeader.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_File',  function (file) {
;C$.$init$.apply(this);
this.mNoOfRecords=0;
try {
this.mReader=Clazz.new_([Clazz.new_([Clazz.new_($I$(3,1).c$$java_io_File,[file]), $I$(4).UTF_8],$I$(2,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(1,1).c$$java_io_Reader);
$I$(5).skip$java_io_Reader(this.mReader);
p$1.readHeader.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.mReader=null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$java_io_Reader',  function (reader) {
;C$.$init$.apply(this);
this.mNoOfRecords=0;
this.mReader=(Clazz.instanceOf(reader, "java.io.BufferedReader")) ? reader : Clazz.new_($I$(1,1).c$$java_io_Reader,[reader]);
try {
p$1.readHeader.apply(this, []);
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
}, 1);

Clazz.newMeth(C$, 'readHeader',  function () {
if (!"$RDFILE 1".equals$O(this.mReader.readLine$()) || this.mReader.readLine$() == null   || (this.mLine=this.mReader.readLine$()) == null  ) {
this.mReader.close$();
this.mReader=null;
return;
}this.mDataMap=Clazz.new_($I$(6,1));
}, p$1);

Clazz.newMeth(C$, 'hasNext$',  function () {
return this.mReader != null ;
});

Clazz.newMeth(C$, 'getRowCount$',  function () {
return this.mNoOfRecords;
});

Clazz.newMeth(C$, 'getFieldData$',  function () {
return this.mDataMap;
});

Clazz.newMeth(C$, 'getFieldData$S',  function (key) {
return this.mDataMap.get$O(key);
});

Clazz.newMeth(C$, 'getERegNo$',  function () {
return this.mERegNo;
});

Clazz.newMeth(C$, 'getIRegNo$',  function () {
return this.mIRegNo;
});

Clazz.newMeth(C$, 'getNextReaction$',  function () {
if (this.mReader == null ) return null;
this.mIRegNo=null;
this.mERegNo=null;
var rxn=null;
this.mDataMap.clear$();
var key=null;
while (this.mLine != null ){
if (this.mLine.startsWith$S("$REREG ")) {
this.mERegNo=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$RIREG ")) {
this.mIRegNo=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$RFMT")) {
rxn=Clazz.new_($I$(7,1));
try {
if (!Clazz.new_($I$(8,1)).parse$com_actelion_research_chem_reaction_Reaction$java_io_BufferedReader(rxn, this.mReader)) {
this.mReader=null;
return null;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.mReader=null;
return null;
} else {
throw e;
}
}
} else if (this.mLine.startsWith$S("$DTYPE ")) {
key=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$DATUM ")) {
if (key != null ) {
var value=this.mLine.substring$I(7).trim$();
if (value.length$() != 0) this.mDataMap.put$O$O(key, value);
key=null;
}}try {
this.mLine=this.mReader.readLine$();
if (this.mLine == null ) {
this.mReader.close$();
this.mReader=null;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return null;
} else {
throw e;
}
}
if (this.isReactionNext$()) break;
}
++this.mNoOfRecords;
return rxn;
});

Clazz.newMeth(C$, 'isMoleculeNext$',  function () {
return this.mLine != null  && (this.mLine.startsWith$S("$MFMT") || this.mLine.startsWith$S("$MEGEG") || this.mLine.startsWith$S("$MIREG")  ) ;
});

Clazz.newMeth(C$, 'isReactionNext$',  function () {
return this.mLine != null  && (this.mLine.startsWith$S("$RFMT") || this.mLine.startsWith$S("$REGEG") || this.mLine.startsWith$S("$RIREG")  ) ;
});

Clazz.newMeth(C$, 'getNextMolecule$',  function () {
if (this.mReader == null ) return null;
this.mIRegNo=null;
this.mERegNo=null;
var mol=null;
this.mDataMap.clear$();
var key=null;
while (this.mLine != null ){
if (this.mLine.startsWith$S("$MEREG ")) {
this.mERegNo=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$MIREG ")) {
this.mIRegNo=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$MFMT")) {
this.mIRegNo=this.mLine.substring$I(7).trim$();
mol=Clazz.new_($I$(9,1));
try {
if (!Clazz.new_($I$(10,1)).parse$com_actelion_research_chem_StereoMolecule$java_io_BufferedReader(mol, this.mReader)) {
this.mReader=null;
return null;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.mReader=null;
return null;
} else {
throw e;
}
}
} else if (this.mLine.startsWith$S("$DTYPE ")) {
key=this.mLine.substring$I(7).trim$();
} else if (this.mLine.startsWith$S("$DATUM ")) {
if (key != null ) {
var value=this.mLine.substring$I(7).trim$();
if (value.length$() != 0) this.mDataMap.put$O$O(key, value);
key=null;
}}try {
this.mLine=this.mReader.readLine$();
if (this.mLine == null ) {
this.mReader.close$();
this.mReader=null;
}} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
return null;
} else {
throw e;
}
}
if (this.isMoleculeNext$()) break;
}
++this.mNoOfRecords;
return mol;
});

Clazz.newMeth(C$, 'getFieldNames$',  function () {
if (this.mFieldName == null ) p$1.extractAllFieldNames$I.apply(this, [1024]);
return this.mFieldName;
});

Clazz.newMeth(C$, 'extractAllFieldNames$I',  function (recordsToInspect) {
var records=0;
var fieldNameList=Clazz.new_($I$(11,1));
while (records < recordsToInspect){
var chem=this.isReactionNext$() ? this.getNextReaction$() : this.getNextMolecule$();
if (chem == null ) break;
for (var key, $key = this.mDataMap.keySet$().iterator$(); $key.hasNext$()&&((key=($key.next$())),1);) fieldNameList.addString$S(key);

++records;
}
this.mFieldName=fieldNameList.toArray$();
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
