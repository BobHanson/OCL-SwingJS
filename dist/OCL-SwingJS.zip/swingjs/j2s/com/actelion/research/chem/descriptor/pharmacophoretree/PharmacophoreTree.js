(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','java.util.HashSet','java.util.LinkedList','java.util.Arrays','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmacophoreTree", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['BiGramInt',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['linkerNodes'],'O',['edges','java.util.List','+nodes','adjacencyList','java.util.Map']]]

Clazz.newMeth(C$, 'c$$java_util_List$java_util_List',  function (nodes, edges) {
;C$.$init$.apply(this);
this.nodes=nodes;
this.edges=edges;
this.linkerNodes=0;
p$1.update.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'update',  function () {
this.linkerNodes=0;
for (var node, $node = this.nodes.iterator$(); $node.hasNext$()&&((node=($node.next$())),1);) {
if (node.isLinkNode$()) ++this.linkerNodes;
}
this.adjacencyList=Clazz.new_($I$(1,1));
for (var i=0; i < this.nodes.size$(); i++) {
this.adjacencyList.putIfAbsent$O$O(Integer.valueOf$I(i), Clazz.new_($I$(2,1)));
for (var j=0; j < this.edges.size$(); j++) {
var edge=this.edges.get$I(j);
if (edge[0] == i || edge[1] == i ) this.adjacencyList.get$O(Integer.valueOf$I(i)).add$O(Integer.valueOf$I(j));
}
}
}, p$1);

Clazz.newMeth(C$, 'initialCut$I$I$java_util_List$java_util_List$java_util_List$java_util_List',  function (cut, edge, sourceTreeEdges, sourceTreeEdgeParents, targetTreeEdges, targetTreeEdgeParents) {
var sourceNode=-1;
var targetNode=-1;
if (cut == -1) {
sourceNode=this.edges.get$I(edge)[0];
targetNode=this.edges.get$I(edge)[1];
} else if (cut == 1) {
sourceNode=this.edges.get$I(edge)[1];
targetNode=this.edges.get$I(edge)[0];
} else {
throw Clazz.new_(Clazz.load('IllegalArgumentException'));
}this.treeWalkBFS$I$I$java_util_List$java_util_List(sourceNode, edge, sourceTreeEdges, sourceTreeEdgeParents);
this.treeWalkBFS$I$I$java_util_List$java_util_List(targetNode, edge, targetTreeEdges, targetTreeEdgeParents);
return Clazz.array(Integer.TYPE, -1, [sourceNode, targetNode]);
});

Clazz.newMeth(C$, 'treeWalkBFS$I$I$java_util_List$java_util_List',  function (headNode, deletedEdgeIndex, treeEdgesBFS, edgeParentsBFS) {
var visitedNodes=Clazz.new_($I$(3,1));
var visitedEdges=Clazz.new_($I$(3,1));
var pqNodes=Clazz.new_($I$(4,1));
var parentEdges=Clazz.new_($I$(1,1));
pqNodes.add$O(Integer.valueOf$I(headNode));
parentEdges.put$O$O(Integer.valueOf$I(headNode), Integer.valueOf$I(deletedEdgeIndex));
visitedEdges.add$O(Integer.valueOf$I(deletedEdgeIndex));
treeEdgesBFS.add$O(Integer.valueOf$I(deletedEdgeIndex));
edgeParentsBFS.add$O(Integer.valueOf$I(-1));
while (!pqNodes.isEmpty$()){
var node=(pqNodes.poll$()).$c();
visitedNodes.add$O(Integer.valueOf$I(node));
var parentEdge=(parentEdges.get$O(Integer.valueOf$I(node))).$c();
for (var edgeNo, $edgeNo = this.adjacencyList.get$O(Integer.valueOf$I(node)).iterator$(); $edgeNo.hasNext$()&&((edgeNo=($edgeNo.next$()).intValue$()),1);) {
var edge=this.edges.get$I(edgeNo);
if (visitedEdges.contains$O(Integer.valueOf$I(edgeNo))) continue;
visitedEdges.add$O(Integer.valueOf$I(edgeNo));
var nextNode=-1;
if (edge[0] == node) nextNode=edge[1];
 else if (edge[1] == node) nextNode=edge[0];
pqNodes.add$O(Integer.valueOf$I(nextNode));
parentEdges.put$O$O(Integer.valueOf$I(nextNode), Integer.valueOf$I(edgeNo));
treeEdgesBFS.add$O(Integer.valueOf$I(edgeNo));
edgeParentsBFS.add$O(Integer.valueOf$I(parentEdge));
}
}
});

Clazz.newMeth(C$, 'enumerateExtensionCutFast$I$IA$java_util_List$java_util_Set$java_util_Set',  function (head, cut, subTreeEdgeIndeces, extensionNodes, sourceNodes) {
for (var i=0; i < cut.length; i++) {
var edge=this.edges.get$I((subTreeEdgeIndeces.get$I(i)).$c());
if (cut[i] == 0) {
extensionNodes.add$O(Integer.valueOf$I(edge[0]));
extensionNodes.add$O(Integer.valueOf$I(edge[1]));
} else if (cut[i] == 1) {
if (extensionNodes.contains$O(Integer.valueOf$I(edge[0]))) sourceNodes.add$O(Integer.valueOf$I(edge[1]));
 else sourceNodes.add$O(Integer.valueOf$I(edge[0]));
} else if (cut[i] == -1) {
sourceNodes.add$O(Integer.valueOf$I(edge[0]));
sourceNodes.add$O(Integer.valueOf$I(edge[1]));
}}
});

Clazz.newMeth(C$, 'enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List',  function (head, cut, subTreeEdgeIndeces, subTreeParentEdgeIndeces, sourceTreeEdgeIndeces, sourceTreeEdgeParentIndeces, sourceTreeHeadNodes, extensionNodes, cutEdges, cutDirections) {
extensionNodes.add$O(Integer.valueOf$I(head));
for (var i=1; i < cut.length; i++) {
var edgeIndex=(subTreeEdgeIndeces.get$I(i)).$c();
var edge=this.edges.get$I(edgeIndex);
if (cut[i] == 0) {
extensionNodes.add$O(Integer.valueOf$I(edge[0]));
extensionNodes.add$O(Integer.valueOf$I(edge[1]));
} else if (cut[i] == 1) {
cutEdges.add$O(Integer.valueOf$I(edgeIndex));
if (extensionNodes.contains$O(Integer.valueOf$I(edge[0]))) {
sourceTreeHeadNodes.add$O(Integer.valueOf$I(edge[1]));
cutDirections.add$O(Integer.valueOf$I(1));
} else {
sourceTreeHeadNodes.add$O(Integer.valueOf$I(edge[0]));
cutDirections.add$O(Integer.valueOf$I(-1));
}var edgeIndeces=Clazz.new_($I$(2,1));
edgeIndeces.add$O(Integer.valueOf$I(edgeIndex));
sourceTreeEdgeIndeces.add$O(edgeIndeces);
var parentEdgeIndeces=Clazz.new_($I$(2,1));
parentEdgeIndeces.add$O(Integer.valueOf$I(-1));
sourceTreeEdgeParentIndeces.add$O(parentEdgeIndeces);
} else if (cut[i] == -1) {
var parentEdgeIndex=(subTreeParentEdgeIndeces.get$I(i)).$c();
var subTreeIndex=cutEdges.indexOf$O(Integer.valueOf$I(parentEdgeIndex));
if (subTreeIndex < 0) {
for (var j=0; j < sourceTreeEdgeIndeces.size$(); j++) {
if (sourceTreeEdgeIndeces.get$I(j).contains$O(Integer.valueOf$I(parentEdgeIndex))) {
subTreeIndex=j;
break;
}}
}sourceTreeEdgeIndeces.get$I(subTreeIndex).add$O(Integer.valueOf$I(edgeIndex));
sourceTreeEdgeParentIndeces.get$I(subTreeIndex).add$O(Integer.valueOf$I(parentEdgeIndex));
}}
});

Clazz.newMeth(C$, 'getExtensionCuts$java_util_List$java_util_List',  function (subtreeEdgeIndeces, subtreeEdgeParentIndeces) {
var cuts=Clazz.new_($I$(2,1));
var lowerBound=0;
var previousCut=Clazz.array(Integer.TYPE, [subtreeEdgeIndeces.size$()]);
$I$(5).fill$IA$I(previousCut, -1);
previousCut[0]=1;
while (lowerBound >= 0){
if (cuts.size$() > 500) return cuts;
var nextCut=previousCut.clone$();
lowerBound=p$1.getNextCut$IA$IA$java_util_List$java_util_List.apply(this, [previousCut, nextCut, subtreeEdgeIndeces, subtreeEdgeParentIndeces]);
previousCut=nextCut;
var alreadyPresent=false;
for (var i=0; i < cuts.size$(); i++) {
if ($I$(5,"equals$IA$IA",[previousCut, cuts.get$I(i)])) alreadyPresent=true;
}
if (!alreadyPresent) cuts.add$O(previousCut);
}
return cuts;
});

Clazz.newMeth(C$, 'getNodesFromEdges$java_util_List',  function (edgeIndeces) {
var nodes=Clazz.new_($I$(3,1));
for (var i=1; i < edgeIndeces.size$(); i++) {
var edgeIndex=(edgeIndeces.get$I(i)).$c();
var edge=this.edges.get$I(edgeIndex);
nodes.add$O(Integer.valueOf$I(edge[0]));
nodes.add$O(Integer.valueOf$I(edge[1]));
}
return nodes;
});

Clazz.newMeth(C$, 'getNextCut$IA$IA$java_util_List$java_util_List',  function (previousCut, nextCut, subtreeEdgeIndeces, subtreeEdgeParentIndeces) {
var lowerBound=-1;
var head=2147483647;
var tail=-2147483648;
for (var i=0; i < previousCut.length; i++) {
if (previousCut[i] == 1) {
if (i < head) head=i;
if (i > tail) tail=i;
}}
if (head < 2147483647 && tail > -2147483648 ) {
var childNodes=Clazz.new_($I$(3,1));
for (var i=0; i < head; i++) {
childNodes.add$O(Integer.valueOf$I(this.edges.get$I((subtreeEdgeIndeces.get$I(i)).$c())[0]));
childNodes.add$O(Integer.valueOf$I(this.edges.get$I((subtreeEdgeIndeces.get$I(i)).$c())[1]));
}
lowerBound=childNodes.size$();
if (lowerBound > 2) lowerBound=-1;
 else {
nextCut[tail]=0;
for (var i=tail + 1; i < nextCut.length; i++) {
var parent=(subtreeEdgeParentIndeces.get$I(i)).$c();
var parentIndexInCutArray=subtreeEdgeIndeces.indexOf$O(Integer.valueOf$I(parent));
if (parentIndexInCutArray == tail) nextCut[i]=1;
 else if (nextCut[parentIndexInCutArray] == 0) nextCut[i]=1;
 else nextCut[i]=-1;
}
}}return lowerBound;
}, p$1);

Clazz.newMeth(C$, 'getNodes$java_util_Collection',  function (indeces) {
var nodeList=Clazz.new_($I$(2,1));
for (var i, $i = indeces.iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
nodeList.add$O(this.nodes.get$I(i));
}
return nodeList;
});

Clazz.newMeth(C$, 'getNodes$',  function () {
return this.nodes;
});

Clazz.newMeth(C$, 'getEdges$',  function () {
return this.edges;
});

Clazz.newMeth(C$, 'getLinkNodes$',  function () {
return this.linkerNodes;
});

Clazz.newMeth(C$, 'removeNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode',  function (node) {
var nodeIndex=this.nodes.indexOf$O(node);
var edgesToBeDeleted=Clazz.new_($I$(2,1));
for (var e=this.edges.size$() - 1; e >= 0; e--) {
if (this.edges.get$I(e)[0] == nodeIndex || this.edges.get$I(e)[1] == nodeIndex ) edgesToBeDeleted.add$O(Integer.valueOf$I(e));
}
this.nodes.remove$I(nodeIndex);
for (var e=0; e < this.edges.size$(); e++) {
var edge=this.edges.get$I(e);
if (edge[0] > nodeIndex) edge[0]+=-1;
if (edge[1] > nodeIndex) edge[1]+=-1;
}
for (var edgeToDelete, $edgeToDelete = edgesToBeDeleted.iterator$(); $edgeToDelete.hasNext$()&&((edgeToDelete=($edgeToDelete.next$()).intValue$()),1);) {
this.edges.remove$I(edgeToDelete);
}
p$1.update.apply(this, []);
});

Clazz.newMeth(C$, 'getSize$',  function () {
var size=this.nodes.stream$().mapToDouble$java_util_function_ToDoubleFunction(((P$.PharmacophoreTree$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTree$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode','applyAsDouble$O'],  function (i) { return (i.getSize$.apply(i, []));});
})()
), Clazz.new_(P$.PharmacophoreTree$lambda1.$init$,[this, null]))).reduce$java_util_function_DoubleBinaryOperator((P$.PharmacophoreTree$lambda2$||(P$.PharmacophoreTree$lambda2$=(((P$.PharmacophoreTree$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTree$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.DoubleBinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$D$D','applyAsDouble$O$O'],  function (a, b) { return (a + b);});
})()
), Clazz.new_(P$.PharmacophoreTree$lambda2.$init$,[this, null])))))).getAsDouble$();
return size;
});

Clazz.newMeth(C$, 'getSubTreeSize$java_util_List$I',  function (edges, headNode) {
var indeces=this.getNodesFromEdges$java_util_List(edges);
var n=this.getNodes$java_util_Collection(indeces);
n.add$O(this.nodes.get$I(headNode));
var size=n.stream$().mapToDouble$java_util_function_ToDoubleFunction(((P$.PharmacophoreTree$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTree$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToDoubleFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode','applyAsDouble$O'],  function (i) { return (i.getSize$.apply(i, []));});
})()
), Clazz.new_(P$.PharmacophoreTree$lambda3.$init$,[this, null]))).reduce$java_util_function_DoubleBinaryOperator((P$.PharmacophoreTree$lambda4$||(P$.PharmacophoreTree$lambda4$=(((P$.PharmacophoreTree$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTree$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.DoubleBinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsDouble$D$D','applyAsDouble$O$O'],  function (a, b) { return (a + b);});
})()
), Clazz.new_(P$.PharmacophoreTree$lambda4.$init$,[this, null])))))).getAsDouble$();
return size;
});

Clazz.newMeth(C$, 'getDirectSim$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree',  function (pTree2) {
return $I$(6,"getSimilarity$java_util_Collection$java_util_Collection",[this.nodes, pTree2.getNodes$()]);
});

Clazz.newMeth(C$, 'getAllSubtrees$',  function () {
var allSubTrees=Clazz.new_($I$(3,1));
for (var e=0; e < this.edges.size$(); e++) {
for (var i=0; i < 2; i++) {
var edge=this.edges.get$I(e);
var treeEdgeIndeces=Clazz.new_($I$(2,1));
var treeEdgeParentIndeces=Clazz.new_($I$(2,1));
this.treeWalkBFS$I$I$java_util_List$java_util_List(edge[i], e, treeEdgeIndeces, treeEdgeParentIndeces);
var cuts=this.getExtensionCuts$java_util_List$java_util_List(treeEdgeIndeces, treeEdgeParentIndeces);
for (var cut, $cut = cuts.iterator$(); $cut.hasNext$()&&((cut=($cut.next$())),1);) {
var sourceTreeEdgeIndeces=Clazz.new_($I$(2,1));
var sourceTreeEdgeParentIndeces=Clazz.new_($I$(2,1));
var sourceTreeHeadNodes=Clazz.new_($I$(2,1));
var extensionNodes=Clazz.new_($I$(3,1));
var cutEdges=Clazz.new_($I$(2,1));
var cutDirs=Clazz.new_($I$(2,1));
this.enumerateExtensionCutFull$I$IA$java_util_List$java_util_List$java_util_List$java_util_List$java_util_List$java_util_Set$java_util_List$java_util_List(edge[i], cut, treeEdgeIndeces, treeEdgeParentIndeces, sourceTreeEdgeIndeces, sourceTreeEdgeParentIndeces, sourceTreeHeadNodes, extensionNodes, cutEdges, cutDirs);
allSubTrees.add$O(extensionNodes);
}
}
}
return Clazz.new_($I$(2,1).c$$java_util_Collection,[allSubTrees]);
});

Clazz.newMeth(C$, 'getPathsFromHeadNode$I$java_util_List$java_util_Set',  function (headNode, paths, visitedEdges) {
var lastPath=paths.get$I(paths.size$() - 1);
var nextPath=Clazz.new_($I$(3,1).c$$java_util_Collection,[lastPath]);
nextPath.add$O(Integer.valueOf$I(headNode));
paths.add$O(nextPath);
var adjacentEdges=this.adjacencyList.get$O(Integer.valueOf$I(headNode));
for (var edge, $edge = adjacentEdges.iterator$(); $edge.hasNext$()&&((edge=($edge.next$())),1);) {
if (visitedEdges.contains$O(edge)) continue;
 else {
var e=this.edges.get$I((edge).$c());
var u=e[0];
var v=e[1];
if (u == headNode) this.getPathsFromHeadNode$I$java_util_List$java_util_Set(v, paths, visitedEdges);
 else this.getPathsFromHeadNode$I$java_util_List$java_util_Set(u, paths, visitedEdges);
}}
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.PharmacophoreTree, "BiGramInt", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['order','u','v'],'O',['edge','int[]']]]

Clazz.newMeth(C$, 'c$$IA',  function (edge) {
C$.c$$IA$I.apply(this, [edge, 1]);
}, 1);

Clazz.newMeth(C$, 'c$$IA$I',  function (edge, order) {
;C$.$init$.apply(this);
this.edge=edge;
this.order=order;
if (edge[0] < edge[1]) {
this.u=edge[0];
this.v=edge[1];
} else {
this.u=edge[1];
this.v=edge[0];
}}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (i, j) {
C$.c$$IA$I.apply(this, [Clazz.array(Integer.TYPE, -1, [i, j]), 1]);
}, 1);

Clazz.newMeth(C$, 'equals$O',  function (obj) {
if (obj == null ) return false;
if (!(Clazz.instanceOf(obj, "com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree.BiGramInt"))) return false;
if (obj === this ) return true;
return ((this.u == (obj).u) && (this.v == (obj).v) );
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return this.u * 31 + this.v;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
