(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.moreparsers.CDXParser','com.actelion.research.chem.MolfileParser','com.actelion.research.chem.io.Mol2FileParser','com.actelion.research.chem.io.SDFileParser','com.actelion.research.chem.io.DWARFileParser','com.actelion.research.chem.io.ODEFileParser','com.actelion.research.chem.Canonizer','com.actelion.research.chem.io.CompoundFileFilter','java.io.File','java.io.BufferedWriter','java.io.OutputStreamWriter','java.io.FileOutputStream','java.nio.charset.StandardCharsets','com.actelion.research.chem.io.RXNFileCreator']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CompoundFileHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mRecordCount','mErrorCount']]
,['O',['sCurrentDirectory','java.io.File']]]

Clazz.newMeth(C$, 'getCurrentDirectory$',  function () {
return C$.sCurrentDirectory;
}, 1);

Clazz.newMeth(C$, 'setCurrentDirectory$java_io_File',  function (d) {
C$.sCurrentDirectory=d;
}, 1);

Clazz.newMeth(C$, 'readStructuresFromFile$Z',  function (readIdentifier) {
var file=this.selectFileToOpen$S$I("Please select a compound file", 787201);
return (file == null  ? null : this.readStructuresFromFile$java_io_File$Z(file, readIdentifier));
});

Clazz.newMeth(C$, 'readStructuresFromFileAsync$Z$java_util_function_Consumer',  function (readIdentifier, whenDone) {
this.selectFileToOpenAsync$S$I$java_util_function_Consumer("Please select a compound file", 787201, ((P$.CompoundFileHelper$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "CompoundFileHelper$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_io_File','accept$O'],  function (file) {
if (file == null ) this.$finals$.whenDone.accept$O(null);
 else if (this.$finals$.readIdentifier) this.b$['com.actelion.research.chem.io.CompoundFileHelper'].readStructuresFromFileAsync$java_io_File$Z$java_util_function_Consumer.apply(this.b$['com.actelion.research.chem.io.CompoundFileHelper'], [file, true, this.$finals$.whenDone]);
 else this.$finals$.whenDone.accept$O(this.b$['com.actelion.research.chem.io.CompoundFileHelper'].readStructuresFromFile$java_io_File$Z.apply(this.b$['com.actelion.research.chem.io.CompoundFileHelper'], [file, false]));
});
})()
), Clazz.new_(P$.CompoundFileHelper$lambda1.$init$,[this, {whenDone:whenDone,readIdentifier:readIdentifier}])));
});

Clazz.newMeth(C$, 'readStructuresFromFile$java_io_File$Z',  function (file, readIdentifier) {
if (file == null ) return this.readStructuresFromFile$Z(readIdentifier);
var moleculeList=Clazz.new_($I$(1,1));
p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, moleculeList, null, null, readIdentifier, false, null]);
return moleculeList;
});

Clazz.newMeth(C$, 'readStructuresFromFileAsync$java_io_File$Z$java_util_function_Consumer',  function (file, readIdentifier, whenDone) {
if (file == null ) {
this.readStructuresFromFileAsync$Z$java_util_function_Consumer(readIdentifier, whenDone);
} else {
p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, Clazz.new_($I$(1,1)), null, null, readIdentifier, false, whenDone]);
}});

Clazz.newMeth(C$, 'readIDCodesFromFile$',  function () {
var file=this.selectFileToOpen$S$I("Please select a compound file", 787201);
return (file == null  ? null : this.readIDCodesFromFile$java_io_File(file));
});

Clazz.newMeth(C$, 'readIDCodesFromFileAsync$java_util_function_Consumer',  function (whenDone) {
this.selectFileToOpenAsync$S$I$java_util_function_Consumer("Please select a compound file", 787201, ((P$.CompoundFileHelper$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "CompoundFileHelper$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_io_File','accept$O'],  function (file) {
if (file == null ) this.$finals$.whenDone.accept$O(null);
 else this.b$['com.actelion.research.chem.io.CompoundFileHelper'].readIDCodesFromFileAsync$java_io_File$java_util_function_Consumer.apply(this.b$['com.actelion.research.chem.io.CompoundFileHelper'], [file, this.$finals$.whenDone]);
});
})()
), Clazz.new_(P$.CompoundFileHelper$lambda2.$init$,[this, {whenDone:whenDone}])));
});

Clazz.newMeth(C$, 'readIDCodesFromFile$java_io_File',  function (file) {
if (file == null ) return this.readIDCodesFromFile$();
var idcodeList=Clazz.new_($I$(1,1));
p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, null, idcodeList, null, false, false, null]);
return idcodeList;
});

Clazz.newMeth(C$, 'readIDCodesFromFileAsync$java_io_File$java_util_function_Consumer',  function (file, whenDone) {
if (file == null ) {
this.readIDCodesFromFileAsync$java_util_function_Consumer(whenDone);
return;
}p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, null, Clazz.new_($I$(1,1)), null, false, false, whenDone]);
});

Clazz.newMeth(C$, 'readIDCodesWithNamesFromFile$Z',  function (readIDCoords) {
var file=this.selectFileToOpen$S$I("Please select substance file", 262913);
return (file == null  ? null : this.readIDCodesWithNamesFromFile$java_io_File$Z(file, readIDCoords));
});

Clazz.newMeth(C$, 'readIDCodesWithNamesFromFileAsync$Z$java_util_function_Consumer',  function (readIDCoords, whenDone) {
this.selectFileToOpenAsync$S$I$java_util_function_Consumer("Please select substance file", 262913, ((P$.CompoundFileHelper$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "CompoundFileHelper$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_io_File','accept$O'],  function (file) {
if (file == null ) {
this.$finals$.whenDone.accept$O(null);
return;
}this.b$['com.actelion.research.chem.io.CompoundFileHelper'].readIDCodesWithNamesFromFileAsync$java_io_File$Z$java_util_function_Consumer.apply(this.b$['com.actelion.research.chem.io.CompoundFileHelper'], [file, this.$finals$.readIDCoords, this.$finals$.whenDone]);
});
})()
), Clazz.new_(P$.CompoundFileHelper$lambda3.$init$,[this, {whenDone:whenDone,readIDCoords:readIDCoords}])));
});

Clazz.newMeth(C$, 'readIDCodesWithNamesFromFile$java_io_File$Z',  function (file, readIDCoords) {
if (file == null ) return this.readIDCodesWithNamesFromFile$Z(readIDCoords);
var idcodeWithIDList=Clazz.new_($I$(1,1));
p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, null, null, idcodeWithIDList, false, readIDCoords, null]);
return idcodeWithIDList;
});

Clazz.newMeth(C$, 'readIDCodesWithNamesFromFileAsync$java_io_File$Z$java_util_function_Consumer',  function (file, readIDCoords, whenDone) {
if (file == null ) {
this.readIDCodesWithNamesFromFileAsync$Z$java_util_function_Consumer(readIDCoords, whenDone);
return;
}p$1.readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer.apply(this, [file, null, null, Clazz.new_($I$(1,1)), false, readIDCoords, whenDone]);
});

Clazz.newMeth(C$, 'readChemObjectsFromFileAsync$java_io_File$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$Z$Z$java_util_function_Consumer',  function (file, moleculeList, idcodeList, idcodeWithIDList, readIdentifier, readIDCoords, whenDone) {
this.mRecordCount=0;
this.mErrorCount=0;
var filename=file.getName$();
var index=filename.lastIndexOf$I(".");
var extension=(index == -1) ? "" : filename.substring$I(index).toLowerCase$();
var parser=null;
var mol=null;
switch (extension) {
case ".cdx":
case ".cdxml":
mol=$I$(2,"parseFile$S",[file.getAbsolutePath$()]);
break;
case ".mol":
case ".mol2":
if (extension.equals$O(".mol")) {
mol=Clazz.new_($I$(3,1)).getCompactMolecule$java_io_File(file);
} else {
try {
mol=Clazz.new_($I$(4,1)).load$S(filename);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}break;
case ".sdf":
parser=Clazz.new_($I$(5,1).c$$java_io_File,[file]);
break;
case ".dwar":
parser=Clazz.new_($I$(6,1).c$$java_io_File,[file]);
break;
case ".ode":
parser=Clazz.new_($I$(7,1).c$$java_io_File,[file]);
break;
default:
parser=null;
break;
}
if (mol != null  && mol.getAllAtoms$() > 0 ) {
if (moleculeList != null ) {
moleculeList.add$O(mol);
if (whenDone != null ) whenDone.accept$O(moleculeList);
return;
}var canonizer=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var idcode=canonizer.getIDCode$();
var coords=canonizer.getEncodedCoordinates$();
if (idcode != null  && coords.length$() != 0  && readIDCoords ) idcode=idcode + " " + coords ;
if (idcodeList != null ) {
idcodeList.add$O(idcode);
if (whenDone != null ) {
whenDone.accept$O(idcodeList);
}return;
}var idcodeWithID=Clazz.array(String, [2]);
idcodeWithID[0]=idcode;
idcodeWithID[1]=mol.getName$();
idcodeWithIDList.add$O(idcodeWithID);
if (whenDone != null ) {
whenDone.accept$O(idcodeWithIDList);
}return;
}if (parser == null ) {
if (whenDone != null ) whenDone.accept$O(null);
return;
}if (idcodeWithIDList == null  && !readIdentifier ) {
p$1.parseChemObjects$com_actelion_research_chem_io_CompoundFileParser$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$I$Z.apply(this, [parser, moleculeList, idcodeList, idcodeWithIDList, -1, readIDCoords]);
return;
}var fieldNames=parser.getFieldNames$();
var p=parser;
var c=((P$.CompoundFileHelper$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "CompoundFileHelper$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer','accept$O'],  function (indexOfID) {
p$1.parseChemObjects$com_actelion_research_chem_io_CompoundFileParser$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$I$Z.apply(this.b$['com.actelion.research.chem.io.CompoundFileHelper'], [Clazz.instanceOf(this.$finals$.p, "com.actelion.research.chem.io.SDFileParser") ? Clazz.new_($I$(5,1).c$$java_io_File$SA,[this.$finals$.file, this.$finals$.fieldNames]) : this.$finals$.p, this.$finals$.moleculeList, this.$finals$.idcodeList, this.$finals$.idcodeWithIDList, indexOfID.intValue$.apply(indexOfID, []), this.$finals$.readIDCoords]);
if (this.$finals$.whenDone != null ) this.$finals$.whenDone.accept$O(this.$finals$.moleculeList != null  ? this.$finals$.moleculeList : this.$finals$.idcodeList != null  ? this.$finals$.idcodeList : this.$finals$.idcodeWithIDList);
});
})()
), Clazz.new_(P$.CompoundFileHelper$lambda4.$init$,[this, {idcodeWithIDList:idcodeWithIDList,p:p,fieldNames:fieldNames,moleculeList:moleculeList,idcodeList:idcodeList,readIDCoords:readIDCoords,file:file,whenDone:whenDone}]));
if (fieldNames == null  || fieldNames.length == 0 ) {
c.accept$O(Integer.valueOf$I(-1));
return;
}this.selectOptionAsync$S$S$SA$java_awt_event_ActionListener("Select compound name or identifier", filename, fieldNames, ((P$.CompoundFileHelper$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "CompoundFileHelper$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.awt.event.ActionListener', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'actionPerformed$java_awt_event_ActionEvent',  function (e) {
var id=e.getActionCommand$();
var indexOfID=-1;
if (id != null ) {
for (var i=0; i < this.$finals$.fieldNames.length; i++) {
if (this.$finals$.fieldNames[i].equals$O(id)) {
indexOfID=i;
break;
}}
}this.$finals$.c.accept$O(Integer.valueOf$I(indexOfID));
});
})()
), Clazz.new_(P$.CompoundFileHelper$1.$init$,[this, {fieldNames:fieldNames,c:c}])));
}, p$1);

Clazz.newMeth(C$, 'parseChemObjects$com_actelion_research_chem_io_CompoundFileParser$java_util_ArrayList$java_util_ArrayList$java_util_ArrayList$I$Z',  function (parser, moleculeList, idcodeList, idcodeWithIDList, indexOfID, readIDCoords) {
if (parser == null ) {
++this.mErrorCount;
return;
}while (parser.next$()){
++this.mRecordCount;
var isError=false;
if (moleculeList != null ) {
var mol=parser.getMolecule$();
if (mol != null ) {
if (indexOfID != -1) mol.setName$S(parser.getFieldData$I(indexOfID));
moleculeList.add$O(mol);
} else {
isError=true;
}}if (idcodeList != null  || idcodeWithIDList != null  ) {
var idcode=parser.getIDCode$();
if (idcode != null ) {
if (readIDCoords) {
var coords=parser.getCoordinates$();
if (coords != null ) idcode=idcode.concat$S(" ").concat$S(coords);
}}var id=null;
if (idcodeWithIDList != null ) {
id=parser.getMoleculeName$();
if (indexOfID != -1) id=parser.getFieldData$I(indexOfID);
}if (idcode != null ) {
if (idcodeList != null ) idcodeList.add$O(idcode);
if (idcodeWithIDList != null ) {
var idcodeWithID=Clazz.array(String, [2]);
idcodeWithID[0]=idcode;
idcodeWithID[1]=id;
idcodeWithIDList.add$O(idcodeWithID);
}} else isError=true;
}if (isError) ++this.mErrorCount;
}
}, p$1);

Clazz.newMeth(C$, 'getRecordCount$',  function () {
return this.mRecordCount;
});

Clazz.newMeth(C$, 'getErrorCount$',  function () {
return this.mErrorCount;
});

Clazz.newMeth(C$, 'createFileFilter$I$Z',  function (filetypes, isSaving) {
if (filetypes == -2) return ((P$.CompoundFileHelper$2||
(function(){/*a*/var C$=Clazz.newClass(P$, "CompoundFileHelper$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('com.actelion.research.chem.io.CompoundFileFilter'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'accept$java_io_File',  function (f) {
return f.isDirectory$();
});
})()
), Clazz.new_($I$(9,1),[this, null],P$.CompoundFileHelper$2));
var filter=Clazz.new_($I$(9,1));
if ((filetypes & 1) != 0) {
filter.addExtension$S("dwar");
if (!isSaving) filter.addExtension$S("ode");
filter.addDescription$S("DataWarrior data files");
}if ((filetypes & 2) != 0) {
filter.addExtension$S("dwat");
if (!isSaving) filter.addExtension$S("odt");
filter.addDescription$S("DataWarrior template files");
}if ((filetypes & 4) != 0) {
filter.addExtension$S("dwaq");
if (!isSaving) filter.addExtension$S("odq");
filter.addDescription$S("DataWarrior query files");
}if ((filetypes & 8) != 0) {
filter.addExtension$S("dwam");
filter.addDescription$S("DataWarrior macro files");
}if ((filetypes & 16) != 0) {
filter.addExtension$S("tsv");
filter.addExtension$S("txt");
filter.addDescription$S("TAB delimited text files");
}if ((filetypes & 224) != 0) {
filter.addExtension$S("csv");
filter.addDescription$S("Comma [,;|] separated text files");
}if ((filetypes & 1024) != 0) {
filter.addExtension$S("rxn");
filter.addDescription$S("MDL reaction files");
}if ((filetypes & 768) != 0) {
filter.addExtension$S("sdf");
filter.addDescription$S("MDL SD-files");
}if ((filetypes & 4194304) != 0) {
filter.addExtension$S("sdf.gz");
filter.addDescription$S("gzipped MDL SD-files)");
}if ((filetypes & 196608) != 0) {
filter.addExtension$S("rdf");
filter.addDescription$S("MDL RD-files");
}if ((filetypes & 2048) != 0) {
filter.addExtension$S("dwas");
if (!isSaving) filter.addExtension$S("som");
filter.addDescription$S("DataWarrior self organized map");
}if ((filetypes & 4096) != 0) {
filter.addExtension$S("jpg");
filter.addExtension$S("jpeg");
filter.addDescription$S("JPEG image files");
}if ((filetypes & 8192) != 0) {
filter.addExtension$S("gif");
filter.addDescription$S("GIF image files");
}if ((filetypes & 16384) != 0) {
filter.addExtension$S("png");
filter.addDescription$S("PNG image files");
}if ((filetypes & 32768) != 0) {
filter.addExtension$S("svg");
filter.addDescription$S("scalable vector graphics files");
}if (filetypes == 4391921) {
filter.setDescription$S("DataWarrior compatible files");
}if (filetypes == 7) {
filter.setDescription$S("Files containing a DataWarrior template");
}if (filetypes == 61440) {
filter.setDescription$S("Image files");
}if ((filetypes & 1048576) != 0) {
filter.addExtension$S("pdb");
filter.addDescription$S("Protein Data Bank files");
}if ((filetypes & 2097152) != 0) {
filter.addExtension$S("mmtf");
filter.addDescription$S("Binary Protein Data Bank files");
}if ((filetypes & 262144) != 0) {
filter.addExtension$S("mol");
filter.addDescription$S("MDL Molfiles");
}if ((filetypes & 524288) != 0) {
filter.addExtension$S("mol2");
filter.addDescription$S("Tripos Mol2 files");
}return filter;
}, 1);

Clazz.newMeth(C$, 'getExtension$java_io_File',  function (file) {
var index=-1;
var filename=(file == null ) ? null : file.getName$();
if (filename != null ) index=C$.getExtensionIndex$S(filename);
return (index == -1) ? null : filename.substring$I(index + 1).toLowerCase$();
}, 1);

Clazz.newMeth(C$, 'getExtensionIndex$S',  function (filename) {
var i=filename.lastIndexOf$I(".");
if (i > 0 && i < filename.length$() - 1  && filename.substring$I(i).equalsIgnoreCase$S(".gz") ) i=filename.lastIndexOf$I$I(".", i - 1);
return (i > 0 && i < filename.length$() - 1 ) ? i : -1;
}, 1);

Clazz.newMeth(C$, 'removePathAndExtension$S',  function (filePath) {
var i1=filePath.lastIndexOf$I($I$(10).separatorChar);
var i2=(C$.getFileType$S(filePath) != -1) ? C$.getExtensionIndex$S(filePath) : -1;
if (i1 == -1) return (i2 == -1) ? filePath : filePath.substring$I$I(0, i2);
 else return (i2 == -1 || i2 < i1 ) ? filePath.substring$I(i1 + 1) : filePath.substring$I$I(i1 + 1, i2);
}, 1);

Clazz.newMeth(C$, 'removeExtension$S',  function (filePath) {
var i=(C$.getFileType$S(filePath) != -1) ? filePath.lastIndexOf$I(".") : -1;
return (i == -1) ? filePath : filePath.substring$I$I(0, i);
}, 1);

Clazz.newMeth(C$, 'getFileType$S',  function (filename) {
var index=C$.getExtensionIndex$S(filename);
if (index == -1) return -1;
var extension=filename.substring$I(index).toLowerCase$();
if (extension.equals$O(".dwar") || extension.equals$O(".ode") ) return 1;
if (extension.equals$O(".dwat") || extension.equals$O(".odt") ) return 2;
if (extension.equals$O(".dwaq") || extension.equals$O(".odq") ) return 4;
if (extension.equals$O(".dwas") || extension.equals$O(".som") ) return 2048;
if (extension.equals$O(".dwam")) return 8;
if (extension.equals$O(".txt") || extension.equals$O(".tsv") ) return 16;
if (extension.equals$O(".csv")) return 224;
if (extension.equals$O(".sdf")) return 768;
if (extension.equals$O(".sdf.gz")) return 4194304;
if (extension.equals$O(".rdf")) return 196608;
if (extension.equals$O(".rxn")) return 1024;
if (extension.equals$O(".jpg") || extension.equals$O(".jpeg") ) return 4096;
if (extension.equals$O(".gif")) return 8192;
if (extension.equals$O(".png")) return 16384;
if (extension.equals$O(".svg")) return 32768;
if (extension.equals$O(".mol")) return 262144;
if (extension.equals$O(".mol2")) return 524288;
if (extension.equals$O(".pdb")) return 1048576;
if (extension.equals$O(".mmtf")) return 2097152;
return -1;
}, 1);

Clazz.newMeth(C$, 'getExtensionList$I',  function (fileTypes) {
var list=Clazz.new_($I$(1,1));
var type=1;
while ((type & 8388607) != 0){
if ((type & fileTypes) != 0) for (var extension, $extension = 0, $$extension = C$.getExtensions$I(type); $extension<$$extension.length&&((extension=($$extension[$extension])),1);$extension++) if (!list.contains$O(extension)) list.add$O(extension);

type<<=1;
}
return list;
});

Clazz.newMeth(C$, 'getExtension$I',  function (filetype) {
var extensions=C$.getExtensions$I(filetype);
return extensions.length == 0 ? "" : extensions[0];
}, 1);

Clazz.newMeth(C$, 'getExtensions$I',  function (filetype) {
var extensions=Clazz.new_($I$(1,1));
switch (filetype) {
case 1:
extensions.add$O(".dwar");
break;
case 4:
extensions.add$O(".dwaq");
break;
case 2:
extensions.add$O(".dwat");
break;
case 8:
extensions.add$O(".dwam");
break;
case 16:
extensions.add$O(".txt");
extensions.add$O(".tsv");
break;
case 224:
case 32:
case 64:
case 128:
extensions.add$O(".csv");
break;
case 768:
case 512:
case 256:
extensions.add$O(".sdf");
break;
case 196608:
case 131072:
case 65536:
extensions.add$O(".rdf");
break;
case 1024:
extensions.add$O(".rxn");
break;
case 2048:
extensions.add$O(".dwas");
break;
case 4096:
extensions.add$O(".jpeg");
extensions.add$O(".jpg");
break;
case 8192:
extensions.add$O(".gif");
break;
case 16384:
extensions.add$O(".png");
break;
case 32768:
extensions.add$O(".svg");
break;
case 262144:
extensions.add$O(".mol");
break;
case 524288:
extensions.add$O(".mol2");
break;
case 1048576:
extensions.add$O(".pdb");
break;
case 2097152:
extensions.add$O(".mmtf");
break;
case 4194304:
extensions.add$O(".sdf.gz");
break;
}
return extensions.toArray$OA(Clazz.array(String, [0]));
}, 1);

Clazz.newMeth(C$, 'saveRXNFile$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
var fileName=this.selectFileToSave$S$I$S("Select reaction file", 1024, "Untitled Reaction");
if (fileName != null ) {
var extension=".rxn";
var dotIndex=fileName.lastIndexOf$I(".");
var slashIndex=fileName.lastIndexOf$S($I$(10).separator);
if (dotIndex == -1 || dotIndex < slashIndex ) fileName=fileName.concat$S(extension);
 else if (!fileName.substring$I(dotIndex).equalsIgnoreCase$S(extension)) {
this.showMessage$S("Incompatible file name extension.");
return;
}try {
var theWriter=Clazz.new_([Clazz.new_([Clazz.new_($I$(13,1).c$$S,[fileName]), $I$(14).UTF_8],$I$(12,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(11,1).c$$java_io_Writer);
Clazz.new_($I$(15,1).c$$com_actelion_research_chem_reaction_Reaction,[rxn]).writeRXNfile$java_io_Writer(theWriter);
theWriter.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
this.showMessage$S("IOException: " + e);
} else {
throw e;
}
}
}});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
