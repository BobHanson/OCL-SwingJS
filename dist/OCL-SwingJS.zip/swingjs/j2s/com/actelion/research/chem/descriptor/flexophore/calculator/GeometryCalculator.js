(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.calculator"),I$=[[0,'com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GeometryCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getCoordinates$com_actelion_research_chem_Molecule$I',  function (mol, atm) {
return Clazz.new_([mol.getAtomX$I(atm), mol.getAtomY$I(atm), mol.getAtomZ$I(atm)],$I$(1,1).c$$D$D$D);
}, 1);

Clazz.newMeth(C$, 'getAngle$com_actelion_research_chem_Molecule3D$I$I$I',  function (mol, a1, a2, a3) {
var c1=mol.getCoordinates$I(a1);
var c2=mol.getCoordinates$I(a2);
var c3=mol.getCoordinates$I(a3);
return c1.subC$com_actelion_research_chem_Coordinates(c2).getAngle$com_actelion_research_chem_Coordinates(c3.subC$com_actelion_research_chem_Coordinates(c2));
}, 1);

Clazz.newMeth(C$, 'getAngle$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates',  function (c1, c2, c3) {
return c1.subC$com_actelion_research_chem_Coordinates(c2).getAngle$com_actelion_research_chem_Coordinates(c3.subC$com_actelion_research_chem_Coordinates(c2));
}, 1);

Clazz.newMeth(C$, 'getAngle$com_actelion_research_chem_Molecule$I$I$I',  function (mol, a1, a2, a3) {
var c1=C$.getCoordinates$com_actelion_research_chem_Molecule$I(mol, a1);
var c2=C$.getCoordinates$com_actelion_research_chem_Molecule$I(mol, a2);
var c3=C$.getCoordinates$com_actelion_research_chem_Molecule$I(mol, a3);
return c1.subC$com_actelion_research_chem_Coordinates(c2).getAngle$com_actelion_research_chem_Coordinates(c3.subC$com_actelion_research_chem_Coordinates(c2));
}, 1);

Clazz.newMeth(C$, 'getDihedral$com_actelion_research_chem_Molecule3D$I$I$I$I',  function (mol, a1, a2, a3, a4) {
var c1=mol.getCoordinates$I(a1);
var c2=mol.getCoordinates$I(a2);
var c3=mol.getCoordinates$I(a3);
var c4=mol.getCoordinates$I(a4);
return c1.getDihedral$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates(c2, c3, c4);
}, 1);

Clazz.newMeth(C$, 'getCenterGravity$com_actelion_research_chem_Molecule3D',  function (mol) {
var c=Clazz.new_($I$(1,1));
for (var i=0; i < mol.getAllAtoms$(); i++) {
c.x+=mol.getAtomX$I(i);
c.y+=mol.getAtomY$I(i);
c.z+=mol.getAtomZ$I(i);
}
c.x/=mol.getAllAtoms$();
c.y/=mol.getAllAtoms$();
c.z/=mol.getAllAtoms$();
return c;
}, 1);

Clazz.newMeth(C$, 'getBounds$com_actelion_research_chem_Molecule3D',  function (molecule) {
if (molecule.getAllAtoms$() == 0) return Clazz.array($I$(1), -1, [Clazz.new_($I$(1,1).c$$D$D$D,[0, 0, 0]), Clazz.new_($I$(1,1).c$$D$D$D,[0, 0, 0])]);
var coords=Clazz.array($I$(1), -1, [Clazz.new_($I$(1,1).c$$D$D$D,[3.4028235E38, 3.4028235E38, 3.4028235E38]), Clazz.new_($I$(1,1).c$$D$D$D,[-3.4028235E38, -3.4028235E38, -3.4028235E38])]);
for (var i=0; i < molecule.getAllAtoms$(); i++) {
coords[0].x=Math.min(coords[0].x, molecule.getAtomX$I(i));
coords[0].y=Math.min(coords[0].y, molecule.getAtomY$I(i));
coords[0].z=Math.min(coords[0].z, molecule.getAtomZ$I(i));
coords[1].x=Math.max(coords[1].x, molecule.getAtomX$I(i));
coords[1].y=Math.max(coords[1].y, molecule.getAtomY$I(i));
coords[1].z=Math.max(coords[1].z, molecule.getAtomZ$I(i));
}
return coords;
}, 1);

Clazz.newMeth(C$, 'translate$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Coordinates',  function (molecule, c) {
for (var i=0; i < molecule.getAllAtoms$(); i++) {
molecule.setAtomX$I$D(i, molecule.getAtomX$I(i) + c.x);
molecule.setAtomY$I$D(i, molecule.getAtomY$I(i) + c.y);
molecule.setAtomZ$I$D(i, molecule.getAtomZ$I(i) + c.z);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-01 14:15:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
