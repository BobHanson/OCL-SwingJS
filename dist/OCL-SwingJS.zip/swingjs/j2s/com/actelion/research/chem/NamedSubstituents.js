(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.TreeMap','com.actelion.research.chem.IDCodeParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NamedSubstituents");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['SUBSTITUENT_LIST','String[][]','sIDCodeMap','java.util.TreeMap']]]

Clazz.newMeth(C$, 'createMap$',  function () {
C$.sIDCodeMap=Clazz.new_($I$(1,1));
for (var sp, $sp = 0, $$sp = C$.SUBSTITUENT_LIST; $sp<$$sp.length&&((sp=($$sp[$sp])),1);$sp++) {
var key=sp[0].split$S(";");
for (var k, $k = 0, $$k = key; $k<$$k.length&&((k=($$k[$k])),1);$k++) C$.sIDCodeMap.put$O$O(C$.normalize$S(k), sp[1]);

}
}, 1);

Clazz.newMeth(C$, 'identify$S',  function (nameStart) {
if (nameStart == null  || nameStart.length$() == 0 ) return null;
var name=null;
nameStart=C$.normalize$S(nameStart);
for (var sp, $sp = 0, $$sp = C$.SUBSTITUENT_LIST; $sp<$$sp.length&&((sp=($$sp[$sp])),1);$sp++) {
var key=sp[0].split$S(";");
for (var k, $k = 0, $$k = key; $k<$$k.length&&((k=($$k[$k])),1);$k++) {
if (C$.normalize$S(k).equals$O(nameStart)) return k;
if (C$.normalize$S(k).startsWith$S(nameStart)) {
if (name == null ) name=k;
 else return "";
}}
}
return name;
}, 1);

Clazz.newMeth(C$, 'normalize$S',  function (s) {
return s.toLowerCase$().replace$CharSequence$CharSequence("-", "");
}, 1);

Clazz.newMeth(C$, 'getSubstituentIDCode$S',  function (name) {
if (C$.sIDCodeMap == null ) C$.createMap$();
return C$.sIDCodeMap.get$O(C$.normalize$S(name));
}, 1);

Clazz.newMeth(C$, 'getSubstituent$S',  function (name) {
var idcode=C$.getSubstituentIDCode$S(name);
return (idcode == null ) ? null : Clazz.new_($I$(2,1).c$$Z,[false]).getCompactMolecule$S(idcode);
}, 1);

Clazz.newMeth(C$, 'isValidSubstituentNameStart$S',  function (s) {
if (C$.sIDCodeMap == null ) C$.createMap$();
s=C$.normalize$S(s);
for (var n, $n = C$.sIDCodeMap.keySet$().iterator$(); $n.hasNext$()&&((n=($n.next$())),1);) if (n.startsWith$S(s)) return true;

return false;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.SUBSTITUENT_LIST=Clazz.array(String, -2, [Clazz.array(String, -1, ["Acyl", "gCaHA`AIf`@"]), Clazz.array(String, -1, ["Alloc", "gNph@l@ILzuR@@"]), Clazz.array(String, -1, ["Allyl", "Al"]), Clazz.array(String, -1, ["Benzyl;Bn", "daD@`F@DjUZxHH@@"]), Clazz.array(String, -1, ["Boc", "daxD`@S@AIgijj@@"]), Clazz.array(String, -1, ["BOM;BzOM", "deTH`@H@Re[TYj`@@@"]), Clazz.array(String, -1, ["Bs", "dmtDpAdLS`aPAIe]jf`@e`@@"]), Clazz.array(String, -1, ["Bt", "dew@`@aJ@DiY]paej`@@@"]), Clazz.array(String, -1, ["Btm", "did@P@BJ@Die_ahH@@@"]), Clazz.array(String, -1, ["Butyl;nButyl", "gJPHB@IRuP@"]), Clazz.array(String, -1, ["Benzoyl;Bz", "didH`@p@RYm^Eh@@@@"]), Clazz.array(String, -1, ["Bzh", "dg|@`N@LdbRbtJUB]aAP@@@@"]), Clazz.array(String, -1, ["Cbz", "dmtD`@S@AIgYVUZh@@@@"]), Clazz.array(String, -1, ["cButyl", "gKPHL@IThuT@@"]), Clazz.array(String, -1, ["cHeptyl", "daD@`L@DjWVzjj`@"]), Clazz.array(String, -1, ["cHexyl", "gOpHL@IToWUU@@"]), Clazz.array(String, -1, ["cOctyl", "did@`L@DjWWajjj@@"]), Clazz.array(String, -1, ["cPentyl", "gFpHL@ITimUP@"]), Clazz.array(String, -1, ["cPropyl", "gBPHL@Qxjh@"]), Clazz.array(String, -1, ["COOH", "gC`h@l@ILt@@ !Bb@K~@Hc}"]), Clazz.array(String, -1, ["DEAE", "daz@`@x@RiUjj`@"]), Clazz.array(String, -1, ["DEIPS", "diD@P@\\B@DjfVjj`@"]), Clazz.array(String, -1, ["DMIPS", "gNpD@xD@RjZjh@"]), Clazz.array(String, -1, ["DMPM", "dcLD`@kPCIEMDdcttDDT@@"]), Clazz.array(String, -1, ["DMPS", "deT@P@\\B@LddTjPsU@@@@"]), Clazz.array(String, -1, ["DMTr", "fak@b@@Mt@ISZ{SMjo{NQKfm@AU@@@E@@@@"]), Clazz.array(String, -1, ["DNP", "dkmB`hdDt~@HeNfS{HihheCAUhBHX@@"]), Clazz.array(String, -1, ["DNS;Dan", "fhi`a@KPP@HH@YIHYheEhYKQgKP@@QP@@@"]), Clazz.array(String, -1, ["DPIPS", "fdyAA@H@\\B@FRRIQSQIHzp_Qjh@h@@@@@"]), Clazz.array(String, -1, ["DPTBS", "fleAA@H@\\B@FRRIQSRIIWNbEMU@EP@@@@@"]), Clazz.array(String, -1, ["DTBMS", "dmT@P@\\B@Djffjjjh@@"]), Clazz.array(String, -1, ["Ethyl", "eMBD@ch@"]), Clazz.array(String, -1, ["Fmoc", "fde@b@@Hp@IL{LrjxeVCzKUT@@@P@@@"]), Clazz.array(String, -1, ["iAmyl", "gGPHJ@YIDZj@@"]), Clazz.array(String, -1, ["iButyl", "gJPHB@ITuP@"]), Clazz.array(String, -1, ["Im", "gFtHAj@IRnKSP@"]), Clazz.array(String, -1, ["iPropyl", "gC`HL@Qz`@"]), Clazz.array(String, -1, ["MDIPS", "diD@P@\\B@DjfZjj`@"]), Clazz.array(String, -1, ["MDPS", "foA@A@@NA@CIIEEBdeeVLzj@@@@@@"]), Clazz.array(String, -1, ["Methyl", "eFBH@c@@"]), Clazz.array(String, -1, ["MEM", "gNphAR@IRoUT@@"]), Clazz.array(String, -1, ["Mes", "deT@`J@DjY{[`bB`@@"]), Clazz.array(String, -1, ["MMTr", "ffcAB@@Z@Dim]ifuWYrI\\uh@Jh@@@@@@"]), Clazz.array(String, -1, ["MOM", "gCaHA`AJZ`@"]), Clazz.array(String, -1, ["MPM;PMB", "deTH`@d@Rfuunh@J@@"]), Clazz.array(String, -1, ["Ms", "gJPdH`DD@cuh@"]), Clazz.array(String, -1, ["MTM", "gC`D@DX@Rfh@"]), Clazz.array(String, -1, ["mTolyl", "daD@`N@DjWjXHB@@"]), Clazz.array(String, -1, ["N3", "gClHaE`@RnReX@"]), Clazz.array(String, -1, ["nAmyl;Amyl", "gGPHJ@IRmU@@"]), Clazz.array(String, -1, ["neoAm", "gGPHJ@IUMU@@"]), Clazz.array(String, -1, ["NO2,Nitro", "gChhhE`BRnRYh@"]), Clazz.array(String, -1, ["Np", "deVDaHAI@HeNR[e_aZ@B@@"]), Clazz.array(String, -1, ["nPropyl;Propyl", "gC`HL@IST@@"]), Clazz.array(String, -1, ["oTolyl", "daD@`J@DjYvxH`@@"]), Clazz.array(String, -1, ["Phenyl", "gOpHL@IToVD@@@"]), Clazz.array(String, -1, ["Pht", "dcLL`@RU@Dfyed]ZBA`@@"]), Clazz.array(String, -1, ["Piv;Pv", "gNqHA`AIffj`@"]), Clazz.array(String, -1, ["PMBM", "dcLD`@T`AJUm]FZh@J@@"]), Clazz.array(String, -1, ["PNB", "dcNLaHAEt@bTyInUvxV`@f@@"]), Clazz.array(String, -1, ["Poc", "didD`@S@AIgexVjj`@"]), Clazz.array(String, -1, ["PPi", "diDFsHSB[`|J|A@Lxn{lddqdZih@@"]), Clazz.array(String, -1, ["pTolyl", "daD@`N@DjWzXHB@@"]), Clazz.array(String, -1, ["sAmyl", "gGPHL@YIDZj@@"]), Clazz.array(String, -1, ["sButyl", "gJPHL@ITuP@"]), Clazz.array(String, -1, ["SEM", "diDHPFApD@rRQUJjj`@"]), Clazz.array(String, -1, ["SES", "dedDpHP@``AgCIICeHmUT@@"]), Clazz.array(String, -1, ["SO3H", "gJQdHl@``D^m@@"]), Clazz.array(String, -1, ["tAmyl", "gGPHB@IUMU@@"]), Clazz.array(String, -1, ["TBDMS;TBS", "dax@P@\\B@Djfjjh@@"]), Clazz.array(String, -1, ["TBDPS", "fdy@A@@NA@CIIEEEIde]XOhuPAT@@@@@"]), Clazz.array(String, -1, ["TBMPS", "dg\\HPHApH@rRQJJPjg]UAT@@@"]), Clazz.array(String, -1, ["tButyl,tBu", "gJPHB@Q}T@@"]), Clazz.array(String, -1, ["TDS", "ded@P@\\B@LddTeeUUP@@"]), Clazz.array(String, -1, ["Tf", "daxDhHP@``BiAiCiCIICHmU@@"]), Clazz.array(String, -1, ["TFA", "gNqBJIARFdF@YEHYUL@@"]), Clazz.array(String, -1, ["Thexyl", "gNpHB@IUMUT@@"]), Clazz.array(String, -1, ["THF", "gFqH@PAJYujj@@"]), Clazz.array(String, -1, ["THP", "gOqH@PAJYZzjh@"]), Clazz.array(String, -1, ["TIPS", "dmT@P@\\B@DjfYjjjh@@"]), Clazz.array(String, -1, ["TMS", "gJPD@xD@czh@"]), Clazz.array(String, -1, ["Tosyl;Ts", "dmtDPHP@``CIICLeaeZ@B@@"]), Clazz.array(String, -1, ["Troc", "diDDHJxHaHcH`PCHiBeJjf@@"]), Clazz.array(String, -1, ["Trt", "fbm@B@A@FRQIRKQPiIZdoIcdHJ`@@@@@@"]), Clazz.array(String, -1, ["Xyl", "did@`J@DjYynBHH@@"])]);
C$.sIDCodeMap=null;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:08 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
