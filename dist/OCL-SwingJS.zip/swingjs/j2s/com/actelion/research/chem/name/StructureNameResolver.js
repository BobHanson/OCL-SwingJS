(function(){var P$=Clazz.newPackage("com.actelion.research.chem.name"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "StructureNameResolver");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['sResolver','com.actelion.research.chem.name.IStructureNameResolver']]]

Clazz.newMeth(C$, 'getInstance$',  function () {
return C$.sResolver;
}, 1);

Clazz.newMeth(C$, 'setInstance$com_actelion_research_chem_name_IStructureNameResolver',  function (resolver) {
C$.sResolver=resolver;
}, 1);

Clazz.newMeth(C$, 'resolve$S',  function (name) {
var mol=C$.resolveLocal$S(name);
return mol != null  ? mol : C$.resolveRemote$S(name);
}, 1);

Clazz.newMeth(C$, 'resolveLocal$S',  function (name) {
return C$.sResolver == null  ? null : C$.sResolver.resolveLocal$S(name);
}, 1);

Clazz.newMeth(C$, 'resolveRemote$S',  function (name) {
return C$.sResolver == null  ? null : C$.sResolver.resolveRemote$S(name);
}, 1);

Clazz.newMeth(C$, 'resolveRemote$SA',  function (nameList) {
return C$.sResolver == null  ? null : C$.sResolver.resolveRemote$SA(nameList);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
