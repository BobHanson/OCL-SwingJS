(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),I$=[[0,'java.util.HashSet','java.util.ArrayList','com.actelion.research.chem.io.pdb.converter.MoleculeGrid','com.actelion.research.chem.conf.Conformer','com.actelion.research.chem.docking.scoring.idoscore.InteractionTerm','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ScoringTask");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'calcScore$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$IA$IA',  function (receptor, ligand, receptorAtomTypes, ligandAtomTypes) {
var receptorAtoms=Clazz.new_($I$(1,1));
var terms=Clazz.new_($I$(2,1));
var molGrid=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[receptor]);
for (var l=0; l < ligand.getAtoms$(); l++) receptorAtoms.addAll$java_util_Collection(molGrid.getNeighbours$com_actelion_research_chem_Coordinates$D(ligand.getCoordinates$I(l), 6.0));

for (var p, $p = receptorAtoms.iterator$(); $p.hasNext$()&&((p=($p.next$()).intValue$()),1);) {
for (var l=0; l < ligand.getAtoms$(); l++) {
var recConf=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[receptor]);
var ligConf=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[ligand]);
terms.add$O($I$(5).create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$IA(recConf, ligConf, p, l, receptorAtomTypes, ligandAtomTypes));
}
}
var score=0.0;
var gradient=Clazz.array(Double.TYPE, [3 * ligand.getAllAtoms$()]);
for (var term, $term = terms.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
if (term != null ) {
score+=term.getFGValue$DA(gradient);
}}
return score;
}, 1);

Clazz.newMeth(C$, 'calcScore$com_actelion_research_chem_StereoMolecule$I$com_actelion_research_chem_Coordinates$IA',  function (receptor, probeAtomType, c, receptorAtomTypes) {
var score=0.0;
var receptorAtoms=Clazz.new_($I$(1,1));
var grid=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[receptor]);
receptorAtoms.addAll$java_util_Collection(grid.getNeighbours$com_actelion_research_chem_Coordinates$D(c, 6.0));
for (var p, $p = receptorAtoms.iterator$(); $p.hasNext$()&&((p=($p.next$()).intValue$()),1);) {
var f=$I$(6).getInstance$().getFunction$I$I(receptorAtomTypes[p], probeAtomType);
var dist=c.distance$com_actelion_research_chem_Coordinates(receptor.getCoordinates$I(p));
score+=f.getFGValue$D(dist)[0];
}
return score;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
