(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.AtomTypeList','java.util.Random','com.actelion.research.chem.Canonizer','java.util.ArrayList','com.actelion.research.chem.Mutation','com.actelion.research.chem.ScaffoldHelper',['com.actelion.research.chem.Mutator','.MutatorSubstituent'],'com.actelion.research.chem.AtomTypeCalculator','com.actelion.research.chem.coords.CoordinateInventor','java.util.Arrays']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Mutator", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MutatorSubstituent',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mMolCopy=Clazz.new_($I$(1,1));
this.mMol=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['D',['mGrowBoost'],'I',['mMinAtoms','mOptAtoms','mMaxAtoms'],'O',['mRandom','java.util.Random','mMolCopy','com.actelion.research.chem.StereoMolecule','+mMol','mAtomTypeList','com.actelion.research.chem.AtomTypeList','mCanonizer','com.actelion.research.chem.Canonizer','mIsPrimaryAtom','boolean[]','mBiasProvider','com.actelion.research.chem.MutationBiasProvider']]]

Clazz.newMeth(C$, 'c$$S',  function (filename) {
;C$.$init$.apply(this);
if (filename != null ) {
try {
this.mAtomTypeList=Clazz.new_($I$(2,1).c$$S$I,[filename, 32190]);
this.mAtomTypeList.calculateProbabilities$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}this.mRandom=Clazz.new_($I$(3,1));
this.mGrowBoost=1.0;
this.mMinAtoms=4;
this.mOptAtoms=9;
this.mMaxAtoms=24;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_AtomTypeList',  function (atomTypeList) {
;C$.$init$.apply(this);
this.mAtomTypeList=atomTypeList;
this.mAtomTypeList.calculateProbabilities$();
this.mRandom=Clazz.new_($I$(3,1));
this.mGrowBoost=1.0;
this.mMinAtoms=4;
this.mOptAtoms=9;
this.mMaxAtoms=24;
}, 1);

Clazz.newMeth(C$, 'setBiasProvider$com_actelion_research_chem_MutationBiasProvider',  function (mbp) {
this.mBiasProvider=mbp;
});

Clazz.newMeth(C$, 'setGrowBoost$D',  function (boost) {
this.mGrowBoost=boost;
});

Clazz.newMeth(C$, 'setPreferredSize$I$I$I',  function (minAtoms, preferredAtoms, maxAtoms) {
this.mMinAtoms=minAtoms;
this.mOptAtoms=preferredAtoms;
this.mMaxAtoms=maxAtoms;
});

Clazz.newMeth(C$, 'getMutatedSet$com_actelion_research_chem_StereoMolecule$I$Z$I',  function (mol, mutationType, regulateSize, count) {
var mutationList=this.generateMutationList$com_actelion_research_chem_StereoMolecule$I$Z(mol, mutationType, regulateSize);
if (count > mutationList.size$()) count=mutationList.size$();
var set=Clazz.array($I$(1), [count]);
for (var i=0; i < count; i++) {
set[i]=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Molecule,[mol]);
this.mutate$com_actelion_research_chem_StereoMolecule$java_util_ArrayList(set[i], mutationList);
}
return set;
});

Clazz.newMeth(C$, 'mutate$com_actelion_research_chem_StereoMolecule',  function (mol) {
return this.mutate$com_actelion_research_chem_StereoMolecule$I$Z(mol, 65535, true);
});

Clazz.newMeth(C$, 'mutate$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, mutationType, regulateSize) {
var ml=this.generateMutationList$com_actelion_research_chem_StereoMolecule$I$Z(mol, mutationType, regulateSize);
if (ml.size$() == 0) {
System.out.println$S("no possible mutation found. ID-Code:" + Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$I,[mol, 16]).getIDCode$());
return null;
}this.mutate$com_actelion_research_chem_StereoMolecule$java_util_ArrayList(mol, ml);
return ml;
});

Clazz.newMeth(C$, 'mutate$com_actelion_research_chem_StereoMolecule$java_util_ArrayList',  function (mol, mutationList) {
if (!mutationList.isEmpty$()) {
var mutation=p$1.selectLikelyMutation$java_util_ArrayList.apply(this, [mutationList]);
if (mutation != null ) {
this.performMutation$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_Mutation(mol, mutation);
}}});

Clazz.newMeth(C$, 'generateMutationList$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, mutationType, regulateSize) {
this.mMol=mol;
if (this.mBiasProvider != null ) this.mBiasProvider.setBiasReference$com_actelion_research_chem_StereoMolecule(mol);
p$1.detectSymmetry.apply(this, []);
var mutationList=Clazz.new_($I$(5,1));
var substituentList=p$1.createSubstituentList.apply(this, []);
if (!regulateSize || (this.mRandom.nextDouble$() > (this.mMol.getAtoms$() - this.mOptAtoms) / (this.mMaxAtoms - this.mOptAtoms) ) ) {
if ((mutationType & 1) != 0) p$1.addProbabilitiesForAddAtom$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 2) != 0) p$1.addProbabilitiesForInsertAtom$java_util_ArrayList.apply(this, [mutationList]);
}if ((mutationType & 4) != 0) p$1.addProbabilitiesForChangeAtom$java_util_ArrayList.apply(this, [mutationList]);
if (!regulateSize || (this.mRandom.nextDouble$() < (this.mMol.getAtoms$() - this.mMinAtoms) / (this.mOptAtoms - this.mMinAtoms) ) ) {
if ((mutationType & 16) != 0) p$1.addProbabilitiesForDeleteAtom$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 8) != 0) p$1.addProbabilitiesForCutOutAtom$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 8192) != 0) p$1.addProbabilitiesForDeleteSubstituent$java_util_ArrayList$java_util_ArrayList.apply(this, [mutationList, substituentList]);
if ((mutationType & 16384) != 0) p$1.addProbabilitiesForCutOutFragment$java_util_ArrayList.apply(this, [mutationList]);
}if ((mutationType & (544)) != 0) p$1.addProbabilitiesForCloseRing$java_util_ArrayList$I.apply(this, [mutationList, mutationType]);
if ((mutationType & (1024)) != 0) p$1.addProbabilitiesForToggleAmidSulfonamid$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 64) != 0) p$1.addProbabilitiesForChangeBond$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 128) != 0) p$1.addProbabilitiesForDeleteBond$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 256) != 0) p$1.addProbabilitiesForChangeRing$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 2048) != 0) p$1.addProbabilitiesForMigrate$java_util_ArrayList.apply(this, [mutationList]);
if ((mutationType & 4096) != 0) p$1.addProbabilitiesForSwapSubstituent$java_util_ArrayList$java_util_ArrayList.apply(this, [mutationList, substituentList]);
if ((mutationType & 32768) != 0) p$1.addProbabilitiesForInvertParity$java_util_ArrayList.apply(this, [mutationList]);
if (false) p$1.tweakProbabilities$java_util_ArrayList.apply(this, [mutationList]);
return mutationList;
});

Clazz.newMeth(C$, 'tweakProbabilities$java_util_ArrayList',  function (mutationList) {
for (var mutation, $mutation = mutationList.iterator$(); $mutation.hasNext$()&&((mutation=($mutation.next$())),1);) mutation.mProbability=Math.pow(mutation.mProbability, 1.0);

}, p$1);

Clazz.newMeth(C$, 'detectSymmetry',  function () {
this.mCanonizer=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$I,[this.mMol, 1]);
this.mIsPrimaryAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
var rankCount=Clazz.array(Integer.TYPE, [1 + this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (!this.mMol.isSelectedAtom$I(atom)) ++rankCount[this.mCanonizer.getSymmetryRank$I(atom)];

var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (!this.mMol.isSelectedAtom$I(atom)) {
var rank=this.mCanonizer.getSymmetryRank$I(atom);
if (rankCount[rank] != 0) {
this.mIsPrimaryAtom[atom]=true;
rankCount[rank]=0;
var current=0;
var highest=0;
graphAtom[0]=atom;
while (current <= highest){
for (var i=0; i < this.mMol.getConnAtoms$I(graphAtom[current]); i++) {
var connAtom=this.mMol.getConnAtom$I$I(graphAtom[current], i);
if (!this.mMol.isSelectedAtom$I(connAtom)) {
var connRank=this.mCanonizer.getSymmetryRank$I(connAtom);
if (rankCount[connRank] != 0) {
this.mIsPrimaryAtom[connAtom]=true;
rankCount[connRank]=0;
graphAtom[highest++]=connAtom;
}}}
++current;
}
}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForAddAtom$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom]) {
var freeValence=this.mMol.getFreeValence$I(atom);
var maxBondOrder=(freeValence > 3) ? 3 : freeValence;
if (maxBondOrder > 0) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
var newAtom=this.mMolCopy.addAtom$I(6);
var newBond=this.mMolCopy.addBond$I$I$I(atom, newAtom, 1);
for (var bondOrder=1; bondOrder <= maxBondOrder; bondOrder++) {
var allowed=false;
for (var i=0; i < $I$(6).cAllowedAtomicNo[bondOrder - 1].length; i++) {
if ($I$(6).cAllowedAtomicNo[bondOrder - 1][i] == this.mMol.getAtomicNo$I(atom)) {
allowed=true;
break;
}}
if (!allowed) break;
for (var i=0; i < $I$(6).cAllowedAtomicNo[bondOrder - 1].length; i++) {
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
var atomicNo=$I$(6).cAllowedAtomicNo[bondOrder - 1][i];
var bondType=p$1.getBondTypeFromOrder$I.apply(this, [bondOrder]);
this.mMolCopy.setAtomicNo$I$I(newAtom, atomicNo);
this.mMolCopy.setBondType$I$I(newBond, bondType);
this.mMolCopy.ensureHelperArrays$I(7);
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]);
var p=this.mGrowBoost * f_Product / f_Educt * Math.sqrt(p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, newAtom]));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[1, atom, -1, atomicNo, bondType, p]));
}}
}
}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForInsertAtom$java_util_ArrayList',  function (mutationList) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.getBondType$I(bond) == 1 && !this.mMol.isAromaticBond$I(bond) ) {
for (var i=0; i < 2; i++) {
var atom1=this.mMol.getBondAtom$I$I(i, bond);
var atom2=this.mMol.getBondAtom$I$I(1 - i, bond);
if (this.mIsPrimaryAtom[atom1] && !this.mMol.isSelectedAtom$I(atom2) && this.mCanonizer.getSymmetryRank$I(atom1) < this.mCanonizer.getSymmetryRank$I(atom2)  ) {
var f_Educt1=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1]));
var f_Educt2=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.deleteBond$I(bond);
var newAtom=this.mMolCopy.addAtom$I(6);
this.mMolCopy.addBond$I$I$I(atom1, newAtom, 1);
this.mMolCopy.addBond$I$I$I(atom2, newAtom, 1);
for (var j=0; j < $I$(6).cAllowedAtomicNo[1].length; j++) {
var atomicNo=$I$(6).cAllowedAtomicNo[1][j];
this.mMolCopy.setAtomicNo$I$I(newAtom, atomicNo);
var f_Product1=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom1]);
var f_Product2=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom2]);
var f_NewAtom=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, newAtom]);
var p=this.mGrowBoost * Math.sqrt(f_NewAtom * f_Product1 * f_Product2  / (f_Educt1 * f_Educt2));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[2, bond, -1, atomicNo, -1, p]));
}}
}}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForChangeAtom$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom]) {
var maxBondOrder=1;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (maxBondOrder < this.mMol.getConnBondOrder$I$I(atom, i)) maxBondOrder=this.mMol.getConnBondOrder$I$I(atom, i);

for (var i=0; i < $I$(6).cAllowedAtomicNo[maxBondOrder - 1].length; i++) {
var proposedAtomicNo=$I$(6).cAllowedAtomicNo[maxBondOrder - 1][i];
var valences=this.mMol.getConnAtoms$I(atom) + this.mMol.getAtomPi$I(atom);
if (this.mMol.getAtomicNo$I(atom) == proposedAtomicNo) continue;
if (valences > 1 && (proposedAtomicNo == 9 || proposedAtomicNo == 17  || proposedAtomicNo == 35  || proposedAtomicNo == 53 ) ) continue;
if (valences > 2 && proposedAtomicNo == 8 ) continue;
if (valences > 3 && proposedAtomicNo == 5 ) continue;
if (valences > 4 && (proposedAtomicNo == 6 || proposedAtomicNo == 7 ) ) continue;
if (valences > 5 && proposedAtomicNo == 15 ) continue;
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.setAtomicNo$I$I(atom, proposedAtomicNo);
this.mMolCopy.ensureHelperArrays$I(7);
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]);
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, j);
f_Educt*=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, connAtom]));
f_Product*=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, connAtom]);
}
var p=Math.pow(f_Product / f_Educt, 1.0 / (1 + this.mMol.getConnAtoms$I(atom)));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[4, atom, -1, proposedAtomicNo, -1, p]));
}}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForDeleteAtom$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom]) {
if (this.mMol.getConnAtoms$I(atom) == 1) {
var connAtom=this.mMol.getConnAtom$I$I(atom, 0);
if (!this.mMol.isSelectedAtom$I(connAtom)) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.deleteBond$I(this.mMol.getConnBond$I$I(atom, 0));
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, connAtom]));
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, connAtom]);
var f_Deleted=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
var p=f_Product / f_Educt / Math.sqrt(f_Deleted) ;
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[16, atom, -1, -1, -1, p]));
}}}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForCutOutAtom$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom] && !this.mMol.isAromaticAtom$I(atom) && this.mMol.getConnAtoms$I(atom) == 2   && this.mMol.getAtomPi$I(atom) == 0  && this.mMol.getAtomRingSize$I(atom) != 3 ) {
var atom1=this.mMol.getConnAtom$I$I(atom, 0);
var atom2=this.mMol.getConnAtom$I$I(atom, 1);
var f_Educt1=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1]));
var f_Educt2=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
var f_Deleted=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.addBond$I$I$I(atom1, atom2, 1);
this.mMolCopy.deleteAtom$I(atom);
var newBond=this.mMolCopy.getAllBonds$() - 1;
atom1=this.mMolCopy.getBondAtom$I$I(0, newBond);
atom2=this.mMolCopy.getBondAtom$I$I(1, newBond);
var f_Product1=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom1]);
var f_Product2=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom2]);
var p=Math.sqrt(f_Product1 * f_Product2 / (f_Educt1 * f_Educt2)) / Math.sqrt(f_Deleted);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[8, atom, -1, -1, -1, p]));
}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForToggleAmidSulfonamid$java_util_ArrayList',  function (mutationList) {
var oxygen=Clazz.array(Integer.TYPE, [4]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom]) {
var atomicNo=this.mMol.getAtomicNo$I(atom);
if (atomicNo != 6 && atomicNo != 16 ) continue;
var oxoCount=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
oxygen[oxoCount]=this.mMol.getConnAtom$I$I(atom, i);
if (this.mMol.getConnBondOrder$I$I(atom, i) == 2 && this.mMol.getAtomicNo$I(oxygen[oxoCount]) == 8 ) ++oxoCount;
}
if ((atomicNo == 6 && oxoCount == 1 ) || (atomicNo == 16 && oxoCount == 2 ) ) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.setAtomicNo$I$I(atom, atomicNo == 6 ? 16 : 6);
if (atomicNo == 6) {
var newOxygen=this.mMolCopy.addAtom$I(8);
this.mMolCopy.addBond$I$I$I(atom, newOxygen, 2);
} else {
this.mMolCopy.deleteBond$I(this.mMol.getBond$I$I(atom, oxygen[1]));
}var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]);
var count=1;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var connAtom=this.mMol.getConnAtom$I$I(atom, i);
var isOxo=false;
for (var j=0; j < oxoCount; j++) {
if (connAtom != oxygen[j]) {
isOxo=true;
break;
}}
if (!isOxo) {
f_Educt*=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, connAtom]));
f_Product*=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, connAtom]);
++count;
}}
var p=10.0 * Math.pow(f_Product / f_Educt, 1.0 / count);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[1024, atom, oxygen[1], -1, -1, p]));
}}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForCloseRing$java_util_ArrayList$I',  function (mutationList, mode) {
for (var atom1=0; atom1 < this.mMol.getAtoms$(); atom1++) {
if (this.mIsPrimaryAtom[atom1]) {
var graphAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphBond=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphParent=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
var graphLevel=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
graphAtom[0]=atom1;
graphLevel[atom1]=1;
var current=0;
var highest=0;
while (current <= highest){
if (graphLevel[graphAtom[current]] >= 7) break;
for (var i=0; i < this.mMol.getConnAtoms$I(graphAtom[current]); i++) {
var candidate=this.mMol.getConnAtom$I$I(graphAtom[current], i);
if (graphLevel[candidate] == 0) {
graphParent[candidate]=graphAtom[current];
graphLevel[candidate]=graphLevel[graphAtom[current]] + 1;
graphBond[candidate]=this.mMol.getConnBond$I$I(graphAtom[current], i);
graphAtom[++highest]=candidate;
}}
++current;
}
var candidateIndex=2;
while (candidateIndex <= highest && graphLevel[candidateIndex] < 3 )++candidateIndex;

while (candidateIndex <= highest){
var atom2=graphAtom[candidateIndex++];
if (this.mMol.isSelectedAtom$I(atom2) || atom2 < atom1 ) continue;
if (this.mMol.getBond$I$I(atom1, atom2) != -1) continue;
if (!p$1.qualifiesForRing$IA$IA$IA$I$I.apply(this, [graphBond, graphLevel, graphParent, atom1, atom2])) continue;
for (var order=1; order <= 2; order++) {
if (this.mMol.getFreeValence$I(atom1) < order || this.mMol.getFreeValence$I(atom2) < order ) break;
if ((mode & 512) != 0 && order == 1 ) {
var ringAtom=Clazz.array(Integer.TYPE, [6]);
var ringSize=1 + this.mMol.getPath$IA$I$I$I$ZA(ringAtom, atom1, atom2, 5, null);
if (ringSize == 5 || ringSize == 6 ) {
var selectedAtomFound=false;
for (var i=1; i < ringSize - 1; i++) {
if (this.mMol.isSelectedAtom$I(ringAtom[i])) {
selectedAtomFound=true;
break;
}}
if (!selectedAtomFound) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.addBond$I$I$I(atom1, atom2, 1);
if (p$1.aromatizeRing$com_actelion_research_chem_StereoMolecule$IA$I.apply(this, [this.mMolCopy, ringAtom, ringSize])) {
var f_Educt=1.0;
var f_Product=1.0;
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
f_Educt/=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
f_Product*=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]);
}
var p=1.0 * Math.pow(f_Product / f_Educt, 1.0 / ringAtom.length);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$IA$D,[512, atom1, atom2, ringSize, ringAtom, p]));
}}}}}if ((mode & 32) != 0 && order == 1 ) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.addBond$I$I$I(atom1, atom2, p$1.getBondTypeFromOrder$I.apply(this, [order]));
var f_Educt1=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1]));
var f_Educt2=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
var f_Product1=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom1]);
var f_Product2=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom2]);
var p=(this.mAtomTypeList == null ) ? 1.0 : this.mAtomTypeList.getRingSizeAdjust$I(graphLevel[atom2]);
p*=1.0 * Math.sqrt(f_Product1 * f_Product2 / (f_Educt1 * f_Educt2));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_([32, atom1, atom2, p$1.getBondTypeFromOrder$I.apply(this, [order]), -1, p],$I$(6,1).c$$I$I$I$I$I$D));
}}}
}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForChangeBond$java_util_ArrayList',  function (mutationList) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
for (var i=0; i < 2; i++) {
var atom1=this.mMol.getBondAtom$I$I(i, bond);
if (this.mIsPrimaryAtom[atom1]) {
var atom2=this.mMol.getBondAtom$I$I(1 - i, bond);
if (!this.mMol.isSelectedAtom$I(atom2)) {
if (this.mIsPrimaryAtom[atom2]) {
if (atom2 < atom1) continue;
} else {
if (this.mCanonizer.getSymmetryRank$I(atom1) < this.mCanonizer.getSymmetryRank$I(atom2)) continue;
}var minFreeValence=this.mMol.getFreeValence$I(atom1);
if (minFreeValence > this.mMol.getFreeValence$I(atom2)) minFreeValence=this.mMol.getFreeValence$I(atom2);
var maxBondOrder=this.mMol.getBondOrder$I(bond) + minFreeValence;
if (maxBondOrder > 3) maxBondOrder=3;
if (this.mMol.isAromaticBond$I(bond)) {
if (this.mMol.getBondOrder$I(bond) == 1) continue;
maxBondOrder=2;
}if (this.mMol.isSmallRingBond$I(bond)) {
if (this.mMol.getBondOrder$I(bond) == 1 && this.mMol.getAtomPi$I(atom1) + this.mMol.getAtomPi$I(atom2) != 0 ) maxBondOrder=1;
 else if (maxBondOrder > 2) maxBondOrder=2;
}if (maxBondOrder == 2 && (this.mMol.getAtomicNo$I(atom1) < 5 || (this.mMol.getAtomicNo$I(atom1) > 8 && this.mMol.getAtomicNo$I(atom1) != 15  && this.mMol.getAtomicNo$I(atom1) != 16 )  || this.mMol.getAtomicNo$I(atom2) < 5  || (this.mMol.getAtomicNo$I(atom2) > 8 && this.mMol.getAtomicNo$I(atom2) != 15  && this.mMol.getAtomicNo$I(atom2) != 16 ) ) ) maxBondOrder=1;
for (var bondOrder=1; bondOrder <= maxBondOrder; bondOrder++) {
if (bondOrder == this.mMol.getBondOrder$I(bond)) continue;
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.setBondType$I$I(bond, p$1.getBondTypeFromOrder$I.apply(this, [bondOrder]));
var f_Educt1=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1]));
var f_Educt2=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
var f_Product1=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom1]);
var f_Product2=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom2]);
var p=Math.sqrt(f_Product1 * f_Product2 / (f_Educt1 * f_Educt2));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_([64, bond, -1, p$1.getBondTypeFromOrder$I.apply(this, [bondOrder]), -1, p],$I$(6,1).c$$I$I$I$I$I$D));
}}
}}}
}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForDeleteBond$java_util_ArrayList',  function (mutationList) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
if (this.mMol.isRingBond$I(bond)) {
for (var i=0; i < 2; i++) {
var atom1=this.mMol.getBondAtom$I$I(i, bond);
if (this.mIsPrimaryAtom[atom1]) {
var atom2=this.mMol.getBondAtom$I$I(1 - i, bond);
if (!this.mMol.isSelectedAtom$I(atom2)) {
if (this.mIsPrimaryAtom[atom2]) {
if (atom2 < atom1) continue;
} else {
if (this.mCanonizer.getSymmetryRank$I(atom1) < this.mCanonizer.getSymmetryRank$I(atom2)) continue;
}this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.deleteBond$I(bond);
var f_Educt1=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1]));
var f_Educt2=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
var f_Product1=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom1]);
var f_Product2=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom2]);
var p=Math.sqrt(f_Product1 * f_Product2 / (f_Educt1 * f_Educt2));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[128, bond, -1, -1, -1, p]));
}}}}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForChangeRing$java_util_ArrayList',  function (mutationList) {
this.mMol.ensureHelperArrays$I(7);
var ringSet=this.mMol.getRingSet$();
for (var ring=0; ring < ringSet.getSize$(); ring++) {
var ringSize=ringSet.getRingSize$I(ring);
if (ringSize == 5 || ringSize == 6 ) {
var ringAtom=ringSet.getRingAtoms$I(ring);
var fixedAtomFound=false;
for (var i=0; i < ringSize; i++) if (this.mMol.isSelectedAtom$I(ringAtom[i])) fixedAtomFound=true;

if (fixedAtomFound) continue;
var maxRank=0;
var maxAtom=-1;
for (var i=0; i < ringSize; i++) {
if (maxRank < this.mCanonizer.getSymmetryRank$I(ringAtom[i])) {
maxRank=this.mCanonizer.getSymmetryRank$I(ringAtom[i]);
maxAtom=ringAtom[i];
}}
if (this.mIsPrimaryAtom[maxAtom]) {
var ringBond=ringSet.getRingBonds$I(ring);
if (p$1.hasExocyclicPiBond$IA$IA.apply(this, [ringAtom, ringBond])) continue;
for (var heteroPosition=0; heteroPosition < ringSize; heteroPosition++) {
if (heteroPosition > 0 && (ringSize == 6 || ringSet.isAromatic$I(ring) ) ) break;
if (ringSize == 5 && this.mMol.getAtomicNo$I(ringAtom[heteroPosition]) != 7  && this.mMol.getAtomicNo$I(ringAtom[heteroPosition]) != 8  && this.mMol.getAtomicNo$I(ringAtom[heteroPosition]) != 16 ) continue;
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.ensureHelperArrays$I(7);
if (!p$1.changeAromaticity$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [this.mMolCopy, ring, heteroPosition])) continue;
var f_Educt=1.0;
var f_Product=1.0;
for (var atom=0; atom < ringSize; atom++) {
f_Educt*=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));
f_Product*=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]);
}
var p=1.0 * Math.pow(f_Product / f_Educt, 1.0 / ringSize);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[256, ring, -1, heteroPosition, -1, p]));
}}
}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForMigrate$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom] && this.mMol.getConnAtoms$I(atom) > 2 ) {
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var migratingAtom=this.mMol.getConnAtom$I$I(atom, i);
if (!this.mMol.isSelectedAtom$I(migratingAtom)) {
var migratingBond=this.mMol.getConnBond$I$I(atom, i);
if (!this.mMol.isRingBond$I(migratingBond) && this.mMol.getBondOrder$I(migratingBond) == 1 ) {
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) {
if (i == j) continue;
var destinationAtom=this.mMol.getConnAtom$I$I(atom, j);
if (this.mIsPrimaryAtom[destinationAtom] && this.mMol.getFreeValence$I(destinationAtom) > 0 ) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
for (var k=0; k < 2; k++) if (this.mMolCopy.getBondAtom$I$I(k, migratingBond) == atom) this.mMolCopy.setBondAtom$I$I$I(k, migratingBond, destinationAtom);

var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, migratingAtom])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, destinationAtom])) ;
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atom]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, migratingAtom]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, destinationAtom]) ;
var p=Math.sqrt(f_Product / f_Educt);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[2048, migratingBond, -1, atom, destinationAtom, p]));
}}}
}}}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForSwapSubstituent$java_util_ArrayList$java_util_ArrayList',  function (mutationList, substituentList) {
for (var s1, $s1 = substituentList.iterator$(); $s1.hasNext$()&&((s1=($s1.next$())),1);) {
if (this.mIsPrimaryAtom[s1.firstAtom]) {
for (var s2, $s2 = substituentList.iterator$(); $s2.hasNext$()&&((s2=($s2.next$())),1);) {
if (this.mIsPrimaryAtom[s2.firstAtom] && s1.coreAtom != s2.coreAtom  && s1.bond != s2.bond ) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
for (var k=0; k < 2; k++) {
if (this.mMolCopy.getBondAtom$I$I(k, s1.bond) == s1.firstAtom) this.mMolCopy.setBondAtom$I$I$I(k, s1.bond, s2.firstAtom);
if (this.mMolCopy.getBondAtom$I$I(k, s2.bond) == s2.firstAtom) this.mMolCopy.setBondAtom$I$I$I(k, s2.bond, s1.firstAtom);
}
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, s1.coreAtom])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, s1.firstAtom])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, s2.coreAtom])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, s2.firstAtom])) ;
var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, s1.coreAtom]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, s1.firstAtom]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, s2.coreAtom]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, s2.firstAtom]) ;
var p=Math.sqrt(f_Product / f_Educt);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[4096, s1.coreAtom, s2.coreAtom, s1.firstAtom, s2.firstAtom, p]));
}}}
}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForDeleteSubstituent$java_util_ArrayList$java_util_ArrayList',  function (mutationList, substituentList) {
for (var s, $s = substituentList.iterator$(); $s.hasNext$()&&((s=($s.next$())),1);) {
if (this.mIsPrimaryAtom[s.coreAtom]) {
var isMemberAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAllAtoms$()]);
this.mMol.getSubstituent$I$I$ZA$com_actelion_research_chem_ExtendedMolecule$IA(s.coreAtom, s.firstAtom, isMemberAtom, null, null);
var selectedAtomFound=false;
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) {
if (isMemberAtom[atom] && this.mMol.isSelectedAtom$I(atom) ) {
selectedAtomFound=true;
break;
}}
if (!selectedAtomFound) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.deleteBond$I(s.bond);
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, s.coreAtom]));
var f_Deleted=1.0;
for (var atom, $atom = 0, $$atom = s.atoms; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) f_Deleted*=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom]));

var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, s.coreAtom]);
var p=f_Product / (f_Educt * Math.pow(f_Deleted, 1.0 / s.atoms.length));
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[8192, s.coreAtom, -1, s.firstAtom, -1, p]));
}}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForCutOutFragment$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mIsPrimaryAtom[atom] && this.mMol.getConnAtoms$I(atom) > 2 ) {
var ringBondCount=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) if (this.mMol.isRingBond$I(this.mMol.getConnBond$I$I(atom, i))) ++ringBondCount;

if (ringBondCount <= 2) {
for (var i=1; i < this.mMol.getConnAtoms$I(atom); i++) {
var atom1=this.mMol.getConnAtom$I$I(atom, i);
var bond1=this.mMol.getConnBond$I$I(atom, i);
if (this.mMol.getBondOrder$I(bond1) != 1) continue;
for (var j=0; j < i; j++) {
var atom2=this.mMol.getConnAtom$I$I(atom, j);
var bond2=this.mMol.getConnBond$I$I(atom, j);
if (this.mMol.getBondOrder$I(bond2) != 1) continue;
var coveredRingBondCount=(this.mMol.isRingBond$I(bond1) ? 1 : 0) + (this.mMol.isRingBond$I(bond2) ? 1 : 0);
if (coveredRingBondCount == ringBondCount) {
this.mMol.copyMolecule$com_actelion_research_chem_Molecule(this.mMolCopy);
this.mMolCopy.setBondAtom$I$I$I(0, bond1, atom1);
this.mMolCopy.setBondAtom$I$I$I(1, bond1, atom2);
this.mMolCopy.deleteBond$I(bond2);
var deletedAtoms=this.mMolCopy.getFragmentAtoms$I(atom);
var selectedAtomFound=false;
for (var deletedAtom, $deletedAtom = 0, $$deletedAtom = deletedAtoms; $deletedAtom<$$deletedAtom.length&&((deletedAtom=($$deletedAtom[$deletedAtom])),1);$deletedAtom++) {
if (this.mMol.isSelectedAtom$I(deletedAtom)) {
selectedAtomFound=true;
break;
}}
if (!selectedAtomFound) {
var atomMap=this.mMolCopy.deleteAtoms$IA(deletedAtoms);
var f_Educt=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom1])) * Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, atom2]));
var f_Deleted=1.0;
for (var deletedAtom, $deletedAtom = 0, $$deletedAtom = deletedAtoms; $deletedAtom<$$deletedAtom.length&&((deletedAtom=($$deletedAtom[$deletedAtom])),1);$deletedAtom++) f_Deleted*=Math.max(9.999999747378752E-6, p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMol, deletedAtom]));

var f_Product=p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atomMap[atom1]]) * p$1.getFrequency$com_actelion_research_chem_StereoMolecule$I.apply(this, [this.mMolCopy, atomMap[atom2]]);
var p=Math.sqrt(f_Product / f_Educt) / Math.pow(f_Deleted, 1.0 / deletedAtoms.length);
if (p > 0.0  && p$1.isValidStructure$com_actelion_research_chem_StereoMolecule.apply(this, [this.mMolCopy]) ) {
if (this.mBiasProvider != null ) p*=this.mBiasProvider.getBiasFactor$com_actelion_research_chem_StereoMolecule(this.mMolCopy);
mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[16384, atom, -1, atom1, atom2, p]));
}}}}
}
}}}
}, p$1);

Clazz.newMeth(C$, 'addProbabilitiesForInvertParity$java_util_ArrayList',  function (mutationList) {
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) if (this.mIsPrimaryAtom[atom] && this.mMol.isAtomStereoCenter$I(atom) ) mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[32768, atom, -1, -1, -1, 1.0]));

for (var bond=0; bond < this.mMol.getBonds$(); bond++) if ((this.mIsPrimaryAtom[this.mMol.getBondAtom$I$I(0, bond)] || this.mIsPrimaryAtom[this.mMol.getBondAtom$I$I(1, bond)] ) && this.mMol.getBondParity$I(bond) != 0 ) mutationList.add$O(Clazz.new_($I$(6,1).c$$I$I$I$I$I$D,[32768, -1, bond, -1, -1, 1.0]));

}, p$1);

Clazz.newMeth(C$, 'createSubstituentList',  function () {
var substituentList=Clazz.new_($I$(5,1));
var isCentralAtom=$I$(7).findMurckoScaffold$com_actelion_research_chem_StereoMolecule(this.mMol);
if (isCentralAtom != null ) {
for (var bond=0; bond < this.mMol.getBonds$(); bond++) {
for (var i=0; i < 2; i++) {
var atom1=this.mMol.getBondAtom$I$I(i, bond);
var atom2=this.mMol.getBondAtom$I$I(1 - i, bond);
if (isCentralAtom[atom1] && !isCentralAtom[atom2] && !this.mMol.isSelectedAtom$I(atom1) && !this.mMol.isSelectedAtom$I(atom2)  ) {
substituentList.add$O(Clazz.new_($I$(8,1).c$$I$I$I,[this, null, atom1, atom2, bond]));
}}
}
}return substituentList;
}, p$1);

Clazz.newMeth(C$, 'getFrequency$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (this.mAtomTypeList != null ) {
try {
var atomType=$I$(9).getAtomType$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, 32190);
return this.mAtomTypeList.getProbabilityFromType$J(atomType);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return 0.0;
} else {
throw e;
}
}
}return 1.0;
}, p$1);

Clazz.newMeth(C$, 'selectLikelyMutation$java_util_ArrayList',  function (mutationList) {
var probabilitySum=0.0;
for (var m, $m = mutationList.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) probabilitySum+=m.mProbability;

var selector=this.mRandom.nextDouble$() * probabilitySum;
probabilitySum=0.0;
for (var m, $m = mutationList.iterator$(); $m.hasNext$()&&((m=($m.next$())),1);) {
probabilitySum+=m.mProbability;
if (selector < probabilitySum ) {
mutationList.remove$O(m);
return m;
}}
return null;
}, p$1);

Clazz.newMeth(C$, 'performMutation$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_Mutation',  function (mol, mutation) {
mol.ensureHelperArrays$I(15);
switch (mutation.mMutationType) {
case 1:
var newAtom=mol.addAtom$I(mutation.mSpecifier1);
mol.addBond$I$I$I(mutation.mWhere1, newAtom, mutation.mSpecifier2);
break;
case 2:
var atom1=mol.getBondAtom$I$I(0, mutation.mWhere1);
var atom2=mol.getBondAtom$I$I(1, mutation.mWhere1);
mol.deleteBond$I(mutation.mWhere1);
newAtom=mol.addAtom$I(mutation.mSpecifier1);
mol.addBond$I$I$I(atom1, newAtom, 1);
mol.addBond$I$I$I(atom2, newAtom, 1);
break;
case 4:
mol.setAtomicNo$I$I(mutation.mWhere1, mutation.mSpecifier1);
break;
case 16:
mol.deleteAtom$I(mutation.mWhere1);
break;
case 8:
atom1=mol.getConnAtom$I$I(mutation.mWhere1, 0);
atom2=mol.getConnAtom$I$I(mutation.mWhere1, 1);
mol.addBond$I$I$I(atom1, atom2, 1);
mol.deleteAtom$I(mutation.mWhere1);
break;
case 32:
mol.addBond$I$I$I(mutation.mWhere1, mutation.mWhere2, mutation.mSpecifier1);
break;
case 512:
mol.addBond$I$I$I(mutation.mWhere1, mutation.mWhere2, mutation.mSpecifier1);
p$1.aromatizeRing$com_actelion_research_chem_StereoMolecule$IA$I.apply(this, [mol, mutation.mAtomList, mutation.mSpecifier1]);
break;
case 1024:
if (mol.getAtomicNo$I(mutation.mWhere1) == 6) {
mol.setAtomicNo$I$I(mutation.mWhere1, 16);
mol.addBond$I$I$I(mutation.mWhere1, mol.addAtom$I(8), 2);
} else {
mol.setAtomicNo$I$I(mutation.mWhere1, 6);
mol.deleteAtom$I(mutation.mWhere2);
}break;
case 64:
mol.setBondType$I$I(mutation.mWhere1, mutation.mSpecifier1);
break;
case 128:
mol.deleteBond$I(mutation.mWhere1);
break;
case 256:
p$1.changeAromaticity$com_actelion_research_chem_StereoMolecule$I$I.apply(this, [mol, mutation.mWhere1, mutation.mSpecifier1]);
break;
case 2048:
for (var i=0; i < 2; i++) if (mol.getBondAtom$I$I(i, mutation.mWhere1) == mutation.mSpecifier1) mol.setBondAtom$I$I$I(i, mutation.mWhere1, mutation.mSpecifier2);

break;
case 8192:
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
mol.getSubstituent$I$I$ZA$com_actelion_research_chem_ExtendedMolecule$IA(mutation.mWhere1, mutation.mSpecifier1, atomMask, null, null);
mol.deleteAtoms$ZA(atomMask);
break;
case 16384:
var rootAtom=mutation.mWhere1;
atom1=mutation.mSpecifier1;
atom2=mutation.mSpecifier2;
var bond1=-1;
var bond2=-1;
for (var i=0; i < mol.getConnAtoms$I(rootAtom); i++) {
if (mol.getConnAtom$I$I(rootAtom, i) == atom1) bond1=mol.getConnBond$I$I(rootAtom, i);
 else if (mol.getConnAtom$I$I(rootAtom, i) == atom2) bond2=mol.getConnBond$I$I(rootAtom, i);
}
if (bond1 != -1 && bond2 != -1 ) {
mol.deleteBond$I(bond1);
mol.deleteBond$I(bond2);
var atomMap=mol.deleteAtoms$IA(mol.getFragmentAtoms$I(rootAtom));
mol.addBond$I$I$I(atomMap[atom1], atomMap[atom2], 1);
}break;
case 32768:
if (mutation.mWhere1 != -1) mol.setAtomParity$I$I$Z(mutation.mWhere1, mol.getAtomParity$I(mutation.mWhere1) != 1 ? 1 : 2, false);
if (mutation.mWhere2 != -1) mol.setBondParity$I$I$Z(mutation.mWhere2, mol.getBondParity$I(mutation.mWhere2) != 1 ? 1 : 2, false);
break;
}
p$1.repairCharges$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
mol.setParitiesValid$I(0);
Clazz.new_($I$(10,1)).invent$com_actelion_research_chem_StereoMolecule(mol);
mol.invalidateHelperArrays$I(255);
p$1.repairStereoChemistry$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
});

Clazz.newMeth(C$, 'getBondTypeFromOrder$I',  function (bondOrder) {
switch (bondOrder) {
case 1:
return 1;
case 2:
return 2;
case 3:
return 4;
}
return 0;
}, p$1);

Clazz.newMeth(C$, 'qualifiesForRing$IA$IA$IA$I$I',  function (graphBond, graphLevel, graphParent, atom1, atom2) {
var ringSize=graphLevel[atom2];
var firstConsecutiveRingAtom=0;
var firstMaxConsecutiveRingAtom=0;
var lastMaxConsecutiveRingAtom=0;
var consecutiveRingBonds=0;
var maxConsecutiveRingBonds=0;
var currentAtom=atom2;
while (currentAtom != atom1){
if (this.mMol.getAtomPi$I(currentAtom) == 2) {
if (this.mMol.getConnBondOrder$I$I(currentAtom, 0) == 2) {
if (ringSize < 9) return false;
} else {
if (ringSize < 10) return false;
}}if (this.mMol.isRingBond$I(graphBond[currentAtom])) {
if (consecutiveRingBonds == 0) firstConsecutiveRingAtom=currentAtom;
++consecutiveRingBonds;
} else {
if (maxConsecutiveRingBonds < consecutiveRingBonds) {
maxConsecutiveRingBonds=consecutiveRingBonds;
firstMaxConsecutiveRingAtom=firstConsecutiveRingAtom;
lastMaxConsecutiveRingAtom=currentAtom;
}consecutiveRingBonds=0;
}currentAtom=graphParent[currentAtom];
}
if (maxConsecutiveRingBonds < consecutiveRingBonds) {
maxConsecutiveRingBonds=consecutiveRingBonds;
firstMaxConsecutiveRingAtom=firstConsecutiveRingAtom;
lastMaxConsecutiveRingAtom=currentAtom;
}var penalty=maxConsecutiveRingBonds;
if (maxConsecutiveRingBonds > 0 && ((this.mMol.isAromaticAtom$I(firstMaxConsecutiveRingAtom) || this.mMol.isAromaticAtom$I(lastMaxConsecutiveRingAtom) ) || (this.mMol.getAtomPi$I(firstMaxConsecutiveRingAtom) > 0 && this.mMol.getAtomPi$I(lastMaxConsecutiveRingAtom) > 0 ) ) ) ++penalty;
if (ringSize - penalty < 3) return false;
return true;
}, p$1);

Clazz.newMeth(C$, 'isValidStructure$com_actelion_research_chem_StereoMolecule',  function (mol) {
var MAX_FORBIDDEN_BRIDGE_LENGTH_AROM=Clazz.array(Integer.TYPE, -2, [null, null, null, Clazz.array(Integer.TYPE, -1, [-1, 2]), Clazz.array(Integer.TYPE, -1, [-1, 2, 6]), Clazz.array(Integer.TYPE, -1, [-1, 1, 5]), Clazz.array(Integer.TYPE, -1, [-1, 1, 4, 6]), Clazz.array(Integer.TYPE, -1, [-1, 1, 4, 6])]);
var MAX_FORBIDDEN_BRIDGE_LENGTH_PI=Clazz.array(Integer.TYPE, -2, [null, null, null, Clazz.array(Integer.TYPE, -1, [-1, 1]), Clazz.array(Integer.TYPE, -1, [-1, 1, 5]), Clazz.array(Integer.TYPE, -1, [-1, 1, 4]), Clazz.array(Integer.TYPE, -1, [-1, 0, 3, 4]), Clazz.array(Integer.TYPE, -1, [-1, 0, 2, 3])]);
var MAX_FORBIDDEN_BRIDGE_LENGTH_ALIPH=Clazz.array(Integer.TYPE, -2, [null, null, null, Clazz.array(Integer.TYPE, -1, [-1, 0]), Clazz.array(Integer.TYPE, -1, [-1, -1, 3]), Clazz.array(Integer.TYPE, -1, [-1, -1, 0]), Clazz.array(Integer.TYPE, -1, [-1, -1, 0, -1]), Clazz.array(Integer.TYPE, -1, [-1, -1, 0, -1])]);
mol.ensureHelperArrays$I(7);
var ringSet=mol.getRingSet$();
var neglectAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var ring=0; ring < ringSet.getSize$() && (ringSet.getRingSize$I(ring) < 8) ; ring++) {
var ringAtom=ringSet.getRingAtoms$I(ring);
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) neglectAtom[atom]=true;

var ringSize=ringSet.getRingSize$I(ring);
for (var i=1; i < ringSize; i++) {
if (mol.getConnAtoms$I(ringAtom[i]) > 2) {
for (var ci=0; ci < mol.getConnAtoms$I(ringAtom[i]); ci++) {
var atom1=mol.getConnAtom$I$I(ringAtom[i], ci);
if (mol.isRingAtom$I(atom1) && !ringSet.isAtomMember$I$I(ring, atom1) ) {
for (var j=0; j < i; j++) {
if (mol.getConnAtoms$I(ringAtom[j]) > 2) {
for (var cj=0; cj < mol.getConnAtoms$I(ringAtom[j]); cj++) {
var atom2=mol.getConnAtom$I$I(ringAtom[j], cj);
if (mol.isRingAtom$I(atom2) && !ringSet.isAtomMember$I$I(ring, atom2) ) {
var ringDif=Math.min(i - j, ringSize - i + j);
var pi1=mol.getAtomPi$I(ringAtom[i]);
var pi2=mol.getAtomPi$I(ringAtom[j]);
var maxForbiddenLength=(ringSet.isAromatic$I(ring) || (pi1 != 0 && pi2 != 0 ) ) ? MAX_FORBIDDEN_BRIDGE_LENGTH_AROM[ringSize][ringDif] : (pi1 != 0 || pi2 != 0 ) ? MAX_FORBIDDEN_BRIDGE_LENGTH_PI[ringSize][ringDif] : MAX_FORBIDDEN_BRIDGE_LENGTH_ALIPH[ringSize][ringDif];
if (maxForbiddenLength != -1 && mol.getPathLength$I$I$I$ZA(atom1, atom2, maxForbiddenLength, neglectAtom) != -1 ) return false;
}}
}}
}}
}}
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) neglectAtom[atom]=false;

}
return true;
}, p$1);

Clazz.newMeth(C$, 'hasExocyclicPiBond$IA$IA',  function (ringAtom, ringBond) {
for (var i=0; i < ringAtom.length; i++) {
for (var j=0; j < this.mMol.getConnAtoms$I(ringAtom[i]); j++) {
var connBond=this.mMol.getConnBond$I$I(ringAtom[i], j);
var bondIsInRing=false;
for (var k=0; k < ringBond.length; k++) {
if (connBond == ringBond[k]) {
bondIsInRing=true;
break;
}}
if (!bondIsInRing && (this.mMol.isAromaticBond$I(connBond) || this.mMol.getBondOrder$I(connBond) > 1 ) ) return true;
}
}
return false;
}, p$1);

Clazz.newMeth(C$, 'changeAromaticity$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, ring, heteroPosition) {
mol.ensureHelperArrays$I(7);
var ringSet=mol.getRingSet$();
var ringSize=ringSet.getRingSize$I(ring);
var ringAtom=ringSet.getRingAtoms$I(ring);
var ringBond=ringSet.getRingBonds$I(ring);
if (ringSet.isAromatic$I(ring)) {
for (var i=0; i < ringSize; i++) mol.setBondType$I$I(ringBond[i], 1);

return true;
} else {
for (var i=0; i < ringSize; i++) mol.setBondType$I$I(ringBond[i], 1);

if (ringSize == 5) {
for (var i=0; i < ringSize; i++) {
if (heteroPosition != i) {
if (mol.getFreeValence$I(ringAtom[i]) < 1) return false;
if (mol.getAtomicNo$I(ringAtom[i]) != 6 && mol.getAtomicNo$I(ringAtom[i]) != 7 ) return false;
}}
var doubleBondPosition1=heteroPosition + 1;
var doubleBondPosition2=heteroPosition + 3;
if (doubleBondPosition1 > 4) doubleBondPosition1-=5;
if (doubleBondPosition2 > 4) doubleBondPosition2-=5;
mol.setBondType$I$I(doubleBondPosition1, 2);
mol.setBondType$I$I(doubleBondPosition2, 2);
return true;
}if (ringSize == 6) {
for (var i=0; i < ringSize; i++) {
if (mol.getFreeValence$I(ringAtom[i]) < 1) return false;
if (mol.getAtomicNo$I(ringAtom[i]) != 6 && mol.getAtomicNo$I(ringAtom[i]) != 7 ) return false;
}
for (var i=0; i < ringSize; i+=2) mol.setBondType$I$I(ringBond[i], 2);

return true;
}}return false;
}, p$1);

Clazz.newMeth(C$, 'repairCharges$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == 7 && (mol.getConnAtoms$I(atom) + mol.getAtomPi$I(atom)) == 4 ) {
mol.setAtomCharge$I$I(atom, 1);
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var connAtom=mol.getConnAtom$I$I(atom, i);
if ((mol.getAtomicNo$I(connAtom) == 7 && (mol.getConnAtoms$I(connAtom) + mol.getAtomPi$I(connAtom)) < 3 ) || (mol.getAtomicNo$I(connAtom) == 8 && (mol.getConnAtoms$I(connAtom) + mol.getAtomPi$I(connAtom)) < 2 ) ) {
mol.setAtomCharge$I$I(connAtom, -1);
}}
}if (mol.getAtomicNo$I(atom) == 6 && mol.getAtomCharge$I(atom) != 0 ) {
mol.setAtomCharge$I$I(atom, 0);
}}
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomCharge$I(atom) != 0) {
var chargedNeighborFound=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
if (mol.getAtomCharge$I(mol.getConnAtom$I$I(atom, i)) != 0) {
chargedNeighborFound=true;
break;
}}
if (!chargedNeighborFound) {
var valence=mol.getConnAtoms$I(atom) + mol.getAtomPi$I(atom);
var maxValence=mol.getMaxValenceUncharged$I(atom);
if (valence <= maxValence) mol.setAtomCharge$I$I(atom, 0);
}}}
}, p$1);

Clazz.newMeth(C$, 'repairStereoChemistry$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(15);
for (var bond=0; bond < mol.getAllBonds$(); bond++) if (mol.isStereoBond$I(bond)) mol.setBondType$I$I(bond, 1);

for (var atom=0; atom < mol.getAtoms$(); atom++) {
var parity=mol.getAtomParity$I(atom);
if (parity == 3) {
parity=(this.mRandom.nextDouble$() < 0.5 ) ? 1 : 2;
var isPseudo=mol.isAtomParityPseudo$I(atom);
mol.setAtomParity$I$I$Z(atom, parity, isPseudo);
mol.setAtomESR$I$I$I(atom, 0, 0);
}if (parity != 0) mol.setStereoBondFromAtomParity$I(atom);
}
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.isBINAPChiralityBond$I(bond)) {
switch (mol.getBondParity$I(bond)) {
case 3:
var parity=(this.mRandom.nextDouble$() < 0.5 ) ? 1 : 2;
var isPseudo=mol.isBondParityPseudo$I(bond);
mol.setBondParity$I$I$Z(bond, parity, isPseudo);
case 1:
case 2:
mol.setStereoBondFromBondParity$I(bond);
break;
}
}}
}, p$1);

Clazz.newMeth(C$, 'aromatizeRing$com_actelion_research_chem_StereoMolecule$IA$I',  function (mol, ringAtom, ringSize) {
mol.ensureHelperArrays$I(1);
var leakIndex=-1;
for (var i=0; i < ringSize; i++) {
var atomicNo=mol.getAtomicNo$I(ringAtom[i]);
if (atomicNo == 8 || atomicNo == 16 ) {
if (ringSize == 6) return false;
if (leakIndex != -1) return false;
leakIndex=i;
} else if (atomicNo == 7) {
if (mol.getFreeValence$I(ringAtom[i]) == 0 && mol.getAtomPi$I(ringAtom[i]) == 0 ) {
if (leakIndex != -1) return false;
leakIndex=i;
}} else if (atomicNo != 6) {
return false;
}}
if (leakIndex == -1 && ringSize == 5 ) {
for (var i=0; i < ringSize; i++) {
if (mol.getAtomicNo$I(ringAtom[i]) == 7) {
leakIndex=i;
break;
}}
}var ringBond=Clazz.array(Integer.TYPE, [ringSize]);
for (var i=0; i < ringSize; i++) ringBond[i]=mol.getBond$I$I(ringAtom[i], ringAtom[i != 0 ? i - 1 : ringSize - 1]);

for (var i=0; i < ringSize; i++) {
var atom1=ringAtom[i == 0 ? ringSize - 1 : i - 1];
var atom2=ringAtom[i == ringSize - 1 ? 0 : i + 1];
for (var j=0; j < mol.getConnAtoms$I(ringAtom[i]); j++) {
var connAtom=mol.getConnAtom$I$I(ringAtom[i], j);
if (connAtom != atom1 && connAtom != atom2  && mol.getConnBondOrder$I$I(ringAtom[i], j) != 1 ) mol.setBondType$I$I(mol.getConnBond$I$I(ringAtom[i], j), 1);
}
}
for (var i=0; i < ringSize; i++) mol.setBondType$I$I(ringBond[i], 1);

var doubleBondIndex=(leakIndex == -1) ? 0 : leakIndex + 2;
var doubleBondCount=(ringSize == 5) ? 2 : 3;
for (var i=0; i < doubleBondCount; i++) {
if (doubleBondIndex >= ringSize) doubleBondIndex-=ringSize;
mol.setBondType$I$I(ringBond[doubleBondIndex], 2);
doubleBondIndex+=2;
}
return true;
}, p$1);

Clazz.newMeth(C$, 'printMutationList$java_util_ArrayList$Z',  function (mutationList, sortByPriority) {
var mutation=mutationList.toArray$OA(Clazz.array($I$(6), [0]));
if (sortByPriority) $I$(11,"sort$OA$java_util_Comparator",[mutation, ((P$.Mutator$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Mutator$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_Mutation$com_actelion_research_chem_Mutation','compare$O$O'],  function (m1, m2) {
return m1.mProbability > m2.mProbability  ? -1 : m1.mProbability < m2.mProbability  ? 1 : 0;
});
})()
), Clazz.new_(P$.Mutator$1.$init$,[this, null]))]);
System.out.println$S("Mutation list (" + mutationList.size$() + " mutations):" );
for (var m, $m = 0, $$m = mutation; $m<$$m.length&&((m=($$m[$m])),1);$m++) System.out.println$S(m.toString());

});
;
(function(){/*c*/var C$=Clazz.newClass(P$.Mutator, "MutatorSubstituent", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['coreAtom','firstAtom','bond'],'O',['atoms','int[]']]]

Clazz.newMeth(C$, 'c$$I$I$I',  function (coreAtom, firstAtom, bond) {
;C$.$init$.apply(this);
this.coreAtom=coreAtom;
this.firstAtom=firstAtom;
this.bond=bond;
var isMember=Clazz.array(Boolean.TYPE, [this.b$['com.actelion.research.chem.Mutator'].mMol.getAllAtoms$()]);
var count=this.b$['com.actelion.research.chem.Mutator'].mMol.getSubstituent$I$I$ZA$com_actelion_research_chem_ExtendedMolecule$IA(coreAtom, firstAtom, isMember, null, null);
this.atoms=Clazz.array(Integer.TYPE, [count]);
for (var atom=0, i=0; atom < this.b$['com.actelion.research.chem.Mutator'].mMol.getAllAtoms$(); atom++) if (isMember[atom]) this.atoms[i++]=atom;

}, 1);

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
