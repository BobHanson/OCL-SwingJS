(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'java.util.ArrayList','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PossibleMappingsFrag2Mol");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexProcessingArray','indexAtomFrag','ringClosures','sizeArrayMappingMolecules'],'O',['parent','com.actelion.research.chem.mcs.PossibleMappingsFrag2Mol','arrIndexCounterAtomFragRingClosure','int[]','+arrIndexAtomMolMapping','liChild','java.util.List']]]

Clazz.newMeth(C$, 'c$$I$I',  function (indexProcessingArray, capacityMappings) {
;C$.$init$.apply(this);
this.indexProcessingArray=indexProcessingArray;
this.indexAtomFrag=-1;
this.arrIndexCounterAtomFragRingClosure=Clazz.array(Integer.TYPE, [8]);
this.arrIndexAtomMolMapping=Clazz.array(Integer.TYPE, [capacityMappings]);
this.sizeArrayMappingMolecules=0;
this.ringClosures=0;
this.liChild=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.parent=null;
this.indexAtomFrag=-1;
this.ringClosures=0;
this.sizeArrayMappingMolecules=0;
this.liChild.clear$();
});

Clazz.newMeth(C$, 'resetMappingMolecules$',  function () {
this.sizeArrayMappingMolecules=0;
});

Clazz.newMeth(C$, 'c$$I',  function (indexProcessingArray) {
C$.c$$I$I.apply(this, [indexProcessingArray, 8]);
}, 1);

Clazz.newMeth(C$, 'addChild$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol',  function (child) {
p$1.setParent$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol.apply(child, [this]);
this.liChild.add$O(child);
});

Clazz.newMeth(C$, 'addIndexMappingAtomMolecule$I',  function (indexMolAtom) {
this.arrIndexAtomMolMapping[this.sizeArrayMappingMolecules]=indexMolAtom;
++this.sizeArrayMappingMolecules;
});

Clazz.newMeth(C$, 'addIndexCounterAtomFragmentRingClosure$I',  function (indexCounterAtomFragmentRingClosure) {
this.arrIndexCounterAtomFragRingClosure[this.ringClosures]=indexCounterAtomFragmentRingClosure;
++this.ringClosures;
});

Clazz.newMeth(C$, 'getIndexCounterAtomFragmentRingClosure$I',  function (i) {
return this.arrIndexCounterAtomFragRingClosure[i];
});

Clazz.newMeth(C$, 'getRingClosures$',  function () {
return this.ringClosures;
});

Clazz.newMeth(C$, 'getIndexAtomFrag$',  function () {
return this.indexAtomFrag;
});

Clazz.newMeth(C$, 'getChilds$',  function () {
return this.liChild.size$();
});

Clazz.newMeth(C$, 'getChild$I',  function (indexChild) {
return this.liChild.get$I(indexChild);
});

Clazz.newMeth(C$, 'empty$',  function () {
return (this.sizeArrayMappingMolecules == 0) ? true : false;
});

Clazz.newMeth(C$, 'getIndexProcessingArray$',  function () {
return this.indexProcessingArray;
});

Clazz.newMeth(C$, 'pollIndexMappingAtomMolecule$',  function () {
var indexAtomMol=this.arrIndexAtomMolMapping[this.sizeArrayMappingMolecules - 1];
--this.sizeArrayMappingMolecules;
return indexAtomMol;
});

Clazz.newMeth(C$, 'getParent$',  function () {
return this.parent;
});

Clazz.newMeth(C$, 'setParent$com_actelion_research_chem_mcs_PossibleMappingsFrag2Mol',  function (parent) {
this.parent=parent;
}, p$1);

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(2,1));
if (this.parent != null ) {
sb.append$S("Parent " + this.parent.indexAtomFrag);
sb.append$S(", fragment atom " + this.indexAtomFrag);
} else {
sb.append$S("No parent, fragment atom " + this.indexAtomFrag);
}sb.append$S(", mapping mol atms ");
for (var i=0; i < this.sizeArrayMappingMolecules; i++) {
sb.append$I(this.arrIndexAtomMolMapping[i]);
if (i < this.sizeArrayMappingMolecules - 1) {
sb.append$S(",");
}}
sb.append$S(".");
return sb.toString();
});

Clazz.newMeth(C$, 'setIndexAtomFrag$I',  function (indexAtomFrag) {
this.indexAtomFrag=indexAtomFrag;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:14 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
