(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.ArrayList',['java.awt.geom.Line2D','.Double'],'java.awt.BasicStroke','java.awt.geom.GeneralPath',['java.awt.geom.Ellipse2D','.Double'],'java.awt.Color']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Depictor2D", null, 'com.actelion.research.chem.AbstractDepictor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mCurrentStringWidth'],'F',['mLineWidth'],'I',['mpTextSize'],'S',['mCurrentString'],'O',['mFonts','java.util.ArrayList','mCurrentFont','java.awt.Font','mCurrentGlyphVector','java.awt.font.GlyphVector']]
,['Z',['isMac']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule.apply(this,[mol]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, displayMode) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$I.apply(this,[mol, displayMode]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'init$',  function () {
C$.superclazz.prototype.init$.apply(this, []);
this.mFonts=Clazz.new_($I$(1,1));
this.mLineWidth=1.0;
});

Clazz.newMeth(C$, 'drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
if (C$.isMac) this.mContext.draw$java_awt_Shape(Clazz.new_($I$(2,1).c$$D$D$D$D,[theLine.x1 - 0.5, theLine.y1 - 0.5, theLine.x2 - 0.5, theLine.y2 - 0.5]));
 else this.mContext.draw$java_awt_Shape(Clazz.new_($I$(2,1).c$$D$D$D$D,[theLine.x1, theLine.y1, theLine.x2, theLine.y2]));
});

Clazz.newMeth(C$, 'drawDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var stroke=this.mContext.getStroke$();
this.mContext.setStroke$java_awt_Stroke(Clazz.new_([this.mLineWidth, 1, 1, this.mLineWidth, Clazz.array(Float.TYPE, -1, [3.0 * this.mLineWidth]), 0.0],$I$(3,1).c$$F$I$I$F$FA$F));
this.drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine(theLine);
this.mContext.setStroke$java_awt_Stroke(stroke);
});

Clazz.newMeth(C$, 'drawString$S$D$D',  function (theString, x, y) {
var strWidth=this.getStringWidth$S(theString);
if (true ||false) {
this.mContext.drawString$S$F$F(theString, (x - strWidth / 2.0), (y + this.mpTextSize / 3.0));
} else {
this.mContext.drawGlyphVector$java_awt_font_GlyphVector$F$F(this.mCurrentGlyphVector, (x - strWidth / 2.0), (y + this.mpTextSize / 3.0));
}});

Clazz.newMeth(C$, 'drawPolygon$com_actelion_research_gui_generic_GenericPolygon',  function (p) {
var polygon=Clazz.new_([1, p.getSize$()],$I$(4,1).c$$I$I);
polygon.moveTo$D$D(p.getX$I(0), p.getY$I(0));
for (var i=1; i < p.getSize$(); i++) polygon.lineTo$D$D(p.getX$I(i), p.getY$I(i));

polygon.closePath$();
this.mContext.fill$java_awt_Shape(polygon);
if (C$.isMac) {
polygon=Clazz.new_([1, p.getSize$()],$I$(4,1).c$$I$I);
polygon.moveTo$D$D(p.getX$I(0) - 0.5, p.getY$I(0) - 0.5);
for (var i=1; i < p.getSize$(); i++) polygon.lineTo$D$D(p.getX$I(i) - 0.5, p.getY$I(i) - 0.5);

polygon.closePath$();
}this.mContext.draw$java_awt_Shape(polygon);
});

Clazz.newMeth(C$, 'fillCircle$D$D$D',  function (x, y, d) {
if (C$.isMac) this.mContext.fill$java_awt_Shape(Clazz.new_($I$(5,1).c$$D$D$D$D,[x - 0.5, y - 0.5, d, d]));
 else this.mContext.fill$java_awt_Shape(Clazz.new_($I$(5,1).c$$D$D$D$D,[x, y, d, d]));
});

Clazz.newMeth(C$, 'getStringWidth$S',  function (theString) {
if (this.mContext != null ) {
if (!theString.equals$O(this.mCurrentString) || this.mCurrentFont !== (this.mContext).getFont$()  ) {
this.mCurrentString=theString;
this.mCurrentFont=(this.mContext).getFont$();
var width=(this.mContext).getFontMetrics$().stringWidth$S(theString);
{
return width;
}
}}return this.mCurrentStringWidth;
});

Clazz.newMeth(C$, 'setTextSize$I',  function (theSize) {
this.mpTextSize=theSize;
if (this.mContext != null ) {
if (this.mContext.getFont$().getSize$() != theSize) {
for (var i=0; i < this.mFonts.size$(); i++) {
if ((this.mFonts.get$I(i)).getSize$() == theSize) {
this.mContext.setFont$java_awt_Font(this.mFonts.get$I(i));
return;
}}
var newFont=this.mContext.getFont$().deriveFont$I$F(0, theSize);
this.mFonts.add$O(newFont);
this.mContext.setFont$java_awt_Font(newFont);
}}});

Clazz.newMeth(C$, 'getTextSize$',  function () {
return this.mpTextSize;
});

Clazz.newMeth(C$, 'getLineWidth$',  function () {
return this.mLineWidth;
});

Clazz.newMeth(C$, 'setLineWidth$D',  function (lineWidth) {
this.mLineWidth=lineWidth;
this.mContext.setStroke$java_awt_Stroke(Clazz.new_($I$(3,1).c$$F$I$I,[lineWidth, 1, 1]));
});

Clazz.newMeth(C$, 'setRGB$I',  function (rgb) {
var color=Clazz.new_($I$(6,1).c$$I,[rgb]);
this.mContext.setColor$java_awt_Color(color);
this.mContext.setPaint$java_awt_Paint(color);
});

C$.$static$=function(){C$.$static$=0;
C$.isMac=(System.getProperty$S("os.name").toLowerCase$().indexOf$S("mac") >= 0);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:37 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
