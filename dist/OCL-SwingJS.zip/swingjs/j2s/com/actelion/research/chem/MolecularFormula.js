(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.Molecule','com.actelion.research.chem.IsotopeHelper','StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolecularFormula");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mAbsoluteIsotopeWeightIncrement','mRelativeIsotopeWeightIncrement'],'O',['+mAtomCount','+mAtomicNo']]
,['O',['sRelativeMass','double[]','+sAbsoluteMass','sFirstFormulaAtomicNo','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule',  function (mol) {
;C$.$init$.apply(this);
mol.ensureHelperArrays$I(1);
var atomCount=Clazz.array(Integer.TYPE, [191]);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
switch (mol.getAtomicNo$I(atom)) {
case 171:
atomCount[1]+=5;
atomCount[6]+=3;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 172:
atomCount[1]+=12;
atomCount[6]+=6;
atomCount[7]+=4;
atomCount[8]+=1;
break;
case 173:
atomCount[1]+=6;
atomCount[6]+=4;
atomCount[7]+=2;
atomCount[8]+=2;
break;
case 174:
atomCount[1]+=5;
atomCount[6]+=4;
atomCount[7]+=1;
atomCount[8]+=3;
break;
case 175:
atomCount[1]+=5;
atomCount[6]+=3;
atomCount[7]+=1;
atomCount[8]+=1;
atomCount[16]+=1;
break;
case 176:
atomCount[1]+=8;
atomCount[6]+=5;
atomCount[7]+=2;
atomCount[8]+=2;
break;
case 177:
atomCount[1]+=7;
atomCount[6]+=5;
atomCount[7]+=1;
atomCount[8]+=3;
break;
case 178:
atomCount[1]+=3;
atomCount[6]+=2;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 179:
atomCount[1]+=7;
atomCount[6]+=6;
atomCount[7]+=3;
atomCount[8]+=1;
break;
case 180:
atomCount[1]+=11;
atomCount[6]+=6;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 181:
atomCount[1]+=11;
atomCount[6]+=6;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 182:
atomCount[1]+=12;
atomCount[6]+=6;
atomCount[7]+=2;
atomCount[8]+=1;
break;
case 183:
atomCount[1]+=9;
atomCount[6]+=5;
atomCount[7]+=1;
atomCount[8]+=1;
atomCount[16]+=1;
break;
case 184:
atomCount[1]+=9;
atomCount[6]+=9;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 185:
atomCount[1]+=7;
atomCount[6]+=5;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 186:
atomCount[1]+=5;
atomCount[6]+=3;
atomCount[7]+=1;
atomCount[8]+=2;
break;
case 187:
atomCount[1]+=7;
atomCount[6]+=4;
atomCount[7]+=1;
atomCount[8]+=2;
break;
case 188:
atomCount[1]+=10;
atomCount[6]+=11;
atomCount[7]+=2;
atomCount[8]+=1;
break;
case 189:
atomCount[1]+=9;
atomCount[6]+=9;
atomCount[7]+=1;
atomCount[8]+=2;
break;
case 190:
atomCount[1]+=9;
atomCount[6]+=5;
atomCount[7]+=1;
atomCount[8]+=1;
break;
case 1:
switch (mol.getAtomMass$I(atom)) {
case 0:
case 1:
++atomCount[1];
break;
case 2:
++atomCount[151];
break;
case 3:
++atomCount[152];
break;
}
break;
default:
++atomCount[mol.getAtomicNo$I(atom)];
break;
}
}
for (var atom=0; atom < mol.getAllAtoms$(); atom++) if (mol.getAtomicNo$I(atom) >= 171 && mol.getAtomicNo$I(atom) <= 190 ) atomCount[1]+=2 - mol.getOccupiedValence$I(atom);
 else {
atomCount[1]+=mol.getImplicitHydrogens$I(atom);
}
var atomicNoCount=0;
for (var i=1; i <= 190; i++) if (atomCount[i] != 0) ++atomicNoCount;

this.mAtomCount=Clazz.array(Integer.TYPE, [atomicNoCount]);
this.mAtomicNo=Clazz.array(Integer.TYPE, [atomicNoCount]);
atomicNoCount=0;
for (var i=0; i < C$.sFirstFormulaAtomicNo.length; i++) {
if (atomCount[C$.sFirstFormulaAtomicNo[i]] != 0) {
this.mAtomCount[atomicNoCount]=atomCount[C$.sFirstFormulaAtomicNo[i]];
this.mAtomicNo[atomicNoCount]=C$.sFirstFormulaAtomicNo[i];
++atomicNoCount;
atomCount[C$.sFirstFormulaAtomicNo[i]]=0;
}}
while (true){
var lowestLabel="zzz";
var lowestAtomicNo=-1;
for (var atomicNo=1; atomicNo <= 190; atomicNo++) if (atomCount[atomicNo] > 0 && lowestLabel.compareTo$S($I$(1).cAtomLabel[atomicNo]) > 0 ) {
lowestLabel=$I$(1).cAtomLabel[atomicNo];
lowestAtomicNo=atomicNo;
}
if (lowestAtomicNo == -1) break;
this.mAtomCount[atomicNoCount]=atomCount[lowestAtomicNo];
this.mAtomicNo[atomicNoCount]=lowestAtomicNo;
++atomicNoCount;
atomCount[lowestAtomicNo]=0;
}
this.mAbsoluteIsotopeWeightIncrement=0.0;
this.mRelativeIsotopeWeightIncrement=0.0;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) != 1 && !mol.isNaturalAbundance$I(atom) ) {
var atomicNo=mol.getAtomicNo$I(atom);
var atomMass=mol.getAtomMass$I(atom);
this.mAbsoluteIsotopeWeightIncrement+=$I$(2).getAbsoluteMass$I$I(atomicNo, atomMass) - C$.sAbsoluteMass[atomicNo];
this.mRelativeIsotopeWeightIncrement+=$I$(2).getAbsoluteMass$I$I(atomicNo, atomMass) - C$.sRelativeMass[atomicNo];
}}
}, 1);

Clazz.newMeth(C$, 'getRelativeWeight$',  function () {
var weight=this.mRelativeIsotopeWeightIncrement;
for (var i=0; i < this.mAtomCount.length; i++) weight+=this.mAtomCount[i] * C$.sRelativeMass[this.mAtomicNo[i]];

return weight;
});

Clazz.newMeth(C$, 'getAbsoluteWeight$',  function () {
var weight=this.mAbsoluteIsotopeWeightIncrement;
for (var i=0; i < this.mAtomCount.length; i++) weight+=this.mAtomCount[i] * C$.sAbsoluteMass[this.mAtomicNo[i]];

return weight;
});

Clazz.newMeth(C$, 'getFormula$',  function () {
var formula=Clazz.new_($I$(3,1));
for (var i=0; i < this.mAtomCount.length; i++) {
formula.append$S($I$(1).cAtomLabel[this.mAtomicNo[i]]);
if (this.mAtomCount[i] > 1) formula.append$I(this.mAtomCount[i]);
}
return formula.toString();
});

Clazz.newMeth(C$, 'equals$O',  function (f) {
if (f === this ) return true;
if (!(Clazz.instanceOf(f, "com.actelion.research.chem.MolecularFormula"))) return false;
for (var i=0; i < this.mAtomCount.length; i++) if (this.mAtomCount[i] != (f).mAtomCount[i]) return false;

return true;
});

C$.$static$=function(){C$.$static$=0;
C$.sRelativeMass=Clazz.array(Double.TYPE, -1, [0.0, 1.00794, 4.0026, 6.941, 9.0122, 10.811, 12.011, 14.007, 15.999, 18.998, 20.18, 22.99, 24.305, 26.982, 28.086, 30.974, 32.066, 35.453, 39.948, 39.098, 40.078, 44.956, 47.867, 50.942, 51.996, 54.938, 55.845, 58.933, 58.693, 63.546, 65.39, 69.723, 72.61, 74.922, 78.96, 79.904, 83.8, 85.468, 87.62, 88.906, 91.224, 92.906, 95.94, 98.906, 101.07, 102.91, 106.42, 107.87, 112.41, 114.82, 118.71, 121.76, 127.6, 126.9, 131.29, 132.91, 137.33, 138.91, 140.12, 140.91, 144.24, 146.92, 150.36, 151.96, 157.25, 158.93, 162.5, 164.93, 167.26, 168.93, 173.04, 174.97, 178.49, 180.95, 183.84, 186.21, 190.23, 192.22, 195.08, 196.97, 200.59, 204.38, 207.2, 208.98, 209.98, 209.99, 222.02, 223.02, 226.03, 227.03, 232.04, 231.04, 238.03, 237.05, 239.05, 241.06, 244.06, 249.08, 252.08, 252.08, 257.1, 258.1, 259.1, 262.11, 267.12, 268.13, 271.13, 270.13, 277.15, 276.15, 281.17, 281.17, 283.17, 285.18, 289.19, 289.19, 293.2, 294.21, 294.21, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.0141, 3.016, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 71.0787, 156.18828, 114.10364, 115.0877, 103.1447, 128.13052, 129.11458, 57.05182, 137.14158, 113.15934, 113.15934, 128.17428, 131.19846, 147.17646, 97.11658, 87.0777, 101.10458, 186.2134, 163.17546, 99.13246]);
C$.sAbsoluteMass=Clazz.array(Double.TYPE, -1, [0.0, 1.007825, 4.0026, 7.016003, 9.012182, 11.009305, 12.0, 14.003074, 15.994915, 18.998403, 19.992435, 22.989767, 23.985042, 26.98153, 27.976927, 30.973762, 31.97207, 34.968852, 39.962384, 38.963707, 39.962591, 44.95591, 47.947947, 50.943962, 51.940509, 54.938047, 55.934939, 58.933198, 57.935346, 62.939598, 63.929145, 68.92558, 73.921177, 74.921594, 79.91652, 78.918336, 83.911507, 84.911794, 87.905619, 88.905849, 89.904703, 92.906377, 97.905406, 89.92381, 101.904348, 102.9055, 105.903478, 106.905092, 113.903357, 114.90388, 119.9022, 120.903821, 129.906229, 126.904473, 131.904144, 132.905429, 137.905232, 138.906346, 139.905433, 140.907647, 141.907719, 135.92398, 151.919729, 152.921225, 157.924099, 158.925342, 163.929171, 164.930319, 165.93029, 168.934212, 173.938859, 174.94077, 179.946545, 180.947992, 183.950928, 186.955744, 191.961467, 192.962917, 194.964766, 196.966543, 201.970617, 204.974401, 207.976627, 208.980374, 193.98818, 195.99573, 199.9957, 201.00411, 206.0038, 210.00923, 232.038054, 216.01896, 238.050784, 229.03623, 232.041169, 237.05005, 238.05302, 242.06194, 240.06228, 243.06947, 243.07446, 248.08275, 251.08887, 253.09515, 257.10295, 257.10777, 271.13, 270.13, 277.15, 276.15, 281.17, 281.17, 283.17, 285.18, 289.19, 289.19, 291.2, 294.21, 294.21, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 2.014, 3.01605, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]);
C$.sFirstFormulaAtomicNo=Clazz.array(Integer.TYPE, -1, [6, 1, 7, 8]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:59 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
