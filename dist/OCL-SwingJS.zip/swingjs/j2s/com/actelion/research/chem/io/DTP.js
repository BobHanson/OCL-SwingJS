(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DTP");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['B',['access1','access2'],'I',['lnum','drpoin','parentID','length','typno','security','sbfpoin','sbfnum','hash','unk5','unk6','unk7','isparent','unk9','unk10','drsize','unk11'],'S',['dtpnam'],'O',['empty','byte[]','depdata','int[]','+rootID']]]

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
