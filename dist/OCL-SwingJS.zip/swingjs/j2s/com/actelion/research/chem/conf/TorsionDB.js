(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},p$2={},I$=[[0,'java.util.TreeMap','com.actelion.research.chem.conf.TorsionInfo','java.io.BufferedReader','java.io.FileReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets','com.actelion.research.chem.conf.TorsionDetail']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionDB");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mSupportedModes','mMergeSpan'],'O',['mTreeMap','java.util.TreeMap']]
,['S',['sDatabase','sExternalResourcePath'],'O',['sInstance','com.actelion.research.chem.conf.TorsionDB']]]

Clazz.newMeth(C$, 'setResourcePath$S',  function (path) {
C$.sExternalResourcePath=path;
}, 1);

Clazz.newMeth(C$, 'initialize$I',  function (mode) {
C$.initialize$I$I(mode, 15);
}, 1);

Clazz.newMeth(C$, 'initialize$I$I',  function (mode, mergeSpan) {
{
if (C$.sInstance == null ) C$.sInstance=Clazz.new_(C$);
if (mode == 1 && (C$.sInstance.mSupportedModes & 1) != 0  && C$.sInstance.mMergeSpan != mergeSpan ) System.out.println$S("WARNING: TorsionDB already initialized in ANGLE mode with different merge span.");
var newMode=mode & ~C$.sInstance.mSupportedModes;
if (newMode != 0) {
p$1.init$I.apply(C$.sInstance, [newMode]);
if (newMode == 1 && mergeSpan != 0 ) p$1.mergeTorsions$I.apply(C$.sInstance, [mergeSpan]);
}}}, 1);

Clazz.newMeth(C$, 'findRotatableBonds$com_actelion_research_chem_StereoMolecule$Z$ZA',  function (mol, skipAllRingBonds, isRotatableBond) {
mol.ensureHelperArrays$I(7);
if (isRotatableBond == null ) isRotatableBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
var count=0;
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondOrder$I(bond) == 1 && !mol.isAromaticBond$I(bond)  && mol.getNonHydrogenNeighbourCount$I(mol.getBondAtom$I$I(0, bond)) > 1  && mol.getNonHydrogenNeighbourCount$I(mol.getBondAtom$I$I(1, bond)) > 1  && !(skipAllRingBonds && mol.isRingBond$I(bond) )  && !(mol.isSmallRingBond$I(bond) && mol.getBondRingSize$I(bond) <= 5 ) ) {
isRotatableBond[bond]=true;
++count;
}}
var centralAtom=Clazz.array(Integer.TYPE, [2]);
var rearAtom=Clazz.array(Integer.TYPE, [2]);
var bondHandled=null;
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (isRotatableBond[bond] && (bondHandled == null  || !bondHandled[bond] ) ) {
var alkyneAtomCount=0;
for (var i=0; i < 2; i++) {
centralAtom[i]=mol.getBondAtom$I$I(i, bond);
rearAtom[i]=mol.getBondAtom$I$I(1 - i, bond);
var startAtom=rearAtom[i];
while (mol.getAtomPi$I(centralAtom[i]) == 2 && mol.getNonHydrogenNeighbourCount$I(centralAtom[i]) == 2  && mol.getAtomicNo$I(centralAtom[i]) < 10 ){
for (var j=0; j < 2; j++) {
var connAtom=mol.getConnAtom$I$I(centralAtom[i], j);
if (connAtom != rearAtom[i]) {
var connBond=mol.getConnBond$I$I(centralAtom[i], j);
if (isRotatableBond[connBond] && mol.getBondOrder$I(connBond) == 1 ) {
isRotatableBond[connBond]=false;
--count;
}rearAtom[i]=centralAtom[i];
centralAtom[i]=connAtom;
++alkyneAtomCount;
break;
}}
if (centralAtom[i] == startAtom) {
alkyneAtomCount=0;
break;
}}
}
if (alkyneAtomCount != 0) {
isRotatableBond[bond]=false;
--count;
if (mol.getNonHydrogenNeighbourCount$I(centralAtom[0]) > 1 && mol.getNonHydrogenNeighbourCount$I(centralAtom[1]) > 1 ) {
var substituentSize0=mol.getSubstituentSize$I$I(rearAtom[0], centralAtom[0]);
var substituentSize1=mol.getSubstituentSize$I$I(rearAtom[1], centralAtom[1]);
var i=(substituentSize0 < substituentSize1) ? 0 : 1;
var relevantBond=mol.getBond$I$I(rearAtom[i], centralAtom[i]);
if (bondHandled == null ) bondHandled=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
bondHandled[relevantBond]=true;
isRotatableBond[relevantBond]=true;
++count;
}}}}
return count;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mTreeMap=Clazz.new_($I$(1,1));
this.mSupportedModes=0;
}, 1);

Clazz.newMeth(C$, 'mergeTorsions$I',  function (mergeSpan) {
this.mMergeSpan=mergeSpan;
for (var ti, $ti = this.mTreeMap.values$().iterator$(); $ti.hasNext$()&&((ti=($ti.next$())),1);) ti.mergeTorsions$I(mergeSpan);

}, p$1);

Clazz.newMeth(C$, 'init$I',  function (mode) {
this.mSupportedModes|=mode;
try {
var tr=C$.openReader$S("torsionID.txt");
var ar=((mode & 1) == 0) ? null : C$.openReader$S("torsionAngle.txt");
var rr=((mode & 1) == 0) ? null : C$.openReader$S("torsionRange.txt");
var fr=((mode & 1) == 0) ? null : C$.openReader$S("torsionFrequency.txt");
var br=((mode & 2) == 0) ? null : C$.openReader$S("torsionBins.txt");
var type=tr.readLine$();
while (type != null ){
var torsionInfo=this.mTreeMap.get$O(type);
if (torsionInfo == null ) {
torsionInfo=Clazz.new_([C$.getSymmetryType$S(type)],$I$(2,1).c$$I);
this.mTreeMap.put$O$O(type, torsionInfo);
}if (ar != null ) {
var angle=ar.readLine$().split$S(",");
torsionInfo.angle=Clazz.array(Short.TYPE, [angle.length]);
for (var i=0; i < angle.length; i++) torsionInfo.angle[i]=Short.parseShort$S(angle[i]);

}if (rr != null ) {
var range=rr.readLine$().split$S(",");
torsionInfo.range=Clazz.array(Short.TYPE, [range.length, 2]);
for (var i=0; i < range.length; i++) {
var index=range[i].indexOf$I$I("-", 1);
torsionInfo.range[i][0]=Short.parseShort$S(range[i].substring$I$I(0, index));
torsionInfo.range[i][1]=Short.parseShort$S(range[i].substring$I(index + 1));
}
}if (fr != null ) {
var frequency=fr.readLine$().split$S(",");
torsionInfo.frequency=Clazz.array(Short.TYPE, [frequency.length]);
for (var i=0; i < frequency.length; i++) torsionInfo.frequency[i]=Byte.parseByte$S(frequency[i]);

}if (br != null ) {
var binSize=br.readLine$().split$S(",");
torsionInfo.binSize=Clazz.array(Byte.TYPE, [binSize.length]);
for (var i=0; i < binSize.length; i++) torsionInfo.binSize[i]=Byte.parseByte$S(binSize[i]);

}type=tr.readLine$();
}
tr.close$();
if (ar != null ) ar.close$();
if (rr != null ) rr.close$();
if (fr != null ) fr.close$();
if (br != null ) br.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'openReader$S',  function (resourceName) {
if (C$.sExternalResourcePath != null ) return Clazz.new_([Clazz.new_($I$(4,1).c$$S,[C$.sExternalResourcePath + resourceName])],$I$(3,1).c$$java_io_Reader);
if (C$.sDatabase == null ) {
var is=Clazz.getClass(C$).getResourceAsStream$S("/resources/" + "csd/" + resourceName );
if (is != null ) {
C$.sDatabase="csd/";
return Clazz.new_([Clazz.new_([is, $I$(6).UTF_8],$I$(5,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(3,1).c$$java_io_Reader);
}C$.sDatabase="cod/";
}return Clazz.new_([Clazz.new_([Clazz.getClass(C$).getResourceAsStream$S("/resources/" + C$.sDatabase + resourceName ), $I$(6).UTF_8],$I$(5,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(3,1).c$$java_io_Reader);
}, 1);

Clazz.newMeth(C$, 'getTorsions$S',  function (torsionID) {
var ti=p$1.getTorsionInfo$S.apply(C$.sInstance, [torsionID]);
return (ti == null ) ? null : ti.get360DegreeAngles$();
}, 1);

Clazz.newMeth(C$, 'getTorsionRanges$S',  function (torsionID) {
var ti=p$1.getTorsionInfo$S.apply(C$.sInstance, [torsionID]);
return (ti == null ) ? null : ti.get360DegreeRanges$();
}, 1);

Clazz.newMeth(C$, 'getTorsionFrequencies$S',  function (torsionID) {
var ti=p$1.getTorsionInfo$S.apply(C$.sInstance, [torsionID]);
return (ti == null ) ? null : ti.get360DegreeFrequencies$();
}, 1);

Clazz.newMeth(C$, 'getTorsionBinCounts$S',  function (torsionID) {
var ti=p$1.getTorsionInfo$S.apply(C$.sInstance, [torsionID]);
return (ti == null ) ? null : ti.get72BinCounts$();
}, 1);

Clazz.newMeth(C$, 'getTorsionInfo$S',  function (torsionID) {
if (torsionID == null ) return null;
var ti=this.mTreeMap.get$O(torsionID);
if (ti != null ) return ti;
if (C$.isInverted$S(torsionID)) {
ti=this.mTreeMap.get$O(C$.normalizeID$S(torsionID));
if (ti != null ) {
ti=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_conf_TorsionInfo,[ti]);
this.mTreeMap.put$O$O(torsionID, ti);
return ti;
}}return null;
}, p$1);

Clazz.newMeth(C$, 'getTorsionID$com_actelion_research_chem_StereoMolecule$I$IA$com_actelion_research_chem_conf_TorsionDetail',  function (mol, bond, torsionAtom, detail) {
if (detail == null ) detail=Clazz.new_($I$(7,1));
detail.classify$com_actelion_research_chem_StereoMolecule$I(mol, bond);
if (torsionAtom != null ) {
torsionAtom[0]=detail.getReferenceAtom$I(0);
torsionAtom[1]=detail.getCentralAtom$I(0);
torsionAtom[2]=detail.getCentralAtom$I(1);
torsionAtom[3]=detail.getReferenceAtom$I(1);
}return detail.getID$();
}, 1);

Clazz.newMeth(C$, 'getSymmetryType$S',  function (torsionID) {
return torsionID.endsWith$S("<") || torsionID.endsWith$S(">")  ? 0 : torsionID.endsWith$S("-") || torsionID.endsWith$S("+")  ? 1 : torsionID.endsWith$S("=") ? 3 : 2;
}, 1);

Clazz.newMeth(C$, 'isInverted$S',  function (torsionID) {
return torsionID.endsWith$S("<") || torsionID.endsWith$S("-") ;
}, 1);

Clazz.newMeth(C$, 'normalizeID$S',  function (torsionID) {
return torsionID.endsWith$S("<") ? torsionID.substring$I$I(0, torsionID.length$() - 1) + ">" : torsionID.endsWith$S("-") ? torsionID.substring$I$I(0, torsionID.length$() - 1) + "+" : torsionID;
}, 1);

Clazz.newMeth(C$, 'calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$IA',  function (mol, atom) {
if (atom[0] != -1 && atom[3] != -1 ) return mol.calculateTorsion$IA(atom);
return C$.calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_Conformer$IA(mol, null, atom);
}, 1);

Clazz.newMeth(C$, 'calculateTorsionExtended$com_actelion_research_chem_conf_Conformer$IA',  function (conformer, atom) {
if (atom[0] != -1 && atom[3] != -1 ) return conformer.calculateTorsion$IA(atom);
return C$.calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_Conformer$IA(conformer.getMolecule$(), conformer, atom);
}, 1);

Clazz.newMeth(C$, 'calculateTorsionExtended$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_Conformer$IA',  function (mol, conformer, atom) {
var angle1=Clazz.array(Double.TYPE, [2]);
var rearAtom=C$.findRearAtoms$com_actelion_research_chem_StereoMolecule$IA(mol, atom);
for (var i=0; i < 2; i++) {
if (atom[3 * i] != -1) {
var central=2 - i;
var terminal=3 - 3 * i;
Clazz.assert(C$, this, function(){return (mol.getNonHydrogenNeighbourCount$I(atom[central]) == 3)});
var index=0;
for (var j=0; j < 3; j++) {
var connAtom=mol.getConnAtom$I$I(atom[central], j);
if (connAtom != rearAtom[1 - i] && mol.getAtomicNo$I(connAtom) != 1 ) {
atom[terminal]=connAtom;
if (conformer != null ) angle1[index++]=conformer.calculateTorsion$IA(atom);
 else angle1[index++]=mol.calculateTorsion$IA(atom);
}}
atom[terminal]=-1;
return C$.calculateVirtualTorsion$DA(angle1);
}}
var angle2=Clazz.array(Double.TYPE, [2]);
var index1=0;
Clazz.assert(C$, this, function(){return (mol.getNonHydrogenNeighbourCount$I(atom[1]) == 3)});
for (var i=0; i < 3; i++) {
var terminal1=mol.getConnAtom$I$I(atom[1], i);
if (terminal1 != rearAtom[0] && mol.getAtomicNo$I(terminal1) != 1 ) {
Clazz.assert(C$, this, function(){return (mol.getNonHydrogenNeighbourCount$I(atom[2]) == 3)});
atom[0]=terminal1;
var index2=0;
for (var j=0; j < 3; j++) {
var terminal2=mol.getConnAtom$I$I(atom[2], j);
if (terminal2 != rearAtom[1] && mol.getAtomicNo$I(terminal2) != 1 ) {
atom[3]=terminal2;
if (conformer != null ) angle2[index2++]=conformer.calculateTorsion$IA(atom);
 else angle2[index2++]=mol.calculateTorsion$IA(atom);
}}
angle1[index1++]=C$.calculateVirtualTorsion$DA(angle2);
}}
atom[0]=-1;
atom[3]=-1;
return C$.calculateVirtualTorsion$DA(angle1);
}, 1);

Clazz.newMeth(C$, 'findRearAtoms$com_actelion_research_chem_StereoMolecule$IA',  function (mol, torsionAtom) {
var rearAtom=Clazz.array(Integer.TYPE, [2]);
if (mol.getBond$I$I(torsionAtom[1], torsionAtom[2]) != -1) {
rearAtom[0]=torsionAtom[2];
rearAtom[1]=torsionAtom[1];
} else {
var pathAtom=Clazz.array(Integer.TYPE, [16]);
var pathLength=mol.getPath$IA$I$I$I$ZA(pathAtom, torsionAtom[1], torsionAtom[2], 15, null);
rearAtom[0]=pathAtom[1];
rearAtom[1]=pathAtom[pathLength - 1];
}return rearAtom;
}, 1);

Clazz.newMeth(C$, 'getExtendedAtomSequence$com_actelion_research_chem_StereoMolecule$IA',  function (mol, atom) {
if (mol.getBond$I$I(atom[1], atom[2]) != -1) return atom;
var pathAtom=Clazz.array(Integer.TYPE, [16]);
var pathLength=mol.getPath$IA$I$I$I$ZA(pathAtom, atom[1], atom[2], 15, null);
var realAtom=Clazz.array(Integer.TYPE, [3 + pathLength]);
realAtom[0]=atom[0];
for (var i=0; i <= pathLength; i++) realAtom[i + 1]=pathAtom[i];

realAtom[pathLength + 2]=atom[3];
return realAtom;
}, 1);

Clazz.newMeth(C$, 'calculateVirtualTorsion$DA',  function (angle) {
var meanAngle=(angle[1] + angle[0]) / 2;
var angleDif=Math.abs(angle[1] - angle[0]);
if (angleDif > 3.141592653589793 ) return meanAngle;
return (meanAngle < 0 ) ? meanAngle + 3.141592653589793 : meanAngle - 3.141592653589793;
}, 1);

Clazz.newMeth(C$, 'getTorsionStrainClass$S$D',  function (torsionID, angle) {
var rangeList=C$.getTorsionRanges$S(C$.normalizeID$S(torsionID));
if (rangeList == null ) return -1;
var strain=2;
var angleIndex=C$.getNormalizedTorsionIndex$S$D(torsionID, angle);
for (var range, $range = 0, $$range = rangeList; $range<$$range.length&&((range=($$range[$range])),1);$range++) {
if (angleIndex >= range[0] && angleIndex <= range[1] ) return 0;
if (angleIndex >= range[0] - 5 && angleIndex <= range[1] + 5 ) strain=1;
}
return strain;
}, 1);

Clazz.newMeth(C$, 'getNormalizedTorsionIndex$S$D',  function (torsionID, angle) {
if (C$.isInverted$S(torsionID)) angle=-angle;
angle=180.0 * angle / 3.141592653589793;
var index=(Math.floor(0.5 + angle)|0);
if (index == 180) index=-180;
var symmetryClass=C$.getSymmetryType$S(torsionID);
switch (symmetryClass) {
case 0:
if (index < 0) index+=360;
break;
case 1:
if (index < 0) index+=180;
break;
case 2:
index=Math.abs(index);
break;
case 3:
if (index < 0) index+=180;
if (index > 90) index=180 - index;
break;
}
return index;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
