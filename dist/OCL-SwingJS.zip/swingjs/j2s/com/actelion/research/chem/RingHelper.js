(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.RingCollection','com.actelion.research.chem.ExtendedMoleculeFunctions','java.util.ArrayList','java.util.Collections']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RingHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrTopoDist','int[][]','ringCollection','com.actelion.research.chem.RingCollection','liRing','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.ringCollection=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_ExtendedMolecule$I$I,[mol, 3, 100]);
this.arrTopoDist=$I$(2).getTopologicalDistanceMatrix$com_actelion_research_chem_StereoMolecule(mol);
this.liRing=Clazz.new_($I$(3,1));
}, 1);

Clazz.newMeth(C$, 'getRingCollection$',  function () {
return this.ringCollection;
});

Clazz.newMeth(C$, 'getLargestRingSize$',  function () {
var maxRingSize=0;
this.liRing.clear$();
var nRings=this.ringCollection.getSize$();
for (var i=0; i < nRings; i++) {
this.liRing.add$O(this.ringCollection.getRingAtoms$I(i));
}
$I$(4,"sort$java_util_List$java_util_Comparator",[this.liRing, ((P$.RingHelper$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "RingHelper$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$IA$IA','compare$O$O'],  function (o1, o2) {
var cmp=0;
if (o1.length > o2.length) {
cmp=1;
} else if (o1.length < o2.length) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.RingHelper$1.$init$,[this, null]))]);
$I$(4).reverse$java_util_List(this.liRing);
for (var arrRing, $arrRing = this.liRing.iterator$(); $arrRing.hasNext$()&&((arrRing=($arrRing.next$())),1);) {
if (!this.isEnclosingRing$IA(arrRing)) {
maxRingSize=arrRing.length;
break;
}}
return maxRingSize;
});

Clazz.newMeth(C$, 'isEnclosingRing$IA',  function (arrIndexRingAtomsRing2Check) {
var enclosingRing=false;
var offset=1;
var index2Width=(arrIndexRingAtomsRing2Check.length/2|0) + 1;
 leave : for (var i=0; i < index2Width; i++) {
var indAt1=arrIndexRingAtomsRing2Check[i];
for (var j=offset; j < index2Width; j++) {
var index2=i + j;
if (index2 >= arrIndexRingAtomsRing2Check.length) {
index2=index2 - arrIndexRingAtomsRing2Check.length;
}var topoDistRingPath=index2 - i;
if (topoDistRingPath > index2Width) {
topoDistRingPath=i - index2 - arrIndexRingAtomsRing2Check.length ;
}var indAt2=arrIndexRingAtomsRing2Check[index2];
var minTopoDist=this.arrTopoDist[indAt1][indAt2];
if (minTopoDist < topoDistRingPath) {
enclosingRing=true;
break leave;
}}
}
return enclosingRing;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
