(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'StringBuilder','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Element");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['weight','covalentRadius','vdwRadius','electronegativity'],'I',['orderNumber'],'S',['name','symbol']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$S$S$D$D$D$D',  function (orderNumber, name, symbol, weight, covalentRadius, vdwRadius, electronegativity) {
;C$.$init$.apply(this);
this.orderNumber=orderNumber;
this.name=name;
this.symbol=symbol;
this.weight=weight;
this.covalentRadius=covalentRadius;
this.vdwRadius=vdwRadius;
this.electronegativity=electronegativity;
}, 1);

Clazz.newMeth(C$, 'getOrderNumber$',  function () {
return this.orderNumber;
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.name;
});

Clazz.newMeth(C$, 'getSymbol$',  function () {
return this.symbol;
});

Clazz.newMeth(C$, 'getWeight$',  function () {
return this.weight;
});

Clazz.newMeth(C$, 'getCovalentRadius$',  function () {
return this.covalentRadius;
});

Clazz.newMeth(C$, 'getVDWRadius$',  function () {
return this.vdwRadius;
});

Clazz.newMeth(C$, 'getElectronegativity$',  function () {
return this.electronegativity;
});

Clazz.newMeth(C$, 'setElectronegativity$D',  function (electronegativity) {
this.electronegativity=electronegativity;
});

Clazz.newMeth(C$, 'toString',  function () {
return this.symbol;
});

Clazz.newMeth(C$, 'toStringForValueTable$',  function () {
var sb=Clazz.new_($I$(1,1));
sb.append$S("new Element(");
sb.append$I(this.orderNumber);
sb.append$S(",");
sb.append$S("\"" + this.name + "\"" );
sb.append$S(",");
sb.append$S("\"" + this.symbol + "\"" );
sb.append$S(",");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.weight)]));
sb.append$S(",");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.covalentRadius)]));
sb.append$S(",");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.vdwRadius)]));
sb.append$S(",");
sb.append$S($I$(2,"format3$Double",[Double.valueOf$D(this.electronegativity)]));
sb.append$S("),");
return sb.toString();
});

Clazz.newMeth(C$, 'getComparatorOrderNumber$',  function () {
return ((P$.Element$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "Element$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_Element$com_actelion_research_chem_Element','compare$O$O'],  function (o1, o2) {
var cmp=0;
if (o1.getOrderNumber$() > o2.getOrderNumber$()) {
cmp=1;
} else if (o1.getOrderNumber$() < o2.getOrderNumber$()) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.Element$1.$init$,[this, null]));
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:16 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
