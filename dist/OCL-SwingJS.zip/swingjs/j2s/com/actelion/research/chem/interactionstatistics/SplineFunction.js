(function(){var P$=Clazz.newPackage("com.actelion.research.chem.interactionstatistics"),I$=[[0,'com.actelion.research.util.ArrayUtils']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SplineFunction");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['occurencesArray','int[]','spline','com.actelion.research.util.FastSpline','+derivate','discreteFunction','double[]']]]

Clazz.newMeth(C$, 'getOccurencesArray$',  function () {
return this.occurencesArray;
});

Clazz.newMeth(C$, 'setOccurencesArray$IA',  function (occurencesArray) {
this.occurencesArray=occurencesArray;
});

Clazz.newMeth(C$, 'setDiscreteFunction$DA',  function (discreteFunction) {
this.discreteFunction=discreteFunction;
});

Clazz.newMeth(C$, 'setSplineFunction$com_actelion_research_util_FastSpline',  function (spline) {
this.spline=spline;
this.derivate=spline.derivative$();
});

Clazz.newMeth(C$, 'getTotalOccurences$',  function () {
return $I$(1).sum$IA(this.occurencesArray);
});

Clazz.newMeth(C$, 'getFGValue$D',  function (v) {
if (this.spline == null ) return Clazz.array(Double.TYPE, -1, [0.0, 0.0]);
try {
var value=this.spline.value$D(v);
var dev=this.derivate.value$D(v);
return Clazz.array(Double.TYPE, -1, [value, dev]);
} catch (e) {
if (Clazz.exceptionOf(e,"ArrayIndexOutOfBoundsException")){
return Clazz.array(Double.TYPE, -1, [0.0, 0.0]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'getDiscreteValue$D',  function (d) {
var index=((0.5 + d / 0.2)|0);
return this.discreteFunction[index];
});

Clazz.newMeth(C$, 'getSpline$',  function () {
return this.spline;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
