(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.DistHistEncoder','com.actelion.research.chem.descriptor.DescriptorEncoder','com.actelion.research.chem.descriptor.DescriptorHandlerFlexophore','com.actelion.research.chem.descriptor.flexophore.PPNode','com.actelion.research.chem.descriptor.flexophore.MolDistHist','com.actelion.research.util.datamodel.IntVec']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistEncoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['distHistEncoder','com.actelion.research.chem.descriptor.flexophore.DistHistEncoder']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.MolDistHistEncoder']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.distHistEncoder=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'encode$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (mdh) {
if (!mdh.isFinalized$()) mdh.realize$();
var strNodes=C$.encodeByteVec$BA(mdh.getArrNode$());
var strDistHist=" " + this.distHistEncoder.encodeHistograms$com_actelion_research_chem_descriptor_flexophore_DistHist(mdh);
var atoms=mdh.getNodeAtoms$() == null  ? "" : " " +  String.instantialize(Clazz.new_($I$(2,1)).encodeIntArray2D$IAA(mdh.getNodeAtoms$()));
return strNodes + strDistHist + atoms ;
});

Clazz.newMeth(C$, 'decode$BA',  function (arr) {
return this.decode$S( String.instantialize(arr));
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
if (s.equals$O("Calculation Failed")) {
return $I$(3).FAILED_OBJECT;
}var st=s.split$S(" ");
var arrNodes=C$.decodeNodes$S(st[0]);
var nNodes=0;
var pos=0;
while (arrNodes[pos] > 0){
pos+=arrNodes[pos] * $I$(4).getNumBytesEntry$() + 1;
++nNodes;
if (pos >= arrNodes.length) {
break;
}}
var arrNodesTrunc=Clazz.array(Byte.TYPE, [pos]);
System.arraycopy$O$I$O$I$I(arrNodes, 0, arrNodesTrunc, 0, arrNodesTrunc.length);
var mdh=Clazz.new_($I$(5,1).c$$I,[nNodes]);
mdh.setArrNode$BA(arrNodesTrunc);
if (st.length >= 2 && st[1].length$() != 0 ) this.distHistEncoder.decodeHistograms$S$com_actelion_research_chem_descriptor_flexophore_MolDistHist(st[1], mdh);
if (st.length >= 3) mdh.setNodeAtoms$IAA(Clazz.new_($I$(2,1)).decodeIntArray2D$BA(st[2].getBytes$()));
return mdh;
});

Clazz.newMeth(C$, 'decodeNodes$S',  function (s) {
var iv=Clazz.new_([Clazz.new_($I$(2,1)).decode$S(s)],$I$(6,1).c$$IA);
var arr=Clazz.array(Byte.TYPE, [iv.sizeBytes$()]);
var sum=0;
for (var i=0; i < arr.length; i++) {
arr[i]=((iv.getByte$I(i) & 255)|0);
sum+=Math.abs(arr[i]);
}
if (sum == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Node vector contains only 0\'s!"]);
}return arr;
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);

Clazz.newMeth(C$, 'encodeByteVec$BA',  function (arr) {
var ratio=4;
var sizeIntVec=(((arr.length / ratio) + ((ratio - 1) / ratio))|0);
var iv=Clazz.new_($I$(6,1).c$$I,[sizeIntVec]);
for (var i=0; i < arr.length; i++) {
iv.setByte$I$I(i, (arr[i] & 255));
}
var s= String.instantialize(Clazz.new_($I$(2,1)).encode$IA(iv.get$()));
return s;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
