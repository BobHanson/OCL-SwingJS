(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.ptree"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','java.util.Arrays','java.util.stream.Collectors','java.util.HashSet','com.actelion.research.chem.StereoMolecule']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['synthons','java.util.List','ringWithLinks','java.util.Map','+ringReactantIndeces','+reactantsWithLinkers','genericProduct','com.actelion.research.chem.StereoMolecule','synthonsToGenericProductMap','java.util.List','+deletionMap','+productRings','bonds','int[]']]]

Clazz.newMeth(C$, 'c$$java_util_List',  function (synthons) {
;C$.$init$.apply(this);
this.synthons=synthons;
this.ringWithLinks=Clazz.new_($I$(1,1));
this.ringReactantIndeces=Clazz.new_($I$(1,1));
this.bonds=Clazz.array(Integer.TYPE, [4]);
p$1.classifyReaction.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'classifyReaction',  function () {
this.reactantsWithLinkers=Clazz.new_($I$(1,1));
for (var reactant, $reactant = this.synthons.iterator$(); $reactant.hasNext$()&&((reactant=($reactant.next$())),1);) {
for (var a=0; a < reactant.getAtoms$(); a++) {
if (reactant.getAtomLabel$I(a).equals$O("U")) {
var bondOrder=reactant.getConnBondOrder$I$I(a, 0);
this.bonds[0]=bondOrder;
} else if (reactant.getAtomLabel$I(a).equals$O("Np")) {
var bondOrder=reactant.getConnBondOrder$I$I(a, 0);
this.bonds[1]=bondOrder;
} else if (reactant.getAtomLabel$I(a).equals$O("Pu")) {
var bondOrder=reactant.getConnBondOrder$I$I(a, 0);
this.bonds[2]=bondOrder;
} else if (reactant.getAtomLabel$I(a).equals$O("Am")) {
var bondOrder=reactant.getConnBondOrder$I$I(a, 0);
this.bonds[3]=bondOrder;
}}
}
for (var r=0; r < this.synthons.size$(); r++) {
this.reactantsWithLinkers.putIfAbsent$O$O(Integer.valueOf$I(r), Clazz.new_($I$(2,1)));
var reactant=this.synthons.get$I(r);
for (var a=0; a < reactant.getAtoms$(); a++) {
if (reactant.getAtomLabel$I(a).equals$O("U")) {
this.reactantsWithLinkers.get$O(Integer.valueOf$I(r)).add$O(Integer.valueOf$I(1));
} else if (reactant.getAtomLabel$I(a).equals$O("Np")) {
this.reactantsWithLinkers.get$O(Integer.valueOf$I(r)).add$O(Integer.valueOf$I(2));
} else if (reactant.getAtomLabel$I(a).equals$O("Pu")) {
this.reactantsWithLinkers.get$O(Integer.valueOf$I(r)).add$O(Integer.valueOf$I(3));
} else if (reactant.getAtomLabel$I(a).equals$O("Am")) {
this.reactantsWithLinkers.get$O(Integer.valueOf$I(r)).add$O(Integer.valueOf$I(4));
}}
}
var bondLabels=Clazz.new_($I$(1,1));
this.synthonsToGenericProductMap=Clazz.new_($I$(2,1));
this.deletionMap=Clazz.new_($I$(2,1));
this.genericProduct=p$1.synthonReaction$java_util_List$java_util_List$java_util_List$java_util_Map.apply(this, [this.synthons, this.synthonsToGenericProductMap, this.deletionMap, bondLabels]);
var rc=this.genericProduct.getRingSet$();
this.productRings=Clazz.new_($I$(2,1));
for (var r=0; r < rc.getSize$(); r++) {
this.productRings.add$O($I$(3,"stream$IA",[rc.getRingAtoms$I(r)]).boxed$().collect$java_util_stream_Collector($I$(4).toSet$()));
}
var eductRings=0;
for (var r=0; r < this.synthons.size$(); r++) eductRings+=this.synthons.get$I(r).getRingSet$().getSize$();

if (eductRings == this.productRings.size$()) this.productRings=Clazz.new_($I$(2,1));
this.ringReactantIndeces=Clazz.new_($I$(1,1));
for (var r=0; r < this.synthons.size$(); r++) {
var reactant=this.synthons.get$I(r);
for (var a=0; a < reactant.getAtoms$(); a++) {
if (reactant.getAtomicNo$I(a) >= 92) continue;
for (var fr=0; fr < this.productRings.size$(); fr++) {
if (this.productRings.get$I(fr).contains$O(Integer.valueOf$I(this.mapSynthonToGenericProductIndex$I$I(r, a)))) {
this.ringReactantIndeces.putIfAbsent$O$O(Integer.valueOf$I(fr), Clazz.new_($I$(5,1)));
this.ringReactantIndeces.get$O(Integer.valueOf$I(fr)).add$O(Integer.valueOf$I(r));
}}
}
}
for (var r=0; r < rc.getSize$(); r++) {
var ringBonds=rc.getRingBonds$I(r);
for (var b, $b = 0, $$b = ringBonds; $b<$$b.length&&((b=($$b[$b])),1);$b++) {
if (bondLabels.containsKey$O(Integer.valueOf$I(b))) {
this.ringWithLinks.putIfAbsent$O$O(Integer.valueOf$I(r), Clazz.new_($I$(5,1)));
this.ringWithLinks.get$O(Integer.valueOf$I(r)).add$O(bondLabels.get$O(Integer.valueOf$I(b)));
}}
}
}, p$1);

Clazz.newMeth(C$, 'synthonReaction$java_util_List$java_util_List$java_util_List$java_util_Map',  function (bbs, atomMap, deletionMap, bondLabels) {
var buildingBlocks=Clazz.new_($I$(2,1));
bbs.stream$().forEach$java_util_function_Consumer(((P$.PharmTreeSynthonReactionHelper$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (this.$finals$.buildingBlocks.add$O.apply(this.$finals$.buildingBlocks, [Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule,[e])]));});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda1.$init$,[this, {buildingBlocks:buildingBlocks}])));
buildingBlocks.forEach$java_util_function_Consumer(((P$.PharmTreeSynthonReactionHelper$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_StereoMolecule','accept$O'],  function (e) { return (e.ensureHelperArrays$I.apply(e, [31]));});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda2.$init$,[this, null])));
var rgrps=Clazz.new_($I$(1,1));
for (var m=0; m < buildingBlocks.size$(); m++) {
var bb=buildingBlocks.get$I(m);
for (var a=0; a < bb.getAtoms$(); a++) {
if (bb.getAtomLabel$I(a).equals$O("U")) {
rgrps.putIfAbsent$O$O(Integer.valueOf$I(1), Clazz.new_($I$(2,1)));
rgrps.get$O(Integer.valueOf$I(1)).add$O(Clazz.array(Integer.TYPE, -1, [m, bb.getConnAtom$I$I(a, 0)]));
bb.markAtomForDeletion$I(a);
} else if (bb.getAtomLabel$I(a).equals$O("Np")) {
rgrps.putIfAbsent$O$O(Integer.valueOf$I(2), Clazz.new_($I$(2,1)));
rgrps.get$O(Integer.valueOf$I(2)).add$O(Clazz.array(Integer.TYPE, -1, [m, bb.getConnAtom$I$I(a, 0)]));
bb.markAtomForDeletion$I(a);
} else if (bb.getAtomLabel$I(a).equals$O("Pu")) {
rgrps.putIfAbsent$O$O(Integer.valueOf$I(3), Clazz.new_($I$(2,1)));
rgrps.get$O(Integer.valueOf$I(3)).add$O(Clazz.array(Integer.TYPE, -1, [m, bb.getConnAtom$I$I(a, 0)]));
bb.markAtomForDeletion$I(a);
} else if (bb.getAtomLabel$I(a).equals$O("Am")) {
rgrps.putIfAbsent$O$O(Integer.valueOf$I(4), Clazz.new_($I$(2,1)));
rgrps.get$O(Integer.valueOf$I(4)).add$O(Clazz.array(Integer.TYPE, -1, [m, bb.getConnAtom$I$I(a, 0)]));
bb.markAtomForDeletion$I(a);
}}
}
for (var m=0; m < buildingBlocks.size$(); m++) {
var bb=buildingBlocks.get$I(m);
var map=bb.deleteMarkedAtomsAndBonds$();
deletionMap.add$O(map);
var m_=m;
rgrps.forEach$java_util_function_BiConsumer(((P$.PharmTreeSynthonReactionHelper$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
v.stream$.apply(v, []).forEach$java_util_function_Consumer.apply(v.stream$.apply(v, []), [((P$.PharmTreeSynthonReactionHelper$lambda3$4||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda3$4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$IA','accept$O'],  function (e) {
if (e[0] == this.$finals$.m_) e[1]=this.$finals$.map[e[1]];
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda3$4.$init$,[this, {m_:this.$finals$.m_,map:this.$finals$.map}]))]);
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda3.$init$,[this, {m_:m_,map:map}])));
}
var product=Clazz.new_($I$(6,1));
atomMap.add$O(product.addMolecule$com_actelion_research_chem_Molecule(buildingBlocks.get$I(0)));
for (var m=1; m < buildingBlocks.size$(); m++) {
var map=product.addMolecule$com_actelion_research_chem_Molecule(buildingBlocks.get$I(m));
atomMap.add$O(map);
var m_=m;
rgrps.forEach$java_util_function_BiConsumer(((P$.PharmTreeSynthonReactionHelper$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
v.stream$.apply(v, []).forEach$java_util_function_Consumer.apply(v.stream$.apply(v, []), [((P$.PharmTreeSynthonReactionHelper$lambda4$5||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda4$5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$IA','accept$O'],  function (e) {
if (e[0] == this.$finals$.m_) e[1]=this.$finals$.map[e[1]];
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda4$5.$init$,[this, {map:this.$finals$.map,m_:this.$finals$.m_}]))]);
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda4.$init$,[this, {map:map,m_:m_}])));
}
rgrps.forEach$java_util_function_BiConsumer(((P$.PharmTreeSynthonReactionHelper$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$Integer$java_util_List','accept$O$O'],  function (k, v) {
var atom1=v.get$I.apply(v, [0])[1];
var atom2=v.get$I.apply(v, [1])[1];
var bond=this.$finals$.product.addBond$I$I.apply(this.$finals$.product, [atom1, atom2]);
this.$finals$.product.setBondOrder$I$I.apply(this.$finals$.product, [bond, this.b$['com.actelion.research.chem.chemicalspaces.ptree.PharmTreeSynthonReactionHelper'].bonds[((k).$c() - 1)|0]]);
this.$finals$.bondLabels.put$O$O.apply(this.$finals$.bondLabels, [Integer.valueOf$I(bond), k]);
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda5.$init$,[this, {product:product,bondLabels:bondLabels}])));
var map=product.getHandleHydrogenMap$();
atomMap.stream$().forEach$java_util_function_Consumer(((P$.PharmTreeSynthonReactionHelper$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$IA','accept$O'],  function (e) {
$I$(3).stream$IA(e).map$java_util_function_IntUnaryOperator.apply($I$(3).stream$IA(e), [((P$.PharmTreeSynthonReactionHelper$lambda6$7||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmTreeSynthonReactionHelper$lambda6$7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntUnaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$I','applyAsInt$O'],  function (i) { return (this.$finals$.map[i]);});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda6$7.$init$,[this, {map:this.$finals$.map}]))]);
});
})()
), Clazz.new_(P$.PharmTreeSynthonReactionHelper$lambda6.$init$,[this, {map:map}])));
product.ensureHelperArrays$I(31);
return product;
}, p$1);

Clazz.newMeth(C$, 'getSynthons$',  function () {
return this.synthons;
});

Clazz.newMeth(C$, 'getRingWithLinks$',  function () {
return this.ringWithLinks;
});

Clazz.newMeth(C$, 'getRingReactantIndeces$',  function () {
return this.ringReactantIndeces;
});

Clazz.newMeth(C$, 'getGenericProduct$',  function () {
return this.genericProduct;
});

Clazz.newMeth(C$, 'getSynthonsToGenericProductMap$',  function () {
return this.synthonsToGenericProductMap;
});

Clazz.newMeth(C$, 'mapSynthonToGenericProductIndex$I$I',  function (synthonID, index) {
var newIndex=this.deletionMap.get$I(synthonID)[index];
return this.synthonsToGenericProductMap.get$I(synthonID)[newIndex];
});

Clazz.newMeth(C$, 'getFormedRings$',  function () {
return this.productRings;
});

Clazz.newMeth(C$, 'getReactantsWithLinkers$',  function () {
return this.reactantsWithLinkers;
});

Clazz.newMeth(C$, 'getBondOrders$',  function () {
return this.bonds;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
