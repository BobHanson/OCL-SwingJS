(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'java.util.HashMap','com.actelion.research.chem.Coordinates','java.util.Collections','java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Molecule3D", null, 'com.actelion.research.chem.StereoMolecule', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nMovables=-1;
this.auxiliaryInfos=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['I',['nMovables'],'O',['auxiliaryInfos','java.util.Map','atomFlags','int[]','infos','Object[][]','partialCharges','double[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Molecule3D',  function (mol) {
;C$.superclazz.c$$com_actelion_research_chem_Molecule.apply(this,[mol]);C$.$init$.apply(this);
this.auxiliaryInfos.putAll$java_util_Map(mol.auxiliaryInfos);
this.atomFlags=Clazz.array(Integer.TYPE, [mol.getMaxAtoms$()]);
this.partialCharges=Clazz.array(Double.TYPE, [mol.getMaxAtoms$()]);
this.infos=Clazz.array(java.lang.Object, [mol.getMaxAtoms$(), 9]);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
this.atomFlags[atom]=mol.atomFlags[atom];
this.partialCharges[atom]=mol.partialCharges[atom];
for (var i=0; i < 9; i++) this.infos[atom][i]=mol.infos[atom][i];

}
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.superclazz.c$$com_actelion_research_chem_Molecule.apply(this,[mol]);C$.$init$.apply(this);
this.atomFlags=Clazz.array(Integer.TYPE, [mol.getMaxAtoms$()]);
this.partialCharges=Clazz.array(Double.TYPE, [mol.getMaxAtoms$()]);
this.infos=Clazz.array(java.lang.Object, [mol.getMaxAtoms$(), 9]);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I$I.apply(this, [5, 5]);
}, 1);

Clazz.newMeth(C$, 'c$$I$I',  function (a, b) {
;C$.superclazz.c$$I$I.apply(this,[a, b]);C$.$init$.apply(this);
this.setName$S("Molecule");
this.atomFlags=Clazz.array(Integer.TYPE, [a]);
this.partialCharges=Clazz.array(Double.TYPE, [a]);
this.infos=Clazz.array(java.lang.Object, [a, 9]);
}, 1);

Clazz.newMeth(C$, 'getOccupiedValence$I',  function (atom) {
return C$.superclazz.prototype.getOccupiedValence$I.apply(this, [atom]) + this.getAttachedHydrogenCount$I(atom);
});

Clazz.newMeth(C$, 'getAttachedHydrogenCount$I',  function (atom) {
return (this.atomFlags[atom] & 960) >> 6;
});

Clazz.newMeth(C$, 'setAttachedHydrogenCount$I$I',  function (atom, value) {
this.atomFlags[atom]|=(value << 6);
});

Clazz.newMeth(C$, 'toString',  function () {
return (this.getName$() != null  ? this.getName$() : "");
});

Clazz.newMeth(C$, 'clear$',  function () {
C$.superclazz.prototype.deleteMolecule$.apply(this, []);
});

Clazz.newMeth(C$, 'setAtomFlag$I$I$Z',  function (atm, flag, value) {
this.nMovables=-1;
if (value) this.atomFlags[atm]|=flag;
 else this.atomFlags[atm]&=~flag;
});

Clazz.newMeth(C$, 'isAtomFlag$I$I',  function (atm, flag) {
return (this.atomFlags[atm] & flag) != 0;
});

Clazz.newMeth(C$, 'getAtomFlags$I',  function (atm) {
return this.atomFlags[atm];
});

Clazz.newMeth(C$, 'setAtomFlags$I$I',  function (atm, flags) {
this.nMovables=-1;
this.atomFlags[atm]=flags;
});

Clazz.newMeth(C$, 'setAllAtomFlag$I$Z',  function (flag, value) {
this.nMovables=-1;
for (var i=0; i < this.getAllAtoms$(); i++) this.setAtomFlag$I$I$Z(i, flag, value);

});

Clazz.newMeth(C$, 'fusion$com_actelion_research_chem_Molecule3D',  function (m2) {
if (m2 === this ) throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["Cannot fusion a molecule with itself"]);
var index=this.getAllAtoms$();
var oldToNew=Clazz.array(Integer.TYPE, [m2.getAllAtoms$()]);
for (var i=0; i < m2.getAllAtoms$(); i++) {
oldToNew[i]=this.addAtom$com_actelion_research_chem_Molecule3D$I(m2, i);
}
for (var i=0; i < m2.getAllBonds$(); i++) {
this.addBond$I$I$I(oldToNew[m2.getBondAtom$I$I(0, i)], oldToNew[m2.getBondAtom$I$I(1, i)], m2.getBondOrder$I(i));
}
return index;
});

Clazz.newMeth(C$, 'setBondOrder$I$I',  function (bond, order) {
if (order == 1) C$.superclazz.prototype.setBondType$I$I.apply(this, [bond, 1]);
 else if (order == 2) C$.superclazz.prototype.setBondType$I$I.apply(this, [bond, 2]);
 else if (order == 3) C$.superclazz.prototype.setBondType$I$I.apply(this, [bond, 4]);
 else System.out.println$S("ERROR: Unusual bond order:" + order);
});

Clazz.newMeth(C$, 'setAtomDescription$I$S',  function (atm, s) {
this.infos[atm][0]=s;
});

Clazz.newMeth(C$, 'getAtomDescription$I',  function (atm) {
return this.infos[atm][0];
});

Clazz.newMeth(C$, 'setPPP$I$IA',  function (atm, a) {
this.infos[atm][5]=a;
});

Clazz.newMeth(C$, 'getPPP$I',  function (atm) {
return this.infos[atm][5];
});

Clazz.newMeth(C$, 'setAtomSequence$I$I',  function (atm, a) {
this.infos[atm][1]=Integer.valueOf$I(a);
});

Clazz.newMeth(C$, 'setResSequence$I$I',  function (atm, a) {
this.infos[atm][8]=Integer.valueOf$I(a);
});

Clazz.newMeth(C$, 'getResSequence$I',  function (atm) {
return this.infos[atm][8] == null  ? -1 : (this.infos[atm][8]).$c();
});

Clazz.newMeth(C$, 'getAtomSequence$I',  function (atm) {
return this.infos[atm][1] == null  ? -1 : (this.infos[atm][1]).$c();
});

Clazz.newMeth(C$, 'setAtomChainId$I$S',  function (atm, a) {
this.infos[atm][6]=a;
});

Clazz.newMeth(C$, 'getAtomChainId$I',  function (atm) {
return this.infos[atm][6];
});

Clazz.newMeth(C$, 'setAtomName$I$S',  function (atm, a) {
this.infos[atm][3]=a;
});

Clazz.newMeth(C$, 'getAtomName$I',  function (atm) {
return this.infos[atm][3];
});

Clazz.newMeth(C$, 'setAtomAmino$I$S',  function (atm, a) {
this.infos[atm][4]=a;
});

Clazz.newMeth(C$, 'getAtomAmino$I',  function (atm) {
return this.infos[atm][4];
});

Clazz.newMeth(C$, 'getAtomBfactor$I',  function (atm) {
return (this.infos[atm][7]).valueOf();
});

Clazz.newMeth(C$, 'setAtomBfactor$I$D',  function (atm, bfactor) {
this.infos[atm][7]=Double.valueOf$D(bfactor);
});

Clazz.newMeth(C$, 'getBond$I$I',  function (a1, a2) {
for (var connBond=0; connBond < this.getAllConnAtomsPlusMetalBonds$I(a1); connBond++) {
if (this.getConnAtom$I$I(a1, connBond) == a2) return this.getConnBond$I$I(a1, connBond);
}
return -1;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
var coords=Clazz.array($I$(2), [this.getAtoms$()]);
for (var i=0; i < this.getAtoms$(); i++) {
coords[i]=this.getCoordinates$I(i);
}
return coords;
});

Clazz.newMeth(C$, 'deleteAtoms$java_util_List',  function (atomsToBeDeleted) {
$I$(3).sort$java_util_List(atomsToBeDeleted);
for (var i=atomsToBeDeleted.size$() - 1; i >= 0; i--) {
this.deleteAtom$I((atomsToBeDeleted.get$I(i)).$c());
}
});

Clazz.newMeth(C$, 'getName$',  function () {
var name=C$.superclazz.prototype.getName$.apply(this, []);
return name == null  ? "" : name;
});

Clazz.newMeth(C$, 'getShortName$',  function () {
var name=this.getName$();
if (name.indexOf$I(" ") > 0) name=name.substring$I$I(0, name.indexOf$I(" "));
if (name.length$() > 12) name=name.substring$I$I(0, 12);
return name;
});

Clazz.newMeth(C$, 'getAuxiliaryInfos$',  function () {
return this.auxiliaryInfos;
});

Clazz.newMeth(C$, 'getAuxiliaryInfo$S',  function (name) {
return this.auxiliaryInfos.get$O(name);
});

Clazz.newMeth(C$, 'setAuxiliaryInfo$S$O',  function (name, value) {
if (value == null ) {
System.err.println$S("Attempt to set " + name + " to null" );
this.auxiliaryInfos.remove$O(name);
} else {
this.auxiliaryInfos.put$O$O(name, value);
}});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
return obj === this ;
});

Clazz.newMeth(C$, 'setInteractionAtomType$I$I',  function (atm, type) {
this.infos[atm][2]=Integer.valueOf$I(type);
});

Clazz.newMeth(C$, 'getInteractionAtomType$I',  function (atm) {
return ((this.infos[atm][2]).valueOf()|0);
});

Clazz.newMeth(C$, 'setMaxAtoms$I',  function (v) {
C$.superclazz.prototype.setMaxAtoms$I.apply(this, [v]);
var u=this.atomFlags.length;
this.atomFlags=$I$(4).copyOf$IA$I(this.atomFlags, v);
this.partialCharges=$I$(4).copyOf$DA$I(this.partialCharges, v);
this.infos=$I$(4).copyOf$OA$I(this.infos, v);
for (var i=u; i < v; i++) this.infos[i]=Clazz.array(java.lang.Object, [9]);

});

Clazz.newMeth(C$, 'copyAtom$com_actelion_research_chem_Molecule$I$I$I',  function (destMol, sourceAtom, esrGroupOffsetAND, esrGroupOffsetOR) {
var destAtom=C$.superclazz.prototype.copyAtom$com_actelion_research_chem_Molecule$I$I$I.apply(this, [destMol, sourceAtom, esrGroupOffsetAND, esrGroupOffsetOR]);
if (Clazz.instanceOf(destMol, "com.actelion.research.chem.Molecule3D")) {
if ((destMol).atomFlags != null ) {
(destMol).atomFlags[destAtom]=this.atomFlags[sourceAtom];
}if ((destMol).partialCharges != null ) {
(destMol).partialCharges[destAtom]=this.partialCharges[sourceAtom];
}if ((destMol).infos != null ) {
(destMol).infos[destAtom]=Clazz.array(java.lang.Object, [9]);
for (var i=0; i < this.infos[sourceAtom].length; i++) {
(destMol).infos[destAtom][i]=p$1.clone$O.apply(this, [this.infos[sourceAtom][i]]);
}
}}return destAtom;
});

Clazz.newMeth(C$, 'clone$O',  function (o) {
var newObject=null;
if (o != null ) {
if (Clazz.instanceOf(o, "java.lang.String")) newObject= String.instantialize(o);
 else if (Clazz.instanceOf(o, "java.lang.Integer")) newObject= new Integer((o).$c());
 else if (Clazz.instanceOf(o, "java.lang.Double")) newObject= new Double((o).valueOf());
 else {
System.out.println$S("ERROR: unexpected Object type. Add support for new type: " + o);
}}return newObject;
}, p$1);

Clazz.newMeth(C$, 'compact$',  function () {
this.setMaxAtoms$I(this.getAllAtoms$());
this.setMaxBonds$I(this.getAllBonds$());
});

Clazz.newMeth(C$, 'swapAtoms$I$I',  function (atom1, atom2) {
C$.superclazz.prototype.swapAtoms$I$I.apply(this, [atom1, atom2]);
var tempi=this.atomFlags[atom1];
this.atomFlags[atom1]=this.atomFlags[atom2];
this.atomFlags[atom2]=tempi;
var tempd=this.partialCharges[atom1];
this.partialCharges[atom1]=this.partialCharges[atom2];
this.partialCharges[atom2]=tempd;
var tempo=this.infos[atom1];
this.infos[atom1]=this.infos[atom2];
this.infos[atom2]=tempo;
});

Clazz.newMeth(C$, 'addAtom$I',  function (atomicNo) {
if (this.mAllAtoms > this.mMaxAtoms) {
this.setMaxAtoms$I(this.mMaxAtoms * 2);
}var atom=C$.superclazz.prototype.addAtom$I.apply(this, [atomicNo]);
this.atomFlags[atom]=0;
this.partialCharges[atom]=0;
this.infos[atom]=Clazz.array(java.lang.Object, [9]);
return atom;
});

Clazz.newMeth(C$, 'addAtom$com_actelion_research_chem_Molecule3D$I',  function (m, i) {
var a=this.addAtom$I(m.getAtomicNo$I(i));
this.atomFlags[a]=m.getAtomFlags$I(i);
this.partialCharges[a]=m.getPartialCharge$I(i);
this.infos[a]=m.infos[i].clone$();
this.setAtomX$I$D(i, this.getAtomX$I(i));
this.setAtomY$I$D(i, this.getAtomY$I(i));
this.setAtomZ$I$D(i, this.getAtomZ$I(i));
return a;
});

Clazz.newMeth(C$, 'deleteAtom$I',  function (atom) {
C$.superclazz.prototype.deleteAtom$I.apply(this, [atom]);
this.compressMolTable$();
this.mValidHelperArrays=0;
});

Clazz.newMeth(C$, 'compressMolTable$',  function () {
for (var bnd=0; bnd < this.mAllBonds; bnd++) {
if (this.mBondType[bnd] == 512) {
var atom1=this.mBondAtom[0][bnd];
var atom2=this.mBondAtom[1][bnd];
if (!!(this.mAtomicNo[atom1] == -1 ^ this.mAtomicNo[atom2] == -1)) {
if (this.mAtomCharge[atom1] != 0 && this.mAtomCharge[atom2] != 0 ) {
if (!!(this.mAtomCharge[atom1] < 0 ^ this.mAtomCharge[atom2] < 0)) {
if (this.mAtomCharge[atom1] < 0) {
++this.mAtomCharge[atom1];
--this.mAtomCharge[atom2];
} else {
--this.mAtomCharge[atom1];
++this.mAtomCharge[atom2];
}}}}}}
var newAtmNo=Clazz.array(Integer.TYPE, [this.mAllAtoms]);
var atomDest=0;
for (var atom=0; atom < this.mAllAtoms; atom++) {
if (this.mAtomicNo[atom] == -1) {
newAtmNo[atom]=-1;
continue;
}if (atomDest < atom) {
this.mAtomicNo[atomDest]=this.mAtomicNo[atom];
this.mAtomCharge[atomDest]=this.mAtomCharge[atom];
this.mAtomMass[atomDest]=this.mAtomMass[atom];
this.mAtomFlags[atomDest]=this.mAtomFlags[atom];
this.mAtomQueryFeatures[atomDest]=this.mAtomQueryFeatures[atom];
this.mAtomMapNo[atomDest]=this.mAtomMapNo[atom];
this.mCoordinates[atomDest].set$com_actelion_research_chem_Coordinates(this.mCoordinates[atom]);
this.atomFlags[atomDest]=this.atomFlags[atom];
if (this.infos[atomDest] == null ) {
this.infos[atomDest]=Clazz.array(java.lang.Object, [9]);
}for (var i=0; i < this.infos[atom].length; i++) {
this.infos[atomDest][i]=p$1.clone$O.apply(this, [this.infos[atom][i]]);
}
this.partialCharges[atomDest]=this.partialCharges[atom];
if (this.mAtomList != null ) this.mAtomList[atomDest]=this.mAtomList[atom];
if (this.mAtomCustomLabel != null ) this.mAtomCustomLabel[atomDest]=this.mAtomCustomLabel[atom];
}newAtmNo[atom]=atomDest;
++atomDest;
}
this.mAllAtoms=atomDest;
var bondDest=0;
for (var bnd=0; bnd < this.mAllBonds; bnd++) {
if (this.mBondType[bnd] == 512) continue;
this.mBondType[bondDest]=this.mBondType[bnd];
this.mBondFlags[bondDest]=this.mBondFlags[bnd];
this.mBondQueryFeatures[bondDest]=this.mBondQueryFeatures[bnd];
this.mBondAtom[0][bondDest]=newAtmNo[this.mBondAtom[0][bnd]];
this.mBondAtom[1][bondDest]=newAtmNo[this.mBondAtom[1][bnd]];
++bondDest;
}
this.mAllBonds=bondDest;
return newAtmNo;
});

Clazz.newMeth(C$, 'reorderAtoms$',  function () {
var changed=false;
var N=this.getAllAtoms$();
var i=0;
var j=N - 1;
if (N == 0) {
this.nMovables=0;
return false;
}while (i < j){
while (i < j && !this.isAtomFlag$I$I(i, 1) )++i;

while (i < j && this.isAtomFlag$I$I(j, 1) )--j;

if (this.isAtomFlag$I$I(i, 1) && !this.isAtomFlag$I$I(j, 1) ) {
this.swapAtoms$I$I(i, j);
changed=true;
}}
this.nMovables=this.isAtomFlag$I$I(i, 1) ? i : i + 1;
return changed;
});

Clazz.newMeth(C$, 'setCoordinates$I$com_actelion_research_chem_Coordinates',  function (atom, c) {
this.setAtomX$I$D(atom, c.x);
this.setAtomY$I$D(atom, c.y);
this.setAtomZ$I$D(atom, c.z);
});

Clazz.newMeth(C$, 'getNMovables$',  function () {
if (this.nMovables < 0 || (this.getAllAtoms$() > 0 && !this.isAtomFlag$I$I(0, 2) ) ) this.reorderAtoms$();
return this.nMovables;
});

Clazz.newMeth(C$, 'isMoleculeInOrder$',  function () {
return this.reorderAtoms$() == false ;
});

Clazz.newMeth(C$, 'getPartialCharge$I',  function (a) {
return this.partialCharges[a];
});

Clazz.newMeth(C$, 'setPartialCharge$I$D',  function (a, v) {
this.partialCharges[a]=v;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_Molecule3D','compareTo$O'],  function (o) {
return o == null  ? 1 : this.getName$().compareTo$S(o.getName$());
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
