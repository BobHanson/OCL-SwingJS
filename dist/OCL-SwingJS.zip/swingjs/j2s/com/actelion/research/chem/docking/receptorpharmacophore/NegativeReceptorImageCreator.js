(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.receptorpharmacophore"),I$=[[0,'com.actelion.research.chem.Molecule3D','com.actelion.research.chem.phesa.MolecularVolume','com.actelion.research.chem.Coordinates','com.actelion.research.chem.conf.Conformer','com.actelion.research.chem.docking.receptorpharmacophore.NegativeReceptorImage','com.actelion.research.chem.alignment3d.transformation.Translation']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NegativeReceptorImageCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_alignment3d_transformation_TransformationSequence',  function (lig, rec, transformation) {
var negImg;
var ligand=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[lig]);
ligand.ensureHelperArrays$I(31);
var receptor=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[rec]);
receptor.ensureHelperArrays$I(31);
var molVol=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[ligand]);
var origCOM=Clazz.new_([molVol.getCOM$()],$I$(3,1).c$$com_actelion_research_chem_Coordinates);
var conf=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[ligand]);
var rotation=molVol.preProcess$com_actelion_research_chem_conf_Conformer(conf);
C$.rotateMols$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_alignment3d_transformation_Rotation$com_actelion_research_chem_Coordinates(receptor, ligand, rotation, origCOM);
negImg=Clazz.new_([ligand, receptor, 0.4, Clazz.new_($I$(3,1).c$$D$D$D,[4.0, 4.0, 4.0])],$I$(5,1).c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates);
var bsVolume=negImg.calculate$();
var rot=rotation.getInvert$();
var trans=Clazz.new_([Clazz.array(Double.TYPE, -1, [origCOM.x, origCOM.y, origCOM.z])],$I$(6,1).c$$DA);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(rot);
transformation.addTransformation$com_actelion_research_chem_alignment3d_transformation_Transformation(trans);
return bsVolume;
}, 1);

Clazz.newMeth(C$, 'rotateMols$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_alignment3d_transformation_Rotation$com_actelion_research_chem_Coordinates',  function (receptor, ligand, rotation, origCOM) {
for (var a=0; a < ligand.getAllAtoms$(); a++) {
var c=ligand.getCoordinates$I(a);
c.sub$com_actelion_research_chem_Coordinates(origCOM);
rotation.apply$com_actelion_research_chem_Coordinates(c);
}
for (var a=0; a < receptor.getAllAtoms$(); a++) {
var c=receptor.getCoordinates$I(a);
c.sub$com_actelion_research_chem_Coordinates(origCOM);
rotation.apply$com_actelion_research_chem_Coordinates(c);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
