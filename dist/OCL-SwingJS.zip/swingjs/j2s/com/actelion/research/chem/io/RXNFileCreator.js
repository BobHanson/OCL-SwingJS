(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'com.actelion.research.chem.reaction.Reaction','java.io.StringWriter','com.actelion.research.chem.reaction.ReactionEncoder','com.actelion.research.chem.MolfileCreator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RXNFileCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.rxnbuffer=null;
},1);

C$.$fields$=[['O',['rxnbuffer','StringBuffer']]
,['S',['NL']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
C$.c$$com_actelion_research_chem_reaction_Reaction$S.apply(this, [rxn, null]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_reaction_Reaction$S',  function (r, programName) {
;C$.$init$.apply(this);
var rxn=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_reaction_Reaction,[r]);
try {
var theWriter=Clazz.new_($I$(2,1));
theWriter.write$S("$RXN" + C$.NL);
theWriter.write$S(programName != null  ? programName : "");
theWriter.write$S(C$.NL + C$.NL);
theWriter.write$S("OCL_RXN_V1.0:" + $I$(3).encode$com_actelion_research_chem_reaction_Reaction$Z$I(r, true, 27));
theWriter.write$S(C$.NL);
theWriter.write$S("  " + rxn.getReactants$() + "  " + rxn.getProducts$() + C$.NL );
var scale=p$1.getScalingFactor$com_actelion_research_chem_reaction_Reaction.apply(this, [rxn]);
for (var i=0; i < rxn.getMolecules$(); i++) {
theWriter.write$S("$MOL" + C$.NL);
Clazz.new_([rxn.getMolecule$I(i), true, scale, null],$I$(4,1).c$$com_actelion_research_chem_ExtendedMolecule$Z$D$StringBuilder).writeMolfile$java_io_Writer(theWriter);
}
this.rxnbuffer=theWriter.getBuffer$();
theWriter.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Error in RXNFileCreator: " + e);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getScalingFactor$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
var avbl=0;
var bondCount=0;
for (var m=0; m < rxn.getMolecules$(); m++) {
avbl+=rxn.getMolecule$I(m).getAverageBondLength$() * rxn.getMolecule$I(m).getAllBonds$();
bondCount+=rxn.getMolecule$I(m).getAllBonds$();
}
if (bondCount != 0) return bondCount / avbl;
return 1.0;
}, p$1);

Clazz.newMeth(C$, 'getRXNfile$',  function () {
return this.rxnbuffer != null  ? this.rxnbuffer.toString() : null;
});

Clazz.newMeth(C$, 'writeRXNfile$java_io_Writer',  function (theWriter) {
if (this.rxnbuffer == null ) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["NULL RXNFileBuffer!"]);
theWriter.write$S(this.rxnbuffer.toString());
});

C$.$static$=function(){C$.$static$=0;
C$.NL=System.lineSeparator$();
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:07 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
