(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InChIJNI0", null, 'com.actelion.research.chem.inchi.InChIJNI1');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
}, 1);

Clazz.newMeth(C$, 'getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (mol, molFileDataOrInChI, options, getKey) {
return C$.superclazz.prototype.getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molFileDataOrInChI, options, getKey]);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 17:05:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
