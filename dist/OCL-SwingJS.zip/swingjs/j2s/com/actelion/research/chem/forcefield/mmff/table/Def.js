(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Def");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','int[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readIntsFile$S(csvpath);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
