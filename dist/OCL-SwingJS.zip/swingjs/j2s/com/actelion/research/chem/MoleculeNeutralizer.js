(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.AromaticityResolver']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MoleculeNeutralizer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'neutralizeChargedMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(7);
var overallCharge=0;
var hasOppositeChargedNeighbour=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var hydrogensForDeletion=null;
var valence=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
var atom1=mol.getBondAtom$I$I(0, bond);
var atom2=mol.getBondAtom$I$I(1, bond);
var charge1=mol.getAtomCharge$I(atom1);
var charge2=mol.getAtomCharge$I(atom2);
if (charge1 != 0 && charge2 != 0  && (!!((charge1 < 0) ^ (charge2 < 0))) ) {
hasOppositeChargedNeighbour[atom1]=true;
hasOppositeChargedNeighbour[atom2]=true;
}valence[atom1]+=mol.getBondOrder$I(bond);
valence[atom2]+=mol.getBondOrder$I(bond);
}
for (var chargedAtom=0; chargedAtom < mol.getAtoms$(); chargedAtom++) {
overallCharge+=mol.getAtomCharge$I(chargedAtom);
if (mol.getAtomCharge$I(chargedAtom) == 1) {
if (mol.getAtomicNo$I(chargedAtom) == 7) {
if (!hasOppositeChargedNeighbour[chargedAtom]) {
if (valence[chargedAtom] <= 3) {
overallCharge-=1;
mol.setAtomCharge$I$I(chargedAtom, 0);
if (mol.getConnAtoms$I(chargedAtom) != mol.getAllConnAtoms$I(chargedAtom)) {
mol.deleteAtom$I(mol.getConnAtom$I$I(chargedAtom, mol.getAllConnAtoms$I(chargedAtom) - 1));
mol.ensureHelperArrays$I(7);
}} else if (mol.isAromaticAtom$I(chargedAtom)) {
var isAromaticAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var isAromaticBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
mol.findRingSystem$I$Z$ZA$ZA(chargedAtom, true, isAromaticAtom, isAromaticBond);
for (var donorAtom=0; donorAtom < mol.getAtoms$(); donorAtom++) {
if (isAromaticAtom[donorAtom] && mol.getAtomicNo$I(donorAtom) == 7  && mol.getAtomCharge$I(donorAtom) == 0  && valence[donorAtom] == 2 ) {
if (C$.removeHydrogenAndDelocalize$com_actelion_research_chem_StereoMolecule$ZA$I$I(mol, isAromaticBond, chargedAtom, donorAtom)) {
overallCharge-=1;
break;
}}}
}}}} else if (mol.getAtomCharge$I(chargedAtom) < 0) {
if (mol.getAtomicNo$I(chargedAtom) == 6 || mol.getAtomicNo$I(chargedAtom) == 7  || mol.getAtomicNo$I(chargedAtom) == 8  || mol.getAtomicNo$I(chargedAtom) == 16 ) {
if (!hasOppositeChargedNeighbour[chargedAtom]) {
overallCharge-=mol.getAtomCharge$I(chargedAtom);
mol.setAtomCharge$I$I(chargedAtom, 0);
} else {
var member=Clazz.array(Integer.TYPE, [16]);
member[0]=chargedAtom;
var noOfMembers=1;
var memberToProcess=0;
while (memberToProcess < noOfMembers){
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var atom=-1;
if (mol.getBondAtom$I$I(0, bond) == member[memberToProcess]) atom=mol.getBondAtom$I$I(1, bond);
 else if (mol.getBondAtom$I$I(1, bond) == member[memberToProcess]) atom=mol.getBondAtom$I$I(0, bond);
if (atom == -1) continue;
if (mol.getAtomCharge$I(atom) != 0) {
var found=false;
for (var i=0; i < noOfMembers; i++) {
if (atom == member[i]) {
found=true;
break;
}}
if (!found) {
if (noOfMembers == member.length) {
var copy=Clazz.array(Integer.TYPE, [2 * member.length]);
System.arraycopy$O$I$O$I$I(member, 0, copy, 0, member.length);
member=copy;
}member[noOfMembers++]=atom;
}}}
++memberToProcess;
}
var fragmentsCharge=0;
for (var i=0; i < noOfMembers; i++) {
fragmentsCharge+=mol.getAtomCharge$I(member[i]);
}
if (fragmentsCharge < 0) {
var leastElectronegative=-1;
var leastElectronegativity=99;
for (var i=0; i < noOfMembers; i++) {
if (mol.getAtomCharge$I(member[i]) < 0) {
if (leastElectronegativity > C$.electronegativity$I(mol.getAtomicNo$I(member[i]))) {
leastElectronegativity=C$.electronegativity$I(mol.getAtomicNo$I(member[i]));
leastElectronegative=member[i];
}}}
if (leastElectronegative != -1) {
overallCharge-=mol.getAtomCharge$I(leastElectronegative);
mol.setAtomCharge$I$I(leastElectronegative, 0);
}}}}}}
if (hydrogensForDeletion != null ) mol.deleteAtoms$ZA(hydrogensForDeletion);
if (overallCharge > 0) overallCharge=C$.removeAcidicHydrogens$com_actelion_research_chem_StereoMolecule$I(mol, overallCharge);
return overallCharge;
}, 1);

Clazz.newMeth(C$, 'removeHydrogenAndDelocalize$com_actelion_research_chem_StereoMolecule$ZA$I$I',  function (mol, isAromaticBond, chargedAtom, donorAtom) {
var oldBondType=Clazz.array(Integer.TYPE, [mol.getBonds$()]);
var bondMask=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
oldBondType[bond]=mol.getBondType$I(bond);
if (isAromaticBond[bond]) {
bondMask[bond]=true;
mol.setBondType$I$I(bond, 1);
}}
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (atom != donorAtom && mol.getAtomPi$I(atom) == 0  && bondMask[mol.getConnBond$I$I(donorAtom, 0)] ) {
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var bond=mol.getConnBond$I$I(atom, i);
mol.setBondType$I$I(bond, 1);
bondMask[bond]=false;
}
}}
for (var i=0; i < mol.getConnAtoms$I(chargedAtom); i++) {
var bond=mol.getConnBond$I$I(chargedAtom, i);
mol.setBondType$I$I(bond, 1);
bondMask[bond]=false;
}
if (Clazz.new_($I$(1,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).locateDelocalizedDoubleBonds$ZA(bondMask)) {
mol.setAtomCharge$I$I(chargedAtom, 0);
if (mol.getConnAtoms$I(donorAtom) != mol.getAllConnAtoms$I(donorAtom)) {
mol.deleteAtom$I(mol.getConnAtom$I$I(donorAtom, mol.getAllConnAtoms$I(donorAtom) - 1));
}mol.ensureHelperArrays$I(7);
return true;
}for (var bond=0; bond < mol.getBonds$(); bond++) {
mol.setBondType$I$I(bond, oldBondType[bond]);
}
return false;
}, 1);

Clazz.newMeth(C$, 'removeAcidicHydrogens$com_actelion_research_chem_StereoMolecule$I',  function (mol, maxHydrogens) {
if (maxHydrogens > 0) maxHydrogens=C$.removeHydrogensFromHalogene$com_actelion_research_chem_StereoMolecule$I$I(mol, maxHydrogens, 9);
if (maxHydrogens > 0) maxHydrogens=C$.removeHydrogensFromHalogene$com_actelion_research_chem_StereoMolecule$I$I(mol, maxHydrogens, 17);
if (maxHydrogens > 0) maxHydrogens=C$.removeHydrogensFromHalogene$com_actelion_research_chem_StereoMolecule$I$I(mol, maxHydrogens, 35);
if (maxHydrogens > 0) maxHydrogens=C$.removeHydrogensFromHalogene$com_actelion_research_chem_StereoMolecule$I$I(mol, maxHydrogens, 53);
if (maxHydrogens > 0) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomCharge$I(atom) > 0) {
var found=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var connAtom=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomCharge$I(connAtom) == 0 && mol.isElectronegative$I(connAtom)  && mol.getImplicitHydrogens$I(connAtom) > 0 ) {
mol.setAtomCharge$I$I(connAtom, -1);
--maxHydrogens;
if (maxHydrogens == 0) return 0;
found=true;
break;
}}
if (found) continue;
}}
}if (maxHydrogens > 0) maxHydrogens=C$.removeAcidicHydrogensFromAcid$com_actelion_research_chem_StereoMolecule$I$I$I(mol, maxHydrogens, 8, 16);
if (maxHydrogens > 0) maxHydrogens=C$.removeAcidicHydrogensFromAcid$com_actelion_research_chem_StereoMolecule$I$I$I(mol, maxHydrogens, 8, 15);
if (maxHydrogens > 0) maxHydrogens=C$.removeAcidicHydrogensFromAcid$com_actelion_research_chem_StereoMolecule$I$I$I(mol, maxHydrogens, 8, 6);
if (maxHydrogens > 0) maxHydrogens=C$.removeAcidicHydrogensFromAcid$com_actelion_research_chem_StereoMolecule$I$I$I(mol, maxHydrogens, 7, 16);
return maxHydrogens;
}, 1);

Clazz.newMeth(C$, 'removeHydrogensFromHalogene$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, maxHydrogens, atomicNo) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == atomicNo && mol.getAtomCharge$I(atom) == 0  && mol.getConnAtoms$I(atom) == 0 ) {
mol.setAtomCharge$I$I(atom, -1);
--maxHydrogens;
if (maxHydrogens == 0) return 0;
}}
return maxHydrogens;
}, 1);

Clazz.newMeth(C$, 'removeAcidicHydrogensFromAcid$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, maxHydrogens, atomicNo, centralAtomicNo) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == atomicNo && mol.getAtomCharge$I(atom) == 0  && mol.getImplicitHydrogens$I(atom) > 0 ) {
var deprotonated=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
if (mol.getConnBondOrder$I$I(atom, i) == 1) {
var centralAtom=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(centralAtom) == centralAtomicNo) {
var oxoFound=false;
var deprotonatedFound=false;
for (var j=0; j < mol.getConnAtoms$I(centralAtom); j++) {
var connAtom=mol.getConnAtom$I$I(centralAtom, j);
if (mol.getAtomCharge$I(connAtom) < 0) {
deprotonatedFound=true;
break;
}if (connAtom != atom && mol.getAtomicNo$I(connAtom) == 8  && mol.getConnBondOrder$I$I(centralAtom, j) == 2 ) {
oxoFound=true;
}}
if (!deprotonatedFound && oxoFound ) {
mol.setAtomCharge$I$I(atom, -1);
--maxHydrogens;
if (maxHydrogens == 0) return 0;
deprotonated=true;
}}}if (deprotonated) break;
}
}}
return maxHydrogens;
}, 1);

Clazz.newMeth(C$, 'electronegativity$I',  function (atomicNo) {
switch (atomicNo) {
case 6:
return 1;
case 53:
return 2;
case 33:
return 3;
case 34:
return 4;
case 35:
return 5;
case 15:
return 6;
case 16:
return 7;
case 17:
return 8;
case 7:
return 9;
case 8:
return 10;
case 9:
return 11;
}
return 0;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:18 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
