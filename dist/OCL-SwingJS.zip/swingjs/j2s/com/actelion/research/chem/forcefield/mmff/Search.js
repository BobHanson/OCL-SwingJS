(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Search");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 's$O$O',  function (a, b) {
return a;
}, 1);

Clazz.newMeth(C$, 'binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable',  function (col, val, lo, hi, findlow, arr) {
lo=Math.max(0, lo);
hi=Math.min(arr.length$(), hi);
var at=((hi - lo)/2|0);
var min=lo;
var max=hi;
if (arr.get$I$I(min, col) > val || arr.get$I$I(max - 1, col) < val ) return -1;
while (hi >= lo){
at=lo + ((hi - lo)/2|0);
var vat=arr.get$I$I(at, col);
if (vat == val) {
if (findlow && at > min  && arr.get$I$I(at - 1, col) == val ) hi=at;
 else if (!findlow && at < max - 1  && arr.get$I$I(at + 1, col) == val ) lo=at;
 else return at;
} else if (vat > val) hi=at;
 else if (vat < val) lo=at;
if (hi - lo == 1 && arr.get$I$I(lo, col) < val  && arr.get$I$I(hi, col) > val ) break;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'binary$I$I$com_actelion_research_chem_forcefield_mmff_Searchable',  function (col, val, data) {
return C$.binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable(col, val, 0, data.length$(), true, data);
}, 1);

Clazz.newMeth(C$, 'binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable',  function (cols, vals, data) {
if (cols.length != vals.length) return -1;
var lo=0;
var hi=data.length$();
var i;
for (i=0; i < cols.length - 1; i++) {
lo=C$.binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable(cols[i], vals[i], lo, hi + 1, true, data);
hi=C$.binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable(cols[i], vals[i], lo, hi + 1, false, data);
if (lo == -1 || hi == -1 ) return -1;
}
return C$.binary$I$I$I$I$Z$com_actelion_research_chem_forcefield_mmff_Searchable(cols[i], vals[i], lo, hi + 1, true, data);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
