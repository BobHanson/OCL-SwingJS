(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SortedStringList", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mList=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['mList','java.util.ArrayList']]]

Clazz.newMeth(C$, 'contains$S',  function (theString) {
return this.getListIndex$S(theString) != -1;
});

Clazz.newMeth(C$, 'equals$com_actelion_research_chem_SortedStringList',  function (s) {
if (this.mList.size$() != s.mList.size$()) return false;
for (var i=0; i < this.mList.size$(); i++) if (!this.mList.get$I(i).equals$O(s.mList.get$I(i))) return false;

return true;
});

Clazz.newMeth(C$, 'getListIndex$S',  function (theString) {
var vectorSize=this.mList.size$();
if (vectorSize == 0) return -1;
var index=1;
while (2 * index <= vectorSize)index<<=1;

var increment=index;
--index;
while (increment != 0){
increment>>=1;
if (index >= vectorSize) {
index-=increment;
continue;
}var comparison=theString.compareTo$S(this.mList.get$I(index));
if (comparison == 0) return index;
if (increment == 0) break;
if (comparison < 0) {
index-=increment;
} else {
index+=increment;
}}
return -1;
});

Clazz.newMeth(C$, 'addString$S',  function (theString) {
var vectorSize=this.mList.size$();
if (vectorSize == 0) {
this.mList.add$I$O(0, theString);
return 0;
}var index=1;
while (2 * index <= vectorSize)index<<=1;

var increment=index;
--index;
while (increment != 0){
increment>>=1;
if (index >= vectorSize) {
index-=increment;
continue;
}var comparison=theString.compareTo$S(this.mList.get$I(index));
if (comparison == 0) return -1;
if (increment == 0) break;
if (comparison < 0) {
index-=increment;
} else {
index+=increment;
}}
if ((index < vectorSize) && (theString.compareTo$S(this.mList.get$I(index)) > 0) ) ++index;
this.mList.add$I$O(index, theString);
return index;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.mList.size$();
});

Clazz.newMeth(C$, 'getStringAt$I',  function (i) {
return this.mList.get$I(i);
});

Clazz.newMeth(C$, 'toArray$',  function () {
return this.mList.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'removeAllStrings$',  function () {
this.mList.clear$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
