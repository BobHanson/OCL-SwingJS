(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[[0,'com.actelion.research.chem.conf.TorsionDB','java.io.BufferedReader','java.io.FileReader','com.actelion.research.chem.Molecule','com.actelion.research.chem.conf.VDWRadii']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondLengthSet");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mBondLength','float[]','+mBondStdDev']]
,['Z',['isInitialized'],'S',['sCustomBondDataFile'],'O',['BOND_ID','int[]','+BOND_COUNT','BOND_LENGTH','float[]','+BOND_STDDEV','CONSIDER_PI','boolean[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
mol.ensureHelperArrays$I(7);
this.mBondLength=Clazz.array(Float.TYPE, [mol.getAllBonds$()]);
this.mBondStdDev=Clazz.array(Float.TYPE, [mol.getAllBonds$()]);
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var index=C$.getBondIndex$com_actelion_research_chem_StereoMolecule$I(mol, bond);
if (index == -1) {
this.mBondLength[bond]=C$.getBondLengthFromCovalentRadii$com_actelion_research_chem_StereoMolecule$I(mol, bond);
this.mBondStdDev[bond]=C$.getStdDevFromCovalentRadii$com_actelion_research_chem_StereoMolecule$I(mol, bond);
} else {
this.mBondLength[bond]=C$.getBondLength$I(index);
this.mBondStdDev[bond]=C$.getBondStdDev$I(index);
}}
}, 1);

Clazz.newMeth(C$, 'setCustomDataFile$S',  function (filePathAndName) {
C$.sCustomBondDataFile=filePathAndName;
C$.isInitialized=false;
}, 1);

Clazz.newMeth(C$, 'initialize$',  function () {
if (!C$.isInitialized) {
{
try {
var bdr=(C$.sCustomBondDataFile == null ) ? $I$(1).openReader$S("bondLengthData.txt") : Clazz.new_([Clazz.new_($I$(3,1).c$$S,[C$.sCustomBondDataFile])],$I$(2,1).c$$java_io_Reader);
var countString=bdr.readLine$();
var count=(countString == null ) ? 0 : Integer.parseInt$S(countString);
C$.BOND_ID=Clazz.array(Integer.TYPE, [count]);
C$.BOND_LENGTH=Clazz.array(Float.TYPE, [count]);
C$.BOND_STDDEV=Clazz.array(Float.TYPE, [count]);
C$.BOND_COUNT=Clazz.array(Integer.TYPE, [count]);
for (var i=0; i < count; i++) {
var line=bdr.readLine$();
if (line != null ) {
var item=line.split$S("\\t");
if (item.length == 4) {
try {
C$.BOND_ID[i]=Integer.parseInt$S(item[0]);
C$.BOND_LENGTH[i]=Float.parseFloat$S(item[1]);
C$.BOND_STDDEV[i]=Float.parseFloat$S(item[2]);
C$.BOND_COUNT[i]=Integer.parseInt$S(item[3]);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
break;
} else {
throw nfe;
}
}
}}}
bdr.close$();
C$.isInitialized=true;
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
}}}, 1);

Clazz.newMeth(C$, 'getLength$I',  function (bond) {
return this.mBondLength[bond];
});

Clazz.newMeth(C$, 'getStdDev$I',  function (bond) {
return this.mBondStdDev[bond];
});

Clazz.newMeth(C$, 'getBondIDString$I',  function (index) {
if (index == -1) return "unknown";
var id=C$.BOND_ID[index];
var order=(id & -16777216) >> 24;
var pi1=(id & 15728640) >> 20;
var pi2=(id & 3840) >> 8;
var atomicNo1=(id & 1044480) >> 12;
var atomicNo2=(id & 255);
var piString1=(C$.isPiConsidered$I(atomicNo1)) ? Integer.toString$I(pi1) : "";
var piString2=(C$.isPiConsidered$I(atomicNo2)) ? Integer.toString$I(pi2) : "";
var s=(order == 0) ? "d" : ((order > 3) ? "a" : "") + (order & 3);
return s + $I$(4).cAtomLabel[atomicNo1] + piString1 + $I$(4).cAtomLabel[atomicNo2] + piString2 ;
}, 1);

Clazz.newMeth(C$, 'getBondIndex$I$Z$Z$I$I$I$I',  function (bondOrder, isAromatic, isDelocalized, atomicNo1, atomicNo2, atomPi1, atomPi2) {
return C$.lookupBondIndex$I(C$.getBondID$I$Z$Z$I$I$I$I(bondOrder, isAromatic, isDelocalized, atomicNo1, atomicNo2, atomPi1, atomPi2));
}, 1);

Clazz.newMeth(C$, 'getBondID$I$Z$Z$I$I$I$I',  function (bondOrder, isAromatic, isDelocalized, atomicNo1, atomicNo2, atomPi1, atomPi2) {
var pi1=(atomicNo1 < C$.CONSIDER_PI.length && C$.CONSIDER_PI[atomicNo1] ) ? atomPi1 << 8 : 0;
var pi2=(atomicNo2 < C$.CONSIDER_PI.length && C$.CONSIDER_PI[atomicNo2] ) ? atomPi2 << 8 : 0;
var atomType1=pi1 + atomicNo1;
var atomType2=pi2 + atomicNo2;
var bondType=isDelocalized ? 0 : isAromatic ? 4 + bondOrder : bondOrder;
return (bondType << 24) + ((atomType1 < atomType2) ? (atomType1 << 12) + atomType2 : (atomType2 << 12) + atomType1);
}, 1);

Clazz.newMeth(C$, 'getBondIndex$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
var atom1=mol.getBondAtom$I$I(0, bond);
var atom2=mol.getBondAtom$I$I(1, bond);
var atomicNo1=mol.getAtomicNo$I(atom1);
var atomicNo2=mol.getAtomicNo$I(atom2);
return C$.getBondIndex$I$Z$Z$I$I$I$I(mol.getBondOrder$I(bond), mol.isAromaticBond$I(bond), mol.isDelocalizedBond$I(bond), atomicNo1, atomicNo2, C$.getAtomPi$com_actelion_research_chem_StereoMolecule$I(mol, atom1), C$.getAtomPi$com_actelion_research_chem_StereoMolecule$I(mol, atom2));
}, 1);

Clazz.newMeth(C$, 'getBondID$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
var atom1=mol.getBondAtom$I$I(0, bond);
var atom2=mol.getBondAtom$I$I(1, bond);
var atomicNo1=mol.getAtomicNo$I(atom1);
var atomicNo2=mol.getAtomicNo$I(atom2);
return C$.getBondID$I$Z$Z$I$I$I$I(mol.getBondOrder$I(bond), mol.isAromaticBond$I(bond), mol.isDelocalizedBond$I(bond), atomicNo1, atomicNo2, C$.getAtomPi$com_actelion_research_chem_StereoMolecule$I(mol, atom1), C$.getAtomPi$com_actelion_research_chem_StereoMolecule$I(mol, atom2));
}, 1);

Clazz.newMeth(C$, 'isPiConsidered$I',  function (atomicNo) {
return (atomicNo < C$.CONSIDER_PI.length) && C$.CONSIDER_PI[atomicNo] ;
}, 1);

Clazz.newMeth(C$, 'getAtomPi$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (atom >= mol.getAtoms$()) return 0;
if (mol.isAromaticAtom$I(atom) && mol.getAtomicNo$I(atom) == 6  && mol.getAtomCharge$I(atom) != 0 ) return 1;
return mol.getAtomPi$I(atom);
}, 1);

Clazz.newMeth(C$, 'lookupBondLength$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
var index=C$.getBondIndex$com_actelion_research_chem_StereoMolecule$I(mol, bond);
return (index == -1) ? C$.getBondLengthFromCovalentRadii$com_actelion_research_chem_StereoMolecule$I(mol, bond) : C$.getBondLength$I(index);
}, 1);

Clazz.newMeth(C$, 'getBondLengthFromCovalentRadii$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
var atomicNo1=mol.getAtomicNo$I(mol.getBondAtom$I$I(0, bond));
var atomicNo2=mol.getAtomicNo$I(mol.getBondAtom$I$I(1, bond));
return C$.getCovalentRadius$I(atomicNo1) + C$.getCovalentRadius$I(atomicNo2);
}, 1);

Clazz.newMeth(C$, 'getStdDevFromCovalentRadii$com_actelion_research_chem_StereoMolecule$I',  function (mol, bond) {
var atomicNo1=mol.getAtomicNo$I(mol.getBondAtom$I$I(0, bond));
var atomicNo2=mol.getAtomicNo$I(mol.getBondAtom$I$I(1, bond));
return (atomicNo1 < $I$(5).COVALENT_RADIUS.length ? 0.05 : 0.125) + (atomicNo2 < $I$(5).COVALENT_RADIUS.length ? 0.05 : 0.125);
}, 1);

Clazz.newMeth(C$, 'getCovalentRadius$I',  function (atomicNo) {
return (atomicNo < $I$(5).COVALENT_RADIUS.length) ? $I$(5).COVALENT_RADIUS[atomicNo] : (atomicNo < $I$(5).VDW_RADIUS.length) ? 0.6 * $I$(5).VDW_RADIUS[atomicNo] : 1.8;
}, 1);

Clazz.newMeth(C$, 'getBondLength$I',  function (index) {
return (index == -1) ? 2.0005 : C$.BOND_LENGTH[index];
}, 1);

Clazz.newMeth(C$, 'getBondCount$I',  function (index) {
return (index == -1) ? 0 : C$.BOND_COUNT[index];
}, 1);

Clazz.newMeth(C$, 'getBondStdDev$I',  function (index) {
return (index == -1) ? 1.0 : C$.BOND_STDDEV[index];
}, 1);

Clazz.newMeth(C$, 'lookupBondIndex$I',  function (id) {
if (!C$.isInitialized) C$.initialize$();
var index=2048;
var increment=1024;
for (var i=0; i < 12; i++) {
var comparison=(index >= C$.BOND_ID.length || id < C$.BOND_ID[index] ) ? -1 : (id == C$.BOND_ID[index]) ? 0 : 1;
if (comparison == 0) return index;
index=(comparison < 0) ? index - increment : index + increment;
increment=(increment/(2)|0);
}
return -1;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.sCustomBondDataFile=null;
C$.isInitialized=false;
C$.CONSIDER_PI=Clazz.array(Boolean.TYPE, -1, [false, false, false, false, false, true, true, true, true, false, false, false, false, false, false, true, true]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:11 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
