(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.calculator"),I$=[[0,'com.actelion.research.util.ArrayUtils']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IntQueue");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.begin=0;
this.end=0;
},1);

C$.$fields$=[['I',['begin','end'],'O',['s','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [100]);
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (size) {
;C$.$init$.apply(this);
this.s=Clazz.array(Integer.TYPE, [size]);
}, 1);

Clazz.newMeth(C$, 'get$I',  function (ind) {
return this.s[ind];
});

Clazz.newMeth(C$, 'getBegin$',  function () {
return this.begin;
});

Clazz.newMeth(C$, 'getEnd$',  function () {
return this.end;
});

Clazz.newMeth(C$, 'isEmpty$',  function () {
return this.end <= this.begin;
});

Clazz.newMeth(C$, 'clear$',  function () {
this.begin=this.end=0;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.end - this.begin;
});

Clazz.newMeth(C$, 'pop$',  function () {
return this.s[this.begin++];
});

Clazz.newMeth(C$, 'peek$',  function () {
return this.s[this.begin++];
});

Clazz.newMeth(C$, 'push$I',  function (i) {
if (this.end >= this.s.length) {
$I$(1).resize$O$I(this.s, this.s.length * 2);
this.s=$I$(1).resize$O$I(this.s, this.s.length * 2);
}this.s[this.end++]=i;
});

Clazz.newMeth(C$, 'indexOf$I',  function (ind) {
for (var i=0; i < this.end; i++) {
if (this.s[i] == ind) return i;
}
return -1;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:20 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
