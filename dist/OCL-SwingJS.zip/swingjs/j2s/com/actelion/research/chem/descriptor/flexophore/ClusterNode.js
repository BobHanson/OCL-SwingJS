(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'java.util.ArrayList','java.util.Collections']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ClusterNode", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexCenter','rmsd'],'O',['liIndexMember','java.util.List']]]

Clazz.newMeth(C$, 'c$$I',  function (indexCenter) {
;C$.$init$.apply(this);
this.indexCenter=indexCenter;
this.liIndexMember=Clazz.new_($I$(1,1));
this.rmsd=0;
}, 1);

Clazz.newMeth(C$, 'add$I',  function (index) {
this.liIndexMember.add$O(Integer.valueOf$I(index));
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_flexophore_ClusterNode','compareTo$O'],  function (cl) {
return Double.compare$D$D(this.rmsd, cl.rmsd);
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var bEqual=true;
var cl=obj;
if (this.liIndexMember.size$() != cl.liIndexMember.size$()) {
return false;
}var l1=Clazz.new_($I$(1,1).c$$java_util_Collection,[this.liIndexMember]);
l1.add$O(Integer.valueOf$I(this.indexCenter));
var l2=Clazz.new_($I$(1,1).c$$java_util_Collection,[cl.liIndexMember]);
l2.add$O(Integer.valueOf$I(cl.indexCenter));
$I$(2).sort$java_util_List(l1);
$I$(2).sort$java_util_List(l2);
for (var i=0; i < l1.size$(); i++) {
var v1=(l1.get$I(i)).$c();
var v2=(l2.get$I(i)).$c();
if (v1 != v2) {
bEqual=false;
break;
}}
return bEqual;
});

Clazz.newMeth(C$, 'getIndexCenter$',  function () {
return this.indexCenter;
});

Clazz.newMeth(C$, 'getRMSD$',  function () {
return this.rmsd;
});

Clazz.newMeth(C$, 'setRMSD$I',  function (rmsd) {
this.rmsd=rmsd;
});

Clazz.newMeth(C$, 'getRMSD$com_actelion_research_chem_descriptor_flexophore_ClusterNode$com_actelion_research_chem_descriptor_flexophore_DistHist',  function (cluster, mdh) {
var rmsd=0;
var liIndex=cluster.getClusterMember$();
for (var i=0; i < liIndex.size$(); i++) {
var dist=mdh.getMinDist$I$I(cluster.getIndexCenter$(), (liIndex.get$I(i)).$c());
rmsd+=dist * dist;
}
return rmsd;
}, 1);

Clazz.newMeth(C$, 'getClusterMember$',  function () {
return this.liIndexMember;
});

Clazz.newMeth(C$, 'isCluster$',  function () {
if (this.liIndexMember.size$() > 0) return true;
 else return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
