(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking"),I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.calc.SingularValueDecomposition','com.actelion.research.calc.Matrix','com.actelion.research.chem.phesa.PheSAAlignment','com.actelion.research.chem.Canonizer','com.actelion.research.chem.AtomFunctionAnalyzer','com.actelion.research.chem.conf.AtomAssembler']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DockingUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getCOM$com_actelion_research_chem_conf_Conformer',  function (conf) {
var counter=0;
var com=Clazz.new_($I$(1,1));
for (var a=0; a < conf.getMolecule$().getAtoms$(); a++) {
var coords=conf.getCoordinates$I(a);
com.add$com_actelion_research_chem_Coordinates(coords);
++counter;
}
com.scale$D(1.0 / counter);
return com;
}, 1);

Clazz.newMeth(C$, 'getCOM$com_actelion_research_chem_StereoMolecule',  function (conf) {
var counter=0;
var com=Clazz.new_($I$(1,1));
for (var a=0; a < conf.getAtoms$(); a++) {
var coords=conf.getCoordinates$I(a);
com.add$com_actelion_research_chem_Coordinates(coords);
++counter;
}
com.scale$D(1.0 / counter);
return com;
}, 1);

Clazz.newMeth(C$, 'createInitialOrientation$com_actelion_research_chem_conf_Conformer',  function (conf) {
var m=C$.calculateMassCovarianceMatrix$com_actelion_research_chem_conf_Conformer(conf);
var svd=Clazz.new_([m.getArray$(), null, null],$I$(2,1).c$$DAA$com_actelion_research_calc_ProgressListener$com_actelion_research_calc_ThreadMaster);
var u=Clazz.new_([svd.getU$()],$I$(3,1).c$$DAA);
var det=u.det$();
if (det < 0 ) {
u.set$I$I$D(0, 1, -u.get$I$I(0, 1));
u.set$I$I$D(1, 1, -u.get$I$I(1, 1));
u.set$I$I$D(2, 1, -u.get$I$I(2, 1));
}$I$(4,"rotateMol$com_actelion_research_chem_conf_Conformer$DAA",[conf, u.getArray$()]);
return u;
}, 1);

Clazz.newMeth(C$, 'calculateMassCovarianceMatrix$com_actelion_research_chem_conf_Conformer',  function (conf) {
var massMatrix=Clazz.new_($I$(3,1).c$$I$I,[3, 3]);
var counter=0;
for (var a=0; a < conf.getMolecule$().getAllAtoms$(); a++) {
var coords=conf.getCoordinates$I(a);
++counter;
var value=coords.x * coords.x;
massMatrix.addToElement$I$I$D(0, 0, value);
value=coords.x * coords.y;
massMatrix.addToElement$I$I$D(0, 1, value);
value=coords.x * coords.z;
massMatrix.addToElement$I$I$D(0, 2, value);
value=coords.y * coords.y;
massMatrix.addToElement$I$I$D(1, 1, value);
value=coords.y * coords.z;
massMatrix.addToElement$I$I$D(1, 2, value);
value=coords.z * coords.z;
massMatrix.addToElement$I$I$D(2, 2, value);
}
massMatrix.set$I$I$D(0, 0, massMatrix.get$I$I(0, 0) / counter);
massMatrix.set$I$I$D(0, 1, massMatrix.get$I$I(0, 1) / counter);
massMatrix.set$I$I$D(0, 2, massMatrix.get$I$I(0, 2) / counter);
massMatrix.set$I$I$D(1, 1, massMatrix.get$I$I(1, 1) / counter);
massMatrix.set$I$I$D(1, 2, massMatrix.get$I$I(1, 2) / counter);
massMatrix.set$I$I$D(2, 2, massMatrix.get$I$I(2, 2) / counter);
massMatrix.set$I$I$D(1, 0, massMatrix.get$I$I(0, 1));
massMatrix.set$I$I$D(2, 0, massMatrix.get$I$I(0, 2));
massMatrix.set$I$I$D(2, 1, massMatrix.get$I$I(1, 2));
return massMatrix;
}, 1);

Clazz.newMeth(C$, 'randomVectorInSphere$java_util_Random',  function (r) {
var r1=1.0;
var r2=0.0;
var r3=0.0;
var notDone=true;
while (notDone){
r1=-1 + 2 * r.nextDouble$();
r2=-1 + 2 * r.nextDouble$();
r3=-1 + 2 * r.nextDouble$();
if (r1 * r1 + r2 * r2 + r3 * r3 < 1.0 ) notDone=false;
}
return Clazz.new_($I$(1,1).c$$D$D$D,[r1, r2, r3]);
}, 1);

Clazz.newMeth(C$, 'repairMolecule3D$com_actelion_research_chem_StereoMolecule',  function (lig) {
Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[lig]);
lig.normalizeAmbiguousBonds$();
C$.repairQuaternaryNitrogen$com_actelion_research_chem_StereoMolecule(lig);
C$.repairCarboxylate$com_actelion_research_chem_StereoMolecule(lig);
C$.addImplicitHydrogens$com_actelion_research_chem_StereoMolecule(lig);
}, 1);

Clazz.newMeth(C$, 'repairQuaternaryNitrogen$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 7) {
if (mol.getOccupiedValence$I(i) == 4) {
if (mol.getAtomCharge$I(i) == 0) {
mol.setAtomCharge$I$I(i, 1);
}}}}
mol.ensureHelperArrays$I(7);
}, 1);

Clazz.newMeth(C$, 'assignLikelyProtonationStates$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var a=0; a < mol.getAtoms$(); a++) {
if (mol.getAtomicNo$I(a) == 7) {
if ($I$(6).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, a)) mol.setAtomCharge$I$I(a, 1);
}if (mol.getAtomicNo$I(a) == 8) {
if ($I$(6).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, a)) mol.setAtomCharge$I$I(a, -1);
}}
C$.addImplicitHydrogens$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$, 'addImplicitHydrogens$com_actelion_research_chem_StereoMolecule',  function (mol) {
Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[mol]).addImplicitHydrogens$();
mol.ensureHelperArrays$I(1);
}, 1);

Clazz.newMeth(C$, 'repairCarboxylate$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (mol.getAtomicNo$I(i) == 8) {
if (mol.getOccupiedValence$I(i) == 1) {
if (mol.getAtomCharge$I(i) == 0) {
mol.setAtomCharge$I$I(i, -1);
}}}}
mol.ensureHelperArrays$I(7);
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:16 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
