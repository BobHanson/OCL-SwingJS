(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.DrawingObjectFactory','com.actelion.research.gui.generic.GenericRectangle','com.actelion.research.chem.Molecule','StringBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractDrawingObject");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mIsSelected','mProtectedFromDeletion'],'D',['mTransformationReferenceX','mTransformationReferenceY'],'O',['mPoint','com.actelion.research.gui.generic.GenericPoint[]','mTransformationValue1','double[]','+mTransformationValue2']]]

Clazz.newMeth(C$, 'instantiate$S',  function (descriptor) {
return $I$(1).createObject$S(descriptor);
}, 1);

Clazz.newMeth(C$, 'move$D$D',  function (dx, dy) {
if (this.mPoint != null ) {
for (var i=0; i < this.mPoint.length; i++) {
this.mPoint[i].x+=dx;
this.mPoint[i].y+=dy;
}
}});

Clazz.newMeth(C$, 'scale$D',  function (f) {
if (this.mPoint != null ) {
for (var i=0; i < this.mPoint.length; i++) {
this.mPoint[i].x*=f;
this.mPoint[i].y*=f;
}
}});

Clazz.newMeth(C$, 'isDeletable$',  function () {
return !this.mProtectedFromDeletion;
});

Clazz.newMeth(C$, 'setDeletable$Z',  function (d) {
this.mProtectedFromDeletion=!d;
});

Clazz.newMeth(C$, 'isSelected$',  function () {
return this.mIsSelected;
});

Clazz.newMeth(C$, 'setSelected$Z',  function (s) {
this.mIsSelected=s;
});

Clazz.newMeth(C$, 'getBoundingRect$com_actelion_research_gui_generic_GenericDrawContext',  function (context) {
if (this.mPoint == null ) return null;
var bounds=Clazz.new_($I$(2,1).c$$D$D$D$D,[this.mPoint[0].x, this.mPoint[0].y, 0, 0]);
for (var i=1; i < this.mPoint.length; i++) {
if (bounds.x > this.mPoint[i].x ) {
bounds.width+=bounds.x - this.mPoint[i].x;
bounds.x=this.mPoint[i].x;
} else if (bounds.width < this.mPoint[i].x - bounds.x ) {
bounds.width=this.mPoint[i].x - bounds.x;
}if (bounds.y > this.mPoint[i].y ) {
bounds.height+=bounds.y - this.mPoint[i].y;
bounds.y=this.mPoint[i].y;
} else if (bounds.height < this.mPoint[i].y - bounds.y ) {
bounds.height=this.mPoint[i].y - bounds.y;
}}
return bounds;
});

Clazz.newMeth(C$, 'isSurroundedBy$com_actelion_research_gui_generic_GenericShape',  function (shape) {
if (this.mPoint == null ) return false;
for (var i=0; i < this.mPoint.length; i++) if (!shape.contains$D$D(this.mPoint[i].x, this.mPoint[i].y)) return false;

return true;
});

Clazz.newMeth(C$, 'translateInit$D$D',  function (x, y) {
this.mTransformationReferenceX=x;
this.mTransformationReferenceY=y;
if (this.mPoint != null ) {
var pointCount=this.mPoint.length;
this.mTransformationValue1=Clazz.array(Double.TYPE, [pointCount]);
this.mTransformationValue2=Clazz.array(Double.TYPE, [pointCount]);
for (var i=0; i < pointCount; i++) {
this.mTransformationValue1[i]=this.mPoint[i].x;
this.mTransformationValue2[i]=this.mPoint[i].y;
}
}});

Clazz.newMeth(C$, 'translate$D$D',  function (x, y) {
if (this.mPoint != null ) {
for (var i=0; i < this.mPoint.length; i++) {
this.mPoint[i].x=this.mTransformationValue1[i] + x - this.mTransformationReferenceX;
this.mPoint[i].y=this.mTransformationValue2[i] + y - this.mTransformationReferenceY;
}
}});

Clazz.newMeth(C$, 'zoomAndRotateInit$D$D',  function (x, y) {
this.mTransformationReferenceX=x;
this.mTransformationReferenceY=y;
if (this.mPoint != null ) {
var pointCount=this.mPoint.length;
this.mTransformationValue1=Clazz.array(Double.TYPE, [pointCount]);
this.mTransformationValue2=Clazz.array(Double.TYPE, [pointCount]);
for (var i=0; i < pointCount; i++) {
var dx=x - this.mPoint[i].x;
var dy=y - this.mPoint[i].y;
this.mTransformationValue2[i]=Math.sqrt(dx * dx + dy * dy);
this.mTransformationValue1[i]=$I$(3).getAngle$D$D$D$D(x, y, this.mPoint[i].x, this.mPoint[i].y);
}
}});

Clazz.newMeth(C$, 'zoomAndRotate$D$D',  function (zoom, angle) {
if (this.mPoint != null ) {
for (var i=0; i < this.mPoint.length; i++) {
var newDistance=this.mTransformationValue2[i] * zoom;
var newAngle=this.mTransformationValue1[i] - angle;
this.mPoint[i].x=this.mTransformationReferenceX + newDistance * Math.sin(newAngle);
this.mPoint[i].y=this.mTransformationReferenceY + newDistance * Math.cos(newAngle);
}
}});

Clazz.newMeth(C$, 'getDescriptor$',  function () {
return "<DrawingObject" + " type=\"" + this.getTypeString$() + "\"" + this.getDescriptorDetail$() + "></DrawingObject>" ;
});

Clazz.newMeth(C$, 'toString',  function () {
var objectString=Clazz.new_($I$(4,1));
objectString.append$S(this.getDescriptor$());
return objectString.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:47 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
