(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'java.util.BitSet','java.util.Random','java.util.Hashtable','StringBuilder','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.StereoMolecule','java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FingerPrintGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['paths','java.util.Hashtable']]
,['I',['debugCounter']]]

Clazz.newMeth(C$, 'getFingerprint$com_actelion_research_chem_StereoMolecule',  function (mol) {
return this.getFingerprint$com_actelion_research_chem_StereoMolecule$I(mol, 512);
});

Clazz.newMeth(C$, 'getFingerprint$com_actelion_research_chem_StereoMolecule$I',  function (mol, size) {
var path=null;
var index;
mol.ensureHelperArrays$I(7);
p$1.findAllPaths$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
var bs=Clazz.new_($I$(1,1).c$$I,[size]);
for (var e=this.paths.elements$(); e.hasMoreElements$(); ) {
path=e.nextElement$();
index=Clazz.new_([path.hashCode$()],$I$(2,1).c$$J).nextInt$I(size);
if (false) System.out.print$S(this.toString().substring$I(40) + " ");
bs.set$I(index);
}
return bs;
});

Clazz.newMeth(C$, 'matches$java_util_BitSet$java_util_BitSet',  function (reference, query) {
var cp=reference.clone$();
cp.and$java_util_BitSet(query);
if (cp.equals$O(query)) {
return true;
}return false;
}, 1);

Clazz.newMeth(C$, 'getBitSetBits$java_util_BitSet',  function (bs) {
var size=bs.size$();
var t=size % 8 == 0 ? (size/8|0) : (size/8|0) + 1;
var r=Clazz.array(Byte.TYPE, [t]);
var bite;
var bit;
if (false) System.out.println$();
for (var i=0; i < size; i++) {
if (bs.get$I(i)) {
bit=($b$[0] = (1 << (7 - (i % 8))), $b$[0]);
bite=(i/8|0);
r[bite]|=bit;
if (false) System.out.print$S("1");
} else {
if (false) System.out.print$S("0");
}}
if (false) System.out.println$();
return r;
}, 1);

Clazz.newMeth(C$, 'findAllPaths$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.paths=Clazz.new_($I$(3,1));
C$.debugCounter=0;
var atoms=mol.getAtoms$();
var s;
var flags=Clazz.array(Boolean.TYPE, [atoms]);
for (var atom=0; atom < atoms; atom++) {
s=mol.getAtomLabel$I(atom);
for (var i=0; i < atoms; i++) flags[i]=false;

p$1.addPath$S.apply(this, [s]);
if (false) System.out.println$S("\t***Starting at atom " + atom + " with symbol " + mol.getAtomLabel$I(atom) );
p$1.traverseDFS$com_actelion_research_chem_StereoMolecule$I$I$S$I$ZA.apply(this, [mol, -1, atom, s, 0, flags]);
}
}, p$1);

Clazz.newMeth(C$, 'traverseDFS$com_actelion_research_chem_StereoMolecule$I$I$S$I$ZA',  function (mol, lastAtom, rootAtom, path, depth, flags) {
var connAtoms=mol.getConnAtoms$I(rootAtom) + mol.getMetalBondedConnAtoms$I(rootAtom);
var nextAtom=0;
var bond=0;
var newPath=Clazz.new_($I$(4,1));
++depth;
for (var i=0; i < connAtoms; i++) {
flags[rootAtom]=true;
nextAtom=mol.getConnAtom$I$I(rootAtom, i);
if (nextAtom == lastAtom) {
continue;
}if (!flags[nextAtom]) {
bond=mol.getConnBond$I$I(rootAtom, i);
newPath.setLength$I(0);
newPath.append$S(path);
if (mol.isDelocalizedBond$I(bond) || mol.isAromaticBond$I(bond) ) {
newPath.append$S(":");
} else if (mol.getBondOrder$I(bond) == 1) {
newPath.append$S("-");
} else if (mol.getBondOrder$I(bond) == 2) {
newPath.append$S("=");
} else if (mol.getBondOrder$I(bond) >= 3) {
newPath.append$S("#");
} else if (mol.getBondOrder$I(bond) == 0) {
newPath.append$S(".");
} else System.out.println$S("FingerPrintGenerator.depthFirstSearch() " + "Error: Invalid Bond order! " + mol.getBondOrder$I(bond) );
newPath.append$S(mol.getAtomLabel$I(nextAtom));
flags[nextAtom]=true;
p$1.addPath$S.apply(this, [newPath.toString()]);
if (depth == 6) {
flags[nextAtom]=false;
}if (depth < 6) {
p$1.traverseDFS$com_actelion_research_chem_StereoMolecule$I$I$S$I$ZA.apply(this, [mol, rootAtom, nextAtom, newPath.toString(), depth, flags]);
flags[nextAtom]=false;
}}}
}, p$1);

Clazz.newMeth(C$, 'addPath$S',  function (newPath) {
var storePath=newPath;
var reversePath=Clazz.new_($I$(4,1).c$$S,[storePath]).reverse$().toString();
var ok=false;
if (reversePath.compareTo$S(newPath) < 0) {
storePath=reversePath;
}if (false) System.out.println$S("Checking for existence of Path " + storePath);
if (!this.paths.containsKey$O(storePath)) {
this.paths.put$O$O(storePath, storePath);
ok=true;
if (false) {
++C$.debugCounter;
System.out.println$S("Storing path no. " + C$.debugCounter + ": " + storePath + ", Hash: " + storePath.hashCode$() );
}}return ok;
}, p$1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var query;
var test="sFp@DiTt@@@@ S~x>xixix>";
var p=Clazz.new_($I$(5,1).c$$Z,[false]);
var m=Clazz.new_($I$(6,1));
var referencebs=null;
var querybs=null;
var r=Clazz.new_([Clazz.new_([System.$in, $I$(9).UTF_8],$I$(8,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(7,1).c$$java_io_Reader);
var fp=null;
try {
if (args.length > 0) {
System.out.println$S("Query set");
test=args[0];
p.parse$com_actelion_research_chem_StereoMolecule$S(m, test);
m.ensureHelperArrays$I(7);
fp=Clazz.new_(C$);
querybs=fp.getFingerprint$com_actelion_research_chem_StereoMolecule(m);
while (true){
System.out.print$S("Molecule:");
query=r.readLine$();
if (query != null  && query.trim$().length$() > 0 ) {
p.parse$com_actelion_research_chem_StereoMolecule$S(m, query);
m.ensureHelperArrays$I(7);
fp=Clazz.new_(C$);
referencebs=fp.getFingerprint$com_actelion_research_chem_StereoMolecule(m);
if (C$.matches$java_util_BitSet$java_util_BitSet(referencebs, querybs)) System.out.println$S(query.trim$() + "\tOK");
 else System.out.println$S(query.trim$() + "\tNOT OK");
}}
} else {
test=r.readLine$();
p.parse$com_actelion_research_chem_StereoMolecule$S(m, test);
m.ensureHelperArrays$I(7);
fp=Clazz.new_(C$);
querybs=fp.getFingerprint$com_actelion_research_chem_StereoMolecule(m);
var count=0;
var notok=0;
while (true){
query=r.readLine$();
if (query != null  && query.trim$().length$() > 0 ) {
System.out.println$S("*********************");
query=query.trim$();
p.parse$com_actelion_research_chem_StereoMolecule$S(m, query);
m.ensureHelperArrays$I(7);
fp=Clazz.new_(C$);
referencebs=fp.getFingerprint$com_actelion_research_chem_StereoMolecule(m);
if (!C$.matches$java_util_BitSet$java_util_BitSet(referencebs, querybs)) ++notok;
++count;
} else break;
}
System.out.println$S("Total/Not OK " + count + " " + notok );
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Server Exception: " + e);
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.debugCounter=0;
};
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
