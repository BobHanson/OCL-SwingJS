(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.mcs.ContainerListWithIntVec','com.actelion.research.util.SizeOf','com.actelion.research.chem.mcs.ListWithIntVec','java.util.HashSet','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Canonizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExhaustiveFragmentGeneratorAtoms");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['fragmentsGenerated'],'I',['nAtomsMolecule','sizeIntVec','maximumFragmentSite','capacityLimitBreakes'],'O',['liHashSetIntegerList','java.util.List','mol','com.actelion.research.chem.ExtendedMolecule','livNeighbours','com.actelion.research.chem.mcs.ListWithIntVec','containerListWithIntVec','com.actelion.research.chem.mcs.ContainerListWithIntVec','liIntegerListSolution','java.util.List','+liIntegerListTmp']]
,['I',['MAX_NUM_FRAGMENTS','CAPACITY_FRAGMENTS']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.liIntegerListSolution=Clazz.new_($I$(1,1));
this.liIntegerListTmp=Clazz.new_($I$(1,1));
var maxSizeIntVec=8;
this.containerListWithIntVec=Clazz.new_($I$(2,1).c$$I$I,[maxSizeIntVec, C$.CAPACITY_FRAGMENTS]);
System.out.println$S("ExhaustiveFragmentGenerator Used mem " + Long.$s($I$(3).usedMemoryMB$()) + "[MB]." );
}, 1);

Clazz.newMeth(C$, 'set$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, nMaximumFragmentSize) {
p$1.initHashSet$I.apply(this, [nMaximumFragmentSize]);
this.mol=mol;
this.nAtomsMolecule=mol.getAtoms$();
if (this.nAtomsMolecule > 256) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Maximum number of atoms exceeded."]);
}this.sizeIntVec=((this.nAtomsMolecule + 32 - 1)/32|0);
this.maximumFragmentSite=nMaximumFragmentSize;
this.livNeighbours=Clazz.new_($I$(4,1).c$$I$I,[this.sizeIntVec, -1]);
this.fragmentsGenerated=false;
this.containerListWithIntVec.reset$();
this.capacityLimitBreakes=0;
});

Clazz.newMeth(C$, 'initHashSet$I',  function (nAtomsFragsNew) {
this.liIntegerListSolution.clear$();
this.liIntegerListTmp.clear$();
if (this.liHashSetIntegerList == null ) {
this.liHashSetIntegerList=Clazz.new_($I$(1,1));
}var sizeOld=this.liHashSetIntegerList.size$();
for (var i=0; i < this.liHashSetIntegerList.size$(); i++) {
this.liHashSetIntegerList.get$I(i).clear$();
}
for (var i=sizeOld; i < nAtomsFragsNew + 1; i++) {
var capacity=1000;
if (i > 15) {
capacity=1000000;
} else if (i > 10) {
capacity=100000;
} else if (i > 5) {
capacity=10000;
}this.liHashSetIntegerList.add$O(Clazz.new_($I$(5,1).c$$I,[capacity]));
}
}, p$1);

Clazz.newMeth(C$, 'generateFragments$',  function () {
var nAtomsMol=this.mol.getAtoms$();
for (var i=0; i < nAtomsMol; i++) {
p$1.getAllPossibleNeigbourCombinationsConsidersPrevious$I.apply(this, [i]);
}
this.fragmentsGenerated=true;
});

Clazz.newMeth(C$, 'get$I',  function (size) {
if (!this.fragmentsGenerated) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fragments have to be generated first. Call generateFragments()."]);
}return Clazz.new_([this.liHashSetIntegerList.get$I(size)],$I$(1,1).c$$java_util_Collection);
});

Clazz.newMeth(C$, 'getFragmentsForSingleAtom$I',  function (indexStartAtom) {
p$1.initHashSet$I.apply(this, [this.maximumFragmentSite]);
return p$1.getAllPossibleNeigbourCombinationsConsidersPrevious$I.apply(this, [indexStartAtom]);
});

Clazz.newMeth(C$, 'getAllPossibleNeigbourCombinationsConsidersPrevious$I',  function (indexStartAtom) {
this.liIntegerListSolution.clear$();
var livStart=this.containerListWithIntVec.get$();
livStart.addBit$I(indexStartAtom);
livStart.calculateHash$();
this.liIntegerListSolution.add$O(livStart);
if (this.maximumFragmentSite == 1) {
return this.liIntegerListSolution;
}var finish=false;
while (!finish){
this.liIntegerListTmp.clear$();
var numAtomsInFragmentParent=this.liIntegerListSolution.get$I(0).size$();
var hsIntListGeneratedSolutions=this.liHashSetIntegerList.get$I(numAtomsInFragmentParent + 1);
if (hsIntListGeneratedSolutions.size$() >= C$.MAX_NUM_FRAGMENTS) {
++this.capacityLimitBreakes;
break;
} breakLimitFrags : for (var livAtomPath, $livAtomPath = this.liIntegerListSolution.iterator$(); $livAtomPath.hasNext$()&&((livAtomPath=($livAtomPath.next$())),1);) {
var livIndexAtomsReachable=p$1.getAllReachableNeighbours$com_actelion_research_chem_ExtendedMolecule$com_actelion_research_chem_mcs_ListWithIntVec.apply(this, [this.mol, livAtomPath]);
for (var i=0; i < livIndexAtomsReachable.size$(); i++) {
var livPathExtended=this.containerListWithIntVec.getWithCopy$com_actelion_research_chem_mcs_ListWithIntVec(livAtomPath);
if (livPathExtended.addBit$I(livIndexAtomsReachable.get$I(i))) {
livPathExtended.calculateHash$();
if (hsIntListGeneratedSolutions.add$O(livPathExtended)) {
this.liIntegerListTmp.add$O(livPathExtended);
if (this.liIntegerListTmp.size$() == C$.MAX_NUM_FRAGMENTS) {
++this.capacityLimitBreakes;
break breakLimitFrags;
}} else {
this.containerListWithIntVec.back$com_actelion_research_chem_mcs_ListWithIntVec(livPathExtended);
}} else {
this.containerListWithIntVec.back$com_actelion_research_chem_mcs_ListWithIntVec(livPathExtended);
}}
}
this.liIntegerListSolution.clear$();
this.liIntegerListSolution.addAll$java_util_Collection(this.liIntegerListTmp);
if (this.liIntegerListSolution.isEmpty$()) {
finish=true;
} else {
var lenFirst=this.liIntegerListSolution.get$I(0).size$();
for (var livAtomPath, $livAtomPath = this.liIntegerListSolution.iterator$(); $livAtomPath.hasNext$()&&((livAtomPath=($livAtomPath.next$())),1);) {
if (livAtomPath.size$() == this.maximumFragmentSite) {
finish=true;
}if (lenFirst != livAtomPath.size$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Error in algorithm."]);
}}
}}
return this.liIntegerListSolution;
}, p$1);

Clazz.newMeth(C$, 'getAllReachableNeighbours$com_actelion_research_chem_ExtendedMolecule$com_actelion_research_chem_mcs_ListWithIntVec',  function (mol, livIndexAtom) {
this.livNeighbours.reset$();
for (var i=0; i < livIndexAtom.size$(); i++) {
var indexAtom=livIndexAtom.get$I(i);
var nConnected=mol.getAllConnAtoms$I(indexAtom);
for (var j=0; j < nConnected; j++) {
var indexAtConn=mol.getConnAtom$I$I(indexAtom, j);
if (!livIndexAtom.isBitSet$I(indexAtConn)) {
this.livNeighbours.addBit$I(indexAtConn);
}}
}
return this.livNeighbours;
}, p$1);

Clazz.newMeth(C$, 'getCapacityLimitBreakes$',  function () {
return this.capacityLimitBreakes;
});

Clazz.newMeth(C$, 'getIdCodeFromFragment$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_mcs_ListWithIntVec',  function (mol, livIndexAtom) {
var includeAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var i=0; i < livIndexAtom.size$(); i++) {
includeAtom[livIndexAtom.get$I(i)]=true;
}
var frag=Clazz.new_($I$(6,1));
mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(frag, includeAtom, true, null);
frag.ensureHelperArrays$I(7);
var can=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[frag]);
return can.getIDCode$();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.MAX_NUM_FRAGMENTS=400000;
C$.CAPACITY_FRAGMENTS=8000000;
{
if (false) {
C$.MAX_NUM_FRAGMENTS=20000;
C$.CAPACITY_FRAGMENTS=500000;
}};
};
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:29 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
