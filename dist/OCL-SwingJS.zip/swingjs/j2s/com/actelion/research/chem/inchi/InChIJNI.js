(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[[0,'net.sf.jniinchi.JniInchiWrapper','net.sf.jniinchi.JniInchiInputInchi','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IsomericSmilesCreator','java.util.ArrayList','java.util.HashMap','com.actelion.research.chem.Molecule','net.sf.jniinchi.INCHI_STEREOTYPE','java.util.Arrays','com.actelion.research.chem.coords.CoordinateInventor','net.sf.jniinchi.INCHI_PARITY','net.sf.jniinchi.INCHI_BOND_TYPE','net.sf.jniinchi.JniInchiInput','net.sf.jniinchi.JniInchiStructure','net.sf.jniinchi.JniInchiAtom','net.sf.jniinchi.JniInchiBond','net.sf.jniinchi.INCHI_BOND_STEREO']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNI");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'inchiToMolecule$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
var struc=$I$(1,"getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi",[Clazz.new_($I$(2,1).c$$S,[inchi])]);
C$.getOCLMolecule$net_sf_jniinchi_JniInchiOutputStructure$com_actelion_research_chem_StereoMolecule(struc, mol);
return true;
} catch (e) {
e.printStackTrace$();
return false;
}
}, 1);

Clazz.newMeth(C$, 'inchiToSMILES$S',  function (inchi) {
try {
var mol=Clazz.new_($I$(3,1));
C$.inchiToMolecule$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
return $I$(4).createSmiles$com_actelion_research_chem_StereoMolecule(mol);
} catch (e) {
e.printStackTrace$();
return null;
}
}, 1);

Clazz.newMeth(C$, 'getOCLMolecule$net_sf_jniinchi_JniInchiOutputStructure$com_actelion_research_chem_StereoMolecule',  function (struc, mol) {
var nAtoms=struc.getNumAtoms$();
var nBonds=struc.getNumBonds$();
var nStereo=struc.getNumStereo0D$();
var atoms=Clazz.new_($I$(5,1));
var map=Clazz.new_($I$(6,1));
for (var i=0; i < nAtoms; i++) {
var a=struc.getAtom$I(i);
atoms.add$O(a);
var sym=a.getElementType$();
var atom=mol.addAtom$I($I$(7).getAtomicNoFromLabel$S(sym));
mol.setAtomCharge$I$I(atom, a.getCharge$());
map.put$O$O(a, Integer.valueOf$I(i));
}
var doubleBonds=Clazz.new_($I$(6,1));
for (var i=0; i < nBonds; i++) {
var b=struc.getBond$I(i);
var a1=b.getOriginAtom$();
var a2=b.getTargetAtom$();
var bt=C$.getOCLSimpleBondType$net_sf_jniinchi_JniInchiBond(b);
var i1=(map.get$O(a1)).$c();
var i2=(map.get$O(a2)).$c();
var bond=mol.addBond$I$I$I(i1, i2, bt);
switch (bt) {
case 1:
break;
case 2:
doubleBonds.put$O$O(Integer.valueOf$I(C$.getBondKey$I$I(i1, i2)), Integer.valueOf$I(bond));
break;
}
}
for (var i=0; i < nStereo; i++) {
var d=struc.getStereo0D$I(i);
var centralAtom=d.getCentralAtom$();
var neighbors=Clazz.array(Integer.TYPE, [d.getNeighbors$().length]);
if (neighbors.length != 4) continue;
for (var j=neighbors.length; --j >= 0; ) {
neighbors[j]=(Integer.valueOf$I((map.get$O(d.getNeighbor$I(j))).$c())).$c();
}
var type=d.getStereoType$();
var p=-1;
switch (type) {
case $I$(8).TETRAHEDRAL:
var ia=(Integer.valueOf$I((map.get$O(centralAtom)).$c())).$c();
p=C$.getOCLAtomParity$net_sf_jniinchi_INCHI_PARITY$Z(d.getParity$(), C$.isOrdered$IA(neighbors));
mol.setAtomParity$I$I$Z(ia, p, false);
break;
case $I$(8).DOUBLEBOND:
var ib=C$.findDoubleBond$java_util_Map$IA(doubleBonds, neighbors);
if (ib < 0) {
System.err.println$S("InChIJNI cannot find double bond for atoms " + $I$(9).toString$IA(neighbors));
continue;
}p=C$.getOCLBondParity$net_sf_jniinchi_INCHI_PARITY$Z(d.getParity$(), (neighbors[0] < neighbors[3]));
mol.setBondParity$I$I$Z(ib, p, false);
break;
case $I$(8).ALLENE:
var ic=(Integer.valueOf$I((map.get$O(centralAtom)).$c())).$c();
p=C$.getOCLBondParity$net_sf_jniinchi_INCHI_PARITY$Z(d.getParity$(), (neighbors[0] > neighbors[3]));
mol.setAtomParity$I$I$Z(ic, p, false);
break;
case $I$(8).NONE:
continue;
}
}
mol.setParitiesValid$I(0);
mol.setPrioritiesPreset$Z(true);
Clazz.new_($I$(10,1).c$$I,[64]);
mol.ensureHelperArrays$I(31);
}, 1);

Clazz.newMeth(C$, 'getBondKey$I$I',  function (i1, i2) {
return (Math.min(i1, i2) << 16) + Math.max(i1, i2);
}, 1);

Clazz.newMeth(C$, 'findDoubleBond$java_util_Map$IA',  function (doubleBonds, neighbors) {
var ib=doubleBonds.get$O(Integer.valueOf$I(C$.getBondKey$I$I(neighbors[1], neighbors[2])));
return (ib == null  ? -1 : ib.intValue$());
}, 1);

Clazz.newMeth(C$, 'getOCLBondParity$net_sf_jniinchi_INCHI_PARITY$Z',  function (parity, isReversed) {
switch (parity) {
case $I$(11).ODD:
return (isReversed ? 2 : 1);
case $I$(11).EVEN:
return (isReversed ? 1 : 2);
case $I$(11).UNKNOWN:
return 3;
case $I$(11).NONE:
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'isOrdered$IA',  function (list) {
var ok=true;
for (var i=0; i < list.length - 1; i++) {
var l1=list[i];
for (var j=i + 1; j < list.length; j++) {
var l2=list[j];
if (l1 > l2) {
list[j]=l1;
l1=list[i]=l2;
ok=!ok;
}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOCLAtomParity$net_sf_jniinchi_INCHI_PARITY$Z',  function (parity, isOrdered) {
switch (parity) {
case $I$(11).ODD:
case $I$(11).EVEN:
return (!!((parity === $I$(11).ODD ) ^ isOrdered) ? 1 : 2);
case $I$(11).UNKNOWN:
return 3;
case $I$(11).NONE:
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getOCLSimpleBondType$net_sf_jniinchi_JniInchiBond',  function (b) {
var type=b.getBondType$();
switch (type) {
case $I$(12).NONE:
return 0;
case $I$(12).ALTERN:
return 8;
case $I$(12).DOUBLE:
return 2;
case $I$(12).TRIPLE:
return 4;
case $I$(12).SINGLE:
default:
return 1;
}
}, 1);

Clazz.newMeth(C$, 'getInChIKey$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return C$.getInChI$com_actelion_research_chem_StereoMolecule$S$Z(mol, options, true);
}, 1);

Clazz.newMeth(C$, 'getInChI$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return C$.getInChI$com_actelion_research_chem_StereoMolecule$S$Z(mol, options, false);
}, 1);

Clazz.newMeth(C$, 'getInChI$com_actelion_research_chem_StereoMolecule$S$Z',  function (mol, options, getKey) {
try {
if (options == null ) options="";
var inchi=null;
var lc=options.toLowerCase$();
options=lc;
if (options.indexOf$S("fixedh?") >= 0) {
var fxd=C$.getInChI$com_actelion_research_chem_StereoMolecule$S$Z(mol, options.replace$C$C("?", " "), false);
options=options.replaceAll$S$S("fixedh\\?", "");
var std=C$.getInChI$com_actelion_research_chem_StereoMolecule$S$Z(mol, options, false);
inchi=(fxd != null  && fxd.length$() <= std.length$()  ? std : fxd);
} else {
var $in=Clazz.new_($I$(13,1).c$$S,[options]);
var struc=C$.newJniInchiStructure$com_actelion_research_chem_StereoMolecule(mol);
$in.setStructure$net_sf_jniinchi_JniInchiStructure(struc);
var out=$I$(1).getInchi$net_sf_jniinchi_JniInchiInput($in);
var msg=out.getMessage$();
if (msg != null ) System.err.println$S(msg);
inchi=out.getInchi$();
}return (getKey ? $I$(1).getInchiKey$S(inchi).getKey$() : inchi);
} catch (e) {
System.out.println$O(e);
if (e.getMessage$().indexOf$S("ption") >= 0) System.out.println$S(e.getMessage$() + ": " + options.toLowerCase$() + "\n See https://www.inchi-trust.org/download/104/inchi-faq.pdf for valid options" );
 else e.printStackTrace$();
return "";
}
}, 1);

Clazz.newMeth(C$, 'newJniInchiStructure$com_actelion_research_chem_StereoMolecule',  function (mol) {
var struc=Clazz.new_($I$(14,1));
var nAtoms=mol.getAllAtoms$();
var atoms=Clazz.array($I$(15), [nAtoms]);
for (var i=0; i < nAtoms; i++) {
var elem=mol.getAtomicNo$I(i);
var sym=$I$(7).cAtomLabel[elem];
var iso=mol.getAtomMass$I(i);
if (elem == 1) {
sym="H";
}var a=atoms[i]=Clazz.new_([mol.getAtomX$I(i), -mol.getAtomY$I(i), mol.getAtomZ$I(i), sym],$I$(15,1).c$$D$D$D$S);
struc.addAtom$net_sf_jniinchi_JniInchiAtom(a);
a.setCharge$I(mol.getAtomCharge$I(i));
if (iso > 0) a.setIsotopicMass$I(iso);
a.setImplicitH$I(mol.getImplicitHydrogens$I(i));
}
var nBonds=mol.getAllBonds$();
for (var i=0; i < nBonds; i++) {
var oclOrder=mol.getBondTypeSimple$I(i);
var order=C$.getInChIOrder$I(oclOrder);
if (order != null ) {
var atom1=mol.getBondAtom$I$I(0, i);
var atom2=mol.getBondAtom$I$I(1, i);
var oclType=mol.getBondType$I(i);
var oclParity=mol.getBondParity$I(i);
var stereo=C$.getInChIStereo$I$I$I(oclOrder, oclType, oclParity);
var bond=Clazz.new_($I$(16,1).c$$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_JniInchiAtom$net_sf_jniinchi_INCHI_BOND_TYPE$net_sf_jniinchi_INCHI_BOND_STEREO,[atoms[atom1], atoms[atom2], order, stereo]);
struc.addBond$net_sf_jniinchi_JniInchiBond(bond);
}}
return struc;
}, 1);

Clazz.newMeth(C$, 'getInChIOrder$I',  function (oclOrder) {
switch (oclOrder) {
case 1:
return $I$(12).SINGLE;
case 2:
return $I$(12).DOUBLE;
case 4:
return $I$(12).TRIPLE;
case 8:
return $I$(12).ALTERN;
case 16:
default:
return null;
}
}, 1);

Clazz.newMeth(C$, 'getInChIStereo$I$I$I',  function (oclOrder, oclType, oclParity) {
if (oclOrder == 1) {
switch (oclType) {
case 129:
return $I$(17).SINGLE_1DOWN;
case 257:
return $I$(17).SINGLE_1UP;
default:
if (oclParity == 3) {
return (oclOrder == 2 ? $I$(17).DOUBLE_EITHER : $I$(17).SINGLE_1EITHER);
}}
}return $I$(17).NONE;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
