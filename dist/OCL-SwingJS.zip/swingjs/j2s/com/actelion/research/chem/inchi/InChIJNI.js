(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[[0,'net.sf.jniinchi.JniInchiWrapper','net.sf.jniinchi.JniInchiInputInchi','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.IsomericSmilesCreator','java.util.HashMap','java.util.ArrayList','com.actelion.research.chem.Molecule','com.actelion.research.chem.coords.CoordinateInventor','net.sf.jniinchi.INCHI_PARITY','net.sf.jniinchi.INCHI_BOND_TYPE','net.sf.jniinchi.INCHI_BOND_STEREO']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIJNI");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'inchiToMolecule$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
var struc=$I$(1,"getStructureFromInchi$net_sf_jniinchi_JniInchiInputInchi",[Clazz.new_($I$(2,1).c$$S,[inchi])]);
C$.getMolecule$net_sf_jniinchi_JniInchiOutputStructure$com_actelion_research_chem_StereoMolecule(struc, mol);
return true;
} catch (e) {
e.printStackTrace$();
return false;
}
}, 1);

Clazz.newMeth(C$, 'inchiToSMILES$S',  function (inchi) {
try {
var mol=Clazz.new_($I$(3,1));
C$.inchiToMolecule$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
return $I$(4).createSmiles$com_actelion_research_chem_StereoMolecule(mol);
} catch (e) {
e.printStackTrace$();
return null;
}
}, 1);

Clazz.newMeth(C$, 'toJSON$net_sf_jniinchi_JniInchiStructure',  function (mol) {
var na=mol.getNumAtoms$();
var nb=mol.getNumBonds$();
var ns=mol.getNumStereo0D$();
var mapAtoms=Clazz.new_($I$(5,1));
var s="{\"atoms\":[\n";
var sep="";
for (var i=0; i < na; i++) {
var a=mol.getAtom$I(i);
mapAtoms.put$O$O(a, Integer.valueOf$I(i));
if (i > 0) s+=",\n";
s+="{\n";
s+=C$.toJSON$S$O$S("index", Integer.valueOf$I(i), ",");
s+=C$.toJSON$S$O$S("elementType", a.getElementType$(), ",");
s+=C$.toJSON$S$O$S("charge", Integer.valueOf$I(a.getCharge$()), ",");
s+=C$.toJSON$S$O$S("isotopeMass", Integer.valueOf$I(a.getIsotopicMass$()), ",");
s+=C$.toJSON$S$O$S("implicitH", Integer.valueOf$I(a.getImplicitH$()), ",");
s+=C$.toJSON$S$O$S("radical", a.getRadical$(), ",");
s+=C$.toJSON$S$O$S("x", Double.valueOf$D(a.getX$()), ",");
s+=C$.toJSON$S$O$S("y", Double.valueOf$D(a.getY$()), ",");
s+=C$.toJSON$S$O$S("z", Double.valueOf$D(a.getZ$()), ",");
s+=C$.toJSON$S$O$S("implicitDeuterium", Integer.valueOf$I(a.getImplicitDeuterium$()), ",");
s+=C$.toJSON$S$O$S("implicitProtium", Integer.valueOf$I(a.getImplicitProtium$()), ",");
s+=C$.toJSON$S$O$S("implicitTritium", Integer.valueOf$I(a.getImplicitTritium$()), "");
s+="}";
}
s+="\n],\n\"bonds\":[\n";
for (var i=0; i < nb; i++) {
if (i > 0) s+=",\n";
s+="{\n";
var b=mol.getBond$I(i);
s+=C$.toJSON$S$O$S("originAtom", mapAtoms.get$O(b.getOriginAtom$()), ",");
s+=C$.toJSON$S$O$S("targetAtom", mapAtoms.get$O(b.getTargetAtom$()), ",");
s+=C$.toJSON$S$O$S("bondType", b.getBondType$(), ",");
s+=C$.toJSON$S$O$S("bondStereo", b.getBondStereo$(), "");
s+="}";
}
s+="\n],\n\"stereo\":[\n";
for (var i=0; i < ns; i++) {
if (i > 0) s+=",\n";
s+="{\n";
var d=mol.getStereo0D$I(i);
s+=C$.toJSON$S$O$S("centralAtomID", mapAtoms.get$O(d.getCentralAtom$()), ",");
s+=C$.toJSON$S$O$S("debugString", d.getDebugString$(), ",");
s+=C$.toJSON$S$O$S("disconnectedParity", d.getDisconnectedParity$(), ",");
s+=C$.toJSON$S$O$S("parity", d.getParity$(), ",");
s+=C$.toJSON$S$O$S("stereoType", d.getStereoType$(), ",");
var an=d.getNeighbors$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=mapAtoms.get$O(d.getNeighbor$I(j)).intValue$();
}
s+=C$.toJSON$S$O$S("neighbors", nbs, "");
s+="}";
}
s+="\n]}\n";
return s;
}, 1);

Clazz.newMeth(C$, 'toJSON$S$O$S',  function (key, val, term) {
key="\"" + key + "\"" ;
var sval=null;
if (Clazz.instanceOf(val, Clazz.array(Integer.TYPE, -1))) {
sval="";
var a=val;
for (var i=0; i < a.length; i++) {
sval+="," + a[i];
}
sval="[" + (sval.length$() > 1 ? sval.substring$I(1) : "") + "]" ;
} else if (Clazz.instanceOf(val, "java.lang.String")) {
sval="\"" + val + "\"" ;
} else {
sval="" + sval;
}return key + ":" + sval + term + "\n" ;
}, 1);

Clazz.newMeth(C$, 'getMolecule$net_sf_jniinchi_JniInchiOutputStructure$com_actelion_research_chem_StereoMolecule',  function (struc, molOut) {
var enabled=Clazz.array(Boolean.TYPE, -1, [false]);
var mol=((P$.InChIJNI$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "InChIJNI$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, Clazz.load('com.actelion.research.chem.StereoMolecule'), null, 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getAtomParity$I',  function (atom) {
if (this.$finals$.enabled[0]) {
switch (atom) {
case 10:
case 15:
case 16:
return 2;
case 9:
case 12:
return 1;
}
return this.$finals$.molOut.getAtomParity$I(atom);
}return C$.superclazz.prototype.getAtomParity$I.apply(this, [atom]);
});
})()
), Clazz.new_($I$(3,1),[this, {enabled:enabled,molOut:molOut}],P$.InChIJNI$1));
var nAtoms=struc.getNumAtoms$();
var nBonds=struc.getNumBonds$();
var nStereo=struc.getNumStereo0D$();
var nh=0;
for (var i=0; i < nAtoms; i++) {
var a=struc.getAtom$I(i);
nh+=a.getImplicitH$();
}
var atoms=Clazz.new_($I$(6,1));
var map=Clazz.new_($I$(5,1));
for (var i=0; i < nAtoms; i++) {
var a=struc.getAtom$I(i);
atoms.add$O(a);
var sym=a.getElementType$();
var atom=mol.addAtom$I($I$(7).getAtomicNoFromLabel$S(sym));
mol.setAtomCharge$I$I(atom, a.getCharge$());
mol.setAtomX$I$D(atom, -1);
map.put$O$O(a, Integer.valueOf$I(i));
}
for (var i=0; i < nStereo; i++) {
var d=struc.getStereo0D$I(i);
var ia=(Integer.valueOf$I((map.get$O(d.getCentralAtom$())).$c())).$c();
var p=C$.decodeParity$net_sf_jniinchi_INCHI_PARITY(d.getParity$());
mol.setAtomParity$I$I$Z(ia, p, false);
var an=d.getNeighbors$();
var nbs=Clazz.array(Integer.TYPE, [an.length]);
for (var j=0; j < an.length; j++) {
nbs[j]=map.get$O(d.getNeighbor$I(j)).intValue$();
}
}
for (var i=0; i < nBonds; i++) {
var b=struc.getBond$I(i);
var a1=b.getOriginAtom$();
var a2=b.getTargetAtom$();
var bt=C$.getBondType$net_sf_jniinchi_JniInchiBond(b);
var i1=(map.get$O(a1)).$c();
var i2=(map.get$O(a2)).$c();
mol.addBond$I$I$I(i1, i2, bt);
}
mol.copyMolecule$com_actelion_research_chem_Molecule(molOut);
enabled[0]=true;
mol.setParitiesValid$I(0);
Clazz.new_($I$(8,1).c$$I,[65]).invent$com_actelion_research_chem_StereoMolecule(mol);
enabled[0]=false;
mol.copyMolecule$com_actelion_research_chem_Molecule(molOut);
}, 1);

Clazz.newMeth(C$, 'decodeParity$net_sf_jniinchi_INCHI_PARITY',  function (parity) {
switch (parity) {
case $I$(9).EVEN:
return 2;
case $I$(9).ODD:
return 1;
case $I$(9).UNKNOWN:
return 3;
case $I$(9).NONE:
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getBondType$net_sf_jniinchi_JniInchiBond',  function (b) {
var type=b.getBondType$();
var stereo=b.getBondStereo$();
switch (type) {
case $I$(10).NONE:
return 0;
case $I$(10).ALTERN:
return 8;
case $I$(10).DOUBLE:
return 2;
case $I$(10).TRIPLE:
return 4;
case $I$(10).SINGLE:
if (true) break;
switch (stereo) {
case $I$(11).NONE:
break;
case $I$(11).SINGLE_1UP:
break;
case $I$(11).SINGLE_1EITHER:
break;
case $I$(11).SINGLE_1DOWN:
break;
case $I$(11).SINGLE_2UP:
break;
case $I$(11).SINGLE_2EITHER:
break;
case $I$(11).SINGLE_2DOWN:
break;
case $I$(11).DOUBLE_EITHER:
break;
}
default:
break;
}
return 1;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
