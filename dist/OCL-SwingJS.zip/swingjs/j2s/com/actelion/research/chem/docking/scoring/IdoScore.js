(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','java.util.stream.IntStream','com.actelion.research.chem.conf.BondRotationHelper','java.util.HashMap','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','com.actelion.research.chem.docking.scoring.idoscore.InteractionTerm']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "IdoScore", null, 'com.actelion.research.chem.docking.scoring.AbstractScoringEngine');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['e0'],'O',['ligStrain','java.util.List','+constraint','+interactionEnergy','torsionHelper','com.actelion.research.chem.conf.BondRotationHelper','receptorAtomTypes','int[]','+ligAtomTypes','ff','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$java_util_Set$IA$com_actelion_research_chem_io_pdb_converter_MoleculeGrid',  function (receptor, bindingSiteAtoms, receptorAtomTypes, grid) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid.apply(this,[receptor, bindingSiteAtoms, grid]);C$.$init$.apply(this);
this.receptorAtomTypes=receptorAtomTypes;
}, 1);

Clazz.newMeth(C$, 'init$com_actelion_research_chem_docking_LigandPose$D',  function (candidatePose, e0) {
this.candidatePose=candidatePose;
this.e0=e0;
this.ligStrain=Clazz.new_($I$(1,1));
this.constraint=Clazz.new_($I$(1,1));
this.interactionEnergy=Clazz.new_($I$(1,1));
var ligAtomTypesList=Clazz.new_($I$(1,1));
var mol=candidatePose.getLigConf$().getMolecule$();
for (var a=0; a < mol.getAtoms$(); a++) {
ligAtomTypesList.add$O(Integer.valueOf$I($I$(2).getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, a)));
}
this.ligAtomTypes=Clazz.array(Integer.TYPE, [ligAtomTypesList.size$()]);
$I$(3).range$I$I(0, this.ligAtomTypes.length).forEach$java_util_function_IntConsumer(((P$.IdoScore$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "IdoScore$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) { return (this.b$['com.actelion.research.chem.docking.scoring.IdoScore'].ligAtomTypes[e]=(this.$finals$.ligAtomTypesList.get$I.apply(this.$finals$.ligAtomTypesList, [e])).$c());});
})()
), Clazz.new_(P$.IdoScore$lambda1.$init$,[this, {ligAtomTypesList:ligAtomTypesList}])));
this.torsionHelper=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var ffOptions=Clazz.new_($I$(5,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(80.0));
$I$(6).initialize$S("MMFF94s+");
this.ff=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[mol, "MMFF94s+", ffOptions]);
p$1.initiateInteractionTerms.apply(this, []);
});

Clazz.newMeth(C$, 'initiateInteractionTerms',  function () {
for (var p, $p = this.bindingSiteAtoms.iterator$(); $p.hasNext$()&&((p=($p.next$()).intValue$()),1);) {
for (var l=0; l < this.candidatePose.getLigConf$().getMolecule$().getAtoms$(); l++) {
var term=$I$(7,"create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I$IA$IA",[this.receptorConf, this.candidatePose.getLigConf$(), p, l, this.receptorAtomTypes, this.ligAtomTypes]);
if (term != null ) this.interactionEnergy.add$O(term);
}
}
}, p$1);

Clazz.newMeth(C$, 'getStrain$DA',  function (gradient) {
var energy=0.0;
for (var term, $term = this.ligStrain.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
energy+=term.getFGValue$DA(gradient);
}
return energy;
});

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var energy=0.0;
for (var term, $term = this.interactionEnergy.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
energy+=term.getFGValue$DA(gradient);
}
energy+=this.getBumpTerm$();
this.ff.setState$DA(this.candidatePose.getCartState$());
var ffEnergy=this.ff.getTotalEnergy$();
if (ffEnergy - this.e0 > 20.0 ) {
this.ff.addGradient$DA(gradient);
energy+=(ffEnergy - this.e0);
}return energy;
});

Clazz.newMeth(C$, 'updateState$',  function () {
this.ff.setState$DA(this.candidatePose.getState$());
});

Clazz.newMeth(C$, 'getScore$',  function () {
var gradient=Clazz.array(Double.TYPE, [this.candidatePose.getLigConf$().getMolecule$().getAllAtoms$() * 3]);
var energy=this.getBumpTerm$();
for (var term, $term = this.interactionEnergy.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) {
energy+=term.getFGValue$DA(gradient);
}
return energy;
});

Clazz.newMeth(C$, 'getContributions$',  function () {
return null;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:41 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
