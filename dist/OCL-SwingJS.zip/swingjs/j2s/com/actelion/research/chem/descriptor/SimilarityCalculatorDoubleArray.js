(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.calc.distance.DistanceMetrics','com.actelion.research.chem.descriptor.SimilarityCalculatorInfo']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SimilarityCalculatorDoubleArray", null, null, 'com.actelion.research.chem.descriptor.ISimilarityCalculator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['getSimilarity$DA$DA','getSimilarity$O$O'],  function (d1, d2) {
if (d1 == null  || d2 == null  ) return NaN;
return $I$(1).getCosine$DA$DA(d1, d2);
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return Clazz.new_($I$(2,1).c$$S$S,["SimilarityCalculatorDoubleArray", "SimCalcDblArray"]);
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return Clazz.new_(C$);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
