(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),p$1={},I$=[[0,'StringBuilder','com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolfileV3Creator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mScalingFactor=1.0;
},1);

C$.$fields$=[['D',['mScalingFactor'],'O',['mMolfile','StringBuilder']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$Z.apply(this, [mol, true]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z',  function (mol, allowScaling) {
C$.c$$com_actelion_research_chem_StereoMolecule$Z$D$StringBuilder.apply(this, [mol, allowScaling, 0.0, Clazz.new_($I$(1,1).c$$I,[32768])]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z$StringBuilder',  function (mol, allowScaling, builder) {
C$.c$$com_actelion_research_chem_StereoMolecule$Z$D$StringBuilder.apply(this, [mol, allowScaling, 0.0, builder]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$Z$D$StringBuilder',  function (mol, allowScaling, scalingFactor, builder) {
;C$.$init$.apply(this);
mol.ensureHelperArrays$I(15);
var nl=System.lineSeparator$();
this.mMolfile=(builder == null ) ? Clazz.new_($I$(1,1)) : builder;
var name=(mol.getName$() != null ) ? mol.getName$() : "";
this.mMolfile.append$S(name + nl);
this.mMolfile.append$S("Actelion Java MolfileCreator 2.0" + nl + nl );
this.mMolfile.append$S("  0  0  0  0  0  0              0 V3000" + nl);
this.mScalingFactor=1.0;
var hasCoordinates=C$.hasCoordinates$com_actelion_research_chem_StereoMolecule(mol);
if (hasCoordinates) {
if (scalingFactor != 0 ) this.mScalingFactor=scalingFactor;
 else if (allowScaling) this.mScalingFactor=C$.calculateScalingFactor$com_actelion_research_chem_StereoMolecule(mol);
}p$1.writeBody$com_actelion_research_chem_StereoMolecule$Z.apply(this, [mol, hasCoordinates]);
this.mMolfile.append$S("M  END" + nl);
}, 1);

Clazz.newMeth(C$, 'hasCoordinates$com_actelion_research_chem_StereoMolecule',  function (mol) {
if (mol.getAllAtoms$() == 1) return true;
for (var atom=1; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAtomX$I(atom) != mol.getAtomX$I(0)  || mol.getAtomY$I(atom) != mol.getAtomY$I(0)   || mol.getAtomZ$I(atom) != mol.getAtomZ$I(0)  ) {
return true;
}}
return false;
}, 1);

Clazz.newMeth(C$, 'calculateScalingFactor$com_actelion_research_chem_StereoMolecule',  function (mol) {
var scalingFactor=1.0;
var avbl=mol.getAverageBondLength$();
if (avbl != 0.0 ) {
if (avbl < 1.0  || avbl > 3.0  ) scalingFactor=1.5 / avbl;
} else {
var minDistance=3.4028235E38;
for (var atom1=1; atom1 < mol.getAllAtoms$(); atom1++) {
for (var atom2=0; atom2 < atom1; atom2++) {
var dx=mol.getAtomX$I(atom2) - mol.getAtomX$I(atom1);
var dy=mol.getAtomY$I(atom2) - mol.getAtomY$I(atom1);
var dz=mol.getAtomZ$I(atom2) - mol.getAtomZ$I(atom1);
var distance=dx * dx + dy * dy + dz * dz;
if (minDistance > distance ) minDistance=distance;
}
}
scalingFactor=3.0 / Math.max(0.75, minDistance);
}return scalingFactor;
}, 1);

Clazz.newMeth(C$, 'writeCTAB$com_actelion_research_chem_StereoMolecule$D',  function (mol, scalingFactor) {
var mf=Clazz.new_(C$);
mf.mScalingFactor=scalingFactor;
mol.ensureHelperArrays$I(15);
p$1.writeBody$com_actelion_research_chem_StereoMolecule$Z.apply(mf, [mol, true]);
return mf.getMolfile$();
}, 1);

Clazz.newMeth(C$, 'writeCTAB$com_actelion_research_chem_StereoMolecule$Z',  function (mol, hasCoordinates) {
var mf=Clazz.new_(C$);
mol.ensureHelperArrays$I(15);
p$1.writeBody$com_actelion_research_chem_StereoMolecule$Z.apply(mf, [mol, hasCoordinates]);
return mf.getMolfile$();
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mMolfile=Clazz.new_($I$(1,1).c$$I,[32768]);
}, 1);

Clazz.newMeth(C$, 'writeBody$com_actelion_research_chem_StereoMolecule$Z',  function (mol, hasCoordinates) {
var nl=System.lineSeparator$();
this.mMolfile.append$S("M  V30 BEGIN CTAB" + nl);
this.mMolfile.append$S("M  V30 COUNTS " + mol.getAllAtoms$() + " " + mol.getAllBonds$() + " 0 0 0" + nl );
this.mMolfile.append$S("M  V30 BEGIN ATOM" + nl);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
this.mMolfile.append$S("M  V30 " + (atom + 1));
if (mol.getAtomList$I(atom) != null ) {
var atomList=mol.getAtomList$I(atom);
var notlist=(mol.getAtomQueryFeatures$I(atom) & 1) != 0;
this.mMolfile.append$S(notlist ? " NOT[" : " [");
for (var i=0; i < atomList.length; i++) {
if (i > 0) {
this.mMolfile.append$S(",");
}var label=$I$(2).cAtomLabel[atomList[i]];
switch (label.length$()) {
case 1:
this.mMolfile.append$S(label);
break;
case 2:
this.mMolfile.append$S(label);
break;
case 3:
this.mMolfile.append$S(label);
break;
default:
this.mMolfile.append$S("?");
break;
}
}
this.mMolfile.append$S("]");
} else if ((mol.getAtomQueryFeatures$I(atom) & 1) != 0) {
this.mMolfile.append$S(" A");
} else if ((mol.getAtomicNo$I(atom) >= 129 && mol.getAtomicNo$I(atom) <= 144 ) || mol.getAtomicNo$I(atom) == 154 ) {
this.mMolfile.append$S(" R#");
} else {
this.mMolfile.append$S(" " + mol.getAtomLabel$I(atom));
}if (hasCoordinates) {
this.mMolfile.append$S(" " + (new Double((((10000.0 * this.mScalingFactor * mol.getAtomX$I(atom) )|0)) / 10000.0).toString()));
this.mMolfile.append$S(" " + (new Double((((10000.0 * this.mScalingFactor * -mol.getAtomY$I(atom) )|0)) / 10000.0).toString()));
this.mMolfile.append$S(" " + (new Double((((10000.0 * this.mScalingFactor * -mol.getAtomZ$I(atom) )|0)) / 10000.0).toString()));
} else {
this.mMolfile.append$S(" 0 0 0");
}this.mMolfile.append$S(" " + mol.getAtomMapNo$I(atom));
if (mol.getAtomCharge$I(atom) != 0) {
this.mMolfile.append$S(" CHG=" + mol.getAtomCharge$I(atom));
}if (mol.getAtomRadical$I(atom) != 0) {
this.mMolfile.append$S(" RAD=");
switch (mol.getAtomRadical$I(atom)) {
case 16:
this.mMolfile.append$S("1");
break;
case 32:
this.mMolfile.append$S("2");
break;
case 48:
this.mMolfile.append$S("3");
break;
}
}if (mol.getAtomParity$I(atom) == 1 || mol.getAtomParity$I(atom) == 2 ) {
this.mMolfile.append$S(" CFG=");
if (mol.getAtomParity$I(atom) == 1) {
this.mMolfile.append$S("1");
} else {
this.mMolfile.append$S("2");
}}if (mol.getAtomMass$I(atom) != 0) {
this.mMolfile.append$S(" MASS=" + mol.getAtomMass$I(atom));
}var valence=mol.getAtomAbnormalValence$I(atom);
if (valence != -1) {
this.mMolfile.append$S(" VAL=" + ((valence == 0) ? "-1" : Integer.valueOf$I(valence)));
}var atomicNo=mol.getAtomicNo$I(atom);
if ((atomicNo >= 129 && atomicNo <= 144 ) || atomicNo == 154 ) {
this.mMolfile.append$S(" RGROUPS=(1 " + (atomicNo == 154 ? 0 : atomicNo >= 142 ? atomicNo - 141 : atomicNo - 125) + ")" );
}var hydrogenFlags=1920 & mol.getAtomQueryFeatures$I(atom);
if (hydrogenFlags == (384)) {
this.mMolfile.append$S(" HCOUNT=2");
} else if (hydrogenFlags == 128) {
this.mMolfile.append$S(" HCOUNT=1");
} else if (hydrogenFlags == (1792)) {
this.mMolfile.append$S(" HCOUNT=-1");
} else if (hydrogenFlags == (1664)) {
this.mMolfile.append$S(" HCOUNT=1");
}var substitution=mol.getAtomQueryFeatures$I(atom) & (6144);
if (substitution != 0) {
if ((substitution & 4096) != 0) {
this.mMolfile.append$S(" SUBST=" + (mol.getAllConnAtoms$I(atom) + 1));
} else {
this.mMolfile.append$S(" SUBST=-1");
}}var ringFeatures=mol.getAtomQueryFeatures$I(atom) & 120;
if (ringFeatures != 0) {
if (ringFeatures == (112)) this.mMolfile.append$S(" RBCNT=-1");
 else if (ringFeatures == 8) this.mMolfile.append$S(" RBCNT=2");
 else if (ringFeatures == (104)) this.mMolfile.append$S(" RBCNT=2");
 else if (ringFeatures == (88)) this.mMolfile.append$S(" RBCNT=3");
 else if (ringFeatures == (56)) this.mMolfile.append$S(" RBCNT=4");
}this.mMolfile.append$S(nl);
}
this.mMolfile.append$S("M  V30 END ATOM" + nl);
this.mMolfile.append$S("M  V30 BEGIN BOND" + nl);
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
this.mMolfile.append$S("M  V30 " + (bond + 1));
var order;
var stereo;
switch (mol.getBondType$I(bond)) {
case 1:
order=1;
stereo=0;
break;
case 2:
order=2;
stereo=0;
break;
case 4:
order=3;
stereo=0;
break;
case 129:
order=1;
stereo=3;
break;
case 257:
order=1;
stereo=1;
break;
case 386:
order=2;
stereo=2;
break;
case 8:
order=4;
stereo=0;
break;
case 16:
order=9;
stereo=0;
break;
default:
order=1;
stereo=0;
break;
}
var bondType=mol.getBondQueryFeatures$I(bond) & 31;
if (bondType != 0) {
if (bondType == 8) {
order=4;
} else if (bondType == (3)) {
order=5;
} else if (bondType == (9)) {
order=6;
} else if (bondType == (10)) {
order=7;
} else {
order=8;
}}this.mMolfile.append$S(" " + order + " " + (mol.getBondAtom$I$I(0, bond) + 1) + " " + (mol.getBondAtom$I$I(1, bond) + 1) );
if (stereo != 0) {
this.mMolfile.append$S(" CFG=" + stereo);
}var ringState=mol.getBondQueryFeatures$I(bond) & 384;
var topology=(ringState == 0) ? 0 : (ringState == 256) ? 1 : 2;
if (topology != 0) {
this.mMolfile.append$S(" TOPO=" + topology);
}this.mMolfile.append$S(nl);
}
this.mMolfile.append$S("M  V30 END BOND" + nl);
var paritiesFound=false;
var absAtomsCount=0;
var orAtomsCount=Clazz.array(Integer.TYPE, [32]);
var andAtomsCount=Clazz.array(Integer.TYPE, [32]);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomParity$I(atom) == 1 || mol.getAtomParity$I(atom) == 2 ) {
paritiesFound=true;
var type=mol.getAtomESRType$I(atom);
if (type == 1) {
++andAtomsCount[mol.getAtomESRGroup$I(atom)];
} else if (type == 2) {
++orAtomsCount[mol.getAtomESRGroup$I(atom)];
} else {
++absAtomsCount;
}}}
var absBondsCount=0;
var orBondsCount=Clazz.array(Integer.TYPE, [32]);
var andBondsCount=Clazz.array(Integer.TYPE, [32]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondOrder$I(bond) != 2 && (mol.getBondParity$I(bond) == 1 || mol.getBondParity$I(bond) == 2 ) ) {
paritiesFound=true;
var type=mol.getBondESRType$I(bond);
if (type == 1) {
++andBondsCount[mol.getBondESRGroup$I(bond)];
} else if (type == 2) {
++orBondsCount[mol.getBondESRGroup$I(bond)];
} else {
++absBondsCount;
}}}
if (paritiesFound) {
this.mMolfile.append$S("M  V30 BEGIN COLLECTION" + nl);
if (absAtomsCount != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STEABS ATOMS=(" + absAtomsCount);
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if ((mol.getAtomParity$I(atom) == 1 || mol.getAtomParity$I(atom) == 2 ) && mol.getAtomESRType$I(atom) == 0 ) {
this.mMolfile.append$S(" " + (atom + 1));
}}
this.mMolfile.append$S(")" + nl);
}if (absBondsCount != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STEABS BONDS=(" + absBondsCount);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondOrder$I(bond) != 2 && (mol.getBondParity$I(bond) == 1 || mol.getBondParity$I(bond) == 2 )  && mol.getBondESRType$I(bond) == 0 ) {
this.mMolfile.append$S(" " + (bond + 1));
}}
this.mMolfile.append$S(")" + nl);
}for (var group=0; group < 32; group++) {
if (orAtomsCount[group] != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STEREL" + (group + 1) + " ATOMS=(" + orAtomsCount[group] );
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if ((mol.getAtomParity$I(atom) == 1 || mol.getAtomParity$I(atom) == 2 ) && mol.getAtomESRType$I(atom) == 2  && mol.getAtomESRGroup$I(atom) == group ) {
this.mMolfile.append$S(" " + (atom + 1));
}}
this.mMolfile.append$S(")" + nl);
}if (andAtomsCount[group] != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STERAC" + (group + 1) + " ATOMS=(" + andAtomsCount[group] );
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if ((mol.getAtomParity$I(atom) == 1 || mol.getAtomParity$I(atom) == 2 ) && mol.getAtomESRType$I(atom) == 1  && mol.getAtomESRGroup$I(atom) == group ) {
this.mMolfile.append$S(" " + (atom + 1));
}}
this.mMolfile.append$S(")" + nl);
}if (orBondsCount[group] != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STEREL" + (group + 1) + " BONDS=(" + orBondsCount[group] );
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondOrder$I(bond) != 2 && (mol.getBondParity$I(bond) == 1 || mol.getBondParity$I(bond) == 2 )  && mol.getBondESRType$I(bond) == 2  && mol.getBondESRGroup$I(bond) == group ) {
this.mMolfile.append$S(" " + (bond + 1));
}}
this.mMolfile.append$S(")" + nl);
}if (andBondsCount[group] != 0) {
this.mMolfile.append$S("M  V30 MDLV30/STERAC" + (group + 1) + " BONDS=(" + andBondsCount[group] );
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (mol.getBondOrder$I(bond) != 2 && (mol.getBondParity$I(bond) == 1 || mol.getBondParity$I(bond) == 2 )  && mol.getBondESRType$I(bond) == 1  && mol.getBondESRGroup$I(bond) == group ) {
this.mMolfile.append$S(" " + (bond + 1));
}}
this.mMolfile.append$S(")" + nl);
}}
this.mMolfile.append$S("M  V30 END COLLECTION" + nl);
}this.mMolfile.append$S("M  V30 END CTAB" + nl);
}, p$1);

Clazz.newMeth(C$, 'getMolfile$',  function () {
return this.mMolfile.toString();
});

Clazz.newMeth(C$, 'getScalingFactor$',  function () {
return this.mScalingFactor;
});

Clazz.newMeth(C$, 'writeMolfile$java_io_Writer',  function (theWriter) {
theWriter.write$S(this.mMolfile.toString());
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:59 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
