(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.conf.BondLengthSet','com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondAngleSet");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMol','com.actelion.research.chem.StereoMolecule','mBondLengthSet','com.actelion.research.chem.conf.BondLengthSet','mBondAngle','float[][][]','mDefinedAngleCount','int[]','+mTinyRingSizeSum','mDefinedAngleSum','float[]']]
,['F',['TO_RADIAN']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_conf_BondLengthSet',  function (mol, set) {
;C$.$init$.apply(this);
this.mBondLengthSet=(set == null ) ? Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[mol]) : set;
this.mMol=mol;
this.mBondAngle=Clazz.array(Float.TYPE, [this.mMol.getAtoms$(), null, null]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
this.mBondAngle[atom]=Clazz.array(Float.TYPE, [this.mMol.getAllConnAtoms$I(atom), null]);
for (var i=1; i < this.mMol.getAllConnAtoms$I(atom); i++) this.mBondAngle[atom][i]=Clazz.array(Float.TYPE, [i]);

}
this.mDefinedAngleCount=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mDefinedAngleSum=Clazz.array(Float.TYPE, [this.mMol.getAtoms$()]);
this.mTinyRingSizeSum=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
var ringSet=this.mMol.getRingSet$();
var isAromaticRing=Clazz.array(Boolean.TYPE, [ringSet.getSize$()]);
ringSet.determineAromaticity$ZA$ZA$IA$Z(isAromaticRing, Clazz.array(Boolean.TYPE, [ringSet.getSize$()]), Clazz.array(Integer.TYPE, [ringSet.getSize$()]), true);
for (var consideredRingSize=3; consideredRingSize <= 7; consideredRingSize++) {
for (var ring=0; ring < ringSet.getSize$(); ring++) {
var ringSize=ringSet.getRingSize$I(ring);
if (ringSize == consideredRingSize) {
if (isAromaticRing[ring]) p$1.calculateBondAnglesOfAromaticRing$I.apply(this, [ring]);
 else if (ringSize <= 4) p$1.calculateBondAnglesOfSmallRing$I.apply(this, [ring]);
}}
}
var isAromaticAtom=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
for (var ring=0; ring < ringSet.getSize$(); ring++) if (isAromaticRing[ring]) for (var ringAtom, $ringAtom = 0, $$ringAtom = ringSet.getRingAtoms$I(ring); $ringAtom<$$ringAtom.length&&((ringAtom=($$ringAtom[$ringAtom])),1);$ringAtom++) isAromaticAtom[ringAtom]=true;


var cTotalAngleCount=Clazz.array(Integer.TYPE, -1, [0, 0, 1, 3, 6, 10, 15, 21]);
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
var connAtoms=this.mMol.getAllConnAtoms$I(atom);
if (connAtoms > 4) {
for (var i=1; i < connAtoms; i++) for (var j=0; j < i; j++) this.mBondAngle[atom][i][j]=1.5707964;


this.mDefinedAngleCount[atom]=cTotalAngleCount[connAtoms];
continue;
}if (this.mDefinedAngleCount[atom] == cTotalAngleCount[connAtoms]) continue;
if (this.mMol.isSmallRingAtom$I(atom) && (isAromaticAtom[atom] || (this.mMol.getAtomRingSize$I(atom) <= 4 && this.mMol.getAtomPi$I(atom) > 0 ) ) ) {
if (connAtoms > 2) {
var angle;
if (this.mDefinedAngleCount[atom] == 1) {
if (this.mMol.getAtomicNo$I(atom) <= 14) angle=(6.2831855 - this.mDefinedAngleSum[atom]) / 2.0;
 else angle=p$1.calculateRemainingTetrahedralAngle$F.apply(this, [this.mDefinedAngleSum[atom]]);
} else {
angle=6.2831855 - this.mDefinedAngleSum[atom];
if (connAtoms > 3) {
if (this.mDefinedAngleCount[atom] == 2) {
var isMissingIndex=Clazz.array(Boolean.TYPE, [this.mMol.getAllConnAtoms$I(atom)]);
for (var i=1; i < connAtoms; i++) {
for (var j=0; j < i; j++) {
if (this.mBondAngle[atom][i][j] != 0.0 ) {
isMissingIndex[i]=!isMissingIndex[i];
isMissingIndex[j]=!isMissingIndex[j];
}}
}
for (var i=0; i < connAtoms; i++) {
if (isMissingIndex[i]) {
for (var j=i + 1; j < connAtoms; j++) {
if (isMissingIndex[j]) {
this.mBondAngle[atom][j][i]=angle;
break;
}}
break;
}}
}angle=1.5707964;
}}for (var i=1; i < connAtoms; i++) for (var j=0; j < i; j++) if (this.mBondAngle[atom][i][j] == 0.0 ) this.mBondAngle[atom][i][j]=angle;


}} else if (this.mMol.isSmallRingAtom$I(atom) && this.mMol.getAtomRingSize$I(atom) <= 4 ) {
switch (p$1.getRingStrainClass$I.apply(this, [atom])) {
case 771:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 3, 2.0654]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 0, 113.53 * C$.TO_RADIAN]);
break;
case 1028:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 4, 1.9798]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 0, 111.55 * C$.TO_RADIAN]);
break;
case 393987:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 3, 2.264]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 6, 2.264]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 3, 98.715 * C$.TO_RADIAN]);
break;
case 459779:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 3, 2.1676]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 4, 2.1676]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 7, 2.1676]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 4, 110.71 * C$.TO_RADIAN]);
break;
case 525316:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 4, 2.0663]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 8, 2.0663]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 4, 114.56 * C$.TO_RADIAN]);
case 394758:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 6, 2.5261]);
break;
case 460550:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 6, 2.3562]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 7, 2.3562]);
break;
case 526087:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 7, 2.2845]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 8, 2.2845]);
break;
case 526344:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 0, 8, 2.1863]);
break;
case 50529027:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 3, 2.4189]);
break;
case 67371779:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 4, 2.2299]);
break;
case 67372036:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 4, 2.0944]);
break;
case 101057283:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 6, 105.42 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 3, 166.51 * C$.TO_RADIAN]);
break;
case 117834755:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 4, 161.13 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 7, 102.62 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 6, 121.61 * C$.TO_RADIAN]);
break;
case 134677507:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 4, 151.4 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 8, 116.18 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 7, 129.0 * C$.TO_RADIAN]);
break;
case 117900035:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 7, 120.88 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 3, 3, 177.92 * C$.TO_RADIAN]);
break;
case 117900292:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 7, 119.79 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 4, 146.2 * C$.TO_RADIAN]);
break;
case 134743044:
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 8, 122.57 * C$.TO_RADIAN]);
p$1.setRingStrainAngles$I$I$I$F.apply(this, [atom, 4, 4, 134.76 * C$.TO_RADIAN]);
break;
}
} else {
var angle=(this.mMol.getAtomicNo$I(atom) > 10) ? 1.910612 : (this.mMol.getAtomPi$I(atom) == 2) ? 3.1415927 : this.mMol.isFlatNitrogen$I(atom) ? 2.0943952 : (this.mMol.getAtomPi$I(atom) == 0) ? 1.910612 : 2.0943952;
for (var i=1; i < connAtoms; i++) for (var j=0; j < i; j++) this.mBondAngle[atom][i][j]=angle;


}}
}, 1);

Clazz.newMeth(C$, 'getAngle$I$I$I',  function (atom, conn1, conn2) {
var connIndex1=-1;
var connIndex2=-1;
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var conn=this.mMol.getConnAtom$I$I(atom, i);
if (conn == conn1 || conn == conn2 ) {
if (connIndex2 == -1) {
connIndex2=i;
} else {
connIndex1=i;
break;
}}}
return this.mBondAngle[atom][connIndex1][connIndex2];
});

Clazz.newMeth(C$, 'getConnAngle$I$I$I',  function (atom, i1, i2) {
return (i1 < i2) ? this.mBondAngle[atom][i2][i1] : this.mBondAngle[atom][i1][i2];
});

Clazz.newMeth(C$, 'calculateBondAnglesOfSmallRing$I',  function (ring) {
var ringSet=this.mMol.getRingSet$();
var ringSize=ringSet.getRingSize$I(ring);
var ringBond=ringSet.getRingBonds$I(ring);
var untouchedBondFound=false;
for (var i=0; i < ringSize; i++) {
if (this.mTinyRingSizeSum[ringBond[i]] == 0) {
untouchedBondFound=true;
break;
}}
if (untouchedBondFound) {
var angle=(180.0 * ringSize - 360.0) / ringSize * C$.TO_RADIAN;
var ringAtom=ringSet.getRingAtoms$I(ring);
for (var i=0; i < ringSize; i++) {
p$1.setBondAngle$I$I$I$F.apply(this, [ringAtom[i], ringBond[(i == 0) ? ringSize - 1 : i - 1], ringBond[i], angle]);
}
if (ringSize <= 4) {
for (var i=0; i < ringSize; i++) this.mTinyRingSizeSum[ringBond[i]]+=ringSize;

}}}, p$1);

Clazz.newMeth(C$, 'calculateBondAnglesOfAromaticRing$I',  function (ring) {
var ringSet=this.mMol.getRingSet$();
var ringSize=ringSet.getRingSize$I(ring);
var ringAtom=ringSet.getRingAtoms$I(ring);
var ringBond=ringSet.getRingBonds$I(ring);
var isRegularRing=true;
for (var i=1; i < ringSize; i++) {
if (this.mBondLengthSet.getLength$I(ringBond[i]) != this.mBondLengthSet.getLength$I(ringBond[0]) ) {
isRegularRing=false;
break;
}}
if (isRegularRing) {
var bondAngle=(ringSize - 2.0) * 3.1415927 / ringSize;
for (var i=0; i < ringSize; i++) p$1.setBondAngle$I$I$I$F.apply(this, [ringAtom[i], ringBond[i], ringBond[(i == 0) ? ringSize - 1 : i - 1], bondAngle]);

return;
}var optAngle=Clazz.array(Float.TYPE, [ringSize]);
var angleSum=0.0;
for (var i=0; i < ringSize; i++) {
optAngle[i]=(this.mMol.getAtomPi$I(ringAtom[i]) == 0) ? 109.47 * C$.TO_RADIAN : (this.mMol.getAtomPi$I(ringAtom[i]) == 1) ? 2.0944998 : 3.1415927;
angleSum+=optAngle[i];
}
var angleInc=((ringSize - 2.0) * 3.1415927 - angleSum) / ringSize;
for (var i=0; i < ringSize; i++) optAngle[i]+=angleInc;

var direction=Clazz.array(Float.TYPE, [ringSize]);
for (var i=1; i < ringSize; i++) direction[i]=direction[i - 1] + 3.1415927 - optAngle[i];

var dError_ddir=Clazz.array(Float.TYPE, [ringSize]);
var cycles=100;
for (var cycle=0; cycle < 100; cycle++) {
var sx=0.0;
var sy=0.0;
for (var i=0; i < ringSize; i++) {
sx+=this.mBondLengthSet.getLength$I(ringBond[i]) * Math.sin(direction[i]);
sy+=this.mBondLengthSet.getLength$I(ringBond[i]) * Math.cos(direction[i]);
}
var gapDirection=$I$(2).getAngle$D$D$D$D(0.0, 0.0, sx, sy);
var gapSize=Math.sqrt(sx * sx + sy * sy);
var maxForceIndex=-1;
var maxForce=0;
for (var i=0; i < ringSize; i++) {
var im1=(i == 0) ? ringSize - 1 : i - 1;
var ip1=(i + 1 == ringSize) ? 0 : i + 1;
var dirDif1=$I$(2).getAngleDif$D$D(direction[i], direction[im1]);
var dirDif2=$I$(2).getAngleDif$D$D(direction[ip1], direction[i]);
var optDif=$I$(2).getAngleDif$D$D(optAngle[i], optAngle[ip1]);
dError_ddir[i]=2 * dirDif1 - 2 * dirDif2 + 2 * optDif;
var gapGain=Math.cos(direction[i] - 1.5707964 - gapDirection);
var force=gapSize * gapGain - 0.03 * dError_ddir[i];
if (Math.abs(force) > Math.abs(maxForce) ) {
maxForce=force;
maxForceIndex=i;
}}
var factor=Math.exp(-5 * cycle / 100);
direction[maxForceIndex]+=factor * maxForce;
}
for (var i=0; i < ringSize; i++) {
var im1=(i == 0) ? ringSize - 1 : i - 1;
var angle=direction[im1] + 3.1415927 - direction[i];
if (angle > 6.283185307179586 ) angle-=6.283185307179586;
p$1.setBondAngle$I$I$I$F.apply(this, [ringAtom[i], ringBond[im1], ringBond[i], angle]);
}
}, p$1);

Clazz.newMeth(C$, 'getRingStrainClass$I',  function (atom) {
var handled=Clazz.array(Boolean.TYPE, [this.mMol.getConnAtoms$I(atom)]);
var strainClass=0;
for (var i=0; i < this.mMol.getConnAtoms$I(atom); i++) {
var largestSum=0;
var largestIndex=-1;
for (var j=0; j < this.mMol.getConnAtoms$I(atom); j++) {
if (!handled[j]) {
var bond=this.mMol.getConnBond$I$I(atom, j);
if (largestSum < this.mTinyRingSizeSum[bond]) {
largestSum=this.mTinyRingSizeSum[bond];
largestIndex=j;
}}}
if (largestSum == 0) return strainClass;
strainClass<<=8;
strainClass+=largestSum;
handled[largestIndex]=true;
}
return strainClass;
}, p$1);

Clazz.newMeth(C$, 'setRingStrainAngles$I$I$I$F',  function (atom, tinyRingSizeSum1, tinyRingSizeSum2, angle) {
var allConnAtoms=this.mMol.getAllConnAtoms$I(atom);
var connAtoms=this.mMol.getConnAtoms$I(atom);
for (var i=1; i < allConnAtoms; i++) {
var bondSum1=(i < connAtoms) ? this.mTinyRingSizeSum[this.mMol.getConnBond$I$I(atom, i)] : 0;
for (var j=0; j < i; j++) {
if (this.mBondAngle[atom][i][j] == 0.0 ) {
var bondSum2=(j < connAtoms) ? this.mTinyRingSizeSum[this.mMol.getConnBond$I$I(atom, j)] : 0;
if ((bondSum1 == tinyRingSizeSum1 && bondSum2 == tinyRingSizeSum2 ) || (bondSum1 == tinyRingSizeSum2 && bondSum2 == tinyRingSizeSum1 ) ) this.mBondAngle[atom][i][j]=angle;
}}
}
}, p$1);

Clazz.newMeth(C$, 'setBondAngle$I$I$I$F',  function (atom, bond1, bond2, angle) {
var conn1=-1;
var conn2=-1;
for (var i=0; i < this.mMol.getAllConnAtoms$I(atom); i++) {
var connBond=this.mMol.getConnBond$I$I(atom, i);
if (connBond == bond1 || connBond == bond2 ) {
if (conn1 == -1) {
conn1=i;
} else {
conn2=i;
break;
}}}
if (this.mBondAngle[atom][conn2][conn1] == 0.0 ) {
this.mBondAngle[atom][conn2][conn1]=angle;
this.mDefinedAngleSum[atom]+=angle;
++this.mDefinedAngleCount[atom];
}}, p$1);

Clazz.newMeth(C$, 'calculateRemainingTetrahedralAngle$F',  function (firstAngle) {
var a109=1.910612;
return a109 + (a109 - firstAngle) * 0.18;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.TO_RADIAN=0.017453292;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
