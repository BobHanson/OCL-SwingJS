(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),p$1={},I$=[[0,'java.util.HashSet','com.actelion.research.chem.descriptor.pharmacophoretree.IonizableGroupDetector2D','com.actelion.research.chem.phesa.pharmacophore.PharmacophoreCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "FeatureCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','donorAtoms','java.util.Set','+acceptorAtoms','+negChargeAtoms','+posChargeAtoms','+aromAtoms','+lipoAtoms']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
this.donorAtoms=Clazz.new_($I$(1,1));
this.acceptorAtoms=Clazz.new_($I$(1,1));
this.negChargeAtoms=Clazz.new_($I$(1,1));
this.posChargeAtoms=Clazz.new_($I$(1,1));
this.aromAtoms=Clazz.new_($I$(1,1));
this.lipoAtoms=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'calculate$',  function () {
var detector=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[this.mol]);
detector.detect$();
this.negChargeAtoms=detector.getNegIonizableAtoms$();
this.posChargeAtoms=detector.getPosIonizableAtoms$();
p$1.getAtomFeatures.apply(this, []);
});

Clazz.newMeth(C$, 'getAtomFeatures',  function () {
for (var i=0; i < this.mol.getAtoms$(); i++) {
if (this.mol.isAromaticAtom$I(i)) this.aromAtoms.add$O(Integer.valueOf$I(i));
 else {
for (var n=0; n < this.mol.getConnAtoms$I(i); n++) if (this.mol.getConnBondOrder$I$I(i, n) == 2) this.aromAtoms.add$O(Integer.valueOf$I(i));

}if (this.mol.getAtomicNo$I(i) == 7 || this.mol.getAtomicNo$I(i) == 8 ) {
if ($I$(3).isAcceptor$com_actelion_research_chem_StereoMolecule$I(this.mol, i)) {
this.acceptorAtoms.add$O(Integer.valueOf$I(i));
}if ($I$(3).isDonorHeavyAtom$com_actelion_research_chem_StereoMolecule$I(this.mol, i)) {
this.donorAtoms.add$O(Integer.valueOf$I(i));
} else this.lipoAtoms.add$O(Integer.valueOf$I(i));
} else {
this.lipoAtoms.add$O(Integer.valueOf$I(i));
}}
}, p$1);

Clazz.newMeth(C$, 'getAtomFunctionalities$',  function () {
var features=Clazz.array(Integer.TYPE, [this.mol.getAtoms$(), 6]);
for (var a=0; a < this.mol.getAtoms$(); a++) {
var atomFeatures=features[a];
if (this.donorAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[1];
if (this.acceptorAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[0];
if (this.negChargeAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[2];
if (this.posChargeAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[3];
if (this.lipoAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[5];
if (this.aromAtoms.contains$O(Integer.valueOf$I(a))) ++atomFeatures[4];
}
return features;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:41 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
