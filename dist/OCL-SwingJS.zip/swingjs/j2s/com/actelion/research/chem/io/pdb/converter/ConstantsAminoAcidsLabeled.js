(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ConstantsAminoAcidsLabeled");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:56 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
