(function(){var P$=Clazz.newPackage("com.actelion.research.chem.hyperspace"),p$1={},p$2={},I$=[[0,'java.util.ArrayList','java.util.BitSet',['com.actelion.research.chem.hyperspace.BitSetTree','.SuperSetIterator'],'java.util.Random',['com.actelion.research.chem.hyperspace.BitSetTree','.Node'],'java.util.Collections',['com.actelion.research.chem.hyperspace.BitSetTree','.BitSetWithRow'],'java.util.HashSet']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BitSetTree", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'java.io.Serializable');
C$.$classes$=[['BitSetWithRow',9],['Node',25],['SuperSetIterator',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['root','com.actelion.research.chem.hyperspace.BitSetTree.Node']]
,['O',['random','java.util.Random']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_hyperspace_BitSetTree_Node',  function (root) {
;C$.$init$.apply(this);
this.root=root;
}, 1);

Clazz.newMeth(C$, 'testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA',  function (b, first_superset) {
return this.root.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(b, first_superset);
});

Clazz.newMeth(C$, 'createTree$java_util_Collection$I$I$I',  function (bitsets, num_bits, binsize, max_tries) {
var root=C$.split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S$I(bitsets, Clazz.new_($I$(2,1).c$$I,[num_bits]), Clazz.new_($I$(2,1).c$$I,[num_bits]), num_bits, binsize, "r", max_tries);
return Clazz.new_(C$.c$$com_actelion_research_chem_hyperspace_BitSetTree_Node,[root]);
}, 1);

Clazz.newMeth(C$, 'createTree$java_util_Collection$I$I',  function (bitsets, num_bits, binsize) {
var root=C$.split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S(bitsets, Clazz.new_($I$(2,1).c$$I,[num_bits]), Clazz.new_($I$(2,1).c$$I,[num_bits]), num_bits, binsize, "r");
return Clazz.new_(C$.c$$com_actelion_research_chem_hyperspace_BitSetTree_Node,[root]);
}, 1);

Clazz.newMeth(C$, 'split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S',  function (bi, bits_0, bits_1, num_bits, binsize, tree_pos) {
return C$.split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S$I(bi, bits_0, bits_1, num_bits, binsize, tree_pos, 20);
}, 1);

Clazz.newMeth(C$, 'split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S$I',  function (bi, bits_0, bits_1, num_bits, binsize, tree_pos, max_tries) {
if (bi.size$() <= binsize) {
return Clazz.new_([-1, bits_0, bits_1, null, null, Clazz.new_($I$(1,1).c$$java_util_Collection,[bi])],$I$(5,1).c$$I$java_util_BitSet$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_Node$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List);
}var possible_splits=Clazz.new_($I$(1,1));
for (var zi=0; zi < num_bits; zi++) {
if ((!bits_0.get$I(zi)) && (!bits_1.get$I(zi)) ) {
possible_splits.add$O(Integer.valueOf$I(zi));
}}
$I$(6).shuffle$java_util_List$java_util_Random(possible_splits, C$.random);
var best_split=0.0;
var best_split_bit=-1;
for (var zi=0; zi < Math.min(possible_splits.size$(), max_tries); zi++) {
var split=(possible_splits.get$I(zi)).$c();
var sa=0;
for (var bsi, $bsi = bi.iterator$(); $bsi.hasNext$()&&((bsi=($bsi.next$())),1);) {
sa+=(bsi.bitset.get$I(split)) ? 1 : 0;
}
var split_value=1.0 * sa / bi.size$();
var split_score=Math.min(split_value, 1.0 - split_value);
if (split_score > best_split ) {
best_split_bit=split;
best_split=split_score;
}if (best_split > 0.42 ) {
break;
}}
if (best_split_bit < 0) {
System.out.println$S("wut?");
} else {
if (true) {
System.out.println$S("SplitScore: " + new Double(best_split).toString() + "  (Size=" + bi.size$() + ",level=" + (bits_0.cardinality$() + bits_1.cardinality$()) + ")" );
}}var bs_a=Clazz.new_($I$(1,1));
var bs_b=Clazz.new_($I$(1,1));
for (var bsi, $bsi = bi.iterator$(); $bsi.hasNext$()&&((bsi=($bsi.next$())),1);) {
if (bsi.bitset.get$I(best_split_bit)) {
bs_b.add$O(bsi);
} else {
bs_a.add$O(bsi);
}}
var bits_0_left=bits_0.clone$();
var bits_1_left=bits_1.clone$();
var bits_0_right=bits_0.clone$();
var bits_1_right=bits_1.clone$();
bits_0_left.set$I$Z(best_split_bit, true);
bits_1_right.set$I$Z(best_split_bit, true);
var left=C$.split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S(bs_a, bits_0_left, bits_1_left, num_bits, binsize, tree_pos + "_0");
var right=C$.split_recursively$java_util_Collection$java_util_BitSet$java_util_BitSet$I$I$S(bs_b, bits_0_right, bits_1_right, num_bits, binsize, tree_pos + "_1");
return Clazz.new_($I$(5,1).c$$I$java_util_BitSet$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_Node$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List,[best_split_bit, bits_0, bits_1, left, right, null]);
}, 1);

Clazz.newMeth(C$, 'isSet$BA$I',  function (arr, bit) {
var index=(bit/8|0);
var bitPosition=bit % 8;
if (index >= arr.length) {
return false;
}return (arr[index] >> bitPosition & 1) == 1;
}, 1);

Clazz.newMeth(C$, 'collectNodes_dfs$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List',  function (n, nodes) {
nodes.add$O(n);
if (n.left != null ) {
p$2.collectNodes_dfs$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List.apply(this, [n.left, nodes]);
}if (n.right != null ) {
p$2.collectNodes_dfs$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List.apply(this, [n.right, nodes]);
}}, p$2);

Clazz.newMeth(C$, 'createFromStructureSearchDataSource$com_actelion_research_chem_StructureSearchDataSource$S$I',  function (ssds, descriptorShortName, descriptorBits) {
return C$.createFromStructureSearchDataSource$com_actelion_research_chem_StructureSearchDataSource$S$I$I$I(ssds, descriptorShortName, descriptorBits, 512, 40);
}, 1);

Clazz.newMeth(C$, 'createFromStructureSearchDataSource$com_actelion_research_chem_StructureSearchDataSource$S$I$I$I',  function (ssds, descriptorShortName, descriptorBits, treeBinSize, maxTries) {
var dcol=ssds.getDescriptorColumn$S(descriptorShortName);
var rows=Clazz.new_($I$(1,1));
for (var zi=0; zi < ssds.getRowCount$(); zi++) {
rows.add$O(Clazz.new_([$I$(2,"valueOf$JA",[ssds.getDescriptor$I$I$I$Z(dcol, zi, 0, false)]), zi],$I$(7,1).c$$java_util_BitSet$I));
}
var bst=C$.createTree$java_util_Collection$I$I$I(rows, descriptorBits, treeBinSize, maxTries);
return bst;
}, 1);

Clazz.newMeth(C$, 'test_bitsets2$',  function () {
var r=Clazz.new_($I$(4,1));
var test=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 20000, 64, 0.6);
var t=C$.createTree$java_util_Collection$I$I(Clazz.new_($I$(8,1).c$$java_util_Collection,[test]), 64, 8);
var to_find=Clazz.new_($I$(2,1).c$$I,[64]);
to_find.set$I(13);
to_find.set$I(17);
to_find.set$I(19);
to_find.set$I(27);
var supersets=Clazz.new_($I$(1,1));
for (var ti, $ti = test.iterator$(); $ti.hasNext$()&&((ti=($ti.next$())),1);) {
var tit=ti.bitset.clone$();
tit.or$java_util_BitSet(to_find);
if (tit.equals$O(ti.bitset)) {
supersets.add$O(ti);
}}
var supersets_2=Clazz.array($I$(5), [1]);
var found=t.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(to_find, supersets_2);
var supersets_3=Clazz.new_($I$(1,1));
t.root.collectSuperSets$java_util_BitSet$java_util_List(to_find, supersets_3);
if (supersets_3.size$() == supersets.size$()) {
System.out.println$S("ok");
} else {
System.out.println$S("not ok");
}}, 1);

Clazz.newMeth(C$, 'test_fetch_supersets$',  function () {
var r=Clazz.new_($I$(4,1));
var test=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 64, 16, 0.6);
var t=C$.createTree$java_util_Collection$I$I(Clazz.new_($I$(8,1).c$$java_util_Collection,[test]), 16, 2);
var to_find=test.get$I(3).bitset;
to_find.set$I$I(to_find.nextSetBit$I(0), 0);
var supersets=Clazz.array($I$(5), [1]);
var found=t.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(to_find, supersets);
if (found) {
System.out.println$S("ok");
} else {
System.out.println$S("ERROR.. not working :(");
}}, 1);

Clazz.newMeth(C$, 'test_benchmark_a$',  function () {
var r=Clazz.new_($I$(4,1));
var bits=2048;
var rand_bs=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 200000, bits, 0.6);
System.out.println$S("Create tree:");
var bst=C$.createTree$java_util_Collection$I$I(Clazz.new_($I$(8,1).c$$java_util_Collection,[rand_bs]), bits, 64);
System.out.println$S("Create tree: done!");
var rand_test=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 1000, bits, 0.12);
System.out.println$S("Start eval:");
var ts_a=System.currentTimeMillis$();
for (var bsi, $bsi = rand_test.iterator$(); $bsi.hasNext$()&&((bsi=($bsi.next$())),1);) {
var result=Clazz.array($I$(5), [1]);
System.out.println$Z(bst.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(bsi.bitset, result));
}
var ts_b=System.currentTimeMillis$();
System.out.println$S("Time= " + (Long.$s(Long.$sub(ts_b,ts_a))));
}, 1);

Clazz.newMeth(C$, 'test_benchmark_b$',  function () {
var r=Clazz.new_($I$(4,1));
var bits=512;
var rand_bs=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 800000, bits, 0.8);
System.out.println$S("Create tree:");
var bst=C$.createTree$java_util_Collection$I$I(Clazz.new_($I$(8,1).c$$java_util_Collection,[rand_bs]), bits, 100000);
System.out.println$S("Create tree: done!");
var rand_test=C$.createRandomBitSetWithRow$java_util_Random$I$I$D(r, 100, bits, 0.3);
System.out.println$S("Start eval:");
var ts_a=System.currentTimeMillis$();
for (var zr=0; zr < rand_test.size$(); zr++) {
var bsi=rand_test.get$I(zr);
if (true) {
var ts_a1=System.currentTimeMillis$();
var ssiterator=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_BitSet,[bst.root, bsi.bitset]);
var rows=Clazz.new_($I$(1,1));
for (var zi=0; zi < 2000; zi++) {
if (ssiterator.hasNext$()) {
rows.add$O(ssiterator.next$());
} else {
break;
}}
var ts_b1=System.currentTimeMillis$();
System.out.println$S(zr + " -> Results: " + rows.size$() );
System.out.println$S("Time A: " + (Long.$s(Long.$sub(ts_b1,ts_a1))));
}if (true) {
var ts_a1=System.currentTimeMillis$();
var rows=Clazz.new_($I$(1,1));
bst.root.collectSuperSetsWithRows$java_util_BitSet$java_util_List$I(bsi.bitset, rows, 2000);
var ts_b1=System.currentTimeMillis$();
System.out.println$S(zr + " -> Results: " + rows.size$() );
System.out.println$S("Time B: " + (Long.$s(Long.$sub(ts_b1,ts_a1))));
}}
var ts_b=System.currentTimeMillis$();
System.out.println$S("Time= " + (Long.$s(Long.$sub(ts_b,ts_a))));
}, 1);

Clazz.newMeth(C$, 'createRandomBitSetWithRow$java_util_Random$I$I$D',  function (r, n, bits, density) {
var rand_bs=Clazz.new_($I$(1,1));
for (var zi=0; zi < n; zi++) {
var bsi=Clazz.new_($I$(2,1).c$$I,[bits]);
for (var zj=0; zj < bits; zj++) {
bsi.set$I$Z(zj, r.nextFloat$() < density );
}
rand_bs.add$O(Clazz.new_($I$(7,1).c$$java_util_BitSet$I,[bsi, zi]));
}
return rand_bs;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.random=Clazz.new_($I$(4,1));
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.BitSetTree, "BitSetWithRow", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['row'],'O',['bitset','java.util.BitSet']]]

Clazz.newMeth(C$, 'c$$java_util_BitSet$I',  function (bs, row) {
;C$.$init$.apply(this);
this.bitset=bs;
this.row=row;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.BitSetTree, "Node", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.left=null;
this.right=null;
this.leaf_data=null;
},1);

C$.$fields$=[['I',['bit'],'O',['bits_1','java.util.BitSet','+bits_0','left','com.actelion.research.chem.hyperspace.BitSetTree.Node','+right','leaf_data','java.util.List']]]

Clazz.newMeth(C$, 'c$$I$java_util_BitSet$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_Node$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_List',  function (bit, bits_0, bits_1, left, right, data) {
;C$.$init$.apply(this);
this.bit=bit;
this.bits_0=bits_0;
this.bits_1=bits_1;
this.left=left;
this.right=right;
this.leaf_data=data;
}, 1);

Clazz.newMeth(C$, 'isLeaf$',  function () {
return this.bit < 0;
});

Clazz.newMeth(C$, 'setLeft$com_actelion_research_chem_hyperspace_BitSetTree_Node',  function (l) {
this.left=l;
});

Clazz.newMeth(C$, 'setRight$com_actelion_research_chem_hyperspace_BitSetTree_Node',  function (r) {
this.right=r;
});

Clazz.newMeth(C$, 'depth$',  function () {
return this.bits_0.cardinality$() + this.bits_1.cardinality$();
});

Clazz.newMeth(C$, 'getLeafData$',  function () {
if (this.leaf_data != null ) {
return this.leaf_data;
} else {
}return null;
});

Clazz.newMeth(C$, 'testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA',  function (b, first_superset) {
first_superset[0]=null;
if (this.bit < 0) {
var n_leaf_data=this.getLeafData$();
if (n_leaf_data.isEmpty$()) {
return false;
}var subset=true;
for (var bsi, $bsi = n_leaf_data.iterator$(); $bsi.hasNext$()&&((bsi=($bsi.next$())),1);) {
var ti=bsi.bitset.clone$();
ti.or$java_util_BitSet(b);
if (ti.equals$O(bsi.bitset)) {
first_superset[0]=this;
return true;
}}
return false;
}var test=this.bits_1.clone$();
test.or$java_util_BitSet(b);
if (test.equals$O(this.bits_1)) {
first_superset[0]=this;
return true;
}if (b.get$I(this.bit)) {
return this.right.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(b, first_superset);
} else {
return this.right.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(b, first_superset) || this.left.testSubset$java_util_BitSet$com_actelion_research_chem_hyperspace_BitSetTree_NodeA(b, first_superset) ;
}});

Clazz.newMeth(C$, 'filterRows$JA$I',  function (fingerprint, max_results) {
var results=Clazz.new_($I$(1,1));
this.collectSuperSetsWithRows$java_util_BitSet$java_util_List$I($I$(2).valueOf$JA(fingerprint), results, max_results);
var rows=results.stream$().mapToInt$java_util_function_ToIntFunction((P$.BitSetTree$Node$lambda1$||(P$.BitSetTree$Node$lambda1$=(((P$.BitSetTree$Node$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "BitSetTree$Node$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.ToIntFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['applyAsInt$com_actelion_research_chem_hyperspace_BitSetTree_BitSetWithRow','applyAsInt$O'],  function (ri) { return (ri.row);});
})()
), Clazz.new_(P$.BitSetTree$Node$lambda1.$init$,[this, null])))))).toArray$();
return rows;
});

Clazz.newMeth(C$, 'collectSuperSetsWithRows$java_util_BitSet$java_util_List$I',  function (bs, supersets, max_supersets) {
if (supersets.size$() >= max_supersets) {
return;
}if (this.isLeaf$()) {
var ts_a1=System.currentTimeMillis$();
var n_leaf_data=this.getLeafData$();
for (var lei, $lei = n_leaf_data.iterator$(); $lei.hasNext$()&&((lei=($lei.next$())),1);) {
var ti=lei.bitset.clone$();
ti.or$java_util_BitSet(bs);
if (ti.equals$O(lei.bitset)) {
supersets.add$O(lei);
}}
var ts_a2=System.currentTimeMillis$();
} else {
if (bs.get$I(this.bit)) {
this.right.collectSuperSetsWithRows$java_util_BitSet$java_util_List$I(bs, supersets, max_supersets);
} else {
this.left.collectSuperSetsWithRows$java_util_BitSet$java_util_List$I(bs, supersets, max_supersets);
this.right.collectSuperSetsWithRows$java_util_BitSet$java_util_List$I(bs, supersets, max_supersets);
}}});

Clazz.newMeth(C$, 'collectSuperSets$java_util_BitSet$java_util_List',  function (bs, supersets) {
if (this.bit < 0) {
var n_leaf_data=this.getLeafData$();
for (var lei, $lei = n_leaf_data.iterator$(); $lei.hasNext$()&&((lei=($lei.next$())),1);) {
var ti=lei.bitset.clone$();
ti.or$java_util_BitSet(bs);
if (ti.equals$O(lei.bitset)) {
supersets.add$O(lei.bitset);
}}
} else {
if (bs.get$I(this.bit)) {
this.right.collectSuperSets$java_util_BitSet$java_util_List(bs, supersets);
} else {
this.left.collectSuperSets$java_util_BitSet$java_util_List(bs, supersets);
this.right.collectSuperSets$java_util_BitSet$java_util_List(bs, supersets);
}}});

Clazz.newMeth(C$, 'checkAllAreSuperset$java_util_BitSet',  function (q) {
if (this.bit < 0) {
var ti=this.bits_1.clone$();
ti.or$java_util_BitSet(q);
var is_superset=ti.equals$O(this.bits_1);
if (is_superset) {
return true;
}is_superset=true;
for (var lei, $lei = this.leaf_data.iterator$(); $lei.hasNext$()&&((lei=($lei.next$())),1);) {
var bi=lei.bitset;
ti=bi.clone$();
ti.or$java_util_BitSet(q);
if (!ti.equals$O(bi)) {
is_superset=false;
break;
}}
return is_superset;
}if (q.get$I(this.bit)) {
if (this.left == null ) {
return true;
}var empty=Clazz.new_([q.size$()],$I$(2,1).c$$I);
if (this.left.getSuperSetIterator$java_util_BitSet(empty).hasNext$()) {
return false;
}return true;
}return this.right.checkAllAreSuperset$java_util_BitSet(q) && this.left.checkAllAreSuperset$java_util_BitSet(q) ;
});

Clazz.newMeth(C$, 'getSuperSetIterator$java_util_BitSet',  function (q) {
return Clazz.new_($I$(3,1).c$$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_BitSet,[this, q]);
});

Clazz.newMeth(C$, 'countAll$',  function () {
if (this.isLeaf$()) {
var n_leaf_data=this.getLeafData$();
return n_leaf_data.size$();
}var ca=(this.left != null ) ? this.left.countAll$() : 0;
var cb=(this.right != null ) ? this.right.countAll$() : 0;
return ca + cb;
});

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.BitSetTree, "SuperSetIterator", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, null, 'java.util.Iterator');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.n=null;
this.q=null;
this.current_iterator=null;
this.current_next=null;
this.remaining_childs=null;
},1);

C$.$fields$=[['O',['n','com.actelion.research.chem.hyperspace.BitSetTree.Node','q','java.util.BitSet','current_iterator','java.util.Iterator','current_next','com.actelion.research.chem.hyperspace.BitSetTree.BitSetWithRow','remaining_childs','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_hyperspace_BitSetTree_Node$java_util_BitSet',  function (n, q) {
;C$.$init$.apply(this);
this.n=n;
this.q=q;
if (!n.isLeaf$()) {
this.remaining_childs=Clazz.new_($I$(1,1));
if (n.left != null ) {
this.remaining_childs.add$O(n.left);
}if (n.right != null ) {
this.remaining_childs.add$O(n.right);
}}}, 1);

Clazz.newMeth(C$, 'hasNext$',  function () {
if (this.current_next == null ) {
p$1.tryToFindNext.apply(this, []);
}return this.current_next != null ;
});

Clazz.newMeth(C$, 'tryToFindNext',  function () {
if (this.current_next != null ) {
return;
}if (this.n.isLeaf$()) {
if (this.current_iterator == null ) {
this.current_iterator=this.n.leaf_data.iterator$();
}while (this.current_iterator.hasNext$()){
var candidate=this.current_iterator.next$();
var ti=candidate.bitset.clone$();
ti.or$java_util_BitSet(this.q);
if (ti.equals$O(candidate.bitset)) {
this.current_next=candidate;
return;
}}
this.current_next=null;
return;
} else {
if (this.current_iterator != null ) {
if (this.current_iterator.hasNext$()) {
this.current_next=this.current_iterator.next$();
return;
} else {
this.current_iterator=null;
}}while (this.current_next == null ){
if (this.current_iterator != null ) {
if (this.current_iterator.hasNext$()) {
this.current_next=this.current_iterator.next$();
return;
} else {
this.current_iterator=null;
}}if (this.current_iterator == null ) {
if (this.remaining_childs.size$() > 0) {
this.current_iterator=this.remaining_childs.remove$I(this.remaining_childs.size$() - 1).getSuperSetIterator$java_util_BitSet(this.q);
} else {
this.current_next=null;
return;
}}if (this.current_iterator.hasNext$()) {
this.current_next=this.current_iterator.next$();
return;
} else {
this.current_next=null;
}}
}}, p$1);

Clazz.newMeth(C$, 'next$',  function () {
var next=this.current_next;
this.current_next=null;
return next;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
