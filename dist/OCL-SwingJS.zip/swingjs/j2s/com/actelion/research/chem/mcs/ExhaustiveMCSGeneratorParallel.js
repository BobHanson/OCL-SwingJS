(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},p$2={},I$=[[0,'com.actelion.research.util.ErrorHashMap','com.actelion.research.chem.IDCodeParser','com.actelion.research.chem.mcs.MCS','java.util.concurrent.atomic.AtomicBoolean','Thread',['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel','.MCSTask'],'com.actelion.research.chem.Canonizer','com.actelion.research.util.datamodel.ByteVec','java.util.ArrayList',['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel','.MCSResult'],'com.actelion.research.util.Pipeline','java.util.concurrent.ConcurrentHashMap','java.util.concurrent.atomic.AtomicLong','Runtime',['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel','.MCSThread'],'java.util.Collections']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExhaustiveMCSGeneratorParallel", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MCSTask',8],['MCSResult',8],['MCSThread',0]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['maxThreads','ringStatus'],'O',['pipeFragByteVec','com.actelion.research.util.Pipeline','hmMCS_MCS','java.util.concurrent.ConcurrentHashMap','liMolByteVec','java.util.ArrayList','ccMCSCalculations','java.util.concurrent.atomic.AtomicLong']]]

Clazz.newMeth(C$, 'c$$I',  function (ringStatus) {
;C$.$init$.apply(this);
this.ringStatus=ringStatus;
this.maxThreads=20;
this.pipeFragByteVec=Clazz.new_($I$(11,1));
this.hmMCS_MCS=Clazz.new_($I$(12,1));
this.liMolByteVec=Clazz.new_($I$(9,1));
this.ccMCSCalculations=Clazz.new_($I$(13,1));
}, 1);

Clazz.newMeth(C$, 'process$java_util_List$java_io_File',  function (liMol, workdir) {
System.out.println$S("MCS process.");
var nProcessors=$I$(14).getRuntime$().availableProcessors$();
var threads=Math.min(nProcessors, this.maxThreads);
System.out.println$S("MCS calculations on " + threads + " processors." );
this.liMolByteVec.clear$();
var cc=0;
for (var mol, $mol = liMol.iterator$(); $mol.hasNext$()&&((mol=($mol.next$())),1);) {
try {
var can=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var idcode=can.getIDCode$();
var bv=Clazz.new_($I$(8,1).c$$S,[idcode]);
this.liMolByteVec.add$O(bv);
this.pipeFragByteVec.addData$O(bv);
++cc;
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$S("Molecule list size " + liMol.size$() + "." );
System.err.println$S("Index molecule " + cc + "." );
e.printStackTrace$();
} else {
throw e;
}
}
}
var liMCSRunnable=Clazz.new_($I$(9,1));
var liMCSThread=Clazz.new_($I$(9,1));
for (var i=0; i < nProcessors; i++) {
var mcsThread=Clazz.new_($I$(15,1).c$$I$I,[this, null, i, this.ringStatus]);
liMCSRunnable.add$O(mcsThread);
var th=Clazz.new_($I$(5,1).c$$Runnable,[mcsThread]);
liMCSThread.add$O(th);
th.start$();
}
System.out.println$S("Calculate MCS from " + liMol.size$() + " molecules." );
var ccCycles=0;
while (!p$2.hasMCSCalculationFinished$java_util_List$java_util_List.apply(this, [liMCSThread, liMCSRunnable])){
try {
$I$(5).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
;++ccCycles;
if (ccCycles % 10 == 0) System.out.println$S("Unique mcs " + this.hmMCS_MCS.size$() + ", queue " + this.pipeFragByteVec.sizePipe$() + "." );
}
var liMolMCS=Clazz.new_($I$(9,1));
var parser=Clazz.new_($I$(2,1).c$$Z,[false]);
var liIdCodeMCS=$I$(16,"list$java_util_Enumeration",[this.hmMCS_MCS.keys$()]);
for (var bvIdCodeMCS, $bvIdCodeMCS = liIdCodeMCS.iterator$(); $bvIdCodeMCS.hasNext$()&&((bvIdCodeMCS=($bvIdCodeMCS.next$())),1);) {
liMolMCS.add$O(parser.getCompactMolecule$S(bvIdCodeMCS.toStringString$()));
}
return liMolMCS;
});

Clazz.newMeth(C$, 'hasMCSCalculationFinished$java_util_List$java_util_List',  function (liThread, liMCSRunnable) {
if (!this.pipeFragByteVec.isEmpty$()) {
return false;
}var calculating=false;
for (var mcsThread, $mcsThread = liMCSRunnable.iterator$(); $mcsThread.hasNext$()&&((mcsThread=($mcsThread.next$())),1);) {
if (mcsThread.isCalculating$()) {
calculating=true;
break;
}}
if (calculating) {
return false;
}var calculated1=this.ccMCSCalculations.get$();
try {
$I$(5).sleep$J(10000);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
var calculated2=this.ccMCSCalculations.get$();
if (Long.$ne(calculated1,calculated2 )) {
return false;
}this.pipeFragByteVec.setAllDataIn$Z(true);
var finished=true;
for (var th, $th = liThread.iterator$(); $th.hasNext$()&&((th=($th.next$())),1);) {
if (th.isAlive$()) {
finished=false;
break;
}}
return finished;
}, p$2);
;
(function(){/*c*/var C$=Clazz.newClass(P$.ExhaustiveMCSGeneratorParallel, "MCSTask", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['bcIdCode1','com.actelion.research.util.datamodel.ByteVec','+bcIdCode2']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_util_datamodel_ByteVec$com_actelion_research_util_datamodel_ByteVec',  function (bcIdCode1, bcIdCode2) {
;C$.$init$.apply(this);
this.bcIdCode1=bcIdCode1;
this.bcIdCode2=bcIdCode2;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask',  function (mcsTask) {
;C$.$init$.apply(this);
this.bcIdCode1=mcsTask.bcIdCode1;
this.bcIdCode2=mcsTask.bcIdCode2;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.ExhaustiveMCSGeneratorParallel, "MCSResult", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, ['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel','.MCSTask']);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['molMCS','com.actelion.research.chem.StereoMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask$com_actelion_research_chem_StereoMolecule',  function (mcsTask, molMCS) {
;C$.superclazz.c$$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask.apply(this,[mcsTask]);C$.$init$.apply(this);
this.molMCS=molMCS;
}, 1);

Clazz.newMeth(C$);
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.ExhaustiveMCSGeneratorParallel, "MCSThread", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexThread','nFailedSimilarityCalculations','added'],'O',['mcs','com.actelion.research.chem.mcs.MCS','idCodeParser','com.actelion.research.chem.IDCodeParser','calculating','java.util.concurrent.atomic.AtomicBoolean','ehm','com.actelion.research.util.ErrorHashMap']]]

Clazz.newMeth(C$, 'c$$I$I',  function (indexThread, ringStatus) {
;C$.$init$.apply(this);
this.indexThread=indexThread;
this.ehm=Clazz.new_($I$(1,1));
this.idCodeParser=Clazz.new_($I$(2,1).c$$Z,[false]);
this.mcs=Clazz.new_($I$(3,1).c$$I,[ringStatus]);
this.calculating=Clazz.new_($I$(4,1));
}, 1);

Clazz.newMeth(C$, 'run$',  function () {
while (!this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].pipeFragByteVec.wereAllDataFetched$()){
var bvFrag=this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].pipeFragByteVec.pollData$();
if (bvFrag == null ) {
this.calculating.set$Z(false);
try {
$I$(5).sleep$J(100);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
continue;
}this.calculating.set$Z(true);
for (var i=0; i < this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].liMolByteVec.size$(); i++) {
var mcsTask=Clazz.new_([this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].liMolByteVec.get$I(i), bvFrag],$I$(6,1).c$$com_actelion_research_util_datamodel_ByteVec$com_actelion_research_util_datamodel_ByteVec);
var liResult=p$1.processMCS$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask.apply(this, [mcsTask]);
for (var mcsResult, $mcsResult = liResult.iterator$(); $mcsResult.hasNext$()&&((mcsResult=($mcsResult.next$())),1);) {
var can=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule,[mcsResult.molMCS]);
var bvMCS=Clazz.new_([can.getIDCode$()],$I$(8,1).c$$S);
if (!this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].hmMCS_MCS.containsKey$O(bvMCS)) {
this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].hmMCS_MCS.put$O$O(bvMCS, bvMCS);
this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].pipeFragByteVec.addData$O(bvMCS);
}}
}
}
});

Clazz.newMeth(C$, 'processMCS$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask',  function (mcsTask) {
var liResult=null;
try {
var mol1=this.idCodeParser.getCompactMolecule$S(mcsTask.bcIdCode1.toStringString$());
var mol2=this.idCodeParser.getCompactMolecule$S(mcsTask.bcIdCode2.toStringString$());
if (mol1.getAtoms$() > mol2.getAtoms$()) {
this.mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol1, mol2);
} else {
this.mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol2, mol1);
}var liMolMCS=this.mcs.getAllCommonSubstructures$();
this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].ccMCSCalculations.incrementAndGet$();
if (liMolMCS == null ) {
liResult=Clazz.new_($I$(9,1));
} else if (!liMolMCS.isEmpty$()) {
liResult=Clazz.new_($I$(9,1));
for (var molMCS, $molMCS = liMolMCS.iterator$(); $molMCS.hasNext$()&&((molMCS=($molMCS.next$())),1);) {
liResult.add$O(Clazz.new_($I$(10,1).c$$com_actelion_research_chem_mcs_ExhaustiveMCSGeneratorParallel_MCSTask$com_actelion_research_chem_StereoMolecule,[mcsTask, molMCS]));
}
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
++this.nFailedSimilarityCalculations;
} else {
throw e;
}
}
return liResult;
}, p$1);

Clazz.newMeth(C$, 'isCalculating$',  function () {
return this.calculating.get$();
});

Clazz.newMeth(C$, 'getEhm$',  function () {
return this.ehm;
});

Clazz.newMeth(C$, 'getAdded$',  function () {
return this.added;
});

Clazz.newMeth(C$, 'getComparisons$',  function () {
return this.b$['com.actelion.research.chem.mcs.ExhaustiveMCSGeneratorParallel'].ccMCSCalculations.get$();
});

Clazz.newMeth(C$, 'getArrFailedSimilarityCalculations$',  function () {
return this.nFailedSimilarityCalculations;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:29 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
