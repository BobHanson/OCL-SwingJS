(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "Searchable");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
