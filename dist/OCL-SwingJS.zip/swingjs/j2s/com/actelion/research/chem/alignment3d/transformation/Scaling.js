(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'java.util.Base64','StringBuilder','com.actelion.research.chem.phesa.EncodeFunctions']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Scaling", null, null, 'com.actelion.research.chem.alignment3d.transformation.Transformation');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['scalingFactor']]]

Clazz.newMeth(C$, 'getScalingFactor$',  function () {
return this.scalingFactor;
});

Clazz.newMeth(C$, 'setScalingFactor$D',  function (scalingFactor) {
this.scalingFactor=scalingFactor;
});

Clazz.newMeth(C$, 'c$$D',  function (scalingFactor) {
;C$.$init$.apply(this);
this.scalingFactor=scalingFactor;
}, 1);

Clazz.newMeth(C$, 'apply$com_actelion_research_chem_Coordinates',  function (coords) {
coords.scale$D(this.scalingFactor);
});

Clazz.newMeth(C$, 'apply$DA',  function (coords) {
coords[0]*=this.scalingFactor;
coords[1]*=this.scalingFactor;
coords[2]*=this.scalingFactor;
});

Clazz.newMeth(C$, 'encode$',  function () {
var encoder=$I$(1).getEncoder$();
var sb=Clazz.new_($I$(2,1));
sb.append$S("s");
sb.append$S(" ");
sb.append$S(encoder.encodeToString$BA($I$(3).doubleToByteArray$D(this.scalingFactor)));
return sb.toString();
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
var scaling=$I$(3,"byteArrayToDouble$BA",[$I$(1).getDecoder$().decode$S(s)]);
return Clazz.new_(C$.c$$D,[scaling]);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:19 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
