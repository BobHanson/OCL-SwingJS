(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureInfo", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.data_=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['data_','java.util.Map']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$S$S$S$F$S',  function (name, id, comment, density, purity) {
;C$.$init$.apply(this);
this.data_.put$O$O("FLD_NAME", name);
this.data_.put$O$O("FLD_ID", id);
this.data_.put$O$O("FLD_CMNT", comment);
if (!java.lang.Float.isNaN$F(density)) this.data_.put$O$O("FLD_DENSITY", Float.toString$F(density));
if (purity != null ) this.data_.put$O$O("FLD_PURITY", purity);
}, 1);

Clazz.newMeth(C$, 'getName$',  function () {
var o=this.data_.get$O("FLD_NAME");
return o != null  ? o.toString() : null;
});

Clazz.newMeth(C$, 'getId$',  function () {
var o=this.data_.get$O("FLD_ID");
return o != null  ? o.toString() : null;
});

Clazz.newMeth(C$, 'getComment$',  function () {
var o=this.data_.get$O("FLD_CMNT");
return o != null  ? o.toString() : null;
});

Clazz.newMeth(C$, 'getDensity$',  function () {
var o=this.data_.get$O("FLD_DENSITY");
return o != null  ? o.toString() : null;
});

Clazz.newMeth(C$, 'getPurity$',  function () {
var o=this.data_.get$O("FLD_PURITY");
return o != null  ? o.toString() : null;
});

Clazz.newMeth(C$, 'setData$S$O',  function (field, data) {
this.data_.put$O$O(field, data);
});

Clazz.newMeth(C$, 'getData$S',  function (field) {
return this.data_.get$O(field);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
