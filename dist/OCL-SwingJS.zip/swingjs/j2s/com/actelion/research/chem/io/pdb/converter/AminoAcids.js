(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),I$=[[0,'com.actelion.research.chem.Molecule3D','java.util.HashMap','com.actelion.research.chem.Coordinates','java.util.TreeMap','com.actelion.research.chem.IDCodeParserWithoutCoordinateInvention']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AminoAcids");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['AA_TEMPLATES','String[][]','sShortLabelMap','java.util.TreeMap']]]

Clazz.newMeth(C$, 'getStructure$S',  function (label) {
return C$.ensureAAMap$().get$O(label.toLowerCase$());
}, 1);

Clazz.newMeth(C$, 'createResidue$S$java_util_List',  function (label, atomRecordList) {
var mol=C$.getStructure$S(label);
if (mol != null ) {
var aminoAcid=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var recordMap=Clazz.new_($I$(2,1));
for (var record, $record = atomRecordList.iterator$(); $record.hasNext$()&&((record=($record.next$())),1);) recordMap.put$O$O(record.getAtomName$(), record);

for (var atom=0; atom < aminoAcid.getAllAtoms$(); atom++) {
var atomName=mol.getAtomLabel$I(atom);
var customLabel=mol.getAtomCustomLabel$I(atom);
if (customLabel != null  && customLabel.startsWith$S("]") ) atomName=atomName.concat$S(customLabel.substring$I(1));
var record=recordMap.get$O(atomName);
if (record != null ) {
var coords3d=Clazz.new_([record.getX$(), record.getY$(), record.getZ$()],$I$(3,1).c$$D$D$D);
aminoAcid.setAtomName$I$S(atom, record.getAtomName$());
aminoAcid.setAtomAmino$I$S(atom, record.getResName$());
aminoAcid.setAtomSequence$I$I(atom, record.getSerialId$());
aminoAcid.setResSequence$I$I(atom, record.getResNum$());
aminoAcid.setAtomAmino$I$S(atom, record.getResName$());
aminoAcid.setAtomChainId$I$S(atom, record.getChainID$());
aminoAcid.setAtomX$I$D(atom, coords3d.x);
aminoAcid.setAtomY$I$D(atom, coords3d.y);
aminoAcid.setAtomZ$I$D(atom, coords3d.z);
}}
;for (var atom=0; atom < aminoAcid.getAllAtoms$(); atom++) if (aminoAcid.getAtomName$I(atom) == null ) aminoAcid.markAtomForDeletion$I(atom);

aminoAcid.deleteMarkedAtomsAndBonds$();
return aminoAcid;
}return null;
}, 1);

Clazz.newMeth(C$, 'ensureAAMap$',  function () {
if (C$.sShortLabelMap == null ) {
C$.sShortLabelMap=Clazz.new_($I$(4,1));
for (var template, $template = 0, $$template = C$.AA_TEMPLATES; $template<$$template.length&&((template=($$template[$template])),1);$template++) {
var mol=Clazz.new_($I$(5,1)).getCompactMolecule$S(template[0]);
mol.setName$S(template[1]);
C$.sShortLabelMap.put$O$O(template[2], mol);
}
}return C$.sShortLabelMap;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.AA_TEMPLATES=Clazz.array(String, -2, [Clazz.array(String, -1, ["gGX`BDdwMULPGzILwXM[jD", "Alanine", "ala"]), Clazz.array(String, -1, ["dctd@BE]ADf{UYjjihp`GzBfMvCS]Plw^OMtbK]hrwUj}tRfwnbXp", "Arginine", "arg"]), Clazz.array(String, -1, ["diEL@BDDyInvZjZL`OtiL[lFfzaYn|^{iFLO]Hi`", "Asparagine", "asn"]), Clazz.array(String, -1, ["diFB@BANEInvZjZLHA~eIc]`twTKMwcw]Hqa{iEL", "Aspartic Acid", "asp"]), Clazz.array(String, -1, ["gNxhMV@aI[jihj@?SHF{ac]PinpP", "Cysteine", "Cys"]), Clazz.array(String, -1, ["defB@BAAeInufjihr@?QdqnpZ[jEf{qyndQ{mFMO]hi`", "Glutamic Acid", "glu"]), Clazz.array(String, -1, ["deeL@BdDEInufjihp`GzLfMvCS]Plw^OMtbO]hqi{mEL", "Glutamine", "gln"]), Clazz.array(String, -1, ["gJX`BDdvu@OtbYnpP", "Glycine", "gly"]), Clazz.array(String, -1, ["dmwD@ByPQInvVUZjejL`OtyL[lFfzaYn|^{iFLO]Hii{mFLo]hi`", "Histidine", "his"]), Clazz.array(String, -1, ["diFD@BADf{ejjdrU@_iRXwXMMuBw]xqn{oELO]Hq`", "Isoleucine", "ile"]), Clazz.array(String, -1, ["diFD@BADf{Yjjhr@?RdqnpZ[jEf{q{ndTp}tcF@", "Leucine", "leu"]), Clazz.array(String, -1, ["deeD@BdDR[mUjjjL`OtYL[lFfzaYn|^[iDV{QenkP", "Lysine", "lys"]), Clazz.array(String, -1, ["diFD`JxPBDivzjihI@?RdAndX[oEF{QqnhR[lD", "Methionine", "met"]), Clazz.array(String, -1, ["dcND@BADf{YU]Zj@@cHC}ASF{AinhV[oGnzQSCwRLZ^{QSKwZL[Vzm@", "Phenylalanine", "phe"]), Clazz.array(String, -1, ["daFD@BADfyVyjjhr@?PdqnpZ[jEfzQyn|P", "Proline", "pro"]), Clazz.array(String, -1, ["gNy`BDtf{ZjfHC}Lf[lFmuBv{q@", "Serine", "ser"]), Clazz.array(String, -1, ["dazL@BAFR[nZjdrT`_hRXwXMMuBw]xqn{oEL", "Threonine", "thr"]), Clazz.array(String, -1, ["foAP`@BZ@aInvYWejsfjiB@bFB@OttfF{AhwTKF{qywRJXW]Hqi]vbfUwZN[W]hqc]uZfmwUnYw]Di`", "Tryptophane", "trp"]), Clazz.array(String, -1, ["dknL@BACR[me]]Zj@BHr@?RTqnpZ[jEf{q{ndTp}tcFgntTr}vcFunkS[hd", "Tyrosine", "tyr"]), Clazz.array(String, -1, ["dazD@BADf{fjjL`OtIL[lFfza[n|Tw]wcF@", "Valine", "val"])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:28 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
