(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ESRGroupNormalizationInfo");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['fragment','action','group','type']]]

Clazz.newMeth(C$, 'c$$I$I$I$I',  function (fragment, action, group, type) {
;C$.$init$.apply(this);
this.fragment=fragment;
this.action=action;
this.group=group;
this.type=type;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:06 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
