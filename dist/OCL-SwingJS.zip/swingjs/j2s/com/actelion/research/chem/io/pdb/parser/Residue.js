(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),p$1={},I$=[[0,'com.actelion.research.chem.io.pdb.converter.AminoAcidsLabeledContainer','java.util.HashMap','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.io.pdb.converter.BondsCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Residue");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isTerminal'],'O',['records','java.util.List','mol','com.actelion.research.chem.Molecule3D']]
,['D',['BOND_CUTOFF_SQ']]]

Clazz.newMeth(C$, 'c$$java_util_List',  function (records) {
;C$.$init$.apply(this);
this.records=records;
this.isTerminal=this.isTerminal$();
this.mol=p$1.constructFragment.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'isTerminal$',  function () {
this.isTerminal=false;
for (var record, $record = this.records.iterator$(); $record.hasNext$()&&((record=($record.next$())),1);) {
if (record.isTerminalC$()) this.isTerminal=true;
}
return this.isTerminal;
});

Clazz.newMeth(C$, 'constructFragment',  function () {
var isAA=false;
if ($I$(1).INSTANCE.get$S(this.getResname$()) != null ) isAA=true;
var fragment;
if (isAA) fragment=p$1.constructFragmentFromIDCode$S.apply(this, [this.getResname$()]);
 else fragment=p$1.constructFragmentFromGeometry$S.apply(this, [this.getResname$()]);
fragment.ensureHelperArrays$I(1);
return fragment;
}, p$1);

Clazz.newMeth(C$, 'constructFragmentFromIDCode$S',  function (resname) {
var fragment;
var recordMap=Clazz.new_($I$(2,1));
for (var record, $record = this.records.iterator$(); $record.hasNext$()&&((record=($record.next$())),1);) {
var atomName=record.getAtomName$();
recordMap.put$O$O(atomName, record);
}
fragment=$I$(1).INSTANCE.get$S(resname).createResidue$java_util_Map(recordMap);
if (fragment == null ) {
fragment=p$1.constructFragmentFromGeometry$S.apply(this, [resname]);
}return fragment;
}, p$1);

Clazz.newMeth(C$, 'constructFragmentFromGeometry$S',  function (resname) {
var fragment=Clazz.new_($I$(3,1));
for (var record, $record = this.records.iterator$(); $record.hasNext$()&&((record=($record.next$())),1);) {
var atomicNo=record.getAtomicNo$();
var atom=fragment.addAtom$I(atomicNo);
fragment.setAtomName$I$S(atom, record.getAtomName$());
fragment.setAtomAmino$I$S(atom, record.getResName$());
fragment.setAtomSequence$I$I(atom, record.getSerialId$());
fragment.setResSequence$I$I(atom, record.getResNum$());
fragment.setAtomAmino$I$S(atom, record.getResName$());
fragment.setAtomChainId$I$S(atom, record.getChainID$());
fragment.setAtomX$I$D(atom, record.getX$());
fragment.setAtomY$I$D(atom, record.getY$());
fragment.setAtomZ$I$D(atom, record.getZ$());
}
fragment.ensureHelperArrays$I(31);
try {
$I$(4).createBonds$com_actelion_research_chem_StereoMolecule$Z$java_util_Map(fragment, true, null);
$I$(4).calculateBondOrders$com_actelion_research_chem_StereoMolecule$Z(fragment, true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.err.println$();
} else {
throw e;
}
}
return fragment;
}, p$1);

Clazz.newMeth(C$, 'getResnum$',  function () {
return this.records.get$I(0).getResNum$();
});

Clazz.newMeth(C$, 'getMolecule$',  function () {
return this.mol;
});

Clazz.newMeth(C$, 'getResname$',  function () {
return this.records.get$I(0).getResName$();
});

Clazz.newMeth(C$, 'getChainID$',  function () {
return this.records.get$I(0).getChainID$();
});

Clazz.newMeth(C$, 'getInsertionCode$',  function () {
return this.records.get$I(0).getInsertionCode$();
});

Clazz.newMeth(C$, 'areBonded$com_actelion_research_chem_io_pdb_parser_Residue',  function (resN) {
var recordC=null;
var recordN=null;
var areBonded=false;
for (var rec, $rec = this.records.iterator$(); $rec.hasNext$()&&((rec=($rec.next$())),1);) {
if (rec.getAtomName$().equals$O("C")) {
recordN=rec;
break;
}}
for (var rec, $rec = resN.records.iterator$(); $rec.hasNext$()&&((rec=($rec.next$())),1);) {
if (rec.getAtomName$().equals$O("N")) {
recordC=rec;
break;
}}
if (recordN != null  && recordC != null  ) {
var dx=recordN.getX$() - recordC.getX$();
var dy=recordN.getY$() - recordC.getY$();
var dz=recordN.getZ$() - recordC.getZ$();
var distSq=dx * dx + dy * dy + dz * dz;
if (distSq < C$.BOND_CUTOFF_SQ ) areBonded=true;
}return areBonded;
});

C$.$static$=function(){C$.$static$=0;
C$.BOND_CUTOFF_SQ=3.24;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:41 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
