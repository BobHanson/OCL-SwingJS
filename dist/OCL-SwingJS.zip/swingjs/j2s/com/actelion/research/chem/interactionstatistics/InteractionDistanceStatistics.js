(function(){var P$=Clazz.newPackage("com.actelion.research.chem.interactionstatistics"),p$1={},I$=[[0,'java.util.HashSet','java.util.ArrayList','java.util.concurrent.ConcurrentHashMap',['com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','.AtomFlagCount'],['com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','.AtomPropertyMask'],'java.io.BufferedWriter','java.io.OutputStreamWriter','java.io.FileOutputStream','java.nio.charset.StandardCharsets','java.io.BufferedReader','java.io.InputStreamReader','java.util.HashMap','com.actelion.research.chem.interactionstatistics.SplineFunction','java.util.stream.Collectors','java.util.concurrent.atomic.AtomicInteger','java.util.stream.IntStream','java.util.Arrays','com.actelion.research.util.SmoothingSplineInterpolator']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['pairPotentials','java.util.Map','+interactionStatistics']]
,['O',['instance','com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics']]]

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.instance == null ) {
{
if (C$.instance == null ) {
C$.instance=Clazz.new_(C$);
}}}return C$.instance;
}, 1);

Clazz.newMeth(C$, 'getInteractionClasses$',  function () {
return this.pairPotentials.keySet$().size$();
});

Clazz.newMeth(C$, 'getPairPotentials$',  function () {
return this.pairPotentials;
});

Clazz.newMeth(C$, 'getAtomTypes$',  function () {
var hs=Clazz.new_($I$(1,1));
for (var pair, $pair = this.pairPotentials.keySet$().iterator$(); $pair.hasNext$()&&((pair=($pair.next$()).objectValue$()),1);) {
var a=p$1.splitLongToInts$J.apply(this, [pair]);
hs.add$O(Integer.valueOf$I(a[0]));
hs.add$O(Integer.valueOf$I(a[1]));
}
return Clazz.new_($I$(2,1).c$$java_util_Collection,[hs]);
});

Clazz.newMeth(C$, 'getAtomKeySet$',  function () {
var atomKeySet=Clazz.new_($I$(1,1));
for (var l, $l = this.pairPotentials.keySet$().iterator$(); $l.hasNext$()&&((l=($l.next$()).objectValue$()),1);) {
var pair=p$1.splitLongToInts$J.apply(this, [l]);
var a=this.getKey$I(pair[0]);
var b=this.getKey$I(pair[1]);
atomKeySet.add$O(Integer.valueOf$I(a));
atomKeySet.add$O(Integer.valueOf$I(b));
}
return atomKeySet;
});

Clazz.newMeth(C$, 'calculatePotentials',  function () {
p$1.splineCalculation.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.interactionStatistics=Clazz.new_($I$(3,1));
p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initialize',  function () {
try {
this.readFromFile$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
e.printStackTrace$();
} else {
throw e;
}
}
p$1.calculatePotentials.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'combineIntsToLong$I$I',  function (a, b) {
var a1;
var a2;
if (a < b) {
a1=a;
a2=b;
} else {
a1=b;
a2=a;
}var l=(Long.$or((Long.$sl(a1,32)),a2));
return l;
});

Clazz.newMeth(C$, 'splitLongToInts$J',  function (l) {
var a=Long.$ival((Long.$sr(l,32)));
var b=Long.$ival(l);
return Clazz.array(Integer.TYPE, -1, [a, b]);
}, p$1);

Clazz.newMeth(C$, 'isGenericAtomPair$I$I',  function (a, b) {
return (p$1.isGenericAtomType$I.apply(this, [a]) && p$1.isGenericAtomType$I.apply(this, [b]) );
}, p$1);

Clazz.newMeth(C$, 'isGenericAtomType$I',  function (a) {
return Integer.toBinaryString$I(a).length$() <= $I$(4).BASIC_ATOM_FLAG_COUNT.getCount$();
}, p$1);

Clazz.newMeth(C$, 'isSpecificAtomType$I',  function (a) {
return Integer.toBinaryString$I(a).length$() <= $I$(4).FUNC_GROUP_FLAG_COUNT.getCount$();
}, p$1);

Clazz.newMeth(C$, 'getKey$I',  function (atomType) {
if (p$1.isSpecificAtomType$I.apply(this, [atomType])) {
return (atomType & $I$(5).SPECIFIC.getMask$());
} else return atomType;
});

Clazz.newMeth(C$, 'isGenericAtomPair$J',  function (l) {
var pair=p$1.splitLongToInts$J.apply(this, [l]);
return p$1.isGenericAtomPair$I$I.apply(this, [pair[0], pair[1]]);
}, p$1);

Clazz.newMeth(C$, 'addInteraction$I$I$D',  function (atom1, atom2, dist) {
if (dist >= 6.0 ) return;
var l=this.combineIntsToLong$I$I(atom1, atom2);
this.interactionStatistics.putIfAbsent$O$O(Long.valueOf$J(l), Clazz.array(Integer.TYPE, [30]));
var index=((0.5 + dist / 0.2)|0);
var occurences=this.interactionStatistics.get$O(Long.valueOf$J(l));
if (index < occurences.length) ++occurences[index];
});

Clazz.newMeth(C$, 'write$S',  function (file) {
var writer=Clazz.new_([Clazz.new_([Clazz.new_($I$(8,1).c$$S,[file]), $I$(9).UTF_8],$I$(7,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(6,1).c$$java_io_Writer);
for (var l, $l = this.interactionStatistics.keySet$().iterator$(); $l.hasNext$()&&((l=($l.next$()).objectValue$()),1);) {
var occurences=this.interactionStatistics.get$O(Long.valueOf$J(l));
writer.write$S(Long.toString$J(l));
for (var index=0; index < occurences.length; index++) {
writer.write$S(" " + occurences[index]);
}
writer.write$S(System.getProperty$S("line.separator"));
}
writer.write$S(System.getProperty$S("line.separator"));
writer.close$();
});

Clazz.newMeth(C$, 'readFromFile$',  function () {
try {
var file="/resources/interactionstatistics/InteractionStatistics.txt";
var url=Clazz.getClass(C$).getResource$S(file);
if (url == null ) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Could not find the interactions parameter file in the classpath: " + file]);
}var is=url.openStream$();
var reader=Clazz.new_([Clazz.new_([is, $I$(9).UTF_8],$I$(11,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(10,1).c$$java_io_Reader);
var line;
while ((line=reader.readLine$()) != null  && !line.isEmpty$() ){
var s=line.split$S(" ");
var l=Long.parseLong$S(s[0]);
var occurences=Clazz.array(Integer.TYPE, [30]);
for (var i=1; i < s.length; i++) {
occurences[i - 1]=Integer.parseInt$S(s[i]);
}
this.interactionStatistics.putIfAbsent$O$O(Long.valueOf$J(l), occurences);
}
reader.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'splineCalculation',  function () {
this.pairPotentials=Clazz.new_($I$(12,1));
var referenceSum=Clazz.array(Double.TYPE, [30]);
this.interactionStatistics.entrySet$().stream$().forEach$java_util_function_Consumer(((P$.InteractionDistanceStatistics$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map_Entry','accept$O'],  function (e) {
var potential=Clazz.new_($I$(13,1));
potential.setOccurencesArray$IA.apply(potential, [e.getValue$.apply(e, [])]);
this.b$['com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics'].pairPotentials.putIfAbsent$O$O.apply(this.b$['com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics'].pairPotentials, [e.getKey$.apply(e, []), potential]);
});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda1.$init$,[this, null])));
var discreteFunctions=this.interactionStatistics.entrySet$().stream$().collect$java_util_stream_Collector($I$(14,"toMap$java_util_function_Function$java_util_function_Function",[((P$.InteractionDistanceStatistics$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (e.getKey$.apply(e, []));});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda2.$init$,[this, null])), ((P$.InteractionDistanceStatistics$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (p$1.distanceNormalization$IA.apply(this.b$['com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics'], [e.getValue$.apply(e, [])]));});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda3.$init$,[this, null]))]));
var runCount=Clazz.new_($I$(15,1).c$$I,[0]);
discreteFunctions.entrySet$().stream$().filter$java_util_function_Predicate(((P$.InteractionDistanceStatistics$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$java_util_Map_Entry','test$O'],  function (e) { return (p$1.isGenericAtomPair$J.apply(this.b$['com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics'], [(e.getKey$.apply(e, [])).valueOf()]));});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda4.$init$,[this, null]))).forEach$java_util_function_Consumer(((P$.InteractionDistanceStatistics$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map_Entry','accept$O'],  function (statistics) {
this.$finals$.runCount.getAndIncrement$.apply(this.$finals$.runCount, []);
$I$(16,"range$I$I",[0, statistics.getValue$.apply(statistics, []).length]).forEach$java_util_function_IntConsumer.apply($I$(16,"range$I$I",[0, statistics.getValue$.apply(statistics, []).length]), [((P$.InteractionDistanceStatistics$lambda5$6||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda5$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) {
this.$finals$.referenceSum[i]+=this.$finals$.statistics.getValue$.apply(this.$finals$.statistics, [])[i];
});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda5$6.$init$,[this, {referenceSum:this.$finals$.referenceSum,statistics:statistics}]))]);
});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda5.$init$,[this, {runCount:runCount,referenceSum:referenceSum}])));
for (var i=0; i < referenceSum.length; i++) {
referenceSum[i]/=runCount.get$();
}
discreteFunctions.replaceAll$java_util_function_BiFunction(((P$.InteractionDistanceStatistics$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$Long$DA','apply$O$O'],  function (k, v) { return (p$1.normalize$DA$DA.apply(this.b$['com.actelion.research.chem.interactionstatistics.InteractionDistanceStatistics'], [v, this.$finals$.referenceSum]));});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda6.$init$,[this, {referenceSum:referenceSum}])));
var X=Clazz.array(Double.TYPE, [referenceSum.length]);
$I$(16).range$I$I(0, X.length).forEach$java_util_function_IntConsumer(((P$.InteractionDistanceStatistics$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.X[i]=(i + 0.5) * 0.2);});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda7.$init$,[this, {X:X}])));
for (var l, $l = discreteFunctions.keySet$().iterator$(); $l.hasNext$()&&((l=($l.next$()).objectValue$()),1);) {
var sigma=Clazz.array(Double.TYPE, [X.length]);
$I$(17).fill$DA$D(sigma, 1);
var interpolator=Clazz.new_($I$(18,1));
interpolator.setLambda$D(0.005);
interpolator.setSigma$DA(sigma);
var ff=interpolator.interpolate$DA$DA(X, discreteFunctions.get$O(Long.valueOf$J(l)));
var Y=Clazz.array(Double.TYPE, [X.length]);
for (var i=0; i < X.length; i++) {
try {
Y[i]=ff.value$D(X[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
Y[i]=0;
} else {
throw e;
}
}
}
var globalMinIndex=-1;
var firstMaxIndex=-1;
for (var i=1; i < Y.length - 1; i++) {
if (Y[i - 1] < Y[i]  && Y[i + 1] < Y[i]  ) {
if (firstMaxIndex == -1) {
firstMaxIndex=i;
}} else if (Y[i - 1] > Y[i]  && Y[i + 1] > Y[i]  ) {
if (globalMinIndex == -1) globalMinIndex=i;
 else if (Y[i] < Y[globalMinIndex] ) globalMinIndex=i;
}}
if (firstMaxIndex >= 0 && firstMaxIndex < globalMinIndex ) {
var derivative=10.0 / (firstMaxIndex * 0.2);
var i=firstMaxIndex - 1;
while (i >= 0){
Y[i]=Y[i + 1] + derivative * 0.2;
--i;
}
ff=interpolator.interpolate$DA$DA(X, Y);
}var potential=this.pairPotentials.get$O(Long.valueOf$J(l));
potential.setSplineFunction$com_actelion_research_util_FastSpline(ff);
potential.setDiscreteFunction$DA(discreteFunctions.get$O(Long.valueOf$J(l)));
}
}, p$1);

Clazz.newMeth(C$, 'normalize$DA$DA',  function (arr, reference) {
$I$(16).range$I$I(0, arr.length).forEach$java_util_function_IntConsumer(((P$.InteractionDistanceStatistics$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "InteractionDistanceStatistics$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.arr[i]=-Math.log((this.$finals$.arr[i] + 1.0E-4) / (this.$finals$.reference[i] + 1.0E-4)));});
})()
), Clazz.new_(P$.InteractionDistanceStatistics$lambda8.$init$,[this, {reference:reference,arr:arr}])));
return arr;
}, p$1);

Clazz.newMeth(C$, 'distanceNormalization$IA',  function (Y) {
var YNorm=Clazz.array(Double.TYPE, [Y.length]);
var normalizedSum=0;
for (var index=0; index < Y.length; index++) {
var v=4.1887902047863905 * (Math.pow(0.2 * (index + 0.5), 3) - Math.pow(0.2 * (index - 0.5), 3));
normalizedSum+=Y[index] / v;
}
if (normalizedSum == 0 ) return YNorm;
for (var index=0; index < Y.length; index++) {
var v=4.1887902047863905 * (Math.pow(0.2 * (index + 0.5), 3) - Math.pow(0.2 * (index - 0.5), 3));
YNorm[index]=(Y[index]) / (v * normalizedSum);
}
return YNorm;
}, p$1);

Clazz.newMeth(C$, 'getFunction$J',  function (l) {
return this.pairPotentials.get$O(Long.valueOf$J(l));
});

Clazz.newMeth(C$, 'getFunction$I$I',  function (a, b) {
var spline;
var a1=a & $I$(5).SPECIFIC.getMask$();
var b1=b & $I$(5).SPECIFIC.getMask$();
var l=this.combineIntsToLong$I$I(a1, b1);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
var a2=a & $I$(5).EXTENDED.getMask$();
var b2=b & $I$(5).EXTENDED.getMask$();
l=this.combineIntsToLong$I$I(a1, b2);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a2, b1);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a2, b2);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
var a3=a & $I$(5).BASIC.getMask$();
var b3=b & $I$(5).BASIC.getMask$();
l=this.combineIntsToLong$I$I(a3, b1);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a1, b3);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a3, b2);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a2, b3);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
if (spline != null  && spline.getTotalOccurences$() > 500.0  ) return spline;
l=this.combineIntsToLong$I$I(a3, b3);
spline=this.pairPotentials.get$O(Long.valueOf$J(l));
return spline;
});

C$.$static$=function(){C$.$static$=0;
C$.instance=Clazz.new_(C$);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
