(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','java.util.stream.Collectors','com.actelion.research.chem.io.pdb.parser.AtomRecord','com.actelion.research.chem.io.pdb.parser.Residue','com.actelion.research.chem.io.pdb.parser.ProteinSynthesizer','com.actelion.research.chem.io.pdb.converter.BondsCalculator','java.util.TreeMap']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureAssembler");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['detachCovalentLigands'],'O',['groups','java.util.Map','bondList','com.actelion.research.util.SortedList','protAtomRecords','java.util.List','+hetAtomRecords','mols','java.util.Map']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_util_SortedList$java_util_List$java_util_List',  function (bondList, protAtomRecords, hetAtomRecords) {
;C$.$init$.apply(this);
this.bondList=bondList;
this.protAtomRecords=protAtomRecords;
this.hetAtomRecords=hetAtomRecords;
}, 1);

Clazz.newMeth(C$, 'setDetachCovalentLigands$Z',  function (b) {
this.detachCovalentLigands=b;
});

Clazz.newMeth(C$, 'assemble$',  function () {
this.groups=Clazz.new_($I$(1,1));
this.mols=Clazz.new_($I$(1,1));
p$1.group.apply(this, []);
var protMols=Clazz.new_($I$(2,1));
this.mols.putIfAbsent$O$O("water", Clazz.new_($I$(2,1)));
this.mols.putIfAbsent$O$O("ligand", Clazz.new_($I$(2,1)));
protMols.add$O(p$1.buildProtein.apply(this, []));
this.mols.put$O$O("protein", protMols);
p$1.buildHetResidues.apply(this, []);
this.mols.forEach$java_util_function_BiConsumer(((P$.StructureAssembler$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (k, v) { return (v.forEach$java_util_function_Consumer.apply(v, [((P$.StructureAssembler$lambda1$2||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda1$2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_Molecule3D','accept$O'],  function (e) { return (p$1.coupleBonds$com_actelion_research_chem_Molecule3D.apply(this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'], [e]));});
})()
), Clazz.new_(P$.StructureAssembler$lambda1$2.$init$,[this, null]))]));});
})()
), Clazz.new_(P$.StructureAssembler$lambda1.$init$,[this, null])));
return this.mols;
});

Clazz.newMeth(C$, 'group',  function () {
this.groups.put$O$O("protein", Clazz.new_($I$(2,1).c$$java_util_Collection,[this.protAtomRecords]));
this.hetAtomRecords.forEach$java_util_function_Consumer(((P$.StructureAssembler$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_io_pdb_parser_AtomRecord','accept$O'],  function (e) {
var li=this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'].groups.computeIfAbsent$O$java_util_function_Function.apply(this.b$['com.actelion.research.chem.io.pdb.parser.StructureAssembler'].groups, [e.getString$.apply(e, []), (P$.StructureAssembler$lambda2$3$||(P$.StructureAssembler$lambda2$3$=(((P$.StructureAssembler$lambda2$3||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda2$3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$S','apply$O'],  function (k) { return (Clazz.new_($I$(2,1)));});
})()
), Clazz.new_(P$.StructureAssembler$lambda2$3.$init$,[this, null])))))]);
li.add$O.apply(li, [e]);
});
})()
), Clazz.new_(P$.StructureAssembler$lambda2.$init$,[this, null])));
for (var i=0; i < this.bondList.size$(); i++) p$1.processBond$IA.apply(this, [this.bondList.get$I(i)]);

}, p$1);

Clazz.newMeth(C$, 'buildProtein',  function () {
var proteinRecords=this.groups.get$O("protein");
var residues_=proteinRecords.stream$().collect$java_util_stream_Collector($I$(3,"groupingBy$java_util_function_Function",[(function($$){((
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_M*/
Clazz.newMeth(C$, 'apply$O',  function (t) { return t.getString$.apply(t,[])});
})()
)); return Clazz.new_(P$.StructureAssembler$lambda3.$init$,[this, null])})($I$(4))]));
var residues=residues_.values$().stream$().map$java_util_function_Function((P$.StructureAssembler$lambda4$||(P$.StructureAssembler$lambda4$=(((P$.StructureAssembler$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_List','apply$O'],  function (v) { return (Clazz.new_($I$(5,1).c$$java_util_List$Z$Z,[v, true, false]));});
})()
), Clazz.new_(P$.StructureAssembler$lambda4.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(3).toList$());
residues.sort$java_util_Comparator(((P$.StructureAssembler$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['compare$com_actelion_research_chem_io_pdb_parser_Residue$com_actelion_research_chem_io_pdb_parser_Residue','compare$O$O'],  function (c1, c2) {
if (!c1.getChainID$.apply(c1, []).equals$O.apply(c1.getChainID$.apply(c1, []), [c2.getChainID$.apply(c2, [])])) return c1.getChainID$.apply(c1, []).compareTo$S.apply(c1.getChainID$.apply(c1, []), [c2.getChainID$.apply(c2, [])]);
 else {
if (c1.getResnum$.apply(c1, []) != c2.getResnum$.apply(c2, [])) return Integer.compare$I$I(c1.getResnum$.apply(c1, []), c2.getResnum$.apply(c2, []));
 else {
return c1.getInsertionCode$.apply(c1, []).compareTo$S.apply(c1.getInsertionCode$.apply(c1, []), [c2.getInsertionCode$.apply(c2, [])]);
}}});
})()
), Clazz.new_(P$.StructureAssembler$lambda5.$init$,[this, null])));
var proteinSynthesizer=Clazz.new_($I$(6,1));
var protMols=Clazz.new_($I$(2,1));
for (var residue, $residue = residues.iterator$(); $residue.hasNext$()&&((residue=($residue.next$())),1);) {
var fragment=residue.getMolecule$();
if (fragment.getAtomAmino$I(0).trim$().equals$O("ACT") || fragment.getAtomAmino$I(0).trim$().equals$O("LIG") ) {
this.mols.get$O("ligand").add$O(fragment);
continue;
} else if (fragment.getAtomAmino$I(0).trim$().equals$O("HOH")) {
this.mols.get$O("water").add$O(fragment);
continue;
}if (proteinSynthesizer.addResidue$com_actelion_research_chem_Molecule3D(fragment)) {
if (residue.isTerminal$()) {
protMols.add$O(proteinSynthesizer.getProtein$());
proteinSynthesizer=Clazz.new_($I$(6,1));
}} else {
protMols.add$O(proteinSynthesizer.getProtein$());
proteinSynthesizer=Clazz.new_($I$(6,1));
proteinSynthesizer.addResidue$com_actelion_research_chem_Molecule3D(fragment);
}}
var nextMol=proteinSynthesizer.getProtein$();
if (nextMol != null  && !protMols.contains$O(nextMol) ) protMols.add$O(nextMol);
var protein=protMols.stream$().reduce$java_util_function_BinaryOperator(((P$.StructureAssembler$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BinaryOperator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_Molecule3D$com_actelion_research_chem_Molecule3D','apply$O$O'],  function (mol1, mol2) {
mol1.addMolecule$com_actelion_research_chem_Molecule.apply(mol1, [mol2]);
return mol1;
});
})()
), Clazz.new_(P$.StructureAssembler$lambda6.$init$,[this, null]))).get$();
return protein;
}, p$1);

Clazz.newMeth(C$, 'buildHetResidues',  function () {
for (var group, $group = this.groups.keySet$().iterator$(); $group.hasNext$()&&((group=($group.next$())),1);) {
if (!group.equals$O("protein")) {
var records=this.groups.get$O(group);
var atomGroup=Clazz.new_($I$(5,1).c$$java_util_List$Z$Z,[records, false, false]);
var fragment=atomGroup.getMolecule$();
if (fragment.getAtomAmino$I(0).equals$O("HOH")) {
this.mols.putIfAbsent$O$O("water", Clazz.new_($I$(2,1)));
this.mols.get$O("water").add$O(fragment);
} else {
this.mols.putIfAbsent$O$O("ligand", Clazz.new_($I$(2,1)));
this.mols.get$O("ligand").add$O(fragment);
}}}
}, p$1);

Clazz.newMeth(C$, 'coupleBonds$com_actelion_research_chem_Molecule3D',  function (mol) {
if (this.bondList.size$() == 0) {
if (mol.getAllAtoms$() > 1) {
try {
$I$(7).createBonds$com_actelion_research_chem_StereoMolecule$Z$java_util_Map(mol, true, null);
$I$(7).calculateBondOrders$com_actelion_research_chem_StereoMolecule$Z(mol, true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}} else {
var sequenceToAtomMap=Clazz.new_($I$(8,1));
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
var sequence=mol.getAtomSequence$I(atom);
if (sequence != -1) sequenceToAtomMap.put$O$O(Integer.valueOf$I(sequence), Integer.valueOf$I(atom));
}
for (var i=0; i < this.bondList.size$(); i++) {
var bond=this.bondList.get$I(i);
var atom1=sequenceToAtomMap.get$O(Integer.valueOf$I(bond[0]));
var atom2=sequenceToAtomMap.get$O(Integer.valueOf$I(bond[1]));
if (atom1 != null  && atom2 != null  ) mol.addBond$I$I((atom1).$c(), (atom2).$c());
}
try {
if (mol.getAllBonds$() == 0) $I$(7).createBonds$com_actelion_research_chem_StereoMolecule$Z$java_util_Map(mol, true, null);
$I$(7).calculateBondOrders$com_actelion_research_chem_StereoMolecule$Z(mol, true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}}, p$1);

Clazz.newMeth(C$, 'processBond$IA',  function (bond) {
var atom1=bond[0];
var atom2=bond[1];
var grps=Clazz.array(String, [2]);
this.groups.forEach$java_util_function_BiConsumer(((P$.StructureAssembler$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$S$java_util_List','accept$O$O'],  function (k, v) {
var atoms=v.stream$.apply(v, []).map$java_util_function_Function.apply(v.stream$.apply(v, []), [((P$.StructureAssembler$lambda7$8||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda7$8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_io_pdb_parser_AtomRecord','apply$O'],  function (e) { return (e.getSerialId$.apply(e, []));});
})()
), Clazz.new_(P$.StructureAssembler$lambda7$8.$init$,[this, null]))]).collect$java_util_stream_Collector.apply(v.stream$.apply(v, []).map$java_util_function_Function.apply(v.stream$.apply(v, []), [((P$.StructureAssembler$lambda7$9||
(function(){/*m*/var C$=Clazz.newClass(P$, "StructureAssembler$lambda7$9", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_io_pdb_parser_AtomRecord','apply$O'],  function (e) { return (e.getSerialId$.apply(e, []));});
})()
), Clazz.new_(P$.StructureAssembler$lambda7$9.$init$,[this, null]))]), [$I$(3).toList$()]);
if (atoms.contains$O.apply(atoms, [Integer.valueOf$I(this.$finals$.atom1)])) this.$finals$.grps[0]=k;
if (atoms.contains$O.apply(atoms, [Integer.valueOf$I(this.$finals$.atom2)])) this.$finals$.grps[1]=k;
});
})()
), Clazz.new_(P$.StructureAssembler$lambda7.$init$,[this, {grps:grps,atom1:atom1,atom2:atom2}])));
if (!grps[0].equals$O(grps[1])) {
if (grps[0].equals$O("protein")) {
if (!this.detachCovalentLigands) {
this.groups.get$O(grps[0]).addAll$java_util_Collection(this.groups.get$O(grps[1]));
this.groups.remove$O(grps[1]);
}} else if (grps[1].equals$O("protein")) {
if (!this.detachCovalentLigands) {
this.groups.get$O(grps[1]).addAll$java_util_Collection(this.groups.get$O(grps[0]));
this.groups.remove$O(grps[0]);
}} else {
this.groups.get$O(grps[0]).addAll$java_util_Collection(this.groups.get$O(grps[1]));
this.groups.remove$O(grps[1]);
}}}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:43 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
