(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.shape"),I$=[[0,'com.actelion.research.chem.phesa.DescriptorHandlerShape',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.PheSASetting'],'com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer',['com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer','.SimilarityMode'],'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ShapeDocking");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['transformation','com.actelion.research.chem.alignment3d.transformation.Transformation','negRecImage','com.actelion.research.chem.phesa.ShapeVolume','dhs','com.actelion.research.chem.phesa.DescriptorHandlerShape','threadMaster','com.actelion.research.calc.ThreadMaster','phesaSetting','com.actelion.research.chem.alignment3d.PheSAAlignmentOptimizer.PheSASetting']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_phesa_ShapeVolume$com_actelion_research_chem_alignment3d_transformation_Transformation',  function (negRecImage, transformation) {
;C$.$init$.apply(this);
this.negRecImage=negRecImage;
this.transformation=transformation;
this.dhs=Clazz.new_($I$(1,1).c$$I$D,[500, 0.5]);
this.phesaSetting=Clazz.new_($I$(2,1));
this.phesaSetting.setNrOptimizationsPMI$I(2 * $I$(3).PMI_OPTIMIZATIONS);
this.phesaSetting.setNrOptimizationsTriangle$I(2 * $I$(3).TRIANGLE_OPTIMIZATIONS);
this.phesaSetting.setUseDirectionality$Z(false);
this.phesaSetting.setSimMode$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_SimilarityMode($I$(4).TVERSKY);
}, 1);

Clazz.newMeth(C$, 'getPhesaSetting$',  function () {
return this.phesaSetting;
});

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (tm) {
this.threadMaster=tm;
});

Clazz.newMeth(C$, 'dock$com_actelion_research_chem_StereoMolecule',  function (candidate) {
var aligned=Clazz.new_($I$(5,1));
var candidateShape=this.dhs.createDescriptor$com_actelion_research_chem_StereoMolecule(candidate);
var results=$I$(3,"alignToNegRecImg$com_actelion_research_chem_phesa_ShapeVolume$java_util_List$com_actelion_research_chem_alignment3d_PheSAAlignmentOptimizer_PheSASetting",[this.negRecImage, candidateShape.getVolumes$(), this.phesaSetting]);
for (var result, $result = results.iterator$(); $result.hasNext$()&&((result=($result.next$())),1);) {
if (result.getSimilarity$() == 0.0 ) {
return aligned;
}var alignedMol=candidateShape.getConformer$com_actelion_research_chem_phesa_MolecularVolume(candidateShape.getVolumes$().get$I(result.getConformerIndex$()));
result.getTransform$().apply$com_actelion_research_chem_StereoMolecule(alignedMol);
this.transformation.apply$com_actelion_research_chem_StereoMolecule(alignedMol);
aligned.add$O(alignedMol);
}
return aligned;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:52 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
