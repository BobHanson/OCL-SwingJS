(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'java.util.HashMap','StringBuilder',['java.util.AbstractMap','.SimpleEntry'],'java.util.regex.Pattern']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RemarkParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['indexLine'],'O',['hmNo_Remark','java.util.HashMap']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'parse$java_util_List$I',  function (liRaw, indexLine) {
this.indexLine=indexLine;
this.hmNo_Remark=Clazz.new_($I$(1,1));
var ccRemark=0;
if (C$.getMatcherRemark$I$S(ccRemark, liRaw.get$I(indexLine)).find$()) {
var siIndex=C$.parseRemark$java_util_List$I$I(liRaw, indexLine, ccRemark);
this.hmNo_Remark.put$O$O(Integer.valueOf$I(ccRemark), siIndex.getKey$());
indexLine=(siIndex.getValue$()).$c();
}++ccRemark;
if (C$.getMatcherRemark$I$S(ccRemark, liRaw.get$I(indexLine)).find$()) {
var siIndex=C$.parseRemark$java_util_List$I$I(liRaw, indexLine, ccRemark);
this.hmNo_Remark.put$O$O(Integer.valueOf$I(ccRemark), siIndex.getKey$());
indexLine=(siIndex.getValue$()).$c();
}++ccRemark;
if (C$.getMatcherRemark$I$S(ccRemark, liRaw.get$I(indexLine)).find$()) {
var siIndex=C$.parseRemark$java_util_List$I$I(liRaw, indexLine, ccRemark);
this.hmNo_Remark.put$O$O(Integer.valueOf$I(ccRemark), siIndex.getKey$());
indexLine=(siIndex.getValue$()).$c();
}++ccRemark;
if (C$.getMatcherRemark$I$S(ccRemark, liRaw.get$I(indexLine)).find$()) {
var siIndex=C$.parseRemark$java_util_List$I$I(liRaw, indexLine, ccRemark);
this.hmNo_Remark.put$O$O(Integer.valueOf$I(ccRemark), siIndex.getKey$());
indexLine=(siIndex.getValue$()).$c();
}var p=C$.getPatternRemark$();
var searchRemarks=true;
while (searchRemarks){
var line=liRaw.get$I(indexLine);
var matcher=p.matcher$CharSequence(line);
if (matcher.find$()) {
var arr=line.split$S("[ ]+");
ccRemark=Integer.parseInt$S(arr[1]);
var siIndex=C$.parseRemark$java_util_List$I$I(liRaw, indexLine, ccRemark);
this.hmNo_Remark.put$O$O(Integer.valueOf$I(ccRemark), siIndex.getKey$());
indexLine=(siIndex.getValue$()).$c();
} else {
searchRemarks=false;
}}
this.indexLine=indexLine;
});

Clazz.newMeth(C$, 'getIndexLine$',  function () {
return this.indexLine;
});

Clazz.newMeth(C$, 'getHmNo_Remark$',  function () {
return this.hmNo_Remark;
});

Clazz.newMeth(C$, 'parseRemark$java_util_List$I$I',  function (liRaw, indexLine, indexRemark) {
var pattern=C$.getPatternRemark$I(indexRemark);
var sb=Clazz.new_($I$(2,1));
var start=indexLine;
for (var i=start; i < liRaw.size$(); i++) {
var l=liRaw.get$I(i);
var matcher=pattern.matcher$CharSequence(l);
if (matcher.find$()) {
var arr=l.split$S("[ ]+");
sb.append$S(" ");
for (var j=2; j < arr.length; j++) {
sb.append$S(arr[j]);
if (j < arr.length - 1) {
sb.append$S(" ");
}}
++indexLine;
} else {
break;
}}
var siTextIndex=Clazz.new_([sb.toString(), Integer.valueOf$I(indexLine)],$I$(3,1).c$$O$O);
return siTextIndex;
}, 1);

Clazz.newMeth(C$, 'getPatternRemark$',  function () {
var p="REMARK[ ]+";
return $I$(4).compile$S(p);
}, 1);

Clazz.newMeth(C$, 'getPatternRemark$I',  function (index) {
var p="REMARK" + "[ ]+" + index ;
return $I$(4).compile$S(p);
}, 1);

Clazz.newMeth(C$, 'getMatcherRemark$I$S',  function (indexRemark, s) {
var p=C$.getPatternRemark$I(indexRemark);
var matcher=p.matcher$CharSequence(s);
return matcher;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
