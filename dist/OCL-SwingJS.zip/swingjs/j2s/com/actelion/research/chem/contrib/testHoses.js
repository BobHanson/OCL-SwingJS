(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.contrib.HoseCodeCreator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "testHoses");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var hoses=$I$(1).getHoseCodesFromDiaID$S$I$I("fdyA`@@LTdlmNs}Bd{sMUSUUU`a@bID@_iAHNET", 5, 0);
for (var hose, $hose = 0, $$hose = hoses; $hose<$$hose.length&&((hose=($$hose[$hose])),1);$hose++) {
System.out.println$S(hose);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:20 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
