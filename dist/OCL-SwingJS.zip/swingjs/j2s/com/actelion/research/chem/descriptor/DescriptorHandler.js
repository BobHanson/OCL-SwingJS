(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "DescriptorHandler", null, null, 'com.actelion.research.chem.descriptor.ISimilarityCalculator');

C$.$clinit$=2;

C$.$fields$=[[]
,['O',['FAILED_BYTES','byte[]']]]

C$.$static$=function(){C$.$static$=0;
C$.FAILED_BYTES="Calculation Failed".getBytes$();
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
