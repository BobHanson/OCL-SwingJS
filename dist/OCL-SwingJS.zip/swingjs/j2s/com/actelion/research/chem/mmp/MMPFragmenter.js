(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'com.actelion.research.chem.IDCodeParser','java.util.ArrayList','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Canonizer','java.util.HashMap',['com.actelion.research.chem.mmp.MMPFragmenter','.MoleculeIndexIDByte'],['com.actelion.research.chem.mmp.MMPFragmenter','.MoleculeIndexID'],'java.util.HashSet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPFragmenter", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MoleculeIndexID',9],['MoleculeIndexIDByte',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.nRotBonds=null;
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','moleculeFragmentsID','java.util.List','moleculeFragments','java.util.HashMap','moleculeIndexesID','java.util.List','+moleculeIndexesIDByte','nRotBonds','Integer','rotBondsIndex','java.util.ArrayList']]
,['S',['r1H'],'O',['KEYS_MIN_ATOMS','Integer','+VALUE_MAX_ATOMS']]]

Clazz.newMeth(C$, 'createR1HMoleculeID$',  function () {
var r1H=Clazz.new_($I$(3,1));
var atom1Index=r1H.addAtom$I(142);
r1H.setAtomCustomLabel$I$S(atom1Index, "#");
var atom2Index=r1H.addAtom$I(1);
r1H.setAtomCustomLabel$I$S(atom2Index, "[H]");
r1H.addBond$I$I$I(atom1Index, atom2Index, 1);
return C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(r1H);
}, 1);

Clazz.newMeth(C$, 'getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule',  function (mol) {
var canonizer=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule$I,[mol, 8]);
return canonizer.getIDCode$();
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=p$1.removeHydrogens$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
this.moleculeFragmentsID=Clazz.new_($I$(2,1));
this.moleculeFragments=Clazz.new_($I$(5,1));
this.moleculeIndexesID=Clazz.new_($I$(2,1));
this.moleculeIndexesIDByte=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getMoleculeIndexesID$',  function () {
return this.getMoleculeIndexesID$Z(true);
});

Clazz.newMeth(C$, 'getMoleculeIndexesID$Z',  function (generateWholeMoleculeVariations) {
if (this.nRotBonds == null ) {
this.fragmentMolecule$Z(generateWholeMoleculeVariations);
}return this.moleculeIndexesID;
});

Clazz.newMeth(C$, 'getMoleculeFragmentsID$',  function () {
if (this.nRotBonds == null ) {
this.fragmentMolecule$Z(false);
}return this.moleculeFragmentsID;
});

Clazz.newMeth(C$, 'getMoleculeIndexesIDByte$',  function () {
return this.getMoleculeIndexesIDByte$Z(true);
});

Clazz.newMeth(C$, 'getMoleculeIndexesIDByte$Z',  function (generateWholeMoleculeVariations) {
if (this.nRotBonds == null ) {
this.fragmentMolecule$Z(generateWholeMoleculeVariations);
}if ((this.nRotBonds).$c() > 0  && this.moleculeIndexesIDByte.size$() == 0 ) {
for (var moleculeIndexID, $moleculeIndexID = this.moleculeIndexesID.iterator$(); $moleculeIndexID.hasNext$()&&((moleculeIndexID=($moleculeIndexID.next$())),1);) {
var keys=moleculeIndexID.keysID;
var value=moleculeIndexID.valueID;
var keysByte=null;
if (keys.length == 1) {
keysByte=Clazz.array(Byte.TYPE, -2, [keys[0].getBytes$(), keys[1].getBytes$()]);
} else if (keys.length == 2) {
keysByte=Clazz.array(Byte.TYPE, -2, [keys[0].getBytes$(), keys[1].getBytes$(), keys[2].getBytes$()]);
}var valueByte=value.getBytes$();
var moleculeIndexByte=Clazz.new_($I$(6,1).c$$BAA$BA,[this, null, keysByte, valueByte]);
this.moleculeIndexesIDByte.add$O(moleculeIndexByte);
}
}return this.moleculeIndexesIDByte;
});

Clazz.newMeth(C$, 'getRotBondsIndex$',  function () {
if (this.rotBondsIndex == null ) {
this.rotBondsIndex=Clazz.new_($I$(2,1));
for (var bond=0; bond < this.mol.getBonds$(); bond++) {
if (!this.mol.isRingBond$I(bond) && this.mol.getBondOrder$I(bond) == 1 ) {
this.rotBondsIndex.add$O(Integer.valueOf$I(bond));
}}
}return this.rotBondsIndex;
});

Clazz.newMeth(C$, 'countRGroups$com_actelion_research_chem_StereoMolecule',  function (mol) {
var count=0;
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == 0 || mol.getAtomicNo$I(atom) >= 142 ) {
++count;
}}
return count;
}, p$1);

Clazz.newMeth(C$, 'addRGroups$com_actelion_research_chem_StereoMolecule',  function (mol) {
return p$1.addRGroups$com_actelion_research_chem_StereoMolecule$Z.apply(this, [mol, false]);
}, p$1);

Clazz.newMeth(C$, 'addRGroups$com_actelion_research_chem_StereoMolecule$Z',  function (mol, inverse) {
var rGroup=1;
mol.ensureHelperArrays$I(1);
if (inverse == false ) {
for (var atom=0; atom < mol.getAtoms$(); atom++) {
if (mol.getAtomicNo$I(atom) == 0 || mol.getAtomicNo$I(atom) >= 142 ) {
mol.setAtomicNo$I$I(atom, 142 + rGroup - 1);
mol.setAtomCustomLabel$I$S(atom, "#" + Integer.toString$I(rGroup));
++rGroup;
}}
} else {
for (var atom=mol.getAtoms$() - 1; atom >= 0; atom--) {
if (mol.getAtomicNo$I(atom) == 0 || mol.getAtomicNo$I(atom) >= 142 ) {
mol.setAtomicNo$I$I(atom, 142 + rGroup - 1);
mol.setAtomCustomLabel$I$S(atom, "#" + Integer.toString$I(rGroup));
++rGroup;
}}
}return mol;
}, p$1);

Clazz.newMeth(C$, 'processFragments$com_actelion_research_chem_StereoMoleculeA$IA$IA$I',  function (fragments, bondIndexes, valueAtomIndexes, cutType) {
var retVal=null;
if (cutType == 1 && fragments.length > 1 ) {
var idCode1=C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[0]);
var idCode2=C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[1]);
retVal=Clazz.new_([Clazz.array(String, -1, [idCode1]), idCode2, Clazz.array(Integer.TYPE, -1, [fragments[0].getAtoms$() - 1]), fragments[1].getAtoms$() - 1, bondIndexes, valueAtomIndexes],$I$(7,1).c$$SA$S$IA$I$IA$IA);
if (C$.KEYS_MIN_ATOMS == null  || fragments[0].getAtoms$() >= (C$.KEYS_MIN_ATOMS).$c()  ) {
this.moleculeFragments.put$O$O(idCode1, fragments[0]);
}if (C$.KEYS_MIN_ATOMS == null  || fragments[1].getAtoms$() >= (C$.KEYS_MIN_ATOMS).$c()  ) {
this.moleculeFragments.put$O$O(idCode2, fragments[1]);
}} else if (cutType == 2 && fragments.length > 2 ) {
for (var mol, $mol = 0, $$mol = fragments; $mol<$$mol.length&&((mol=($$mol[$mol])),1);$mol++) {
mol.ensureHelperArrays$I(1);
}
if (p$1.countRGroups$com_actelion_research_chem_StereoMolecule.apply(this, [fragments[1]]) == 2) {
fragments=Clazz.array($I$(3), -1, [fragments[1], fragments[0], fragments[2]]);
} else if (p$1.countRGroups$com_actelion_research_chem_StereoMolecule.apply(this, [fragments[2]]) == 2) {
fragments=Clazz.array($I$(3), -1, [fragments[2], fragments[0], fragments[1]]);
}var canonizer=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_StereoMolecule,[fragments[0]]);
var graphIndexes=canonizer.getGraphIndexes$();
var rGroupIndexes=Clazz.array(Integer.TYPE, [2]);
var rGroupCounter=0;
for (var atom=0; atom < fragments[0].getAtoms$(); atom++) {
if (fragments[0].getAtomicNo$I(atom) >= 142 || fragments[0].getAtomicNo$I(atom) == 0 ) {
rGroupIndexes[rGroupCounter]=atom;
++rGroupCounter;
}}
if (graphIndexes[rGroupIndexes[0]] < graphIndexes[rGroupIndexes[1]]) {
retVal=Clazz.new_([Clazz.array(String, -1, [C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[1]), C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[2])]), C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(p$1.addRGroups$com_actelion_research_chem_StereoMolecule.apply(this, [fragments[0]])), Clazz.array(Integer.TYPE, -1, [fragments[1].getAtoms$() - 1, fragments[2].getAtoms$() - 1]), fragments[0].getAtoms$() - 1, bondIndexes, valueAtomIndexes],$I$(7,1).c$$SA$S$IA$I$IA$IA);
} else {
retVal=Clazz.new_([Clazz.array(String, -1, [C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[2]), C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(fragments[1])]), C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(p$1.addRGroups$com_actelion_research_chem_StereoMolecule$Z.apply(this, [fragments[0], true])), Clazz.array(Integer.TYPE, -1, [fragments[2].getAtoms$() - 1, fragments[1].getAtoms$() - 1]), fragments[0].getAtoms$() - 1, Clazz.array(Integer.TYPE, -1, [bondIndexes[1], bondIndexes[0]]), Clazz.array(Integer.TYPE, -1, [valueAtomIndexes[1], valueAtomIndexes[0]])],$I$(7,1).c$$SA$S$IA$I$IA$IA);
}}return retVal;
}, p$1);

Clazz.newMeth(C$, 'removeHydrogens$com_actelion_research_chem_StereoMolecule',  function (mol) {
mol.ensureHelperArrays$I(15);
mol.setAllAtoms$I(mol.getAtoms$());
mol.setAllBonds$I(mol.getBonds$());
return mol;
}, p$1);

Clazz.newMeth(C$, 'fragmentMolecule$',  function () {
this.fragmentMolecule$Z(true);
});

Clazz.newMeth(C$, 'fragmentMolecule$Z',  function (generateWholeMoleculeVariations) {
var rGroupsIndex=Clazz.array(Integer.TYPE, [4]);
var newBondsIndex=Clazz.array(Integer.TYPE, [2]);
var hFragments=Clazz.new_($I$(8,1));
var editableMol=Clazz.new_($I$(3,1));
this.mol.copyMolecule$com_actelion_research_chem_Molecule(editableMol);
editableMol.ensureHelperArrays$I(1);
for (var i=0; i < 2; i++) {
rGroupsIndex[i * 2]=editableMol.addAtom$I(142);
editableMol.setAtomCustomLabel$I$S(rGroupsIndex[i * 2], "#");
rGroupsIndex[i * 2 + 1]=editableMol.addAtom$I(142);
editableMol.setAtomCustomLabel$I$S(rGroupsIndex[i * 2 + 1], "#");
newBondsIndex[i]=editableMol.addBond$I$I$I(rGroupsIndex[i * 2], rGroupsIndex[i * 2 + 1], 1);
}
this.rotBondsIndex=this.getRotBondsIndex$();
this.nRotBonds=Integer.valueOf$I(this.rotBondsIndex.size$());
for (var firstCut=0; firstCut < (this.nRotBonds).$c() ; firstCut++) {
var atom0=editableMol.getBondAtom$I$I(0, (this.rotBondsIndex.get$I(firstCut)).$c());
var atom1=editableMol.getBondAtom$I$I(1, (this.rotBondsIndex.get$I(firstCut)).$c());
editableMol.setBondType$I$I(newBondsIndex[0], editableMol.getBondType$I((this.rotBondsIndex.get$I(firstCut)).$c()));
editableMol.setBondAtom$I$I$I(1, (this.rotBondsIndex.get$I(firstCut)).$c(), rGroupsIndex[0]);
editableMol.setBondAtom$I$I$I(0, newBondsIndex[0], atom1);
var scFragments=editableMol.getFragments$();
var singleCutFragments=p$1.processFragments$com_actelion_research_chem_StereoMoleculeA$IA$IA$I.apply(this, [scFragments, Clazz.array(Integer.TYPE, -1, [(this.rotBondsIndex.get$I(firstCut)).valueOf()]), Clazz.array(Integer.TYPE, -1, [atom1]), 1]);
if ((C$.KEYS_MIN_ATOMS == null  || singleCutFragments.keysIDAtoms[0] >= (C$.KEYS_MIN_ATOMS).$c()  ) && (C$.VALUE_MAX_ATOMS == null  || singleCutFragments.valueIDAtoms <= (C$.VALUE_MAX_ATOMS).$c()  ) ) {
this.moleculeIndexesID.add$O(singleCutFragments);
}if ((C$.KEYS_MIN_ATOMS == null  || singleCutFragments.valueIDAtoms >= (C$.KEYS_MIN_ATOMS).$c()  ) && (C$.VALUE_MAX_ATOMS == null  || singleCutFragments.keysIDAtoms[0] <= (C$.VALUE_MAX_ATOMS).$c()  ) ) {
var invertedSingleCutFragments=Clazz.new_([Clazz.array(String, -1, [singleCutFragments.valueID]), singleCutFragments.keysID[0], Clazz.array(Integer.TYPE, -1, [singleCutFragments.valueIDAtoms]), singleCutFragments.keysIDAtoms[0], Clazz.array(Integer.TYPE, -1, [(this.rotBondsIndex.get$I(firstCut)).valueOf()]), Clazz.array(Integer.TYPE, -1, [atom0])],$I$(7,1).c$$SA$S$IA$I$IA$IA);
this.moleculeIndexesID.add$O(invertedSingleCutFragments);
}if (C$.KEYS_MIN_ATOMS == null  || singleCutFragments.keysIDAtoms[0] >= (C$.KEYS_MIN_ATOMS).$c()  ) {
hFragments.add$O(singleCutFragments.keysID[0]);
}if (C$.KEYS_MIN_ATOMS == null  || singleCutFragments.valueIDAtoms >= (C$.KEYS_MIN_ATOMS).$c()  ) {
hFragments.add$O(singleCutFragments.valueID);
}if (true) {
for (var secondCut=firstCut + 1; secondCut < (this.nRotBonds).$c() ; secondCut++) {
var atom2=editableMol.getBondAtom$I$I(1, (this.rotBondsIndex.get$I(secondCut)).$c());
editableMol.setBondType$I$I(newBondsIndex[1], editableMol.getBondType$I((this.rotBondsIndex.get$I(secondCut)).$c()));
editableMol.setBondAtom$I$I$I(1, (this.rotBondsIndex.get$I(secondCut)).$c(), rGroupsIndex[2]);
editableMol.setBondAtom$I$I$I(0, newBondsIndex[1], atom2);
var dcFragments=editableMol.getFragments$();
var doubleCutFragments=p$1.processFragments$com_actelion_research_chem_StereoMoleculeA$IA$IA$I.apply(this, [dcFragments, Clazz.array(Integer.TYPE, -1, [(this.rotBondsIndex.get$I(firstCut)).valueOf(), (this.rotBondsIndex.get$I(secondCut)).valueOf()]), Clazz.array(Integer.TYPE, -1, [atom1, atom2]), 2]);
if ((C$.KEYS_MIN_ATOMS == null  || (doubleCutFragments.keysIDAtoms[0] >= (C$.KEYS_MIN_ATOMS).$c()  && doubleCutFragments.keysIDAtoms[1] >= (C$.KEYS_MIN_ATOMS).$c()  ) ) && (C$.VALUE_MAX_ATOMS == null  || doubleCutFragments.valueIDAtoms <= (C$.VALUE_MAX_ATOMS).$c()  ) ) {
this.moleculeIndexesID.add$O(doubleCutFragments);
}editableMol.setBondAtom$I$I$I(1, (this.rotBondsIndex.get$I(secondCut)).$c(), atom2);
editableMol.setBondAtom$I$I$I(0, newBondsIndex[1], rGroupsIndex[2]);
}
}editableMol.setBondAtom$I$I$I(1, (this.rotBondsIndex.get$I(firstCut)).$c(), atom1);
editableMol.setBondAtom$I$I$I(0, newBondsIndex[0], rGroupsIndex[0]);
}
for (var cursor, $cursor = this.moleculeFragments.entrySet$().iterator$(); $cursor.hasNext$()&&((cursor=($cursor.next$())),1);) {
var fragmentID=cursor.getKey$();
var moleculeFragment=cursor.getValue$();
for (var atom=moleculeFragment.getAtoms$() - 1; atom >= 0; atom--) {
if (moleculeFragment.getAtomicNo$I(atom) == 0 || moleculeFragment.getAtomicNo$I(atom) >= 142 ) {
moleculeFragment.setAtomicNo$I$I(atom, 1);
moleculeFragment.setAtomCustomLabel$I$S(atom, null);
break;
}}
this.moleculeFragmentsID.add$O(Clazz.array(String, -1, [fragmentID, moleculeFragment.getIDCode$()]));
}
if (generateWholeMoleculeVariations) {
this.generateWholeMoleculeVariations$();
}});

Clazz.newMeth(C$, 'generateWholeMoleculeVariations$',  function () {
var wholeMoleculeVariations=Clazz.new_($I$(5,1));
var atomCount=this.mol.getAtoms$();
var editableMol=Clazz.new_($I$(3,1));
this.mol.copyMolecule$com_actelion_research_chem_Molecule(editableMol);
var rGroupIndex=editableMol.addAtom$I(142);
editableMol.setAtomCustomLabel$I$S(rGroupIndex, "#");
editableMol.ensureHelperArrays$I(1);
for (var atom=0; atom < editableMol.getAtoms$() - 1; atom++) {
if (this.mol.getPlainHydrogens$I(atom) > 0) {
var newBond=editableMol.addBond$I$I$I(rGroupIndex, atom, 1);
var idCode=C$.getIDCodeWithCustomLabels$com_actelion_research_chem_StereoMolecule(editableMol);
var atomIndexes=Clazz.new_($I$(2,1));
if (wholeMoleculeVariations.containsKey$O(idCode)) {
atomIndexes=wholeMoleculeVariations.get$O(idCode);
}atomIndexes.add$O(Integer.valueOf$I(atom));
wholeMoleculeVariations.put$O$O(idCode, atomIndexes);
editableMol.deleteBond$I(newBond);
}}
for (var cursor, $cursor = wholeMoleculeVariations.entrySet$().iterator$(); $cursor.hasNext$()&&((cursor=($cursor.next$())),1);) {
var atomIndexes=Clazz.array(Integer.TYPE, [cursor.getValue$().size$()]);
for (var i=0; i < atomIndexes.length; i++) atomIndexes[i]=(cursor.getValue$().get$I(i)).$c();

var hFrag=Clazz.new_([Clazz.array(String, -1, [cursor.getKey$()]), C$.r1H, Clazz.array(Integer.TYPE, -1, [atomCount]), 0, Clazz.array(Integer.TYPE, -1, [-1]), atomIndexes],$I$(7,1).c$$SA$S$IA$I$IA$IA);
this.moleculeIndexesID.add$O(hFrag);
}
});

Clazz.newMeth(C$, 'getMol$',  function () {
return this.mol;
});

C$.$static$=function(){C$.$static$=0;
C$.KEYS_MIN_ATOMS=Integer.valueOf$I(4);
C$.VALUE_MAX_ATOMS=null;
C$.r1H=C$.createR1HMoleculeID$();
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPFragmenter, "MoleculeIndexID", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.idCodeParser=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['I',['valueIndex','valueIDAtoms'],'S',['valueID'],'O',['keysID','String[]','keysIndex','int[]','+keysIDAtoms','idCodeParser','com.actelion.research.chem.IDCodeParser','bondIndexes','int[]','+valueAtomIndexes','coordinates','java.util.List','chemicalSpaceSizes','Integer[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$SA$IA$S$I$IA$I$IA$IA',  function (keysID, keysIndex, valueID, valueIndex, keysIDAtoms, valueIDAtoms, bondIndexes, valueAtomIndexes) {
;C$.$init$.apply(this);
this.keysID=keysID;
this.keysIndex=keysIndex;
this.valueID=valueID;
this.valueIndex=valueIndex;
this.keysIDAtoms=keysIDAtoms;
if (keysIDAtoms == null ) {
this.keysIDAtoms=Clazz.array(Integer.TYPE, [keysID.length]);
for (var i=0; i < keysID.length; i++) {
this.keysIDAtoms[i]=this.idCodeParser.getAtomCount$S(keysID[i]) - 1;
}
}this.valueIDAtoms=valueIDAtoms;
this.bondIndexes=bondIndexes;
this.valueAtomIndexes=valueAtomIndexes;
this.coordinates=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'c$$SA$S$IA$I$IA$IA',  function (keysID, valueID, keysIDAtoms, valueIDAtoms, bondIndexes, valueAtomIndexes) {
;C$.$init$.apply(this);
this.keysID=keysID;
this.valueID=valueID;
this.keysIDAtoms=keysIDAtoms;
if (keysIDAtoms == null ) {
this.keysIDAtoms=Clazz.array(Integer.TYPE, [keysID.length]);
for (var i=0; i < keysID.length; i++) {
this.keysIDAtoms[i]=this.idCodeParser.getAtomCount$S(keysID[i]) - 1;
}
}this.valueIDAtoms=valueIDAtoms;
this.bondIndexes=bondIndexes;
this.valueAtomIndexes=valueAtomIndexes;
this.coordinates=Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getKeysID$',  function () {
return this.keysID;
});

Clazz.newMeth(C$, 'getValueID$',  function () {
return this.valueID;
});

Clazz.newMeth(C$, 'getKeysIDAtoms$',  function () {
return this.keysIDAtoms;
});

Clazz.newMeth(C$, 'getValueIDAtoms$',  function () {
return this.valueIDAtoms;
});

Clazz.newMeth(C$, 'getKeysIndex$',  function () {
return this.keysIndex;
});

Clazz.newMeth(C$, 'setKeysIndex$IA',  function (keysIndex) {
this.keysIndex=keysIndex;
});

Clazz.newMeth(C$, 'getValueIndex$',  function () {
return this.valueIndex;
});

Clazz.newMeth(C$, 'setValueIndex$I',  function (valueIndex) {
this.valueIndex=valueIndex;
});

Clazz.newMeth(C$, 'getBondIndexes$',  function () {
return this.bondIndexes;
});

Clazz.newMeth(C$, 'getValueAtomIndexes$',  function () {
return this.valueAtomIndexes;
});

Clazz.newMeth(C$, 'setCoordinates$D$D',  function (x, y) {
this.coordinates.add$O(Clazz.array(Double, -1, [Double.valueOf$D(x), Double.valueOf$D(y)]));
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
return this.coordinates;
});

Clazz.newMeth(C$, 'setChemicalSpaceSize$IntegerA',  function (chemicalSpaceSizes) {
this.chemicalSpaceSizes=chemicalSpaceSizes;
});

Clazz.newMeth(C$, 'getChemicalSpaceSizes$',  function () {
return this.chemicalSpaceSizes;
});
})()
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPFragmenter, "MoleculeIndexIDByte", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['keysIDByte','byte[][]','valueIDByte','byte[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$BAA$BA',  function (keysIDByte, valueIDByte) {
;C$.$init$.apply(this);
this.keysIDByte=keysIDByte;
this.valueIDByte=valueIDByte;
}, 1);

Clazz.newMeth(C$, 'getKeysIDByte$',  function () {
return this.keysIDByte;
});

Clazz.newMeth(C$, 'getValueIDByte$',  function () {
return this.valueIDByte;
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
