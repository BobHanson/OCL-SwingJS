(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerShapeOneConf", null, 'com.actelion.research.chem.phesa.DescriptorHandlerShape');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$Z.apply(this,[true]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$D',  function (ppWeight) {
;C$.superclazz.c$$D.apply(this,[ppWeight]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$I$D',  function (maxConfs, ppWeight) {
;C$.superclazz.c$$Z$I$D.apply(this,[true, maxConfs, ppWeight]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
var dhs=Clazz.new_(C$);
dhs.ppWeight=this.ppWeight;
dhs.flexible=this.flexible;
dhs.maxConfs=this.maxConfs;
return dhs;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
