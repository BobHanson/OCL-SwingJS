(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.io.pdb.converter.GeometryCalculator','java.util.Set','java.util.TreeSet']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MoleculeGrid");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.gridSize=Clazz.array(Integer.TYPE, [3]);
},1);

C$.$fields$=[['D',['gridWidth'],'O',['mol','com.actelion.research.chem.StereoMolecule','min','com.actelion.research.chem.Coordinates','+max','gridSize','int[]','grid','java.util.Set[][][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
C$.c$$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates.apply(this, [mol, 1.1, Clazz.new_($I$(1,1).c$$D$D$D,[0.0, 0.0, 0.0])]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates',  function (mol, gridWidth, extension) {
;C$.$init$.apply(this);
this.mol=mol;
this.gridWidth=gridWidth;
var bounds=$I$(2).getBounds$com_actelion_research_chem_StereoMolecule(mol);
this.min=bounds[0];
this.max=bounds[1];
this.min.x-=extension.x;
this.min.y-=extension.y;
this.min.z-=extension.z;
this.max.x+=extension.x;
this.max.y+=extension.y;
this.max.z+=extension.z;
this.gridSize[0]=(((this.max.x - this.min.x) / gridWidth)|0) + 1;
this.gridSize[1]=(((this.max.y - this.min.y) / gridWidth)|0) + 1;
this.gridSize[2]=(((this.max.z - this.min.z) / gridWidth)|0) + 1;
this.grid=Clazz.array($I$(3), [Math.max(0, this.gridSize[0]), Math.max(0, this.gridSize[1]), Math.max(0, this.gridSize[2])]);
var atoms=mol.getAtoms$();
for (var i=0; i < atoms; i++) {
var x=(((mol.getAtomX$I(i) - this.min.x) / gridWidth)|0);
var y=(((mol.getAtomY$I(i) - this.min.y) / gridWidth)|0);
var z=(((mol.getAtomZ$I(i) - this.min.z) / gridWidth)|0);
if (this.grid[x][y][z] == null ) this.grid[x][y][z]=Clazz.new_($I$(4,1));
this.grid[x][y][z].add$O(Integer.valueOf$I(i));
}
}, 1);

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_Coordinates$D',  function (c, maxDist) {
var radius=((maxDist / this.gridWidth)|0) + 1;
var x=(((c.x - this.min.x) / this.gridWidth)|0);
var y=(((c.y - this.min.y) / this.gridWidth)|0);
var z=(((c.z - this.min.z) / this.gridWidth)|0);
var res=Clazz.new_($I$(4,1));
for (var i=Math.max(0, x - radius); i <= Math.min(this.gridSize[0] - 1, x + radius); i++) {
for (var j=Math.max(0, y - radius); j <= Math.min(this.gridSize[1] - 1, y + radius); j++) {
for (var k=Math.max(0, z - radius); k <= Math.min(this.gridSize[2] - 1, z + radius); k++) {
if (this.grid[i][j][k] != null ) res.addAll$java_util_Collection(this.grid[i][j][k]);
}
}
}
return res;
});

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_Coordinates$D$Z',  function (c, maxDist, enforceDist) {
return this.getNeighbours$com_actelion_research_chem_Coordinates$D$Z$I(c, maxDist, enforceDist, -1);
});

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_Coordinates$D$Z$I',  function (c, maxDist, enforceDist, requiredFlags) {
var radius=((maxDist / this.gridWidth)|0) + 1;
var x=(((c.x - this.min.x) / this.gridWidth)|0);
var y=(((c.y - this.min.y) / this.gridWidth)|0);
var z=(((c.z - this.min.z) / this.gridWidth)|0);
var res=Clazz.new_($I$(4,1));
for (var i=Math.max(0, x - radius); i <= Math.min(this.gridSize[0] - 1, x + radius); i++) {
for (var j=Math.max(0, y - radius); j <= Math.min(this.gridSize[1] - 1, y + radius); j++) {
for (var k=Math.max(0, z - radius); k <= Math.min(this.gridSize[2] - 1, z + radius); k++) {
if (this.grid[i][j][k] != null ) {
if (enforceDist) {
for (var elt, $elt = this.grid[i][j][k].iterator$(); $elt.hasNext$()&&((elt=($elt.next$()).intValue$()),1);) {
if (this.mol.getCoordinates$I(elt).distSquareTo$com_actelion_research_chem_Coordinates(c) > maxDist * maxDist ) continue;
res.add$O(Integer.valueOf$I(elt));
}
} else {
res.addAll$java_util_Collection(this.grid[i][j][k]);
}}}
}
}
return res;
});

Clazz.newMeth(C$, 'hasNeighbours$com_actelion_research_chem_Coordinates$D',  function (c, maxDist) {
var radius=((maxDist / this.gridWidth)|0) + 1;
var x=(((c.x - this.min.x) / this.gridWidth)|0);
var y=(((c.y - this.min.y) / this.gridWidth)|0);
var z=(((c.z - this.min.z) / this.gridWidth)|0);
for (var i=Math.max(0, x - radius); i <= Math.min(this.gridSize[0] - 1, x + radius); i++) {
for (var j=Math.max(0, y - radius); j <= Math.min(this.gridSize[1] - 1, y + radius); j++) {
for (var k=Math.max(0, z - radius); k <= Math.min(this.gridSize[2] - 1, z + radius); k++) {
if (this.grid[i][j][k] != null ) {
for (var a, $a = this.grid[i][j][k].iterator$(); $a.hasNext$()&&((a=($a.next$()).intValue$()),1);) {
if (this.mol.getCoordinates$I(a).distSquareTo$com_actelion_research_chem_Coordinates(c) <= maxDist * maxDist ) {
return true;
}}
}}
}
}
return false;
});

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_CoordinatesA$D',  function (bounds, maxDist) {
var radius=((maxDist / this.gridWidth)|0) + 1;
var x1=(((bounds[0].x - this.min.x) / this.gridWidth)|0);
var y1=(((bounds[0].y - this.min.y) / this.gridWidth)|0);
var z1=(((bounds[0].z - this.min.z) / this.gridWidth)|0);
var x2=(((bounds[1].x - this.min.x) / this.gridWidth)|0);
var y2=(((bounds[1].y - this.min.y) / this.gridWidth)|0);
var z2=(((bounds[1].z - this.min.z) / this.gridWidth)|0);
var xMin=Math.min(x1, x2);
var xMax=Math.max(x1, x2);
var yMin=Math.min(y1, y2);
var yMax=Math.max(y1, y2);
var zMin=Math.min(z1, z2);
var zMax=Math.max(z1, z2);
var res=Clazz.new_($I$(4,1));
for (var i=Math.max(0, xMin - radius); i <= Math.min(this.gridSize[0] - 1, xMax + radius); i++) {
for (var j=Math.max(0, yMin - radius); j <= Math.min(this.gridSize[1] - 1, yMax + radius); j++) {
for (var k=Math.max(0, zMin - radius); k <= Math.min(this.gridSize[2] - 1, zMax + radius); k++) {
if (this.grid[i][j][k] != null ) res.addAll$java_util_Collection(this.grid[i][j][k]);
}
}
}
return res;
});

Clazz.newMeth(C$, 'getClosestNeighbour$com_actelion_research_chem_Coordinates$D',  function (c, maxDist) {
var set=this.getNeighbours$com_actelion_research_chem_Coordinates$D(c, maxDist);
var closest=-1;
var bestDist=maxDist;
for (var a, $a = set.iterator$(); $a.hasNext$()&&((a=($a.next$()).intValue$()),1);) {
var d=this.mol.getCoordinates$I(a).distanceSquared$com_actelion_research_chem_Coordinates(c);
if (d < bestDist ) {
closest=a;
bestDist=d;
}}
return closest;
});

Clazz.newMeth(C$, 'updateGrid$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var i=0; i < mol.getAllAtoms$(); i++) {
var x=(((mol.getAtomX$I(i) - this.min.x) / this.gridWidth)|0);
var y=(((mol.getAtomY$I(i) - this.min.y) / this.gridWidth)|0);
var z=(((mol.getAtomZ$I(i) - this.min.z) / this.gridWidth)|0);
if (this.grid[x][y][z] == null ) this.grid[x][y][z]=Clazz.new_($I$(4,1));
if (this.grid[x][y][z].contains$O(Integer.valueOf$I(i))) continue;
 else {
p$1.removeAtom$I.apply(this, [i]);
this.grid[x][y][z].add$O(Integer.valueOf$I(i));
}}
});

Clazz.newMeth(C$, 'removeAtom$I',  function (index) {
var l=Math.max(0, this.gridSize[0]);
var m=Math.max(0, this.gridSize[1]);
var n=Math.max(0, this.gridSize[2]);
for (var i=0; i < l; i++) {
for (var j=0; j < m; j++) {
for (var k=0; k < n; n++) {
if (this.grid[i][k][k].contains$O(Integer.valueOf$I(index))) this.grid[i][k][k].remove$O(Integer.valueOf$I(index));
}
}
}
}, p$1);

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_Molecule$I$D',  function (mol, atom, maxDist) {
return this.getNeighbours$com_actelion_research_chem_Molecule$I$D$Z(mol, atom, maxDist, false);
});

Clazz.newMeth(C$, 'getNeighbours$com_actelion_research_chem_Molecule$I$D$Z',  function (mol, atom, maxDist, enforceDist) {
var res=this.getNeighbours$com_actelion_research_chem_Coordinates$D$Z(mol.getCoordinates$I(atom), maxDist, enforceDist);
res.remove$O(Integer.valueOf$I(atom));
return res;
});

Clazz.newMeth(C$, 'getGridCoordinates$com_actelion_research_chem_Coordinates',  function (c) {
var gridCoords=Clazz.array(Integer.TYPE, [3]);
gridCoords[0]=(((c.x - this.min.x) / this.gridWidth)|0);
gridCoords[1]=(((c.y - this.min.y) / this.gridWidth)|0);
gridCoords[2]=(((c.z - this.min.z) / this.gridWidth)|0);
return gridCoords;
});

Clazz.newMeth(C$, 'getCartCoordinates$IA',  function (gridCoords) {
var gridX=gridCoords[0];
var gridY=gridCoords[1];
var gridZ=gridCoords[2];
var cartCoords=Clazz.new_($I$(1,1));
cartCoords.x=this.min.x + gridX * this.gridWidth;
cartCoords.y=this.min.y + gridY * this.gridWidth;
cartCoords.z=this.min.z + gridZ * this.gridWidth;
return cartCoords;
});

Clazz.newMeth(C$, 'getGridSize$',  function () {
return this.gridSize;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:12 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
