(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ModelSampleFragments");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['bondsFragment','uniqueFragments','uniqueFragmentsEstimated']]]

Clazz.newMeth(C$, 'c$$I',  function (bondsFragment) {
;C$.$init$.apply(this);
this.bondsFragment=bondsFragment;
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (bondsFragment, uniqueFragments, uniqueFragmentsEstimated) {
;C$.$init$.apply(this);
this.bondsFragment=bondsFragment;
this.uniqueFragments=uniqueFragments;
this.uniqueFragmentsEstimated=uniqueFragmentsEstimated;
}, 1);

Clazz.newMeth(C$, 'getBondsFragment$',  function () {
return this.bondsFragment;
});

Clazz.newMeth(C$, 'getUniqueFragmentsEstimated$',  function () {
return this.uniqueFragmentsEstimated;
});

Clazz.newMeth(C$, 'getUniqueFragments$',  function () {
return this.uniqueFragments;
});

Clazz.newMeth(C$, 'setUniqueFragmentsEstimated$I',  function (uniqueFragmentsEstimated) {
this.uniqueFragmentsEstimated=uniqueFragmentsEstimated;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(1,1).c$$S,["ModelSampleFragments{"]);
sb.append$S("bondsFragment=").append$I(this.bondsFragment);
sb.append$S(", uniqueFragments=").append$I(this.uniqueFragments);
sb.append$S(", uniqueFragmentsEstimated=").append$I(this.uniqueFragmentsEstimated);
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$, 'getComparatorBonds$',  function () {
return ((P$.ModelSampleFragments$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "ModelSampleFragments$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_mcs_ModelSampleFragments$com_actelion_research_chem_mcs_ModelSampleFragments','compare$O$O'],  function (o1, o2) {
var cmp=0;
if (o1.bondsFragment > o2.bondsFragment) {
cmp=1;
} else if (o1.bondsFragment < o2.bondsFragment) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.ModelSampleFragments$1.$init$,[this, null]));
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:44 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
