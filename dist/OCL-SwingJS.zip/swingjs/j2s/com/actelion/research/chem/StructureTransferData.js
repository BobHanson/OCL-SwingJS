(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.ExtendedMolecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StructureTransferData", null, null, 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.si_=null;
this.mol_=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['si_','com.actelion.research.chem.StructureInfo','mol_','com.actelion.research.chem.ExtendedMolecule']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_ExtendedMolecule$com_actelion_research_chem_StructureInfo',  function (mol, si) {
;C$.$init$.apply(this);
this.mol_=mol;
this.si_=si;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getMolecule$',  function () {
return this.mol_;
});

Clazz.newMeth(C$, 'getStructureInfo$',  function () {
return this.si_;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
