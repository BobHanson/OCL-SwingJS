(function(){var P$=Clazz.newPackage("com.actelion.research.chem");
/*c*/var C$=Clazz.newClass(P$, "AtomFunctionAnalyzer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getOxoCount$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var count=0;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) if (mol.getConnBondOrder$I$I(atom, i) == 2 && mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, i)) == 8 ) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var count=0;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) if (mol.getConnBondOrder$I$I(atom, i) == 2 && (mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, i)) == 7 || mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, i)) == 8  || mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, i)) == 16 ) ) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'getNegativeNeighbourCount$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var count=0;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) if (mol.isElectronegative$I(mol.getConnAtom$I$I(atom, i))) ++count;

return count;
}, 1);

Clazz.newMeth(C$, 'isAlkylAmine$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 7 || mol.isAromaticAtom$I(atom)  || mol.getAtomPi$I(atom) != 0 ) return false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(conn) != 6 || mol.getAtomPi$I(conn) != 0  || mol.isAromaticAtom$I(conn)  || C$.getNegativeNeighbourCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) != 1 ) {
return false;
}}
return true;
}, 1);

Clazz.newMeth(C$, 'isStabilized$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, atom, twice) {
var aleadyFound=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
if (!mol.isAromaticBond$I(mol.getConnBond$I$I(atom, i)) && mol.getConnBondOrder$I$I(atom, i) == 1 ) {
var conn=mol.getConnAtom$I$I(atom, i);
if (!mol.isAromaticAtom$I(conn) && ((mol.getAtomicNo$I(conn) == 6 && C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) == 1 ) || (mol.getAtomicNo$I(conn) == 16 && C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) == 2 ) ) ) {
if (aleadyFound || !twice ) return true;
aleadyFound=true;
}}}
return false;
}, 1);

Clazz.newMeth(C$, 'isAmide$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 7 || mol.getAtomPi$I(atom) != 0  || mol.isAromaticAtom$I(atom) ) return false;
var carbonylEquivalentFound=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if ((mol.getAtomicNo$I(conn) == 6 && C$.getOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) == 1 ) || (mol.getAtomicNo$I(conn) == 16 && C$.getOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) == 2 ) ) carbonylEquivalentFound=true;
 else if (mol.getAtomicNo$I(conn) != 6) return false;
}
return carbonylEquivalentFound;
}, 1);

Clazz.newMeth(C$, 'isAmine$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 7 || mol.isAromaticAtom$I(atom)  || mol.getAtomPi$I(atom) != 0 ) return false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(conn) != 6 || (!mol.isAromaticAtom$I(conn) && (mol.getAtomPi$I(conn) != 0 || C$.getNegativeNeighbourCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) != 1 ) ) ) {
return false;
}}
return true;
}, 1);

Clazz.newMeth(C$, 'isArylAmine$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomicNo$I(atom) != 7 || mol.isAromaticAtom$I(atom)  || mol.getAtomPi$I(atom) != 0 ) return false;
var aromaticNeighbourFound=false;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(conn) != 6 || (!mol.isAromaticAtom$I(conn) && (mol.getAtomPi$I(conn) != 0 || C$.getNegativeNeighbourCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) != 1 ) ) ) {
return false;
}if (mol.isAromaticAtom$I(conn)) aromaticNeighbourFound=true;
}
return aromaticNeighbourFound;
}, 1);

Clazz.newMeth(C$, 'hasUnbalancedAtomCharge$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
if (mol.getAtomCharge$I(atom) == 0) {
return false;
}var unbalanced=true;
var chargeCenterAtom=mol.getAtomCharge$I(atom);
var nConnected=mol.getConnAtoms$I(atom);
var sumChargeConnectedAtoms=0;
for (var i=0; i < nConnected; i++) {
var indexAtom=mol.getConnAtom$I$I(atom, i);
sumChargeConnectedAtoms+=mol.getAtomCharge$I(indexAtom);
}
if (Math.abs(chargeCenterAtom) <= Math.abs(sumChargeConnectedAtoms)) {
if (Math.signum(chargeCenterAtom) != Math.signum(sumChargeConnectedAtoms) ) {
unbalanced=false;
}}return unbalanced;
}, 1);

Clazz.newMeth(C$, 'isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return C$.isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I$Z(mol, atom, true);
}, 1);

Clazz.newMeth(C$, 'isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, atom, considerCharge) {
if (mol.getAtomicNo$I(atom) != 8 || (considerCharge && mol.getAtomCharge$I(atom) != 0 )  || mol.getConnAtoms$I(atom) != 1  || mol.getConnBondOrder$I$I(atom, 0) != 1 ) return false;
var connAtom=mol.getConnAtom$I$I(atom, 0);
if (mol.getAtomicNo$I(connAtom) == 6) {
var nConnected2C=mol.getConnAtoms$I(connAtom);
for (var i=0; i < nConnected2C; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) {
continue;
}if (mol.getAtomicNo$I(indexAtom) != 8) {
continue;
}var indexBond=mol.getBond$I$I(connAtom, indexAtom);
if (mol.getBondType$I(indexBond) == 2) return true;
}
} else if (mol.getAtomicNo$I(connAtom) == 7) {
if (mol.getAtomCharge$I(connAtom) == 1) return true;
} else if (mol.getAtomicNo$I(connAtom) == 16) {
var nConnected2S=mol.getConnAtoms$I(connAtom);
var nDoubleBondedO2S=0;
for (var i=0; i < nConnected2S; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) continue;
if (mol.getAtomicNo$I(indexAtom) != 8) continue;
var indexBond=mol.getBond$I$I(connAtom, indexAtom);
if (mol.getBondType$I(indexBond) == 2) ++nDoubleBondedO2S;
}
if (nDoubleBondedO2S == 2) return true;
} else if (C$.isAcidicOxygenAtPhosphoricAcid$com_actelion_research_chem_StereoMolecule$I$Z(mol, atom, considerCharge)) return true;
return false;
}, 1);

Clazz.newMeth(C$, 'isAcidicOxygenAtPhosphoricAcid$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return C$.isAcidicOxygenAtPhosphoricAcid$com_actelion_research_chem_StereoMolecule$I$Z(mol, atom, true);
}, 1);

Clazz.newMeth(C$, 'isAcidicOxygenAtPhosphoricAcid$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, atom, considerCharge) {
if (mol.getAtomicNo$I(atom) != 8) return false;
if (mol.getConnAtoms$I(atom) != 1) return false;
var connAtom=mol.getConnAtom$I$I(atom, 0);
if (mol.getAtomicNo$I(connAtom) == 15) {
var nConnected2P=mol.getConnAtoms$I(connAtom);
for (var i=0; i < nConnected2P; i++) {
var indexAtom=mol.getConnAtom$I$I(connAtom, i);
if (indexAtom == atom) continue;
if (mol.getAtomicNo$I(indexAtom) != 8) continue;
var indexBond=mol.getBond$I$I(connAtom, indexAtom);
if (mol.getBondType$I(indexBond) == 2) return true;
}
}return false;
}, 1);

Clazz.newMeth(C$, 'isMemberOfNitroGroup$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var member=false;
if ((mol.getAtomicNo$I(atom) != 7) && (mol.getAtomicNo$I(atom) != 8) ) return false;
if (mol.getAtomicNo$I(atom) == 7) {
if (C$.isNitroGroupN$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
member=true;
}} else if (mol.getAtomicNo$I(atom) == 8) {
var nConnAts=mol.getConnAtoms$I(atom);
for (var i=0; i < nConnAts; i++) {
var indexAt=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(indexAt) == 7) {
if (C$.isNitroGroupN$com_actelion_research_chem_StereoMolecule$I(mol, indexAt)) {
member=true;
break;
}}}
}return member;
}, 1);

Clazz.newMeth(C$, 'isNitroGroupN$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var nitro=false;
if ((mol.getAtomicNo$I(atom) != 7)) return false;
var nConnAts=mol.getConnAtoms$I(atom);
var indexSingleBondedO=-1;
var indexDoubleBondedO=-1;
for (var i=0; i < nConnAts; i++) {
var indexAt=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(indexAt) == 8) {
var indexBnd=mol.getBond$I$I(atom, indexAt);
if (mol.getBondOrder$I(indexBnd) == 1) {
indexSingleBondedO=indexAt;
} else if (mol.getBondOrder$I(indexBnd) == 2) {
indexDoubleBondedO=indexAt;
}}}
if ((indexSingleBondedO > -1) && (indexDoubleBondedO > -1) ) {
nitro=true;
}return nitro;
}, 1);

Clazz.newMeth(C$, 'isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return C$.isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I$Z(mol, atom, true);
}, 1);

Clazz.newMeth(C$, 'isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I$Z',  function (mol, atom, considerCharge) {
if (mol.getAtomicNo$I(atom) != 7 || (considerCharge && mol.getAtomCharge$I(atom) != 0 )  || (mol.getConnAtoms$I(atom) + mol.getAtomPi$I(atom) > 3) ) return false;
if (mol.isAromaticAtom$I(atom)) {
if (mol.getAtomPi$I(atom) != 1) return false;
if (mol.getAtomRingCount$I$I(atom, 7) != 1) return false;
var rc=mol.getRingSet$();
for (var r=0; r < rc.getSize$(); r++) {
if (rc.isAtomMember$I$I(r, atom)) {
if (rc.getRingSize$I(r) == 5 || rc.getRingSize$I(r) == 6 ) {
var ring=rc.getRingAtoms$I(r);
var nIndex=-1;
for (var i=0; i < ring.length; i++) {
if (ring[i] == atom) {
nIndex=i;
break;
}}
var enablerCount=0;
var opi=null;
var mi=null;
if (ring.length == 5) {
opi=Clazz.array(Integer.TYPE, [2]);
opi[0]=ring[(nIndex - 1 < 0) ? nIndex + 4 : nIndex - 1];
opi[1]=ring[(nIndex - 4 < 0) ? nIndex + 1 : nIndex - 4];
mi=Clazz.array(Integer.TYPE, [2]);
mi[0]=ring[(nIndex - 2 < 0) ? nIndex + 3 : nIndex - 2];
mi[1]=ring[(nIndex - 3 < 0) ? nIndex + 2 : nIndex - 3];
}if (ring.length == 6) {
opi=Clazz.array(Integer.TYPE, [3]);
opi[0]=ring[(nIndex - 1 < 0) ? nIndex + 5 : nIndex - 1];
opi[1]=ring[(nIndex - 3 < 0) ? nIndex + 3 : nIndex - 3];
opi[2]=ring[(nIndex - 5 < 0) ? nIndex + 1 : nIndex - 5];
mi=Clazz.array(Integer.TYPE, [2]);
mi[0]=ring[(nIndex - 2 < 0) ? nIndex + 4 : nIndex - 2];
mi[1]=ring[(nIndex - 4 < 0) ? nIndex + 2 : nIndex - 4];
}for (var i=0; i < ring.length; i++) if (atom != ring[i] && mol.getAtomicNo$I(ring[i]) == 7  && mol.getAtomPi$I(ring[i]) == 1 ) --enablerCount;

for (var i=0; i < opi.length; i++) {
var exoCyclicAtom=-1;
var exoCyclicBond=-1;
for (var j=0; j < mol.getConnAtoms$I(opi[i]); j++) {
if (!mol.isAromaticBond$I(mol.getConnBond$I$I(opi[i], j))) {
exoCyclicAtom=mol.getConnAtom$I$I(opi[i], j);
exoCyclicBond=mol.getConnBond$I$I(opi[i], j);
break;
}}
if (exoCyclicAtom != -1) {
if (mol.getAtomicNo$I(exoCyclicAtom) == 7 && mol.getAtomPi$I(exoCyclicAtom) == 0  && (mol.getConnAtoms$I(exoCyclicAtom) + mol.getAtomPi$I(exoCyclicAtom) <= 3)  && !C$.isStabilized$com_actelion_research_chem_StereoMolecule$I$Z(mol, exoCyclicAtom, false) ) {
++enablerCount;
continue;
}if (mol.getAtomicNo$I(exoCyclicAtom) == 8 && mol.getConnAtoms$I(exoCyclicAtom) == 1 ) {
enablerCount+=2;
continue;
}if (mol.isAromaticBond$I(exoCyclicBond)) {
for (var s=0; s < rc.getSize$(); s++) {
if (rc.isAromatic$I(s) && rc.isAtomMember$I$I(s, exoCyclicAtom) ) {
var ratom=rc.getRingAtoms$I(s);
for (var j=0; j < ratom.length; j++) {
if (mol.getAtomicNo$I(ratom[j]) == 7 && mol.getAtomPi$I(ratom[j]) == 1 ) {
--enablerCount;
break;
}}
break;
}}
}}}
for (var i=0; i < mi.length; i++) {
var exoCyclicAtom=-1;
for (var j=0; j < mol.getConnAtoms$I(mi[i]); j++) if (!mol.isAromaticBond$I(mol.getConnBond$I$I(mi[i], j))) exoCyclicAtom=mol.getConnAtom$I$I(mi[i], j);

if (mol.getAtomicNo$I(mi[i]) == 6) {
if (exoCyclicAtom != -1 && C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, exoCyclicAtom) != 0 ) --enablerCount;
} else if (mol.getAtomicNo$I(mi[i]) == 7) {
if (mol.getAtomPi$I(mi[i]) == 0 && (exoCyclicAtom == -1 || (!mol.isAromaticAtom$I(exoCyclicAtom) && C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, exoCyclicAtom) == 0 ) ) ) ++enablerCount;
}}
return enablerCount > 0;
}break;
}}
return false;
}if (mol.getAtomPi$I(atom) > 1) return false;
if (mol.getAtomPi$I(atom) == 1) {
var imineC=-1;
var supporterCount=0;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.getConnBondOrder$I$I(atom, i) == 2) {
if (mol.getAtomicNo$I(conn) != 6) return false;
imineC=conn;
continue;
}if (mol.getAtomicNo$I(conn) == 8) return false;
if (mol.getAtomicNo$I(conn) == 7) {
--supporterCount;
if (C$.isStabilized$com_actelion_research_chem_StereoMolecule$I$Z(mol, conn, false)) --supporterCount;
continue;
}if (mol.isAromaticAtom$I(conn)) --supporterCount;
}
if (imineC == -1) return false;
var aromaticNeighborCount=0;
for (var i=0; i < mol.getConnAtoms$I(imineC); i++) {
if (mol.getConnBondOrder$I$I(imineC, i) == 1) {
var conn=mol.getConnAtom$I$I(imineC, i);
if (C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) != 0) return false;
if (mol.isAromaticAtom$I(conn)) ++aromaticNeighborCount;
if (mol.getAtomicNo$I(conn) == 7 && !C$.isStabilized$com_actelion_research_chem_StereoMolecule$I$Z(mol, conn, true) ) ++supporterCount;
if (mol.getAtomicNo$I(conn) == 8 || mol.getAtomicNo$I(conn) == 16 ) --supporterCount;
}}
if (aromaticNeighborCount == 2) --supporterCount;
return (supporterCount >= 0);
}for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var conn=mol.getConnAtom$I$I(atom, i);
if (mol.isAromaticAtom$I(conn)) return false;
if (mol.getAtomicNo$I(conn) != 6) return false;
if (C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, conn) != 0) return false;
if (mol.getAtomPi$I(conn) != 0 && C$.isVinylogFakeOxo$com_actelion_research_chem_StereoMolecule$I(mol, conn) ) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'isVinylogFakeOxo$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
if (mol.getConnBondOrder$I$I(atom, i) != 1) {
var conn=mol.getConnAtom$I$I(atom, i);
for (var j=0; j < mol.getConnAtoms$I(conn); j++) if (mol.getConnBondOrder$I$I(conn, j) == 1 && C$.getFakeOxoCount$com_actelion_research_chem_StereoMolecule$I(mol, mol.getConnAtom$I$I(conn, j)) != 0 ) return true;

}}
return false;
}, 1);

Clazz.newMeth(C$, 'isAmphiphilic$com_actelion_research_chem_StereoMolecule',  function (mol) {
var amphiphilic=true;
var acidic=false;
var basic=false;
for (var at=0; at < mol.getAtoms$(); at++) {
if (C$.isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, at)) {
acidic=true;
}if (C$.isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, at)) {
basic=true;
}}
amphiphilic=basic && acidic ;
return amphiphilic;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:05:56 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
