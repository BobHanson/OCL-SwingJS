(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "TorsionRelevanceHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getRelevance$com_actelion_research_chem_StereoMolecule$IA',  function (mol, rotatableBond) {
mol.ensureHelperArrays$I(7);
var bondWeight=Clazz.array(Float.TYPE, [rotatableBond.length]);
for (var i=0; i < bondWeight.length; i++) {
if (mol.isRingBond$I(rotatableBond[i])) {
bondWeight[i]=0.33;
} else {
var atom1=mol.getBondAtom$I$I(0, rotatableBond[i]);
var atom2=mol.getBondAtom$I$I(1, rotatableBond[i]);
if (mol.getConnAtoms$I(atom1) == 1 || mol.getConnAtoms$I(atom2) == 1 ) {
bondWeight[i]=1.0 / mol.getAtoms$();
} else {
var atomCount=mol.getSubstituentSize$I$I(atom1, atom2);
bondWeight[i]=2.0 * Math.min(atomCount, mol.getAtoms$() - atomCount) / mol.getAtoms$();
}}}
return bondWeight;
}, 1);

Clazz.newMeth(C$, 'getRelevance$com_actelion_research_chem_StereoMolecule$ZA',  function (mol, isRotatableBond) {
mol.ensureHelperArrays$I(7);
var bondWeight=Clazz.array(Float.TYPE, [mol.getBonds$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
if (isRotatableBond == null  || isRotatableBond[bond] ) {
if (mol.isRingBond$I(bond)) {
bondWeight[bond]=0.33;
} else {
var atom1=mol.getBondAtom$I$I(0, bond);
var atom2=mol.getBondAtom$I$I(1, bond);
if (mol.getConnAtoms$I(atom1) == 1 || mol.getConnAtoms$I(atom2) == 1 ) {
bondWeight[bond]=1.0 / mol.getAtoms$();
} else {
var atomCount=mol.getSubstituentSize$I$I(atom1, atom2);
bondWeight[bond]=2.0 * Math.min(atomCount, mol.getAtoms$() - atomCount) / mol.getAtoms$();
}}}}
return bondWeight;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:36 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
