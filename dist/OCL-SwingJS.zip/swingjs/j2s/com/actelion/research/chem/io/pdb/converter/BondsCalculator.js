(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.converter"),I$=[[0,'com.actelion.research.chem.io.pdb.converter.MoleculeGrid','java.util.ArrayList','com.actelion.research.chem.conf.VDWRadii','com.actelion.research.chem.io.pdb.converter.GeometryCalculator','com.actelion.research.chem.Coordinates','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.AromaticityResolver','com.actelion.research.chem.Canonizer','com.actelion.research.util.IntQueue','com.actelion.research.calc.SingularValueDecomposition','java.util.HashSet']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondsCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['PARAMS','double[][]']]]

Clazz.newMeth(C$, 'createBonds$com_actelion_research_chem_StereoMolecule$Z$java_util_Map',  function (mol, lenient, atomToGroup) {
if (mol.getAllAtoms$() == 0) return;
var displayWarning=true;
var grid=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var potentialBonds=Clazz.new_($I$(2,1));
var neighborCount=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (!mol.isOrganicAtom$I(i)) continue;
var set=grid.getNeighbours$com_actelion_research_chem_Coordinates$D$Z(mol.getAtomCoordinates$I(i), 3.2, false);
for (var j, $j = set.iterator$(); $j.hasNext$()&&((j=($j.next$()).intValue$()),1);) {
if (i >= j) continue;
if (!mol.isOrganicAtom$I(j)) continue;
var dist=Math.sqrt(mol.getCoordinates$I(i).distanceSquared$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(j)));
var idealDist=$I$(3).COVALENT_RADIUS[mol.getAtomicNo$I(i)] + $I$(3).COVALENT_RADIUS[mol.getAtomicNo$I(j)];
if (atomToGroup != null ) {
if (!C$.match$S$S(atomToGroup.get$O(Integer.valueOf$I(i)), atomToGroup.get$O(Integer.valueOf$I(j))) || (mol.getAllAtoms$() > 200 && ((j - i) > 12 && (j - i) > (mol.getAllAtoms$()/50|0) ) ) ) {
if (dist > idealDist + 0.45 ) continue;
potentialBonds.add$O(Clazz.array(Integer.TYPE, -1, [i, j]));
continue;
}} else if (dist > idealDist + 0.45 ) continue;
if (neighborCount[i] >= C$.maxNeighborCount$com_actelion_research_chem_StereoMolecule$I(mol, i) || neighborCount[j] >= C$.maxNeighborCount$com_actelion_research_chem_StereoMolecule$I(mol, j) ) {
if (!lenient) throw Clazz.new_(Clazz.load('Exception').c$$S,["Valence exceeded " + i + " or " + j ]);
if (!displayWarning) {
System.err.println$S("Valence exceeded " + i + " or " + j );
displayWarning=false;
}continue;
}try {
mol.addBond$I$I$I(i, j, 1);
++neighborCount[i];
++neighborCount[j];
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!lenient) throw e;
} else {
throw e;
}
}
}
}
if (potentialBonds.size$() < (mol.getAllAtoms$()/30|0)) {
for (var pair, $pair = potentialBonds.iterator$(); $pair.hasNext$()&&((pair=($pair.next$())),1);) {
try {
mol.addBond$I$I$I(pair[0], pair[1], 1);
++neighborCount[pair[0]];
++neighborCount[pair[1]];
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
if (!lenient) throw e;
} else {
throw e;
}
}
}
}}, 1);

Clazz.newMeth(C$, 'maxNeighborCount$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
var atomicNo=mol.getAtomicNo$I(atom);
return atomicNo == 5 ? 6 : atomicNo <= 7 ? 4 : atomicNo == 8 ? 2 : atomicNo == 9 ? 1 : atomicNo == 14 ? 4 : atomicNo == 15 ? 4 : atomicNo == 16 ? 4 : atomicNo == 17 ? 1 : atomicNo == 33 ? 5 : atomicNo == 34 ? 6 : atomicNo == 35 ? 6 : atomicNo == 52 ? 6 : atomicNo == 53 ? 6 : 8;
}, 1);

Clazz.newMeth(C$, 'match$S$S',  function (g1, g2) {
return g1.equals$O(g2);
}, 1);

Clazz.newMeth(C$, 'calculateBondOrders$com_actelion_research_chem_StereoMolecule$Z',  function (mol, lenient) {
var visited=Clazz.array(Boolean.TYPE, [mol.getAllBonds$()]);
mol.ensureHelperArrays$I(7);
var spOrder=Clazz.array(Integer.TYPE, [mol.getAllAtoms$()]);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (mol.getConnAtoms$I(atom) <= 1) {
spOrder[atom]=1;
} else if (mol.getConnAtoms$I(atom) == 2) {
var angle=$I$(4,"getAngle$com_actelion_research_chem_StereoMolecule$I$I$I",[mol, mol.getConnAtom$I$I(atom, 0), atom, mol.getConnAtom$I$I(atom, 1)]);
if (Math.abs(angle - 3.141592653589793) < 0.5235987755982988 ) spOrder[atom]=1;
 else spOrder[atom]=2;
} else if (mol.getConnAtoms$I(atom) == 3) {
var c=mol.getCoordinates$I(atom);
var u=c.subC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(mol.getConnAtom$I$I(atom, 0)));
var v=c.subC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(mol.getConnAtom$I$I(atom, 1)));
var w=c.subC$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(mol.getConnAtom$I$I(atom, 2)));
var normal=u.cross$com_actelion_research_chem_Coordinates(v);
if (normal.distSq$() > 0 ) {
var proj=normal.unitC$().dot$com_actelion_research_chem_Coordinates(w) / w.dist$();
if (Math.abs(proj) < 0.3 ) spOrder[atom]=2;
 else spOrder[atom]=3;
} else {
spOrder[atom]=3;
}}}
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (mol.getAllConnAtoms$I(atom) == 2) {
} else if (mol.getAllConnAtoms$I(atom) == 3) {
var a;
var b;
var a1=mol.getConnAtom$I$I(atom, 0);
var a2=mol.getConnAtom$I$I(atom, 1);
var a3=mol.getConnAtom$I$I(atom, 2);
if (mol.getAtomicNo$I(atom) == 6 && spOrder[atom] == 2 ) {
if (mol.getAtomRingSize$I(atom) > 0) continue;
if ((mol.getAtomicNo$I(a2) == 8 && mol.getAtomicNo$I(a3) == 8  && mol.getAllConnAtoms$I(a2) == 1  && mol.getAllConnAtoms$I(a3) == 1 ) || (mol.getAtomicNo$I(a1) == 8 && mol.getAtomicNo$I(a3) == 8  && mol.getAllConnAtoms$I(a1) == 1  && mol.getAllConnAtoms$I(a3) == 1 ) || (mol.getAtomicNo$I(a1) == 8 && mol.getAtomicNo$I(a2) == 8  && mol.getAllConnAtoms$I(a1) == 1  && mol.getAllConnAtoms$I(a2) == 1 )  ) {
mol.setBondOrder$I$I(C$.shortestBond$com_actelion_research_chem_StereoMolecule$I$I$Z(mol, atom, 8, false), 2);
continue;
}a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 8, 2, 0, 0);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, 8, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 16, 2, 0, 0);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, 8, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 7, 2, 0, 0);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, 8, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 16, 2, 0, 0);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, 16, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 7, 2, 0, 0);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, 16, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}if ((mol.getAtomicNo$I(a1) == 6 && mol.getAtomicNo$I(a2) == 7  && mol.getAtomicNo$I(a3) == 7  && mol.getAllConnAtoms$I(a2) == 1  && mol.getAllConnAtoms$I(a3) == 1 ) || (mol.getAtomicNo$I(a1) == 7 && mol.getAtomicNo$I(a2) == 6  && mol.getAtomicNo$I(a3) == 7  && mol.getAllConnAtoms$I(a1) == 1  && mol.getAllConnAtoms$I(a3) == 1 ) || (mol.getAtomicNo$I(a1) == 7 && mol.getAtomicNo$I(a2) == 7  && mol.getAtomicNo$I(a3) == 6  && mol.getAllConnAtoms$I(a1) == 1  && mol.getAllConnAtoms$I(a2) == 1 )  ) {
mol.setBondOrder$I$I(C$.shortestBond$com_actelion_research_chem_StereoMolecule$I$I$Z(mol, atom, 7, true), 2);
continue;
}if (mol.getAtomicNo$I(a1) == 7 && mol.getAtomicNo$I(a2) == 7  && mol.getAtomicNo$I(a3) == 7 ) {
if (mol.getConnAtoms$I(a1) == 2 && mol.getConnAtoms$I(a2) == 1  && mol.getConnAtoms$I(a3) == 1 ) {
if (mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a2)) < mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a3)) ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 1), 2);
continue;
} else {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 2), 2);
continue;
}} else if (mol.getConnAtoms$I(a1) == 1 && mol.getConnAtoms$I(a2) == 2  && mol.getConnAtoms$I(a3) == 1 ) {
if (mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a1)) < mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a3)) ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 0), 2);
continue;
} else {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 2), 2);
continue;
}} else if (mol.getConnAtoms$I(a1) == 1 && mol.getConnAtoms$I(a2) == 1  && mol.getConnAtoms$I(a3) == 2 ) {
if (mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a1)) < mol.getCoordinates$I(atom).distSquareTo$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(a2)) ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 0), 2);
continue;
} else {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 1), 2);
continue;
}}}} else if (mol.getAtomicNo$I(atom) == 7) {
a=C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, atom, 6, 2, 8, 1);
b=C$.connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a, 8, 1);
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}for (var j=0; j < mol.getAllConnAtoms$I(atom); j++) {
if (mol.getAtomicNo$I(a1) == 8 && mol.getAllConnAtoms$I(a1) == 1  && mol.getAtomicNo$I(a2) == 8  && mol.getAllConnAtoms$I(a2) == 1 ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 0), 2);
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 1), 2);
} else if (mol.getAtomicNo$I(a1) == 8 && mol.getAllConnAtoms$I(a1) == 1  && mol.getAtomicNo$I(a3) == 8  && mol.getAllConnAtoms$I(a3) == 1 ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 0), 2);
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 2), 2);
} else if (mol.getAtomicNo$I(a2) == 8 && mol.getAllConnAtoms$I(a2) == 1  && mol.getAtomicNo$I(a3) == 8  && mol.getAllConnAtoms$I(a3) == 1 ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 1), 2);
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, 2), 2);
}}
if (a >= 0 && b >= 0 ) {
mol.setBondOrder$I$I(b, 2);
continue;
}}} else if (mol.getAllConnAtoms$I(atom) == 4) {
if (mol.getAtomicNo$I(atom) == 16) {
var count=0;
for (var j=0; count < 2 && j < mol.getAllConnAtoms$I(atom) ; j++) {
if (mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, j)) == 8 && mol.getAllConnAtoms$I(mol.getConnAtom$I$I(atom, j)) == 1 ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, j), 2);
++count;
}}
for (var j=0; count < 2 && j < mol.getAllConnAtoms$I(atom) ; j++) {
if (mol.getAtomicNo$I(mol.getConnAtom$I$I(atom, j)) == 7 && mol.getAllConnAtoms$I(mol.getConnAtom$I$I(atom, j)) == 1 ) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, j), 2);
++count;
}}
} else if (mol.getAtomicNo$I(atom) == 15) {
}}}
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
var a1=mol.getBondAtom$I$I(0, bond);
var a2=mol.getBondAtom$I$I(1, bond);
if (mol.isRingBond$I(bond)) continue;
if (mol.getImplicitHydrogens$I(a1) == 0 || mol.getImplicitHydrogens$I(a2) == 0 ) continue;
if (!C$.isPlanar$com_actelion_research_chem_StereoMolecule$I$I(mol, a1, a2)) continue;
var order=C$.getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I(mol, a1, a2);
if (order > 3.0  && spOrder[a1] == 1  && spOrder[a2] == 1  && mol.getImplicitHydrogens$I(a1) >= 2  && mol.getImplicitHydrogens$I(a2) >= 2 ) {
mol.setBondOrder$I$I(bond, 3);
visited[bond]=true;
} else if (order > 2.6  && spOrder[a1] <= 2  && spOrder[a2] <= 2 ) {
mol.setBondOrder$I$I(bond, 2);
visited[bond]=true;
}}
mol.ensureHelperArrays$I(3);
var ringSet=mol.getRingSetSimple$();
var atomToRings=C$.getAtomToRings$com_actelion_research_chem_StereoMolecule(mol);
var isAromaticRing=Clazz.array(Boolean.TYPE, [ringSet.getSize$()]);
var normal=Clazz.new_($I$(5,1));
var cog=Clazz.new_($I$(5,1));
var coords=Clazz.array(Double.TYPE, [7, 3]);
for (var size=5; size <= 7; size++) for (var ringNo=0; ringNo < ringSet.getSize$(); ringNo++) {
var ringAtom=ringSet.getRingAtoms$I(ringNo);
if (ringAtom.length != size) continue;
var planar=true;
for (var i=0; i < ringAtom.length && planar ; i++) {
if ((mol.getAtomicNo$I(ringAtom[i]) == 6 || mol.getAtomicNo$I(ringAtom[i]) == 7 ) && spOrder[ringAtom[i]] != 2 ) planar=false;
if (mol.getConnAtoms$I(ringAtom[i]) > 3 || mol.getAtomicNo$I(ringAtom[i]) > 16 ) planar=false;
}
if (!planar) continue;
C$.calculateNearestPlane$com_actelion_research_chem_StereoMolecule$IA$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$DAA(mol, ringAtom, cog, normal, coords);
planar=true;
for (var i=0; i < ringAtom.length && planar ; i++) if (Math.abs(normal.x * coords[i][0] + normal.y * coords[i][1] + normal.z * coords[i][2]) > (size == 5 ? 0.05 : 0.1) ) planar=false;

if (!planar) continue;
if (ringAtom.length == 5) {
var start=-1;
var posN=Clazz.array(Integer.TYPE, -1, [-1, -1]);
var ok=true;
for (var i=0; ok && i < ringAtom.length ; i++) {
if (mol.getAtomicNo$I(ringAtom[i]) == 6 && mol.getAllConnAtoms$I(ringAtom[i]) == 3 ) {
start=i;
} else if (mol.getAllConnAtoms$I(ringAtom[i]) != 2) ok=false;
 else if (mol.getAtomicNo$I(ringAtom[i]) == 7) {
if (posN[0] < 0) posN[0]=i;
 else if (posN[1] < 0) posN[1]=i;
 else ok=false;
}}
if (ok && start >= 0  && posN[1] >= 0 ) {
if ((start + 2) % 5 == posN[0] && (start + 4) % 5 == posN[1] ) {
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[start], ringAtom[(start + 1) % 5]), 2);
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[(start + 3) % 5], ringAtom[(start + 4) % 5]), 2);
continue;
} else if ((start + 2) % 5 == posN[1] && (start + 4) % 5 == posN[0] ) {
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[start], ringAtom[(start + 1) % 5]), 2);
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[(start + 3) % 5], ringAtom[(start + 4) % 5]), 2);
continue;
} else if ((start + 3) % 5 == posN[0] && (start + 1) % 5 == posN[1] ) {
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[start], ringAtom[(start + 4) % 5]), 2);
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[(start + 1) % 5], ringAtom[(start + 2) % 5]), 2);
continue;
} else if ((start + 3) % 5 == posN[1] && (start + 1) % 5 == posN[0] ) {
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[start], ringAtom[(start + 4) % 5]), 2);
mol.setBondOrder$I$I(mol.getBond$I$I(ringAtom[(start + 1) % 5], ringAtom[(start + 2) % 5]), 2);
continue;
}}}var start=-1;
var nElectrons=0;
var nAmbiguousN=0;
var nAmbiguousC=0;
for (var i=0; i < ringAtom.length; i++) {
var a1=ringAtom[(i) % ringAtom.length];
var a2=ringAtom[(i + 1) % ringAtom.length];
var a0=ringAtom[(i - 1 + ringAtom.length) % ringAtom.length];
var bnd1=mol.getBond$I$I(a1, a2);
var bnd2=mol.getBond$I$I(a1, a0);
if (mol.getAtomicNo$I(a1) == 6) {
if (mol.getAllConnAtoms$I(a1) == 3 && (C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, a1, 8, -1, 0, 0) >= 0 || C$.connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I(mol, a1, 16, -1, 0, 0) >= 0 ) ) {
var valence=mol.getConnBondOrder$I$I(a1, 0) + mol.getConnBondOrder$I$I(a1, 1) + mol.getConnBondOrder$I$I(a1, 2) ;
if (valence == 4 && (mol.getBondOrder$I(bnd1) == 2 || mol.getBondOrder$I(bnd2) == 2 ) ) ++nElectrons;
 else if (valence == 4) nElectrons+=0;
 else {
++nAmbiguousC;
++nElectrons;
}} else {
if (mol.getConnAtoms$I(a1) == 3 && start < 0 ) start=i;
++nElectrons;
}} else if (mol.getAtomicNo$I(a1) == 7) {
if (mol.getConnAtoms$I(a1) == 3) {
nElectrons+=2;
} else if (mol.getConnAtoms$I(a1) == 2) {
++nAmbiguousN;
++nElectrons;
} else {
++nElectrons;
}} else {
nElectrons+=2;
}if (mol.getBondOrder$I(bnd2) > 1) start=i;
 else if (mol.getImplicitHydrogens$I(a1) > 0 && mol.getImplicitHydrogens$I(a0) > 0  && (mol.getAtomRingBondCount$I(a1) == 2 || mol.getAtomRingBondCount$I(a0) == 2 ) ) {
if (mol.getConnAtoms$I(a1) == 3 || mol.getConnAtoms$I(a0) == 3 ) start=i;
 else if (start < 0) start=i;
}}
var nPyroles=0;
var nOxo=0;
var diff=nElectrons % 4 - 2;
if (diff < 0) {
nPyroles+=Math.min(-diff, Math.max(0, nAmbiguousN));
nElectrons+=nPyroles;
} else if (diff > 0) {
nOxo+=Math.min(diff, Math.max(0, nAmbiguousC));
nElectrons-=nOxo;
}if (nElectrons % 4 != 2) {
if (ringAtom.length == 3) continue;
var ok=false;
if (diff > 0) {
for (var i=0; i < ringAtom.length; i++) {
if (mol.getAtomicNo$I(ringAtom[i]) == 7) {
ok=true;
}}
}if (!ok) {
if (!lenient) throw Clazz.new_(Clazz.load('Exception').c$$S,["Huckel\'s rule not verified"]);
continue;
}}isAromaticRing[ringNo]=true;
}

var copy=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule,[mol]);
var delocalizedBondsCount=0;
var exoBondConversionCount=0;
mol.ensureHelperArrays$I(1);
var needsChargeCorrection=false;
var isAromaticBond=Clazz.array(Boolean.TYPE, [mol.getAllBonds$()]);
for (var r=0; r < isAromaticRing.length; r++) {
if (isAromaticRing[r]) {
var ringAtom=ringSet.getRingAtoms$I(r);
var ringBond=ringSet.getRingBonds$I(r);
for (var i=0; i < ringAtom.length; i++) {
for (var j=0; j < mol.getConnAtoms$I(ringAtom[i]); j++) {
if (mol.getConnBondOrder$I$I(ringAtom[i], j) == 2) {
var connAtom=mol.getConnAtom$I$I(ringAtom[i], j);
if (mol.getAtomicNo$I(connAtom) == 7 || mol.getAtomicNo$I(connAtom) == 8  || mol.getAtomicNo$I(connAtom) == 16 ) {
mol.setBondType$I$I(mol.getConnBond$I$I(ringAtom[i], j), 1);
++exoBondConversionCount;
}break;
}}
}
for (var rb, $rb = 0, $$rb = ringBond; $rb<$$rb.length&&((rb=($$rb[$rb])),1);$rb++) {
if (!isAromaticBond[rb]) {
mol.setBondOrder$I$I(rb, 1);
isAromaticBond[rb]=true;
++delocalizedBondsCount;
}}
}}
var isDelocalizedBond=isAromaticBond.clone$();
if (!Clazz.new_($I$(7,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).locateDelocalizedDoubleBonds$ZA$Z$Z(isAromaticBond, true, false)) {
copy.setFragment$Z(true);
for (var i=0; i < isDelocalizedBond.length; i++) {
if (isDelocalizedBond[i]) {
copy.setBondType$I$I(i, 8);
copy.setBondQueryFeature$I$I$Z(i, 8, true);
}}
var c1=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[copy]);
System.out.println$S("$$$ " + c1.getIDCode$() + "\t" + c1.getEncodedCoordinates$() + "\t" + delocalizedBondsCount + "\t" + exoBondConversionCount );
var c2=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
System.out.println$S("$$$ " + c2.getIDCode$() + "\t" + c2.getEncodedCoordinates$() + "\t\t" );
System.out.println$S("Could not aromatize all rings.");
}var aromaticAtoms=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
for (var i=0; i < ringSet.getSize$(); i++) {
if (isAromaticRing[i]) {
for (var atm, $atm = 0, $$atm = ringSet.getRingAtoms$I(i); $atm<$$atm.length&&((atm=($$atm[$atm])),1);$atm++) {
aromaticAtoms[atm]=true;
}
}}
for (var atom=0; atom < mol.getAllAtoms$(); atom++) {
if (spOrder[atom] == 2 && !aromaticAtoms[atom]  && mol.getAtomicNo$I(atom) == 6  && mol.getAllConnAtoms$I(atom) == 3  && mol.getImplicitHydrogens$I(atom) > 0  && C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, atom, -1, 2) >= 0 ) {
var a1=mol.getConnAtom$I$I(atom, 0);
var a2=mol.getConnAtom$I$I(atom, 1);
var a3=mol.getConnAtom$I$I(atom, 2);
var order1;
var order2;
var order3;
if (mol.getImplicitHydrogens$I(a1) == 0 && C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a1, -1, 2) >= 0 ) order1=1;
 else order1=C$.getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, a1);
if (mol.getImplicitHydrogens$I(a2) == 0 && C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a2, -1, 2) >= 0 ) order2=1;
 else order2=C$.getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, a2);
if (mol.getImplicitHydrogens$I(a3) == 0 && C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a3, -1, 2) >= 0 ) order3=1;
 else order3=C$.getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, a3);
var connBond=-1;
if (order1 > order2  && order1 > order3   && order1 > 1  ) {
connBond=0;
} else if (order2 > order1  && order2 > order3   && order2 > 1  ) {
connBond=1;
} else if (order3 > order1  && order3 > order2   && order3 > 1  ) {
connBond=2;
}if (connBond >= 0) {
mol.setBondOrder$I$I(mol.getConnBond$I$I(atom, connBond), 2);
}}}
var queue=Clazz.new_($I$(9,1));
for (var bond=0; bond < mol.getAllBonds$(); bond++) {
if (!visited[bond]) queue.push$I(bond);
while (!queue.isEmpty$()){
var bnd=queue.pop$();
if (visited[bnd]) continue;
visited[bnd]=true;
var atm1=mol.getBondAtom$I$I(0, bnd);
var atm2=mol.getBondAtom$I$I(1, bnd);
for (var j=0; j < mol.getAllConnAtoms$I(atm1); j++) {
queue.push$I(mol.getConnBond$I$I(atm1, j));
}
for (var j=0; j < mol.getAllConnAtoms$I(atm2); j++) {
queue.push$I(mol.getConnBond$I$I(atm2, j));
}
var order=C$.getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I(mol, atm1, atm2);
if (order > 2  && !aromaticAtoms[atm1]  && !aromaticAtoms[atm2] ) {
if (mol.getAtomPi$I(atm1) != 0) continue;
if (mol.getAtomPi$I(atm2) != 0) continue;
if (mol.getAtomicNo$I(atm1) == 16 && mol.getAllConnAtoms$I(atm1) <= 2 ) continue;
if (mol.getAtomicNo$I(atm2) == 16 && mol.getAllConnAtoms$I(atm2) <= 2 ) continue;
var freeValence1=C$.getMaxFreeValence$com_actelion_research_chem_StereoMolecule$I(mol, atm1);
var freeValence2=C$.getMaxFreeValence$com_actelion_research_chem_StereoMolecule$I(mol, atm2);
var aligned=spOrder[atm1] == 1 && spOrder[atm2] == 1 ;
if (order > 3.0  && freeValence1 > 1  && freeValence2 > 1  && aligned ) {
mol.setBondOrder$I$I(bnd, 3);
} else if (freeValence1 > 0 && freeValence2 > 0 ) {
if ((mol.getAtomicNo$I(atm1) == 6 && mol.getAtomicNo$I(atm2) == 6 ) && !C$.isPlanar$com_actelion_research_chem_StereoMolecule$I$I(mol, atm1, atm2) ) continue;
if (mol.getAtomicNo$I(atm1) == 6 && spOrder[atm1] > 2 ) continue;
if (mol.getAtomicNo$I(atm2) == 6 && spOrder[atm2] > 2 ) continue;
mol.setBondOrder$I$I(bnd, 2);
}}}
}
if (needsChargeCorrection) {
mol.ensureHelperArrays$I(1);
for (var atom=0; atom < mol.getAtoms$(); atom++) if ((mol.getAtomicNo$I(atom) == 7 || mol.getAtomicNo$I(atom) == 8 ) && mol.getAtomCharge$I(atom) == 0  && mol.getOccupiedValence$I(atom) > mol.getDefaultMaxValenceUncharged$I(atom) ) mol.setAtomCharge$I$I(atom, 1);

}}, 1);

Clazz.newMeth(C$, 'calculateNearestPlane$com_actelion_research_chem_StereoMolecule$IA$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates$DAA',  function (mol, atom, cog, n, coords) {
cog.set$D$D$D(0, 0, 0);
for (var i=0; i < atom.length; i++) cog.add$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(atom[i]));

cog.scale$D(1.0 / atom.length);
for (var i=0; i < atom.length; i++) {
coords[i][0]=mol.getAtomX$I(atom[i]) - cog.x;
coords[i][1]=mol.getAtomY$I(atom[i]) - cog.y;
coords[i][2]=mol.getAtomZ$I(atom[i]) - cog.z;
}
var squareMatrix=Clazz.array(Double.TYPE, [3, 3]);
for (var i=0; i < atom.length; i++) for (var j=0; j < 3; j++) for (var k=0; k < 3; k++) squareMatrix[j][k]+=coords[i][j] * coords[i][k];



var svd=Clazz.new_($I$(10,1).c$$DAA$com_actelion_research_calc_ProgressListener$com_actelion_research_calc_ThreadMaster,[squareMatrix, null, null]);
var S=svd.getSingularValues$();
var minIndex=0;
for (var i=1; i < 3; i++) if (S[i] < S[minIndex] ) minIndex=i;

var U=svd.getU$();
n.x=U[0][minIndex];
n.y=U[1][minIndex];
n.z=U[2][minIndex];
}, 1);

Clazz.newMeth(C$, 'getAtomToRings$com_actelion_research_chem_StereoMolecule',  function (mol) {
var atomToRings=Clazz.array($I$(2), [mol.getAllAtoms$()]);
var ringSet=mol.getRingSetSimple$();
for (var r=0; r < ringSet.getSize$(); r++) {
var ringAtom=ringSet.getRingAtoms$I(r);
for (var atom, $atom = 0, $$atom = ringAtom; $atom<$$atom.length&&((atom=($$atom[$atom])),1);$atom++) {
if (atomToRings[atom] == null ) atomToRings[atom]=Clazz.new_($I$(2,1));
atomToRings[atom].add$O(Integer.valueOf$I(r));
}
}
return atomToRings;
}, 1);

Clazz.newMeth(C$, 'aromatize$com_actelion_research_chem_StereoMolecule$java_util_Set$java_util_Set',  function (mol, aromaticAtoms, aromaticBonds) {
var atomToRings=C$.getAtomToRings$com_actelion_research_chem_StereoMolecule(mol);
var ringSet=mol.getRingSetSimple$();
return C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$java_util_Set$java_util_Set(mol, atomToRings, ringSet, aromaticAtoms, aromaticBonds);
}, 1);

Clazz.newMeth(C$, 'aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$java_util_Set$java_util_Set',  function (mol, atomToRings, ringSet, aromaticAtoms, aromaticBonds) {
var aromaticRings=Clazz.array(Boolean.TYPE, [ringSet.getSize$()]);
for (var i=0; i < ringSet.getSize$(); i++) {
var isAromatic=true;
var ringSize=ringSet.getRingSize$I(i);
for (var j=-1; j < ringSize; j++) {
var ringAtom=ringSet.getRingAtoms$I(i);
var a1=j == -1 ? ringAtom[ringSize - 1] : ringAtom[j];
var a2=j == ringSize - 1 ? ringAtom[0] : ringAtom[j + 1];
var b=mol.getBond$I$I(a1, a2);
if (!aromaticBonds.contains$O(Integer.valueOf$I(b))) {
isAromatic=false;
}}
aromaticRings[i]=isAromatic;
}
var nonAromaticAtoms=Clazz.new_($I$(11,1));
for (var i=0; i < mol.getAllAtoms$(); i++) nonAromaticAtoms.add$O(Integer.valueOf$I(i));

nonAromaticAtoms.removeAll$java_util_Collection(aromaticAtoms);
var ok=true;
for (var i=0; i < aromaticRings.length; i++) {
if (aromaticRings[i]) {
var success=C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, i, aromaticRings, nonAromaticAtoms, Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]), 0, ringSet.getRingSize$I(i) % 2, Clazz.new_($I$(2,1)), true);
if (!success) success=C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, i, aromaticRings, nonAromaticAtoms, Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]), 0, ringSet.getRingSize$I(i) % 2, Clazz.new_($I$(2,1)), false);
if (!success) {
System.out.println$S("Could not aromatize ring " + i);
aromaticRings[i]=false;
ok=false;
}}}
return ok;
}, 1);

Clazz.newMeth(C$, 'aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z',  function (mol, atomToRings, ringSet, index, aromatic, nonAromaticAtoms, visited, seed, left, bondsMade, easy) {
var ring=ringSet.getRingAtoms$I(index);
var allVisited=true;
var bestSeed=-1;
for (var i=0; i < ring.length; i++) {
if (!visited[ring[(seed + i) % ring.length]]) {
if (bestSeed < 0) bestSeed=seed + i;
allVisited=false;
}}
if (allVisited) {
return true;
} else {
seed=bestSeed;
}var a=ring[seed % ring.length];
var ap=ring[(seed + 1) % ring.length];
if (visited[a]) {
return C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, index, aromatic, nonAromaticAtoms, visited, seed + 1, left, bondsMade, easy);
} else {
for (var j=-1; j < mol.getAllConnAtoms$I(a); j++) {
var a2=j == -1 ? ap : mol.getConnAtom$I$I(a, j);
if (visited[a2]) continue;
if (j >= 0 && a2 == ap ) continue;
if (nonAromaticAtoms.contains$O(Integer.valueOf$I(a2))) continue;
if (nonAromaticAtoms.contains$O(Integer.valueOf$I(a))) continue;
if (mol.getAtomicNo$I(a) == 8 || mol.getAtomicNo$I(a) == 16 ) continue;
if (mol.getAtomicNo$I(a2) == 8 || mol.getAtomicNo$I(a2) == 16 ) continue;
if (easy && mol.getFreeValence$I(a) <= 0 ) continue;
if (easy && mol.getFreeValence$I(a2) <= 0 ) continue;
if (C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a, -1, 2) >= 0) continue;
if (C$.connected$com_actelion_research_chem_StereoMolecule$I$I$I(mol, a2, -1, 2) >= 0) continue;
visited[a]=visited[a2]=true;
var b=mol.getBond$I$I(a, a2);
mol.setBondOrder$I$I(b, 2);
var trackBondsMade=Clazz.new_($I$(2,1));
var success=C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, index, aromatic, nonAromaticAtoms, visited, seed + 1, left, trackBondsMade, easy);
if (success) {
var rings=atomToRings[a2];
if (rings.size$() > 1) {
for (var r, $r = rings.iterator$(); $r.hasNext$()&&((r=($r.next$()).intValue$()),1);) {
if (r != index && r >= 0  && r < aromatic.length  && aromatic[r] ) {
var newSeed;
for (newSeed=0; ringSet.getRingAtoms$I(r)[newSeed] != a2; newSeed++) {
}
success=C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, r, aromatic, nonAromaticAtoms, visited, newSeed, ringSet.getRingSize$I(r) % 2, trackBondsMade, easy);
if (!success) break;
}}
}}if (success) {
bondsMade.add$O(Integer.valueOf$I(b));
bondsMade.addAll$java_util_Collection(trackBondsMade);
return true;
} else {
visited[a]=visited[a2]=false;
mol.setBondOrder$I$I(b, 1);
for (var b2, $b2 = trackBondsMade.iterator$(); $b2.hasNext$()&&((b2=($b2.next$()).intValue$()),1);) {
mol.setBondOrder$I$I(b2, 1);
visited[mol.getBondAtom$I$I(0, b2)]=visited[mol.getBondAtom$I$I(1, b2)]=false;
}
}}
if (left > 0 && (mol.getAtomicNo$I(a) != 6) ) {
visited[a]=true;
var trackBondsMade=Clazz.new_($I$(2,1));
var success=C$.aromatize$com_actelion_research_chem_StereoMolecule$java_util_ArrayListA$com_actelion_research_chem_RingCollection$I$ZA$java_util_Set$ZA$I$I$java_util_List$Z(mol, atomToRings, ringSet, index, aromatic, nonAromaticAtoms, visited, seed + 1, left - 1, trackBondsMade, easy);
if (success) {
bondsMade.addAll$java_util_Collection(trackBondsMade);
return true;
} else {
visited[a]=false;
for (var b2, $b2 = trackBondsMade.iterator$(); $b2.hasNext$()&&((b2=($b2.next$()).intValue$()),1);) {
mol.setBondOrder$I$I(b2, 1);
visited[mol.getBondAtom$I$I(0, b2)]=visited[mol.getBondAtom$I$I(1, b2)]=false;
}
}}return false;
}}, 1);

Clazz.newMeth(C$, 'isPlanar$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, a1, a2) {
var ci=mol.getCoordinates$I(a1);
var u=null;
var v=null;
for (var i=0; v == null  && i < mol.getAllConnAtoms$I(a1) ; i++) {
if (u == null ) u=mol.getCoordinates$I(mol.getConnAtom$I$I(a1, i)).subC$com_actelion_research_chem_Coordinates(ci);
 else {
v=mol.getCoordinates$I(mol.getConnAtom$I$I(a1, i)).subC$com_actelion_research_chem_Coordinates(ci);
}}
for (var i=0; v == null  && i < mol.getAllConnAtoms$I(a2) ; i++) {
if (u == null ) u=mol.getCoordinates$I(mol.getConnAtom$I$I(a2, i)).subC$com_actelion_research_chem_Coordinates(ci);
 else {
v=mol.getCoordinates$I(mol.getConnAtom$I$I(a2, i)).subC$com_actelion_research_chem_Coordinates(ci);
}}
if (u == null ) return false;
var normal=u.cross$com_actelion_research_chem_Coordinates(v);
if (normal.distSq$() == 0 ) return false;
normal=normal.unitC$();
var cj=mol.getCoordinates$I(a2);
for (var k=0; k < mol.getAllConnAtoms$I(a2); k++) {
var ck=mol.getCoordinates$I(mol.getConnAtom$I$I(a2, k));
if (Math.abs(ck.subC$com_actelion_research_chem_Coordinates(cj).dot$com_actelion_research_chem_Coordinates(normal)) > 0.2 ) return false;
}
for (var k=0; k < mol.getAllConnAtoms$I(a1); k++) {
var ck=mol.getCoordinates$I(mol.getConnAtom$I$I(a1, k));
if (Math.abs(ck.subC$com_actelion_research_chem_Coordinates(cj).dot$com_actelion_research_chem_Coordinates(normal)) > 0.2 ) return false;
}
return true;
}, 1);

Clazz.newMeth(C$, 'getLikelyOrder$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, atm1, atm2) {
var k;
for (k=0; k < C$.PARAMS.length; k++) if ((C$.PARAMS[k][0] == mol.getAtomicNo$I(atm1)  && C$.PARAMS[k][1] == mol.getAtomicNo$I(atm2)  ) || (C$.PARAMS[k][1] == mol.getAtomicNo$I(atm1)  && C$.PARAMS[k][0] == mol.getAtomicNo$I(atm2)  ) ) break;

if (k >= C$.PARAMS.length) return 1;
var r=mol.getCoordinates$I(atm1).distance$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(atm2));
return Math.exp((C$.PARAMS[k][2] - r) / C$.PARAMS[k][3]);
}, 1);

Clazz.newMeth(C$, 'connectedAtom$com_actelion_research_chem_StereoMolecule$I$I$I$I$I',  function (mol, a, atomicNo, valence, otherAtomicNo, otherValence) {
 loop : for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var atm=mol.getConnAtom$I$I(a, i);
if (atomicNo > 0 && mol.getAtomicNo$I(atm) != atomicNo ) continue;
if (valence > 0 && mol.getAllConnAtoms$I(atm) != valence ) continue;
if (otherAtomicNo > 0 || otherValence > 0 ) {
for (var j=0; j < mol.getAllConnAtoms$I(atm); j++) {
var otherAtm=mol.getConnAtom$I$I(atm, j);
if (otherAtm == a) continue loop;
if (otherAtomicNo > 0 && mol.getAtomicNo$I(otherAtm) != otherAtomicNo ) continue loop;
if (otherValence > 0 && mol.getAllConnAtoms$I(otherAtm) != otherValence ) continue loop;
}
}return atm;
}
return -1;
}, 1);

Clazz.newMeth(C$, 'connectedBond$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, a, atomicNo, valence) {
if (a < 0) return -1;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var atm=mol.getConnAtom$I$I(a, i);
if (atomicNo > 0 && mol.getAtomicNo$I(atm) != atomicNo ) continue;
if (valence > 0 && mol.getAllConnAtoms$I(atm) != valence ) continue;
return mol.getConnBond$I$I(a, i);
}
return -1;
}, 1);

Clazz.newMeth(C$, 'shortestBond$com_actelion_research_chem_StereoMolecule$I$I$Z',  function (mol, a, toAtomicNo, privilegeRing) {
var bestBond=-1;
var bestDist=1.7976931348623157E308;
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var atm=mol.getConnAtom$I$I(a, i);
if (toAtomicNo > 0 && mol.getAtomicNo$I(atm) != toAtomicNo ) continue;
if (C$.getMaxFreeValence$com_actelion_research_chem_StereoMolecule$I(mol, atm) == 0) continue;
var dist=mol.getCoordinates$I(a).distance$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(atm));
if (privilegeRing && mol.isRingBond$I(mol.getConnBond$I$I(a, i)) ) dist-=2;
if (dist < bestDist ) {
bestDist=dist;
bestBond=mol.getConnBond$I$I(a, i);
}}
return bestBond;
}, 1);

Clazz.newMeth(C$, 'getMaxFreeValence$com_actelion_research_chem_StereoMolecule$I',  function (mol, a) {
return mol.getFreeValence$I(a) + mol.getImplicitHydrogens$I(a);
}, 1);

Clazz.newMeth(C$, 'connected$com_actelion_research_chem_StereoMolecule$I$I$I',  function (mol, a, atomicNo, bondOrder) {
for (var i=0; i < mol.getAllConnAtoms$I(a); i++) {
var atm=mol.getConnAtom$I$I(a, i);
if (atomicNo >= 0 && mol.getAtomicNo$I(atm) != atomicNo ) continue;
if (bondOrder > 0 && mol.getConnBondOrder$I$I(a, i) != bondOrder ) continue;
return atm;
}
return -1;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.PARAMS=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [6, 6, 1.523, 0.1855]), Clazz.array(Double.TYPE, -1, [6, 7, 1.47, 0.2458]), Clazz.array(Double.TYPE, -1, [6, 8, 1.41, 0.21]), Clazz.array(Double.TYPE, -1, [6, 16, 1.815, 0.069]), Clazz.array(Double.TYPE, -1, [7, 7, 1.381, 0.1919]), Clazz.array(Double.TYPE, -1, [7, 8, 1.31, 0.15]), Clazz.array(Double.TYPE, -1, [8, 8, 1.428, 0.0]), Clazz.array(Double.TYPE, -1, [8, 15, 1.696, 0.22]), Clazz.array(Double.TYPE, -1, [8, 16, 1.657, 0.24]), Clazz.array(Double.TYPE, -1, [16, 16, 2.024, 0.36])]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
