(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.RingBoolean','java.util.Arrays','com.actelion.research.chem.forcefield.mmff.type.Atom']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMFFMolecule", null, 'com.actelion.research.chem.StereoMolecule');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mRingArom','com.actelion.research.chem.forcefield.mmff.RingBoolean[]','mAtomTypes','int[]','+mHydrogenMap']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.superclazz.c$$com_actelion_research_chem_Molecule.apply(this,[mol]);C$.$init$.apply(this);
this.mHydrogenMap=this.getHandleHydrogenMap$();
var rings=this.getRingSet$();
this.mRingArom=Clazz.array($I$(1), [rings.getSize$()]);
$I$(2,"fill$OA$O",[this.mRingArom, $I$(1).NOT_SET]);
var allset=false;
var changed=true;
while (!allset && changed ){
allset=true;
changed=false;
for (var r=0; r < rings.getSize$(); r++) {
if (this.mRingArom[r] === $I$(1).NOT_SET ) {
this.mRingArom[r]=$I$(3).ringIsMMFFAromatic$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(this, r);
if (this.mRingArom[r] !== $I$(1).NOT_SET ) changed=true;
}if (this.mRingArom[r] === $I$(1).NOT_SET ) allset=false;
}
}
if (!allset) throw Clazz.new_(Clazz.load('com.actelion.research.chem.forcefield.mmff.BadRingAromException'));
this.mAtomTypes=Clazz.array(Integer.TYPE, [this.getAllAtoms$()]);
for (var i=0; i < this.mAtomTypes.length; i++) {
this.mAtomTypes[i]=-1;
this.mAtomTypes[i]=$I$(3).getType$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(this, i);
if (this.mAtomTypes[i] == 0) throw Clazz.new_(Clazz.load('com.actelion.research.chem.forcefield.mmff.BadAtomTypeException').c$$S,["Couldn\'t assign an atom type to atom " + i + " (" + this.getAtomLabel$I(i) + ")" ]);
}
}, 1);

Clazz.newMeth(C$, 'getAtomType$I',  function (a) {
return this.mAtomTypes[a];
});

Clazz.newMeth(C$, 'getHydrogenMap$',  function () {
return this.mHydrogenMap;
});

Clazz.newMeth(C$, 'ringIsMMFFAromatic$I',  function (r) {
return this.mRingArom[r] === $I$(1).TRUE ;
});

Clazz.newMeth(C$, 'isSetRingMMFFAromaticity$I',  function (r) {
return this.mRingArom[r] !== $I$(1).NOT_SET ;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
