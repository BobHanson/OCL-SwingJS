(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),p$1={},I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList','com.actelion.research.chem.forcefield.mmff.SortedPair',['com.actelion.research.chem.forcefield.mmff.Separation','.Relation']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "VanDerWaals", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['C',['da1','da2'],'D',['rstar_ij','well_depth'],'I',['a1t','a2t','a1','a2']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (table, mol, a1, a2) {
;C$.$init$.apply(this);
this.a1t=mol.getAtomType$I(a1);
this.a2t=mol.getAtomType$I(a2);
this.a1=a1;
this.a2=a2;
var rs=p$1.minimum$com_actelion_research_chem_forcefield_mmff_Tables.apply(this, [table]);
var wd=p$1.wellDepth$com_actelion_research_chem_forcefield_mmff_Tables$D.apply(this, [table, rs]);
this.da1=table.vdws.da$I(this.a1t);
this.da2=table.vdws.da$I(this.a2t);
if ((this.da1 == "D" && this.da2 == "A" ) || (this.da1 == "A" && this.da2 == "D" ) ) {
rs=rs * table.vdws.darad;
wd*=table.vdws.daeps;
}this.rstar_ij=rs;
this.well_depth=wd;
}, 1);

Clazz.newMeth(C$, 'minimum$com_actelion_research_chem_forcefield_mmff_Tables',  function (table) {
var rs1=table.vdws.r_star$I(this.a1t);
var rs2=table.vdws.r_star$I(this.a2t);
var da1=table.vdws.da$I(this.a1t);
var da2=table.vdws.da$I(this.a2t);
var gamma_ij=(rs1 - rs2) / (rs1 + rs2);
return (0.5 * (rs1 + rs2) * (1.0 + (((da1 == "D") || (da2 == "D") ) ? 0.0 : table.vdws.b * (1.0 - Math.exp(-(table.vdws.beta) * gamma_ij * gamma_ij )))) );
}, p$1);

Clazz.newMeth(C$, 'wellDepth$com_actelion_research_chem_forcefield_mmff_Tables$D',  function (table, rs) {
var gi1=table.vdws.g_i$I(this.a1t);
var gi2=table.vdws.g_i$I(this.a2t);
var alpha1=table.vdws.alpha_i$I(this.a1t);
var alpha2=table.vdws.alpha_i$I(this.a2t);
var ni1=table.vdws.n_i$I(this.a1t);
var ni2=table.vdws.n_i$I(this.a2t);
var rstar_ij2=rs * rs;
var c4=181.16;
return (c4 * gi1 * gi2 * alpha1 * alpha2  / ((Math.sqrt(alpha1 / ni1) + Math.sqrt(alpha2 / ni2)) * rstar_ij2 * rstar_ij2 * rstar_ij2 ));
}, p$1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var dist=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a1, this.a2]).length$();
var vdw1=1.07;
var vdw1m1=0.07000000000000006;
var vdw2=1.12;
var vdw2m1=0.1200000000000001;
var dist2=dist * dist;
var dist7=dist2 * dist2 * dist2 * dist ;
var aTerm=1.07 * this.rstar_ij / (dist + 0.07000000000000006 * this.rstar_ij);
var aTerm2=aTerm * aTerm;
var aTerm7=aTerm2 * aTerm2 * aTerm2 * aTerm ;
var rstar_ij2=this.rstar_ij * this.rstar_ij;
var rstar_ij7=rstar_ij2 * rstar_ij2 * rstar_ij2 * this.rstar_ij ;
var bTerm=1.12 * rstar_ij7 / (dist7 + 0.1200000000000001 * rstar_ij7) - 2.0;
return aTerm7 * bTerm * this.well_depth ;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var vdw1=1.07;
var vdw1m1=0.07000000000000006;
var vdw2=1.12;
var vdw2m1=0.1200000000000001;
var vdw2t7=7.840000000000001;
var dist=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.a1, this.a2]).length$();
var q=dist / this.rstar_ij;
var q2=q * q;
var q6=q2 * q2 * q2 ;
var q7=q6 * q;
var q7pvdw2m1=q7 + 0.1200000000000001;
var t=1.07 / (q + 1.07 - 1.0);
var t2=t * t;
var t7=t2 * t2 * t2 * t ;
var dE_dr=this.well_depth / this.rstar_ij * t7 * (-7.840000000000001 * q6 / (q7pvdw2m1 * q7pvdw2m1) + ((-7.840000000000001 / q7pvdw2m1 + 14.0) / (q + 0.07000000000000006)));
for (var i=0; i < 3; i++) {
var dGrad=0.01 * this.rstar_ij;
if (dist > 0.0 ) dGrad=dE_dr * (pos[3 * this.a1 + i] - pos[3 * this.a2 + i]) / dist;
grad[3 * this.a1 + i]+=dGrad;
grad[3 * this.a2 + i]-=dGrad;
}
});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation$D',  function (table, mol, sep, nonbondedCutoff) {
var vdws=Clazz.new_($I$(2,1));
for (var i=0; i < mol.getAllAtoms$(); i++) {
for (var j=i + 1; j < mol.getAllAtoms$(); j++) {
var atompair=Clazz.new_($I$(3,1).c$$I$I,[i, j]);
var relation=sep.get$com_actelion_research_chem_forcefield_mmff_SortedPair(atompair);
if ((relation === $I$(4).ONE_FOUR  || relation === $I$(4).ONE_X  ) && Clazz.new_($I$(1,1).c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I,[mol, i, j]).length$() < nonbondedCutoff  ) {
vdws.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I,[table, mol, i, j]));
}}
}
return vdws;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
