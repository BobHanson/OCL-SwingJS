(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.MolDistHistEncoder','java.util.StringTokenizer','com.actelion.research.chem.IDCodeParser','java.util.ArrayList','com.actelion.research.calc.ArrayUtilsCalc','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','com.actelion.research.chem.Coordinates','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.chem.descriptor.DescriptorEncoder','StringBuilder','com.actelion.research.chem.Canonizer','java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistVizEncoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['molDistHistEncoder','com.actelion.research.chem.descriptor.flexophore.MolDistHistEncoder']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.MolDistHistVizEncoder']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.molDistHistEncoder=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'readEncoded$S$S',  function (vizinfo, flexophore) {
var st=Clazz.new_($I$(2,1).c$$S,[vizinfo]);
var idcode=st.nextToken$();
var coord=st.nextToken$();
var mdh=this.molDistHistEncoder.decode$S(flexophore);
var parser=Clazz.new_($I$(3,1));
var ster=parser.getCompactMolecule$S$S(idcode, coord);
ster.ensureHelperArrays$I(7);
var cc=0;
var liPPNodeViz=Clazz.new_($I$(4,1));
var hasInevitablePPPoints=false;
while (st.hasMoreTokens$()){
var sArr=st.nextToken$();
if (sArr.equals$O("-1")) {
hasInevitablePPPoints=true;
break;
}var arrAtIndex=$I$(5).readIntArray$S(sArr);
var node=Clazz.new_([mdh.getNode$I(cc)],$I$(6,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode);
var arrCoordinates=Clazz.array($I$(7), [arrAtIndex.length]);
for (var i=0; i < arrAtIndex.length; i++) {
var x=ster.getAtomX$I(arrAtIndex[i]);
var y=ster.getAtomY$I(arrAtIndex[i]);
var z=ster.getAtomZ$I(arrAtIndex[i]);
arrCoordinates[i]=Clazz.new_($I$(7,1).c$$D$D$D,[x, y, z]);
node.addIndexOriginalAtom$I(arrAtIndex[i]);
}
var coordCenter=$I$(7).createBarycenter$com_actelion_research_chem_CoordinatesA(arrCoordinates);
node.setCoordinates$D$D$D(coordCenter.x, coordCenter.y, coordCenter.z);
liPPNodeViz.add$O(node);
++cc;
}
var ff=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_StereoMolecule,[ster]);
for (var i=0; i < ff.getAllAtoms$(); i++) {
var c=Clazz.new_([ster.getAtomX$I(i), ster.getAtomY$I(i), ster.getAtomZ$I(i)],$I$(7,1).c$$D$D$D);
ff.setCoordinates$I$com_actelion_research_chem_Coordinates(i, c);
}
var mdhv=Clazz.new_([mdh.getNumPPNodes$(), ff],$I$(9,1).c$$I$com_actelion_research_chem_Molecule3D);
for (var i=0; i < mdh.getNumPPNodes$(); i++) {
mdhv.addNode$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(liPPNodeViz.get$I(i));
}
for (var i=0; i < mdh.getNumPPNodes$(); i++) {
for (var j=i + 1; j < mdh.getNumPPNodes$(); j++) {
mdhv.setDistHist$I$I$BA(i, j, mdh.getDistHist$I$I(i, j));
}
}
if (hasInevitablePPPoints) {
var strInevitablePPPoints=st.nextToken$();
var de=Clazz.new_($I$(10,1));
var arrIndexInevitablePPPoints=de.decodeCounts$S(strInevitablePPPoints);
for (var i=0; i < arrIndexInevitablePPPoints.length; i++) {
mdhv.addMandatoryPharmacophorePoint$I(arrIndexInevitablePPPoints[i]);
}
}mdhv.realize$();
return mdhv;
});

Clazz.newMeth(C$, 'toStringVizInfoEncoded$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var sb=Clazz.new_($I$(11,1));
if (mdhv.molecule3D == null ) return null;
var molecule3D=$I$(9).finalizeMolecule$com_actelion_research_chem_Molecule3D(mdhv.molecule3D);
var liliOriginalIndex=Clazz.new_($I$(4,1));
for (var i=0; i < mdhv.getNumPPNodes$(); i++) {
var node=mdhv.getNode$I(i);
var liOriginalIndex=node.getListIndexOriginalAtoms$();
liliOriginalIndex.add$O(liOriginalIndex);
}
var mol=Clazz.new_($I$(8,1).c$$com_actelion_research_chem_Molecule3D,[molecule3D]);
mol.ensureHelperArrays$I(7);
var can=Clazz.new_($I$(12,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
var idcode=can.getIDCode$();
var coord=can.getEncodedCoordinates$Z(true);
var arrMap=can.getGraphIndexes$();
var nNonHAtoms=mol.getAtoms$();
for (var i=0; i < liliOriginalIndex.size$(); i++) {
var liOriginalIndex=liliOriginalIndex.get$I(i);
for (var j=0; j < liOriginalIndex.size$(); j++) {
var ind=(liOriginalIndex.get$I(j)).$c();
try {
if (ind < nNonHAtoms) {
liOriginalIndex.set$I$O(j, Integer.valueOf$I(arrMap[ind]));
} else {
liOriginalIndex.set$I$O(j, Integer.valueOf$I(ind));
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}
}
sb.append$S(idcode);
sb.append$S(" ");
sb.append$S(coord);
sb.append$S(" ");
for (var i=0; i < liliOriginalIndex.size$(); i++) {
sb.append$S($I$(5,"toString$java_util_Collection",[liliOriginalIndex.get$I(i)]));
if (i < liliOriginalIndex.size$() - 1) sb.append$S(" ");
}
var hsIndexInevitablePPPoints=mdhv.getHashSetIndexInevitablePPPoints$();
if (hsIndexInevitablePPPoints.size$() > 0) {
sb.append$S(" -1 ");
var de=Clazz.new_($I$(10,1));
var a=Clazz.array(Byte.TYPE, [hsIndexInevitablePPPoints.size$()]);
var cc=0;
for (var index, $index = hsIndexInevitablePPPoints.iterator$(); $index.hasNext$()&&((index=($index.next$()).intValue$()),1);) {
a[cc++]=(index|0);
}
var strEncodedInevitablePPPoints= String.instantialize(de.encodeCounts$BA(a), $I$(13).UTF_8);
sb.append$S(strEncodedInevitablePPPoints);
}return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
