(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[[0,'java.util.Arrays','java.net.URL']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ParserUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z',  function (is, n, out, andCloseInput, andCloseOutput) {
var toOut=(out != null );
var buflen=(Long.$gt(n,0 ) && Long.$lt(n,1024 )  ? Long.$ival(n) : 1024);
var buf=Clazz.array(Byte.TYPE, [buflen]);
var bytes=(out == null  ? Clazz.array(Byte.TYPE, [Long.$lt(n,0 ) ? 4096 : Long.$ival(n)]) : null);
var len=0;
var totalLen=0;
if (Long.$lt(n,0 )) n=2147483647;
while (Long.$lt(totalLen,n ) && (len=is.read$BA$I$I(buf, 0, buflen)) > 0 ){
totalLen+=len;
if (toOut) {
out.write$BA$I$I(buf, 0, len);
} else {
if (totalLen > bytes.length) bytes=$I$(1).copyOf$BA$I(bytes, totalLen * 2);
System.arraycopy$O$I$O$I$I(buf, 0, bytes, totalLen - len, len);
if (Long.$ne(n,2147483647 ) && totalLen + buflen > bytes.length ) buflen=bytes.length - totalLen;
}}
if (andCloseInput) {
try {
is.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
}if (toOut) {
if (andCloseOutput) try {
out.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
} else {
throw e;
}
}
return null;
}if (totalLen == bytes.length) return bytes;
buf=Clazz.array(Byte.TYPE, [totalLen]);
System.arraycopy$O$I$O$I$I(bytes, 0, buf, 0, totalLen);
return buf;
}, 1);

Clazz.newMeth(C$, 'getURLContentsAsString$S',  function (url) {
var b=C$.getURLContentsAsBytes$S(url);
return (b == null  ? null :  String.instantialize(b));
}, 1);

Clazz.newMeth(C$, 'getURLContentsAsBytes$S',  function (url) {
try {
if (url.indexOf$S("//") < 0) url="file:///" + url;
return C$.getLimitedStreamBytes$java_io_InputStream$J$java_io_OutputStream$Z$Z(Clazz.new_($I$(2,1).c$$S,[url]).openStream$(), -1, null, true, true);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
return null;
} else {
throw e;
}
}
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
