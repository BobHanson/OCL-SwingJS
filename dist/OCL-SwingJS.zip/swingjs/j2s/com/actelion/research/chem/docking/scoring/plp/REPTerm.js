(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.scoring.plp"),I$=[[0,'com.actelion.research.chem.Coordinates']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "REPTerm", null, null, 'com.actelion.research.chem.potentialenergy.PotentialEnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['recAtom','ligAtom'],'O',['ligand','com.actelion.research.chem.conf.Conformer','+receptor']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I',  function (receptor, ligand, recAtom, ligAtom) {
;C$.$init$.apply(this);
this.recAtom=recAtom;
this.ligAtom=ligAtom;
this.receptor=receptor;
this.ligand=ligand;
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I',  function (receptor, ligand, recAtom, ligAtom) {
return Clazz.new_(C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer$I$I,[receptor, ligand, recAtom, ligAtom]);
}, 1);

Clazz.newMeth(C$, 'getFGValue$DA',  function (gradient) {
var ci=this.receptor.getCoordinates$I(this.recAtom);
var ck=this.ligand.getCoordinates$I(this.ligAtom);
var cr=ci.subC$com_actelion_research_chem_Coordinates(ck);
var r2=cr.distSq$();
var grad=Clazz.new_($I$(1,1));
var energy=0.0;
if (r2 > 25.0 ) {
energy=0;
} else {
var prefactor=0.0;
var r=Math.sqrt(r2);
if (r < 3.2 ) {
prefactor=(-6.234374999999999) * (1.0 / r);
grad=cr.scaleC$D(prefactor);
energy=r * (-19.95) / 3.2 + 20.0;
} else {
prefactor=(-0.027777777777777783) * (1.0 / r);
grad=cr.scaleC$D(prefactor);
energy=-0.05 * (r - 3.2) / (1.7999999999999998) + 0.05;
}}gradient[3 * this.ligAtom]-=grad.x;
gradient[3 * this.ligAtom + 1]-=grad.y;
gradient[3 * this.ligAtom + 2]-=grad.z;
return energy;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
