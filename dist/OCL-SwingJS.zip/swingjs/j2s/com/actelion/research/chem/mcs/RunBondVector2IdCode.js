(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'java.util.concurrent.atomic.AtomicBoolean','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.mcs.BondVector2IdCode','java.util.concurrent.atomic.AtomicInteger','Thread','com.actelion.research.chem.properties.complexity.FragmentDefinedByBondsIdCode']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RunBondVector2IdCode", null, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id'],'O',['pipeInputFragIndexListsFromEFG','com.actelion.research.util.Pipeline','+pipeOutputFragmentDefinedByBondsIdCode','endOfRunReached','java.util.concurrent.atomic.AtomicBoolean','bondVector2IdCode','com.actelion.research.chem.mcs.BondVector2IdCode','processedFragments','java.util.concurrent.atomic.AtomicInteger']]]

Clazz.newMeth(C$, 'c$$I$com_actelion_research_util_Pipeline$com_actelion_research_util_Pipeline',  function (id, pipeInputFragIndexListsFromEFG, pipeOutputFragmentDefinedByBondsIdCode) {
;C$.$init$.apply(this);
this.id=id;
this.pipeInputFragIndexListsFromEFG=pipeInputFragIndexListsFromEFG;
this.pipeOutputFragmentDefinedByBondsIdCode=pipeOutputFragmentDefinedByBondsIdCode;
this.endOfRunReached=Clazz.new_($I$(1,1).c$$Z,[false]);
}, 1);

Clazz.newMeth(C$, 'init$com_actelion_research_chem_StereoMolecule',  function (mol) {
var molCopy=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[mol]);
molCopy.ensureHelperArrays$I(31);
this.bondVector2IdCode=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[molCopy]);
this.processedFragments=Clazz.new_($I$(4,1));
});

Clazz.newMeth(C$, 'run$',  function () {
try {
while (!this.pipeInputFragIndexListsFromEFG.wereAllDataFetched$()){
var livIndexBond=this.pipeInputFragIndexListsFromEFG.pollData$();
if (livIndexBond == null ) {
try {
$I$(5).sleep$J(10);
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
e.printStackTrace$();
} else {
throw e;
}
}
continue;
}try {
var livIdCode=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_properties_complexity_IBitArray,[livIndexBond]);
var idcodeFrag=this.bondVector2IdCode.getFragmentIdCode$com_actelion_research_chem_properties_complexity_IBitArray(livIndexBond);
livIdCode.setIdCode$S(idcodeFrag);
this.pipeOutputFragmentDefinedByBondsIdCode.addData$O(livIdCode);
} catch (e) {
e.printStackTrace$();
} finally {
this.processedFragments.incrementAndGet$();
}
}
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
} finally {
this.endOfRunReached.set$Z(true);
}
});

Clazz.newMeth(C$, 'isEndOfRunReached$',  function () {
return this.endOfRunReached.get$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:44 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
