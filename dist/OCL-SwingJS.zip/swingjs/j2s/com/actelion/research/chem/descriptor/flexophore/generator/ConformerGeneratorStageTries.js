(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),p$1={},I$=[[0,'org.openmolecules.chem.conf.gen.ConformerGenerator','org.openmolecules.chem.conf.gen.RigidFragmentCache']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ConformerGeneratorStageTries");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.recentException=null;
},1);

C$.$fields$=[['I',['initializationStage','ccGeneratedConformers'],'J',['seed'],'O',['conformerGenerator','org.openmolecules.chem.conf.gen.ConformerGenerator','recentException','Exception','molInPlace','com.actelion.research.chem.Molecule3D']]]

Clazz.newMeth(C$, 'resetInitializationStage$',  function () {
this.initializationStage=0;
});

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.seed=123456789;
this.conformerGenerator=Clazz.new_($I$(1,1).c$$J$Z,[this.seed, false]);
this.conformerGenerator.setTimeOut$J(180000);
$I$(2).getDefaultInstance$().loadDefaultCache$();
this.initializationStage=0;
}, 1);

Clazz.newMeth(C$, 'initializeHelper',  function () {
this.ccGeneratedConformers=0;
}, p$1);

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (threadMaster) {
this.conformerGenerator.setThreadMaster$com_actelion_research_calc_ThreadMaster(threadMaster);
});

Clazz.newMeth(C$, 'incrementInitializationStage$',  function () {
++this.initializationStage;
if (this.initializationStage > 3) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Maximum initialization stage exceeded!"]);
}return p$1.initializeConformers.apply(this, []);
});

Clazz.newMeth(C$, 'canIncrementInitializationStage$',  function () {
if (this.initializationStage < 3) {
return true;
}return false;
});

Clazz.newMeth(C$, 'getPotentialConformerCount$',  function () {
return this.conformerGenerator.getPotentialConformerCount$();
});

Clazz.newMeth(C$, 'setMolecule$com_actelion_research_chem_Molecule3D',  function (molInPlace) {
this.molInPlace=molInPlace;
this.resetInitializationStage$();
return p$1.initializeConformers.apply(this, []);
});

Clazz.newMeth(C$, 'initializeConformers',  function () {
p$1.initializeHelper.apply(this, []);
var successfulInitialization=false;
var exception=null;
while (!successfulInitialization){
try {
if (this.initializationStage == 0) {
successfulInitialization=this.conformerGenerator.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(this.molInPlace, 3, 100000, false);
} else if (this.initializationStage == 1) {
this.conformerGenerator=Clazz.new_($I$(1,1));
successfulInitialization=this.conformerGenerator.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(this.molInPlace, 3, 100000, true);
} else if (this.initializationStage == 2) {
this.conformerGenerator=Clazz.new_($I$(1,1));
successfulInitialization=this.conformerGenerator.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(this.molInPlace, 1, 100000, true);
} else if (this.initializationStage == 3) {
this.conformerGenerator=Clazz.new_($I$(1,1));
successfulInitialization=this.conformerGenerator.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(this.molInPlace, 4, 100000, true);
} else if (this.initializationStage > 3) {
break;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
exception=e;
} else {
throw e;
}
}
if (!successfulInitialization) {
System.out.println$S("Initialization failed for stage " + this.initializationStage);
if (this.canIncrementInitializationStage$()) {
if (!this.incrementInitializationStage$()) break;
} else {
break;
}}}
if (!successfulInitialization) {
System.err.println$S("CreatorMolDistHistViz initializeConformers(...) failed for " + this.molInPlace.getIDCode$());
this.recentException=exception;
}return successfulInitialization;
}, p$1);

Clazz.newMeth(C$, 'getRecentException$',  function () {
return this.recentException;
});

Clazz.newMeth(C$, 'generateConformerAndSetCoordinates$I$com_actelion_research_chem_Molecule3D',  function (nAtoms, molInPlace) {
var nextConformerAvailable=false;
var conformer=this.conformerGenerator.getNextConformer$();
var ccTries=0;
while (conformer == null  && this.ccGeneratedConformers == 0 ){
if (ccTries > 10) {
if (this.canIncrementInitializationStage$()) {
this.incrementInitializationStage$();
conformer=this.conformerGenerator.getNextConformer$();
ccTries=0;
} else {
break;
}} else {
this.injectNewSeed$();
conformer=this.conformerGenerator.getNextConformer$();
++ccTries;
}}
if (conformer != null ) {
++this.ccGeneratedConformers;
for (var i=0; i < nAtoms; i++) {
var x=conformer.getX$I(i);
var y=conformer.getY$I(i);
var z=conformer.getZ$I(i);
molInPlace.setAtomX$I$D(i, x);
molInPlace.setAtomY$I$D(i, y);
molInPlace.setAtomZ$I$D(i, z);
}
nextConformerAvailable=true;
} else {
}return nextConformerAvailable;
});

Clazz.newMeth(C$, 'injectNewSeed$',  function () {
this.seed=Clazz.new_(java.util.Date).getTime$();
this.conformerGenerator=Clazz.new_($I$(1,1).c$$J$Z,[this.seed, false]);
p$1.initializeConformers.apply(this, []);
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-01 14:15:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
