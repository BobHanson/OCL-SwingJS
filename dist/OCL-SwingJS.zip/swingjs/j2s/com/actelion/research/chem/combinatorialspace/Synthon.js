(function(){var P$=Clazz.newPackage("com.actelion.research.chem.combinatorialspace"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Synthon");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['origBB','com.actelion.research.chem.StereoMolecule','+synthon','reactions','java.util.Map']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (origBB, synthon) {
;C$.$init$.apply(this);
this.origBB=synthon;
this.synthon=synthon;
}, 1);

Clazz.newMeth(C$, 'addReaction$S$I',  function (rxn, rxnID) {
this.reactions.put$O$O(rxn, Integer.valueOf$I(rxnID));
});

Clazz.newMeth(C$, 'getOrigBB$',  function () {
return this.origBB;
});

Clazz.newMeth(C$, 'getSynthon$',  function () {
return this.synthon;
});

Clazz.newMeth(C$, 'getReactions$',  function () {
return this.reactions;
});

Clazz.newMeth(C$, 'areSynthonsCompatible$com_actelion_research_chem_combinatorialspace_Synthon$com_actelion_research_chem_combinatorialspace_Synthon',  function (synthon1, synthon2) {
for (var rxn1, $rxn1 = synthon1.reactions.keySet$().iterator$(); $rxn1.hasNext$()&&((rxn1=($rxn1.next$())),1);) {
var id1=(synthon1.reactions.get$O(rxn1)).$c();
if (synthon2.reactions.containsKey$O(rxn1)) {
var id2=(synthon2.reactions.get$O(rxn1)).$c();
if (id1 != id2) return true;
}}
return false;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-30 18:28:43 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
