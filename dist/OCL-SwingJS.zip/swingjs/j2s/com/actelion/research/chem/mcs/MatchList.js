(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'com.actelion.research.util.datamodel.IntVec']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatchList");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrMatchListFragment','int[]','ivMatchListMolecule','com.actelion.research.util.datamodel.IntVec']]]

Clazz.newMeth(C$, 'c$$I',  function (nInteger) {
;C$.$init$.apply(this);
this.ivMatchListMolecule=Clazz.new_($I$(1,1).c$$I,[nInteger]);
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.ivMatchListMolecule.set$I(0);
this.arrMatchListFragment=null;
});

Clazz.newMeth(C$, 'set$IA',  function (arrMatchListFragment) {
this.arrMatchListFragment=arrMatchListFragment;
for (var i=0; i < arrMatchListFragment.length; i++) {
this.ivMatchListMolecule.setBit$I(arrMatchListFragment[i]);
}
this.ivMatchListMolecule.calculateHashCode$();
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return this.ivMatchListMolecule.hashCode$();
});

Clazz.newMeth(C$, 'equals$O',  function (obj) {
var ml=obj;
return this.ivMatchListMolecule.equal$com_actelion_research_util_datamodel_IntVec(ml.ivMatchListMolecule);
});

Clazz.newMeth(C$, 'getMatchListFragment$',  function () {
return this.arrMatchListFragment;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
