(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),p$1={},I$=[[0,'com.actelion.research.chem.inchi.InChIJS','com.actelion.research.chem.inchi.InChIJNI1','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.IsomericSmilesCreator','com.actelion.research.chem.MolfileParser','com.actelion.research.chem.Molecule','java.util.HashMap','java.util.Arrays','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIOCL", null, null, 'org.iupac.InChIStructureProvider');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['getInchiModel','getKey','inputInChI'],'S',['inchi']]
,['Z',['interfaceHasMolFileToInChI']]]

Clazz.newMeth(C$, 'getInChIOCL$',  function () {
return (false) ? Clazz.new_($I$(1,1)) : Clazz.new_($I$(2,1));
}, 1);

Clazz.newMeth(C$, 'getInChI$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInChIOCL$(), [mol, null, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChI$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInChIOCL$(), [null, molFileDataOrInChI, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChIFromSmiles$S$S',  function (smiles, options) {
var mol=Clazz.new_($I$(3,1));
try {
Clazz.new_($I$(4,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, smiles);
return C$.getInChI$com_actelion_research_chem_StereoMolecule$S(mol, options);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getInChIKey$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInChIOCL$(), [mol, null, options, true]);
}, 1);

Clazz.newMeth(C$, 'getInChIKey$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInChIOCL$(), [null, molFileDataOrInChI, options, true]);
}, 1);

Clazz.newMeth(C$, 'getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
C$.getInChIOCL$().getOCLMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol);
return true;
} catch (e) {
e.printStackTrace$();
return false;
}
}, 1);

Clazz.newMeth(C$, 'getSmilesFromInChI$S$S',  function (inchi, options) {
var mol=Clazz.new_($I$(3,1));
return (C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol) ? $I$(5).createSmiles$com_actelion_research_chem_StereoMolecule(mol) : null);
}, 1);

Clazz.newMeth(C$, 'getInChIModelJSON$S',  function (inchi) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getInChIOCL$(), [null, inchi, "model", false]);
}, 1);

Clazz.newMeth(C$, 'getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (mol, molDataOrInChI, options, getKey) {
try {
if (mol == null  && molDataOrInChI == null  ) return null;
this.inchi=null;
options=p$1.setParameters$S$S$com_actelion_research_chem_StereoMolecule.apply(this, [options, molDataOrInChI, mol]);
getKey=!!(getKey|(this.getKey));
if (options == null ) return "";
if (this.inchi != null ) {
if (!getKey) return this.inchi;
molDataOrInChI=this.inchi;
}if (molDataOrInChI != null  && !this.inputInChI  && !C$.interfaceHasMolFileToInChI ) {
mol=Clazz.new_($I$(3,1));
if (!Clazz.new_($I$(6,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molDataOrInChI)) return null;
}return this.getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S$Z(mol, molDataOrInChI, options, getKey);
} catch (e) {
{
e = (e.getMessage$ ? e.getMessage$() : e);
}
System.err.println$S("InChIOCL exception: " + e);
return null;
}
}, p$1);

Clazz.newMeth(C$, 'setParameters$S$S$com_actelion_research_chem_StereoMolecule',  function (options, molDataOrInChI, mol) {
if (mol == null  ? molDataOrInChI == null  : mol.getAtoms$() == 0) return null;
if (options == null ) options="";
var inchi=null;
var lc=options.toLowerCase$().trim$();
var getInchiModel=(lc.indexOf$S("model") == 0);
var getKey=(lc.indexOf$S("key") >= 0);
if (lc.startsWith$S("model/")) {
inchi=options.substring$I(10);
options=lc="";
} else if (getInchiModel) {
options=lc=lc.substring$I(5);
}var optionalFixedH=(options.indexOf$S("fixedh?") >= 0);
if (lc.indexOf$S("fixedh") < 0) {
options=lc=lc.replace$CharSequence$CharSequence("standard", "").trim$();
}var inputInChI=(molDataOrInChI != null  && molDataOrInChI.startsWith$S("InChI=") );
if (!inputInChI) {
options=lc;
if (getKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "");
options=options.replace$CharSequence$CharSequence("key", "");
}if (optionalFixedH) {
var fxd=p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options.replace$C$C("?", " "), false]);
options=options.replace$CharSequence$CharSequence("fixedh?", "");
var std=p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options, false]);
inchi=(fxd != null  && fxd.length$() <= std.length$()  ? std : fxd);
options=null;
}}this.inputInChI=inputInChI;
this.inchi=inchi;
this.getKey=getKey;
this.getInchiModel=getInchiModel;
return options;
}, p$1);

Clazz.newMeth(C$, 'getOCLMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
this.initializeInchiModel$S(inchi);
var nAtoms=this.getNumAtoms$();
var nBonds=this.getNumBonds$();
var nStereo=this.getNumStereo0D$();
for (var i=0; i < nAtoms; i++) {
this.setAtom$I(i);
var sym=this.getElementType$();
var atom=mol.addAtom$I($I$(7).getAtomicNoFromLabel$S(sym));
mol.setAtomCharge$I$I(atom, this.getCharge$());
}
var doubleBonds=Clazz.new_($I$(8,1));
for (var i=0; i < nBonds; i++) {
this.setBond$I(i);
var i1=this.getIndexOriginAtom$();
var i2=this.getIndexTargetAtom$();
var bt=C$.getOCLSimpleBondType$S(this.getInchiBondType$());
var bond=mol.addBond$I$I$I(i1, i2, bt);
switch (bt) {
case 1:
break;
case 2:
doubleBonds.put$O$O(Integer.valueOf$I(C$.getBondKey$I$I(i1, i2)), Integer.valueOf$I(bond));
break;
}
}
for (var i=0; i < nStereo; i++) {
this.setStereo0D$I(i);
var centerAtom=this.getCenterAtom$();
var neighbors=this.getNeighbors$();
if (neighbors.length != 4) continue;
var p=-1;
switch (this.getStereoType$()) {
case "TETRAHEDRAL":
p=C$.getOCLAtomParity$S$Z(this.getParity$(), C$.isOrdered$IA(neighbors));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "DOUBLEBOND":
var ib=C$.findDoubleBond$java_util_Map$IA(doubleBonds, neighbors);
if (ib < 0) {
System.err.println$S("InChIJNI cannot find double bond for atoms " + $I$(9).toString$IA(neighbors));
continue;
}p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] < neighbors[3]));
mol.setBondParity$I$I$Z(ib, p, false);
break;
case "ALLENE":
p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] > neighbors[3]));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "NONE":
continue;
}
}
mol.setParitiesValid$I(0);
mol.setPrioritiesPreset$Z(true);
Clazz.new_($I$(10,1).c$$I,[64]);
mol.ensureHelperArrays$I(31);
});

Clazz.newMeth(C$, 'getBondKey$I$I',  function (i1, i2) {
return (Math.min(i1, i2) << 16) + Math.max(i1, i2);
}, 1);

Clazz.newMeth(C$, 'findDoubleBond$java_util_Map$IA',  function (doubleBonds, neighbors) {
var ib=doubleBonds.get$O(Integer.valueOf$I(C$.getBondKey$I$I(neighbors[1], neighbors[2])));
return (ib == null  ? -1 : ib.intValue$());
}, 1);

Clazz.newMeth(C$, 'getOCLBondParity$S$Z',  function (parity, isReversed) {
switch (parity) {
case "ODD":
return (isReversed ? 2 : 1);
case "EVEN":
return (isReversed ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'isOrdered$IA',  function (list) {
var ok=true;
for (var i=0; i < list.length - 1; i++) {
var l1=list[i];
for (var j=i + 1; j < list.length; j++) {
var l2=list[j];
if (l1 > l2) {
list[j]=l1;
l1=list[i]=l2;
ok=!ok;
}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOCLAtomParity$S$Z',  function (parity, isOrdered) {
var isOdd=false;
switch (parity) {
case "ODD":
isOdd=true;
case "EVEN":
return (!!(isOdd ^ isOrdered) ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getOCLSimpleBondType$S',  function (type) {
switch (type) {
case "NONE":
return 0;
case "ALTERN":
return 8;
case "DOUBLE":
return 2;
case "TRIPLE":
return 4;
case "SINGLE":
default:
return 1;
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.interfaceHasMolFileToInChI=true ||false;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:51:30 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
