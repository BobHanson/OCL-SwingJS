(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),p$1={},I$=[[0,'java.util.Stack','StringBuffer','java.nio.ByteBuffer','java.nio.ByteOrder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CDXMLWriter");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.objects=Clazz.new_($I$(1,1));
this.sb=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['I',['sbpt'],'O',['objects','java.util.Stack','sb','StringBuffer','buf','java.nio.ByteBuffer']]
,['O',['cdxAttributes','String[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'fromCDX$BA',  function (cdx) {
return p$1.cdxToCdxml$BA.apply(Clazz.new_(C$), [cdx]);
}, 1);

Clazz.newMeth(C$, 'cdxToCdxml$BA',  function (cdx) {
this.buf=$I$(3).wrap$BA(cdx);
this.buf.order$java_nio_ByteOrder($I$(4).LITTLE_ENDIAN);
try {
C$.openDocument$StringBuffer(this.sb);
C$.appendHeader$StringBuffer(this.sb);
this.buf.position$I(22);
p$1.processObject$I.apply(this, [this.buf.getShort$()]);
this.sb.append$S("</CDXML>\n");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S(this.sb + "\n" + this.objects );
e.printStackTrace$();
return null;
} else {
throw e;
}
}
return this.sb.toString();
}, p$1);

Clazz.newMeth(C$, 'appendHeader$StringBuffer',  function (sb) {
sb.append$S("<!DOCTYPE CDXML SYSTEM \"http://www.cambridgesoft.com/xml/cdxml.dtd\" >\n");
C$.startOpenTag$StringBuffer$S(sb, "CDXML");
C$.addAttributes$StringBuffer$SA(sb, C$.cdxAttributes);
C$.terminateTag$StringBuffer(sb);
}, 1);

Clazz.newMeth(C$, 'processObject$I',  function (type) {
var id=this.buf.getInt$();
type=type & 65535;
var terminated=false;
var name=null;
switch (type) {
case 32768:
case 32770:
default:
id=-2147483648;
terminated=true;
break;
case 32769:
name="page";
id=-2147483648;
break;
case 32771:
name="fragment";
break;
case 32772:
name="n";
break;
case 32773:
name="b";
break;
case 32774:
name="t";
id=-2147483648;
break;
case 32791:
name="bracketedgroup";
break;
case 32792:
name="bracketattachment";
break;
case 32793:
name="crossingbond";
break;
}
this.sbpt=this.sb.length$();
this.objects.push$O(name);
if (name != null ) {
C$.startOpenTag$StringBuffer$S(this.sb, name);
if (id != -2147483648) {
C$.addAttribute$StringBuffer$S$S(this.sb, "id", "" + id);
}}var prop;
while ((prop=this.buf.getShort$()) != 0){
if ((prop & 32768) != 0) {
if (!terminated) {
C$.terminateTag$StringBuffer(this.sb);
terminated=true;
}p$1.processObject$I.apply(this, [prop]);
continue;
}var len=p$1.readLength.apply(this, []);
switch (type) {
case 32772:
p$1.writeNodeProperties$I$I.apply(this, [prop, len]);
break;
case 32774:
if (!terminated) {
C$.terminateTag$StringBuffer(this.sb);
terminated=true;
}p$1.writeTextProperty$I$I.apply(this, [prop, len]);
break;
case 32773:
p$1.writeBondProperties$I$I.apply(this, [prop, len]);
break;
case 32791:
p$1.writeBracketedGroupProperties$I$I.apply(this, [prop, len]);
break;
case 32793:
p$1.writeCrossingBondProperties$I$I.apply(this, [prop, len]);
break;
default:
p$1.skip$I.apply(this, [len]);
break;
}
}
if (name != null ) {
if (!terminated) {
C$.terminateEmptyTag$StringBuffer(this.sb);
} else {
C$.closeTag$StringBuffer$S(this.sb, name);
}}}, p$1);

Clazz.newMeth(C$, 'writeBracketedGroupProperties$I$I',  function (prop, len) {
switch (prop) {
case 2599:
C$.addAttribute$StringBuffer$S$S(this.sb, "BracketedObjectIDs", p$1.readArray$I.apply(this, [len]));
break;
case 2600:
C$.addAttribute$StringBuffer$S$S(this.sb, "RepeatCount", "" + (p$1.readFloat64.apply(this, [])|0));
break;
case 2596:
var usage=p$1.readInt$I.apply(this, [len]);
var sval=null;
switch (usage) {
case 16:
sval="MultipleGroup";
break;
default:
p$1.removeObject.apply(this, []);
return;
}
C$.addAttribute$StringBuffer$S$S(this.sb, "BracketUsage", sval);
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeCrossingBondProperties$I$I',  function (prop, len) {
switch (prop) {
case 2604:
C$.addAttribute$StringBuffer$S$S(this.sb, "BondID", "" + p$1.readInt$I.apply(this, [len]));
break;
case 2605:
C$.addAttribute$StringBuffer$S$S(this.sb, "InnerAtomID", "" + p$1.readInt$I.apply(this, [len]));
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeNodeProperties$I$I',  function (prop, len) {
switch (prop) {
case 512:
var y=C$.toPoint$I(p$1.readInt$I.apply(this, [len >> 1]));
var x=C$.toPoint$I(p$1.readInt$I.apply(this, [len >> 1]));
C$.addAttribute$StringBuffer$S$S(this.sb, "p", new Double(x).toString() + " " + new Double(y).toString() );
break;
case 1024:
var nodeType=C$.getNodeType$I(p$1.readInt$I.apply(this, [len]));
C$.addAttribute$StringBuffer$S$S(this.sb, "NodeType", nodeType);
break;
case 1026:
C$.addAttribute$StringBuffer$S$S(this.sb, "Element", "" + p$1.readInt$I.apply(this, [len]));
break;
case 1056:
C$.addAttribute$StringBuffer$S$S(this.sb, "Isotope", "" + p$1.readInt$I.apply(this, [len]));
break;
case 1057:
C$.addAttribute$StringBuffer$S$S(this.sb, "Charge", "" + p$1.readInt$I.apply(this, [len]));
break;
case 16:
C$.addAttribute$StringBuffer$S$S(this.sb, "Warning", p$1.readString$I.apply(this, [len]));
break;
case 1073:
C$.addAttribute$StringBuffer$S$S(this.sb, "BondOrdering", p$1.readArray$I.apply(this, [len]));
break;
case 1285:
C$.addAttribute$StringBuffer$S$S(this.sb, "ConnectionOrder", p$1.readArray$I.apply(this, [len]));
break;
case 1074:
C$.addAttribute$StringBuffer$S$S(this.sb, "Attachments", p$1.readArray$I.apply(this, [-1]));
break;
case 1075:
C$.addAttribute$StringBuffer$S$S(this.sb, "GenericNickname", p$1.readString$I.apply(this, [len]));
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeBondProperties$I$I',  function (prop, len) {
switch (prop) {
case 1536:
var order=C$.getBondOrder$I(p$1.readInt$I.apply(this, [len]));
if (order == null ) {
p$1.removeObject.apply(this, []);
return;
}C$.addAttribute$StringBuffer$S$S(this.sb, "Order", order);
break;
case 1537:
var d=C$.getBondDisplay$I(p$1.readInt$I.apply(this, [len]));
if (d == null ) {
p$1.removeObject.apply(this, []);
return;
}C$.addAttribute$StringBuffer$S$S(this.sb, "Display", d);
break;
case 1538:
var d2=C$.getBondDisplay$I(p$1.readInt$I.apply(this, [len]));
if (d2 != null ) C$.addAttribute$StringBuffer$S$S(this.sb, "Display2", d2);
break;
case 1540:
C$.addAttribute$StringBuffer$S$S(this.sb, "B", "" + p$1.readInt$I.apply(this, [len]));
break;
case 1541:
C$.addAttribute$StringBuffer$S$S(this.sb, "E", "" + p$1.readInt$I.apply(this, [len]));
break;
case 1544:
C$.addAttribute$StringBuffer$S$S(this.sb, "BeginAttach", "" + p$1.readInt$I.apply(this, [len]));
break;
case 1545:
C$.addAttribute$StringBuffer$S$S(this.sb, "EndAttach", "" + p$1.readInt$I.apply(this, [len]));
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'writeTextProperty$I$I',  function (prop, len) {
switch (prop) {
case 1792:
var text=p$1.readString$I.apply(this, [len]);
System.out.println$S("CDXMLW text=" + text);
C$.openTag$StringBuffer$S(this.sb, "s");
this.sb.setLength$I(this.sb.length$() - 1);
this.sb.append$S(C$.wrapCData$S(text));
C$.closeTag$StringBuffer$S(this.sb, "s");
break;
default:
p$1.skip$I.apply(this, [len]);
}
}, p$1);

Clazz.newMeth(C$, 'wrapCData$S',  function (s) {
return (s.indexOf$S("&") < 0 && s.indexOf$S("<") < 0  ? s : "<![CDATA[" + s.replace$CharSequence$CharSequence("]]>", "]]]]><![CDATA[>") + "]]>" );
}, 1);

Clazz.newMeth(C$, 'getNodeType$I',  function (n) {
var name=null;
switch (n) {
case 0:
return "Unspecified";
case 1:
return "Element";
case 4:
return "Nickname";
case 5:
return "Fragment";
case 7:
return "GenericNickname";
case 10:
return "MultiAttachment";
case 11:
return "VariableAttachment";
case 12:
return "ExternalConnectionPoint";
case 2:
name="ElementList";
break;
case 3:
name="ElementListNickname";
break;
case 6:
name="Formula";
break;
case 8:
name="AnonymousAlternativeGroup";
break;
case 9:
name="NamedAnonymousGroup";
break;
case 13:
name="LinkNode";
break;
}
System.err.println$S("CDXMLWriter Node type " + name + " not identified" );
return "_";
}, 1);

Clazz.newMeth(C$, 'getBondDisplay$I',  function (i) {
switch (i) {
case 0:
return "Solid";
case 1:
return "Dash";
case 2:
return "Hash";
case 3:
return "WedgedHashBegin";
case 4:
return "WedgedHashEnd";
case 5:
return "Bold";
case 6:
return "WedgeBegin";
case 7:
return "WedgeEnd";
case 8:
return "Wavy";
case 9:
return "HollowWedgeBegin";
case 10:
return "HollowWedgeEnd";
case 11:
return "WavyWedgeBegin";
case 12:
return "WavyWedgeEnd";
case 13:
return "Dot";
case 14:
return "DashDot";
}
return null;
}, 1);

Clazz.newMeth(C$, 'getBondOrder$I',  function (i) {
switch (i) {
case 1:
return "1";
case 2:
return "2";
case 4:
return "3";
case 8:
return "4";
case 16:
return "5";
case 32:
return "6";
case 64:
return "0.5";
case 128:
return "1.5";
case 256:
return "2.5";
case 512:
return "3.5";
case 1024:
return "4.5";
case 2048:
return "5.5";
case 4096:
return "dative";
case 8192:
return "ionic";
case 16384:
return "hydrogen";
case 32768:
return "threecenter";
}
return null;
}, 1);

Clazz.newMeth(C$, 'removeObject',  function () {
this.sb.setLength$I(this.sbpt);
}, p$1);

Clazz.newMeth(C$, 'skip$I',  function (len) {
this.buf.position$I(this.buf.position$() + len);
}, p$1);

Clazz.newMeth(C$, 'readFloat64',  function () {
return this.buf.getDouble$();
}, p$1);

Clazz.newMeth(C$, 'readInt$I',  function (len) {
switch (len) {
case 1:
return (256 + this.buf.get$()) % 256;
case 2:
return this.buf.getShort$();
case 4:
return this.buf.getInt$();
case 8:
return Long.$ival(this.buf.getLong$());
}
System.err.println$S("CDXMLWriter.readInt len " + len);
return 0;
}, p$1);

Clazz.newMeth(C$, 'readString$I',  function (len) {
var nStyles=this.buf.getShort$();
len-=2;
switch (nStyles) {
case 0:
break;
default:
p$1.skip$I.apply(this, [nStyles * 10]);
len-=nStyles * 10;
break;
}
var temp=Clazz.array(Byte.TYPE, [len]);
this.buf.get$BA$I$I(temp, 0, len);
return  String.instantialize(temp, 0, len, "UTF-8");
}, p$1);

Clazz.newMeth(C$, 'readArray$I',  function (len) {
var n=(len < 0 ? this.buf.getShort$() : (len/4|0));
var s="";
for (var i=n; --i >= 0; ) {
s+=" " + this.buf.getInt$();
}
return s.trim$();
}, p$1);

Clazz.newMeth(C$, 'readLength',  function () {
var len=this.buf.getShort$();
if (len == -1) {
len=this.buf.getInt$();
}return len;
}, p$1);

Clazz.newMeth(C$, 'toPoint$I',  function (i) {
return Math.round$D(i / 655.36) / 100.0;
}, 1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
}, 1);

Clazz.newMeth(C$, 'openDocument$StringBuffer',  function (sb) {
sb.append$S("<?xml version=\"1.0\"?>\n");
}, 1);

Clazz.newMeth(C$, 'openTag$StringBuffer$S',  function (sb, name) {
sb.append$S("<").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'startOpenTag$StringBuffer$S',  function (sb, name) {
sb.append$S("<").append$S(name);
}, 1);

Clazz.newMeth(C$, 'terminateTag$StringBuffer',  function (sb) {
sb.append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'terminateEmptyTag$StringBuffer',  function (sb) {
sb.append$S("/>\n");
}, 1);

Clazz.newMeth(C$, 'appendEmptyTag$StringBuffer$S$SA',  function (sb, name, attributes) {
C$.startOpenTag$StringBuffer$S(sb, name);
C$.addAttributes$StringBuffer$SA(sb, attributes);
C$.terminateEmptyTag$StringBuffer(sb);
}, 1);

Clazz.newMeth(C$, 'addAttributes$StringBuffer$SA',  function (sb, attributes) {
for (var i=0; i < attributes.length; i++) {
C$.addAttribute$StringBuffer$S$S(sb, attributes[i], attributes[++i]);
}
}, 1);

Clazz.newMeth(C$, 'addAttribute$StringBuffer$S$S',  function (sb, key, val) {
sb.append$S(" ").append$S(key).append$S("=").append$S(C$.esc$S(val));
}, 1);

Clazz.newMeth(C$, 'closeTag$StringBuffer$S',  function (sb, name) {
sb.append$S("</").append$S(name).append$S(">\n");
}, 1);

Clazz.newMeth(C$, 'esc$S',  function (str) {
if (str == null  || str.length$() == 0 ) return "\"\"";
var haveEscape=false;
var i=0;
for (; i < "\\\\\tt\rr\nn\"\"".length$(); i+=2) if (str.indexOf$I("\\\\\tt\rr\nn\"\"".charAt$I(i)) >= 0) {
haveEscape=true;
break;
}
if (haveEscape) while (i < "\\\\\tt\rr\nn\"\"".length$()){
var pt=-1;
var ch="\\\\\tt\rr\nn\"\"".charAt$I(i++);
var ch2="\\\\\tt\rr\nn\"\"".charAt$I(i++);
var sb=Clazz.new_($I$(2,1));
var pt0=0;
while ((pt=str.indexOf$I$I(ch, pt + 1)) >= 0){
sb.append$S(str.substring$I$I(pt0, pt)).append$C("\\").append$C(ch2);
pt0=pt + 1;
}
sb.append$S(str.substring$I$I(pt0, str.length$()));
str=sb.toString();
}
return "\"" + C$.escUnicode$S(str) + "\"" ;
}, 1);

Clazz.newMeth(C$, 'escUnicode$S',  function (str) {
for (var i=str.length$(); --i >= 0; ) if ((str.charCodeAt$I(i)) > 127 ) {
var s="0000" + Integer.toHexString$I(str.charAt$I(i).$c());
str=str.substring$I$I(0, i) + "\\u" + s.substring$I(s.length$() - 4) + str.substring$I(i + 1) ;
}
return str;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return (this.sb.toString());
});

C$.$static$=function(){C$.$static$=0;
C$.cdxAttributes=Clazz.array(String, -1, ["HashSpacing", "2.50", "MarginWidth", "1.60", "LineWidth", "0.60", "BoldWidth", "2", "BondLength", "14.40", "BondSpacing", "18"]);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-15 21:09:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
