(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.ArrayList','java.awt.BasicStroke','java.awt.Color']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Depictor", null, 'com.actelion.research.chem.AbstractDepictor');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['F',['mLineWidth'],'I',['mpTextSize','mMaxTextSize'],'O',['mFonts','java.util.ArrayList','currentFont','java.awt.Font']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule.apply(this,[mol]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (mol, displayMode) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$I.apply(this,[mol, displayMode]);C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'setMaximumTextSize$I',  function (maxTextSize) {
this.mMaxTextSize=maxTextSize;
});

Clazz.newMeth(C$, 'init$',  function () {
C$.superclazz.prototype.init$.apply(this, []);
this.mFonts=Clazz.new_($I$(1,1));
this.mMaxTextSize=16;
this.mLineWidth=1.0;
});

Clazz.newMeth(C$, 'drawBlackLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
this.mContext.drawLine$I$I$I$I(Math.round(theLine.x1), Math.round(theLine.y1), Math.round(theLine.x2), Math.round(theLine.y2));
});

Clazz.newMeth(C$, 'drawDottedLine$com_actelion_research_chem_AbstractDepictor_DepictorLine',  function (theLine) {
var stroke=(this.mContext).getStroke$();
(this.mContext).setStroke$java_awt_Stroke(Clazz.new_([this.mLineWidth, 1, 1, this.mLineWidth, Clazz.array(Float.TYPE, -1, [3.0 * this.mLineWidth]), 0.0],$I$(2,1).c$$F$I$I$F$FA$F));
this.mContext.drawLine$I$I$I$I((theLine.x1|0), (theLine.y1|0), (theLine.x2|0), (theLine.y2|0));
(this.mContext).setStroke$java_awt_Stroke(stroke);
});

Clazz.newMeth(C$, 'drawString$S$D$D',  function (theString, x, y) {
var strWidth=this.getStringWidth$S(theString);
this.mContext.drawString$S$I$I(theString, Math.round((x - strWidth / 2)), Math.round((y + 1 + (this.mpTextSize/3|0) )));
});

Clazz.newMeth(C$, 'drawPolygon$com_actelion_research_gui_generic_GenericPolygon',  function (p) {
var px=Clazz.array(Integer.TYPE, [p.getSize$()]);
var py=Clazz.array(Integer.TYPE, [p.getSize$()]);
for (var i=0; i < p.getSize$(); i++) {
px[i]=Math.round(p.getX$I(i));
py[i]=Math.round(p.getY$I(i));
}
this.mContext.drawPolygon$IA$IA$I(px, py, p.getSize$());
this.mContext.fillPolygon$IA$IA$I(px, py, p.getSize$());
});

Clazz.newMeth(C$, 'fillCircle$D$D$D',  function (x, y, d) {
this.mContext.fillOval$I$I$I$I(Math.round(x), Math.round(y), Math.round(d), Math.round(d));
});

Clazz.newMeth(C$, 'getStringWidth$S',  function (theString) {
return this.mContext.getFontMetrics$().stringWidth$S(theString);
});

Clazz.newMeth(C$, 'setTextSize$I',  function (theSize) {
this.mpTextSize=Math.min(theSize, this.mMaxTextSize);
if (this.mContext != null ) {
if (this.currentFont == null  || this.currentFont.getSize$() != this.mpTextSize ) {
for (var i=0; i < this.mFonts.size$(); i++) {
if ((this.mFonts.get$I(i)).getSize$() == this.mpTextSize) {
(this.mContext).setFont$java_awt_Font(this.mFonts.get$I(i));
return;
}}
var newFont=this.mContext.getFont$().deriveFont$I$F(0, this.mpTextSize);
this.mFonts.add$O(newFont);
this.currentFont=newFont;
this.mContext.setFont$java_awt_Font(newFont);
}}});

Clazz.newMeth(C$, 'getTextSize$',  function () {
return this.mpTextSize;
});

Clazz.newMeth(C$, 'getLineWidth$',  function () {
return this.mLineWidth;
});

Clazz.newMeth(C$, 'setLineWidth$D',  function (lineWidth) {
if (lineWidth <= 1.5 ) lineWidth=1.0;
if (this.mLineWidth != lineWidth ) {
this.mLineWidth=lineWidth;
(this.mContext).setStroke$java_awt_Stroke(Clazz.new_($I$(2,1).c$$F$I$I,[lineWidth, 1, 1]));
}});

Clazz.newMeth(C$, 'setRGB$I',  function (rgb) {
this.mContext.setColor$java_awt_Color(Clazz.new_($I$(3,1).c$$I,[rgb]));
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:37 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
