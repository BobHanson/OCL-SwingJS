(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield"),p$1={},I$=[[0,'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractForceField", null, null, 'com.actelion.research.chem.forcefield.ForceField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.listeners=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['Z',['mIsInterrupted'],'D',['mTotalEnergy'],'I',['mDim'],'J',['mTimeInterval'],'O',['listeners','java.util.ArrayList','mMol','com.actelion.research.chem.StereoMolecule','mPos','double[]','+mNewpos','+mGrad','mFixedAtoms','int[]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
var implicitHydrogens=0;
for (var at=0; at < mol.getAtoms$(); at++) {
implicitHydrogens+=mol.getImplicitHydrogens$I(at);
}
if (implicitHydrogens > 0) {
throw Clazz.new_(Clazz.load('IllegalArgumentException').c$$S,["molecule needs explicit hydrogen atoms for force field calculations"]);
}this.mMol=mol;
this.mDim=3 * mol.getAllAtoms$();
this.mGrad=Clazz.array(Double.TYPE, [this.mDim]);
this.mPos=Clazz.array(Double.TYPE, [this.mDim]);
this.mNewpos=Clazz.array(Double.TYPE, [this.mDim]);
this.mIsInterrupted=false;
this.mTimeInterval=20;
for (var i=0; i < mol.getAllAtoms$(); i++) {
this.mPos[3 * i]=mol.getAtomX$I(i);
this.mPos[3 * i + 1]=mol.getAtomY$I(i);
this.mPos[3 * i + 2]=mol.getAtomZ$I(i);
}
}, 1);

Clazz.newMeth(C$, 'addListener$com_actelion_research_chem_forcefield_ForceFieldChangeListener',  function (listener) {
this.listeners.add$O(listener);
});

Clazz.newMeth(C$, 'addGradient$DA',  function (grad) {
Clazz.assert(C$, this, function(){return grad.length == this.mGrad.length});
this.updateGradient$();
for (var i=0; i < this.mGrad.length; i++) {
grad[i]+=this.mGrad[i];
}
});

Clazz.newMeth(C$, 'getState$DA',  function (pos) {
Clazz.assert(C$, this, function(){return pos.length == this.mPos.length});
for (var i=0; i < this.mPos.length; i++) {
pos[i]=this.mPos[i];
}
});

Clazz.newMeth(C$, 'setState$DA',  function (pos) {
Clazz.assert(C$, this, function(){return pos.length == this.mPos.length});
for (var i=0; i < this.mPos.length; i++) {
this.mPos[i]=pos[i];
}
});

Clazz.newMeth(C$, 'coordVariance$I',  function (c) {
var m=0.0;
var s=0.0;
var k=1;
for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
var v;
switch (c) {
case 0:
v=this.mMol.getAtomX$I(i);
break;
case 1:
v=this.mMol.getAtomY$I(i);
break;
default:
v=this.mMol.getAtomZ$I(i);
break;
}
var tm=m;
m+=(v - tm) / k;
s+=(v - tm) * (v - m);
++k;
}
return (k > 1 ? s / (k - 1) : 0.0);
});

Clazz.newMeth(C$, 'minimise$',  function () {
return this.minimise$I$D$D(4000, 1.0E-4, 1.0E-6);
});

Clazz.newMeth(C$, 'setFixedAtoms$IA',  function (fixedAtoms) {
this.mFixedAtoms=fixedAtoms;
});

Clazz.newMeth(C$, 'zeroGradient$',  function () {
if (this.mFixedAtoms != null ) {
for (var i, $i = 0, $$i = this.mFixedAtoms; $i<$$i.length&&((i=($$i[$i])),1);$i++) {
this.mGrad[3 * i]=0.0;
this.mGrad[3 * i + 1]=0.0;
this.mGrad[3 * i + 2]=0.0;
}
}});

Clazz.newMeth(C$, 'minimise$I$D$D',  function (maxIts, gradTol, funcTol) {
var res=1;
for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
this.mPos[3 * i]=this.mMol.getAtomX$I(i);
this.mPos[3 * i + 1]=this.mMol.getAtomY$I(i);
this.mPos[3 * i + 2]=this.mMol.getAtomZ$I(i);
}
res=this.run_minimiser$I$D$D(maxIts, gradTol, funcTol);
if (res == 0) {
for (var i=0; i < this.mMol.getAllAtoms$(); i++) {
this.mMol.setAtomX$I$D(i, this.mPos[3 * i]);
this.mMol.setAtomY$I$D(i, this.mPos[3 * i + 1]);
this.mMol.setAtomZ$I$D(i, this.mPos[3 * i + 2]);
}
}for (var listener, $listener = this.listeners.iterator$(); $listener.hasNext$()&&((listener=($listener.next$())),1);) {
listener.stateChanged$();
}
return res;
});

Clazz.newMeth(C$, 'run_minimiser$I$D$D',  function (maxIts, gradTol, funcTol) {
var sum;
var maxStep;
var fp;
this.mGrad=Clazz.array(Double.TYPE, [this.mDim]);
var dGrad=Clazz.array(Double.TYPE, [this.mDim]);
var hessDGrad=Clazz.array(Double.TYPE, [this.mDim]);
var newPos=Clazz.array(Double.TYPE, [this.mDim]);
var xi=Clazz.array(Double.TYPE, [this.mDim]);
var invHessian=Clazz.array(Double.TYPE, [this.mDim * this.mDim]);
for (var i=0; i < this.mDim; i++) newPos[i]=this.mPos[i];

fp=this.getTotalEnergy$DA(this.mPos);
this.updateGradient$();
this.zeroGradient$();
sum=0.0;
for (var i=0; i < this.mDim; i++) {
invHessian[i * this.mDim + i]=1.0;
xi[i]=-this.mGrad[i];
sum+=this.mPos[i] * this.mPos[i];
}
maxStep=100.0 * Math.max(Math.sqrt(sum), this.mDim);
var timePassed;
var t0=System.currentTimeMillis$();
for (var iter=1; iter <= maxIts && !this.mIsInterrupted ; iter++) {
var status=p$1.linearSearch$DA$D$DA$DA$D.apply(this, [this.mPos, fp, xi, newPos, maxStep]);
if (status < 0) return 2;
fp=this.mTotalEnergy;
var test=0.0;
for (var i=0; i < this.mDim; i++) {
xi[i]=newPos[i] - this.mPos[i];
this.mPos[i]=newPos[i];
var temp=Math.abs(xi[i]) / Math.max(Math.abs(this.mPos[i]), 1.0);
if (temp > test ) test=temp;
dGrad[i]=this.mGrad[i];
}
if (test < 1.2E-7 ) {
return 0;
}var gradScale=this.updateGradient$();
this.zeroGradient$();
test=0.0;
var term=Math.max(this.mTotalEnergy * gradScale, 1.0);
for (var i=0; i < this.mDim; i++) {
var tmp=Math.abs(this.mGrad[i]) * Math.max(Math.abs(this.mPos[i]), 1.0);
test=Math.max(test, tmp);
dGrad[i]=this.mGrad[i] - dGrad[i];
}
test/=term;
if (test < gradTol ) {
return 0;
}var fac=0;
var fae=0;
var sumDGrad=0;
var sumXi=0;
for (var i=0; i < this.mDim; i++) {
var itab=i * this.mDim;
hessDGrad[i]=0.0;
for (var j=0; j < this.mDim; j++) hessDGrad[i]+=invHessian[itab + j] * dGrad[j];

fac+=dGrad[i] * xi[i];
fae+=dGrad[i] * hessDGrad[i];
sumDGrad+=dGrad[i] * dGrad[i];
sumXi+=xi[i] * xi[i];
}
if (fac > Math.sqrt(3.0E-8 * sumDGrad * sumXi ) ) {
fac=1.0 / fac;
var fad=1.0 / fae;
for (var i=0; i < this.mDim; i++) dGrad[i]=fac * xi[i] - fad * hessDGrad[i];

for (var i=0; i < this.mDim; i++) {
var itab=i * this.mDim;
for (var j=i; j < this.mDim; j++) {
invHessian[itab + j]+=fac * xi[i] * xi[j]  - fad * hessDGrad[i] * hessDGrad[j]  + fae * dGrad[i] * dGrad[j] ;
invHessian[j * this.mDim + i]=invHessian[itab + j];
}
}
}for (var i=0; i < this.mDim; i++) {
var itab=i * this.mDim;
xi[i]=0.0;
for (var j=0; j < this.mDim; j++) xi[i]-=invHessian[itab + j] * this.mGrad[j];

}
var t1=System.currentTimeMillis$();
timePassed=Long.$sub(t1,t0);
if (Long.$ge(timePassed,this.mTimeInterval )) {
for (var listener, $listener = this.listeners.iterator$(); $listener.hasNext$()&&((listener=($listener.next$())),1);) {
listener.stateChanged$();
}
t0=t1;
}}
return 1;
});

Clazz.newMeth(C$, 'linearSearch$DA$D$DA$DA$D',  function (oldPt, oldVal, dir, newPt, maxStep) {
var MAX_ITER_LINEAR_SEARCH=1000;
var ret=-1;
var tmpPt=Clazz.array(Double.TYPE, [this.mDim]);
var sum=0.0;
var slope=0.0;
var test=0.0;
var lambda=0.0;
var lambda2=0.0;
var lambdaMin=0.0;
var tmpLambda=0.0;
var val2=0.0;
sum=0.0;
for (var i=0; i < this.mDim; i++) sum+=dir[i] * dir[i];

sum=Math.sqrt(sum);
if (sum > maxStep ) for (var i=0; i < this.mDim; i++) dir[i]*=maxStep / sum;

slope=0.0;
for (var i=0; i < this.mDim; i++) slope+=dir[i] * this.mGrad[i];

if (slope >= 0.0 ) return ret;
test=0.0;
for (var i=0; i < this.mDim; i++) {
var temp=Math.abs(dir[i]) / Math.max(Math.abs(oldPt[i]), 1.0);
if (temp > test ) test=temp;
}
lambdaMin=1.0E-7 / test;
lambda=1.0;
var it=0;
while (it < 1000){
if (lambda < lambdaMin ) {
ret=1;
break;
}for (var i=0; i < this.mDim; i++) newPt[i]=oldPt[i] + lambda * dir[i];

this.mTotalEnergy=this.getTotalEnergy$DA(newPt);
if (this.mTotalEnergy - oldVal <= 1.0E-4 * lambda * slope  ) return 0;
if (it == 0) tmpLambda=-slope / (2.0 * (this.mTotalEnergy - oldVal - slope ));
 else {
var rhs1=this.mTotalEnergy - oldVal - lambda * slope ;
var rhs2=val2 - oldVal - lambda2 * slope ;
var a=(rhs1 / (lambda * lambda) - rhs2 / (lambda2 * lambda2)) / (lambda - lambda2);
var b=(-lambda2 * rhs1 / (lambda * lambda) + lambda * rhs2 / (lambda2 * lambda2)) / (lambda - lambda2);
if (a == 0.0 ) tmpLambda=-slope / (2.0 * b);
 else {
var disc=b * b - 3 * a * slope ;
if (disc < 0.0 ) tmpLambda=0.5 * lambda;
 else if (b <= 0.0 ) tmpLambda=(-b + Math.sqrt(disc)) / (3.0 * a);
 else tmpLambda=-slope / (b + Math.sqrt(disc));
}if (tmpLambda > 0.5 * lambda ) tmpLambda=0.5 * lambda;
}lambda2=lambda;
val2=this.mTotalEnergy;
lambda=Math.max(tmpLambda, 0.1 * lambda);
++it;
}
for (var i=0; i < this.mDim; i++) newPt[i]=oldPt[i];

return ret;
}, p$1);

Clazz.newMeth(C$, 'interrupt$',  function () {
this.mIsInterrupted=true;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
