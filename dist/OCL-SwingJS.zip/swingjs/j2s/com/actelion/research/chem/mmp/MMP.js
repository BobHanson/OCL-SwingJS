(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'com.actelion.research.chem.mmp.MMPFragmenter','java.text.SimpleDateFormat','java.util.Calendar','java.util.HashMap','java.util.ArrayList','java.util.LinkedHashMap','com.actelion.research.chem.mmp.MMPairs','com.actelion.research.chem.mmp.MMPUniqueFragments','com.actelion.research.chem.mmp.MMPFragments','com.actelion.research.chem.IDCodeParser','java.util.Arrays','java.text.DecimalFormat',['com.actelion.research.chem.mmp.MMP','.MoleculeIndex'],'java.util.Collections',['com.actelion.research.chem.mmp.MMPFragmenter','.MoleculeIndexID'],'com.actelion.research.chem.mmp.MMPEnumerator','java.math.BigDecimal']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMP", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MoleculeIndex',9]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.maxValueAtoms=0;
},1);

C$.$fields$=[['I',['maxValueAtoms','r1HIndex','moleculesRowCount'],'S',['datasetName'],'O',['matchedMolecularPairs','com.actelion.research.chem.mmp.MMPairs','mMPIndex','java.util.HashMap','+wholeMoleculesIndex','moleculesFragmentsID','java.util.List','mmpUniqueFragments','com.actelion.research.chem.mmp.MMPUniqueFragments','mmpFragments','com.actelion.research.chem.mmp.MMPFragments','fieldNames','String[]','fieldNumerics','boolean[]','fieldPercentiles5','float[]','+fieldPercentiles95']]
,['S',['VERSION','r1H']]]

Clazz.newMeth(C$, 'getDateAndTime$',  function () {
return Clazz.new_($I$(2,1).c$$S,["d-MMM-yyyy HH:mm:ss"]).format$java_util_Date($I$(3).getInstance$().getTime$());
}, 1);

Clazz.newMeth(C$, 'isNumeric$S',  function (str) {
if (str == null ) {
return true;
}try {
Double.parseDouble$S(str);
} catch (nfe) {
if (Clazz.exceptionOf(nfe,"NumberFormatException")){
return false;
} else {
throw nfe;
}
}
return true;
}, 1);

Clazz.newMeth(C$, 'getIndex$I',  function (valueAtoms) {
if (this.mMPIndex.containsKey$O(Integer.valueOf$I(valueAtoms))) {
return this.mMPIndex.get$O(Integer.valueOf$I(valueAtoms));
}return null;
}, p$1);

Clazz.newMeth(C$, 'addValues$I$S$IA$Z',  function (valueAtoms, keys, values, isH) {
var added=true;
var keysHash=null;
var valuesList=null;
if (this.mMPIndex.containsKey$O(Integer.valueOf$I(valueAtoms))) {
keysHash=this.mMPIndex.get$O(Integer.valueOf$I(valueAtoms));
} else {
keysHash=Clazz.new_($I$(4,1));
}if (keysHash.containsKey$O(keys)) {
valuesList=keysHash.get$O(keys);
if (valuesList == null ) valuesList=Clazz.new_($I$(5,1));
if (isH == true  && !valuesList.isEmpty$() ) {
var lastItem=valuesList.get$I(valuesList.size$() - 1);
if (lastItem[0] != this.r1HIndex) valuesList.add$O(values);
 else added=false;
} else {
valuesList.add$O(values);
}} else {
valuesList=Clazz.new_($I$(5,1));
valuesList.add$O(values);
}keysHash.put$O$O(keys, valuesList);
this.mMPIndex.put$O$O(Integer.valueOf$I(valueAtoms), keysHash);
return added;
}, p$1);

Clazz.newMeth(C$, 'c$$S$com_actelion_research_chem_io_CompoundFileParser$Z',  function (datasetName, compoundFileParser, verbose) {
;C$.$init$.apply(this);
this.mMPIndex=Clazz.new_($I$(4,1));
this.wholeMoleculesIndex=Clazz.new_($I$(6,1));
this.moleculesFragmentsID=Clazz.new_($I$(5,1));
this.matchedMolecularPairs=Clazz.new_($I$(7,1));
this.mmpUniqueFragments=Clazz.new_($I$(8,1));
this.r1HIndex=this.mmpUniqueFragments.addFragment$S$I$SA(C$.r1H, 0, null);
this.mmpFragments=Clazz.new_($I$(9,1));
this.moleculesRowCount=0;
this.fieldNames=compoundFileParser.getFieldNames$();
this.fieldNumerics=Clazz.array(Boolean.TYPE, [this.fieldNames.length]);
this.fieldPercentiles5=Clazz.array(Float.TYPE, [this.fieldNames.length]);
this.fieldPercentiles95=Clazz.array(Float.TYPE, [this.fieldNames.length]);
var idCodeParser=Clazz.new_($I$(10,1));
var isSDFileParser=compoundFileParser.getClass$().getName$().contains$CharSequence("SDFileParser");
var fieldDatas=Clazz.array($I$(5), [this.fieldNames.length]);
for (var i=0; i < this.fieldNames.length; i++) {
fieldDatas[i]=Clazz.new_($I$(5,1));
}
$I$(11).fill$ZA$Z(this.fieldNumerics, true);
this.datasetName=datasetName;
var formatter=Clazz.new_($I$(12,1).c$$S,["#.##"]);
var molCounter=0;
if (verbose) {
if (compoundFileParser.getRowCount$() != -1) {
System.out.println$S(C$.getDateAndTime$() + ": fragmenting " + compoundFileParser.getRowCount$() + " molecules..." );
} else {
System.out.println$S(C$.getDateAndTime$() + ": fragmenting molecules...");
}}while (compoundFileParser.next$()){
var mol=compoundFileParser.getMolecule$();
mol.stripSmallFragments$();
var moleculeName=(compoundFileParser.getMoleculeName$() == null ) ? mol.getName$() : compoundFileParser.getMoleculeName$();
var molID=compoundFileParser.getIDCode$();
var molIDCoord=compoundFileParser.getCoordinates$();
if (isSDFileParser) {
idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(mol, molID);
}var moleculeData=Clazz.array(String, [this.fieldNames.length]);
for (var i=0; i < this.fieldNames.length; i++) {
if (this.fieldNumerics[i] != false ) {
var fieldData=compoundFileParser.getFieldData$I(i);
if (fieldData == null  || fieldData.equals$O("N/A")  || fieldData.equals$O("?") ) {
fieldData=null;
} else if (fieldData.charAt$I(0).$c() == 65533) {
fieldData=null;
}moleculeData[i]=fieldData;
if (!C$.isNumeric$S(fieldData) && !C$.isNumeric$S(fieldData.substring$I(1)) && !C$.isNumeric$S(fieldData.substring$I(2))  ) {
this.fieldNumerics[i]=false;
} else if (fieldData != null  && C$.isNumeric$S(fieldData) ) {
if (true && this.fieldNames[i].endsWith$S("_uM") ) {
var data=C$.round$F$I(-Math.log10(Float.parseFloat$S(fieldData) * 1.0E-6), 3);
fieldData=Float.toString$F(data);
moleculeData[i]=fieldData;
fieldDatas[i].add$O(Float.valueOf$F(data));
} else {
fieldDatas[i].add$O(Float.valueOf$F(Float.parseFloat$S(fieldData)));
moleculeData[i]=formatter.format$D(Float.parseFloat$S(fieldData));
}} else if (fieldData != null  && !fieldData.startsWith$S("<")  && !fieldData.startsWith$S(">") ) {
this.fieldNumerics[i]=false;
} else if (fieldData != null  && (fieldData.startsWith$S("<=") || fieldData.startsWith$S(">=") ) ) {
if (true && this.fieldNames[i].endsWith$S("_uM") ) {
var data=C$.round$F$I(-Math.log10(Float.parseFloat$S(fieldData.substring$I(2)) * 1.0E-6), 3);
if (fieldData.startsWith$S(">=")) {
moleculeData[i]="<=" + Float.toString$F(data);
} else {
moleculeData[i]=">=" + Float.toString$F(data);
}} else {
moleculeData[i]=fieldData.substring$I$I(0, 2) + formatter.format$D(Float.parseFloat$S(fieldData.substring$I(2)));
}} else if (fieldData != null  && (fieldData.startsWith$S("<") || fieldData.startsWith$S(">") ) ) {
if (true && this.fieldNames[i].endsWith$S("_uM") ) {
var data=C$.round$F$I(-Math.log10(Float.parseFloat$S(fieldData.substring$I(1)) * 1.0E-6), 3);
if (fieldData.startsWith$S(">")) {
moleculeData[i]="<" + Float.toString$F(data);
} else {
moleculeData[i]=">" + Float.toString$F(data);
}} else {
moleculeData[i]=fieldData.substring$I$I(0, 1) + formatter.format$D(Float.parseFloat$S(fieldData.substring$I(1)));
}}}}
var moleculesIndex=Clazz.new_($I$(5,1));
var molIndex=molCounter;
if (!this.wholeMoleculesIndex.containsKey$O(molID)) {
var mmp=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.moleculesFragmentsID.add$O(mmp.getMoleculeFragmentsID$());
var moleculeIndexesID=mmp.getMoleculeIndexesID$Z(false);
for (var moleculeIndexID, $moleculeIndexID = moleculeIndexesID.iterator$(); $moleculeIndexID.hasNext$()&&((moleculeIndexID=($moleculeIndexID.next$())),1);) {
var keysID=moleculeIndexID.getKeysID$();
var valueID=moleculeIndexID.getValueID$();
var valueAtoms=moleculeIndexID.getValueIDAtoms$();
var key1Index=this.mmpUniqueFragments.addFragment$S(keysID[0]);
var valueIndex=this.mmpUniqueFragments.addFragment$S(valueID);
moleculeIndexID.setValueIndex$I(valueIndex);
if (keysID.length == 1) {
p$1.addValues$I$S$IA$Z.apply(this, [valueAtoms, Integer.toString$I(key1Index) + "\t", Clazz.array(Integer.TYPE, -1, [valueIndex, molCounter]), false]);
moleculeIndexID.setKeysIndex$IA(Clazz.array(Integer.TYPE, -1, [key1Index]));
} else {
var key2Index=this.mmpUniqueFragments.addFragment$S(keysID[1]);
p$1.addValues$I$S$IA$Z.apply(this, [valueAtoms, Integer.toString$I(key1Index) + "\t" + Integer.toString$I(key2Index) , Clazz.array(Integer.TYPE, -1, [valueIndex, molCounter]), false]);
moleculeIndexID.setKeysIndex$IA(Clazz.array(Integer.TYPE, -1, [key1Index, key2Index]));
}this.mmpFragments.addFragments$I$com_actelion_research_chem_mmp_MMPFragmenter_MoleculeIndexID(molCounter, moleculeIndexID);
if (moleculeIndexID.getValueIDAtoms$() > this.maxValueAtoms) {
this.maxValueAtoms=moleculeIndexID.getValueIDAtoms$();
}}
++molCounter;
} else {
moleculesIndex=this.wholeMoleculesIndex.get$O(molID);
molIndex=moleculesIndex.get$I(0).moleculeIndex;
}if (moleculesIndex.size$() > 0) {
moleculesIndex.add$O(Clazz.new_($I$(13,1).c$$I$S$SA,[molIndex, moleculeName, moleculeData]));
} else {
moleculesIndex.add$O(Clazz.new_($I$(13,1).c$$I$S$S$S$SA,[molIndex, molIDCoord, molID, moleculeName, moleculeData]));
}this.wholeMoleculesIndex.put$O$O(molID, moleculesIndex);
++this.moleculesRowCount;
if (verbose) {
if (this.moleculesRowCount % 1000 == 0) {
System.out.println$S("# " + this.moleculesRowCount);
} else if (this.moleculesRowCount % 100 == 0) {
System.out.print$S("#");
} else if (this.moleculesRowCount % 10 == 0) {
System.out.print$S(".");
}}}
if (verbose) {
System.out.println$S(" " + this.moleculesRowCount);
System.out.println$S(C$.getDateAndTime$() + ": getting percentiles...");
}for (var i=0; i < this.fieldNames.length; i++) {
if (this.fieldNumerics[i] != false  && fieldDatas[i].size$() > 0 ) {
$I$(14).sort$java_util_List(fieldDatas[i]);
var index=(Math.floor(0.05 * fieldDatas[i].size$())|0);
if (Math.round(0.05 * fieldDatas[i].size$()) != 0.05 * fieldDatas[i].size$() ) {
this.fieldPercentiles5[i]=(fieldDatas[i].get$I(index)).valueOf();
} else {
this.fieldPercentiles5[i]=((fieldDatas[i].get$I(index)).$c() + (fieldDatas[i].get$I(index + 1)).$c()) / 2.0;
}index=(Math.floor(0.95 * fieldDatas[i].size$())|0);
if (Math.round(0.95 * fieldDatas[i].size$()) != 0.95 * fieldDatas[i].size$() ) {
this.fieldPercentiles95[i]=(fieldDatas[i].get$I(index)).valueOf();
} else {
this.fieldPercentiles95[i]=((fieldDatas[i].get$I(index)).$c() + (fieldDatas[i].get$I(index + 1)).$c()) / 2.0;
}}}
if (verbose) System.out.println$S(C$.getDateAndTime$() + ": processing hydrogen replacements...");
for (var fragmentsID, $fragmentsID = this.moleculesFragmentsID.iterator$(); $fragmentsID.hasNext$()&&((fragmentsID=($fragmentsID.next$())),1);) {
for (var fragmentID, $fragmentID = fragmentsID.iterator$(); $fragmentID.hasNext$()&&((fragmentID=($fragmentID.next$())),1);) {
if (this.wholeMoleculesIndex.containsKey$O(fragmentID[1])) {
var moleculeIndex=this.wholeMoleculesIndex.get$O(fragmentID[1]).get$I(0).moleculeIndex;
var fragmentIndex=this.mmpUniqueFragments.addFragment$S(fragmentID[0]);
var added=p$1.addValues$I$S$IA$Z.apply(this, [0, Integer.toString$I(fragmentIndex) + "\t", Clazz.array(Integer.TYPE, -1, [this.r1HIndex, moleculeIndex]), true]);
if (added) {
var moleculeIndexID=Clazz.new_([Clazz.array(String, -1, [fragmentID[0]]), Clazz.array(Integer.TYPE, -1, [fragmentIndex]), C$.r1H, this.r1HIndex, null, 0, Clazz.array(Integer.TYPE, -1, [-1]), Clazz.array(Integer.TYPE, -1, [-1])],$I$(15,1).c$$SA$IA$S$I$IA$I$IA$IA);
this.mmpFragments.addFragments$I$com_actelion_research_chem_mmp_MMPFragmenter_MoleculeIndexID(moleculeIndex, moleculeIndexID);
}}}
}
if (verbose) System.out.print$S(C$.getDateAndTime$() + ": generating MMPs");
this.maxValueAtoms+=1;
var counter=0;
var combinations;
if (C$.VERSION === "1.0" ) {
combinations=Clazz.array(Integer.TYPE, [(this.maxValueAtoms * (this.maxValueAtoms + 1)/2|0) - 1, 2]);
for (var i=1; i < this.maxValueAtoms; i++) {
for (var j=0; j <= i; j++) {
combinations[counter][0]=i;
combinations[counter][1]=j;
++counter;
}
}
} else {
combinations=Clazz.array(Integer.TYPE, [this.maxValueAtoms * this.maxValueAtoms, 2]);
for (var i=0; i < this.maxValueAtoms; i++) {
for (var j=0; j < this.maxValueAtoms; j++) {
combinations[counter][0]=i;
combinations[counter][1]=j;
++counter;
}
}
}if (verbose) System.out.println$S(" (" + combinations.length + " combinations)..." );
var mMPEnumerator=Clazz.new_($I$(16,1));
counter=0;
for (var combination, $combination = 0, $$combination = combinations; $combination<$$combination.length&&((combination=($$combination[$combination])),1);$combination++) {
if (combination[0] == combination[1] && combination[0] != 0 ) {
mMPEnumerator=Clazz.new_([combination, p$1.getIndex$I.apply(this, [combination[0]]), null, C$.VERSION],$I$(16,1).c$$IA$java_util_HashMap$java_util_HashMap$S);
} else if (combination[0] != combination[1]) {
mMPEnumerator=Clazz.new_([combination, p$1.getIndex$I.apply(this, [combination[0]]), p$1.getIndex$I.apply(this, [combination[1]]), C$.VERSION],$I$(16,1).c$$IA$java_util_HashMap$java_util_HashMap$S);
}var mMPs=mMPEnumerator.getMMPEnumeration$();
if (mMPs != null  && mMPs.size$() > 0 ) this.matchedMolecularPairs.writeMMPEnumeration$java_util_HashMap(mMPs);
++counter;
if (verbose) {
if (counter % 1000 == 0) {
System.out.println$S("# " + counter);
} else if (counter % 100 == 0) {
System.out.print$S("#");
} else if (counter % 10 == 0) {
System.out.print$S(".");
}}}
compoundFileParser.close$();
if (verbose) System.out.println$S(" " + counter + "\n" + C$.getDateAndTime$() + ": done." );
}, 1);

Clazz.newMeth(C$, 'writeMolecules$java_io_PrintWriter',  function (printWriter) {
var line="moleculeIndex\tidcoordinates2D\tmolecule\tmoleculeName";
printWriter.println$S("<molecules>");
printWriter.println$S("<column properties>");
printWriter.println$S("<columnName=\"moleculeIndex\">");
printWriter.println$S("<columnName=\"idcoordinates2D\">");
printWriter.println$S("<columnProperty=\"specialType\tidcoordinates2D\">");
printWriter.println$S("<columnProperty=\"parent\tmolecule\">");
printWriter.println$S("<columnName=\"molecule\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"moleculeName\">");
for (var i=0; i < this.fieldNames.length; i++) {
if (this.fieldNumerics[i]) {
if (true && this.fieldNames[i].endsWith$S("_uM") ) {
this.fieldNames[i]="p" + this.fieldNames[i].substring$I$I(0, this.fieldNames[i].length$() - 3);
}var columnName=this.fieldNames[i];
var longName=this.fieldNames[i];
var category="other";
var items=this.fieldNames[i].split$S$I("\t", -1);
if (items.length > 1) {
category=items[0];
columnName=items[1];
longName=items[1];
if (items.length == 3) {
longName=items[2];
}}printWriter.println$S("<columnName=\"" + columnName + "\" percentile5=\"" + new Double(Math.floor(this.fieldPercentiles5[i] * 10.0) / 10.0).toString()  + "\" percentile95=\"" + new Double(Math.ceil(this.fieldPercentiles95[i] * 10.0) / 10.0).toString() + "\" longName=\"" + longName + "\" category=\"" + category + "\">");
line+="\t" + columnName;
}}
printWriter.println$S("</column properties>");
printWriter.println$S(line);
var it=this.wholeMoleculesIndex.keySet$().iterator$();
while (it.hasNext$()){
var molID=it.next$();
var molIDCoord="";
var moleculesIndex=this.wholeMoleculesIndex.get$O(molID);
for (var moleculeIndex, $moleculeIndex = moleculesIndex.iterator$(); $moleculeIndex.hasNext$()&&((moleculeIndex=($moleculeIndex.next$())),1);) {
if (molIDCoord === ""  && moleculeIndex.moleculeIDCoord != null  ) {
molIDCoord=moleculeIndex.moleculeIDCoord;
}line=Integer.toString$I(moleculeIndex.moleculeIndex) + "\t" + molIDCoord + "\t" + molID + "\t" + moleculeIndex.moleculeName ;
for (var i=0; i < moleculeIndex.moleculeData.length; i++) {
if (this.fieldNumerics[i]) {
if (moleculeIndex.moleculeData[i] != null ) {
line+="\t" + moleculeIndex.moleculeData[i];
} else {
line+="\t";
}}}
printWriter.println$S(line);
}
}
printWriter.println$S("</molecules>");
}, p$1);

Clazz.newMeth(C$, 'writeMMPFile$java_io_PrintWriter',  function (printWriter) {
printWriter.println$S("<matchedmolecularpairs-fileinfo>");
printWriter.println$S("<version=\"" + C$.VERSION + "\">" );
var dateFormat=Clazz.new_($I$(2,1).c$$S,["dd/MM/yyyy"]);
var date=Clazz.new_(java.util.Date);
printWriter.println$S("<date=\"" + dateFormat.format$java_util_Date(date) + "\">" );
printWriter.println$S("<dataset=\"" + this.datasetName + "\">" );
printWriter.println$S("<moleculesrowcount=" + Integer.toString$I(this.moleculesRowCount) + ">" );
printWriter.println$S("<mmpuniquefragmentsrowcount=" + Integer.toString$I(this.mmpUniqueFragments.getUniqueFragmentsCount$()) + ">" );
printWriter.println$S("<mmpfragmentsrowcount=" + Integer.toString$I(this.mmpFragments.getFragmentsCount$()) + ">" );
printWriter.println$S("<mmprowcount=" + Integer.toString$I(this.matchedMolecularPairs.getMMPsCount$()) + ">" );
printWriter.println$S("<keysminatoms=\"" + Integer.toString$I(($I$(1).KEYS_MIN_ATOMS).$c()) + "\">" );
printWriter.println$S("</matchedmolecularpairs-fileinfo>");
p$1.writeMolecules$java_io_PrintWriter.apply(this, [printWriter]);
this.mmpUniqueFragments.writeUniqueFragments$java_io_PrintWriter(printWriter);
this.mmpFragments.writeFragments$java_io_PrintWriter(printWriter);
this.matchedMolecularPairs.writeMMPs$java_io_PrintWriter(printWriter);
printWriter.close$();
});

Clazz.newMeth(C$, 'round$F$I',  function (f, decimalPlace) {
var bd=Clazz.new_([Float.toString$F(f)],$I$(17,1).c$$S);
bd=bd.setScale$I$I(decimalPlace, 4);
return bd.floatValue$();
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.VERSION="1.1";
C$.r1H=$I$(1).createR1HMoleculeID$();
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMP, "MoleculeIndex", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['moleculeIndex'],'S',['moleculeName','moleculeIDCode','moleculeIDCoord'],'O',['moleculeData','String[]']]]

Clazz.newMeth(C$, 'c$$I$S$S$S$SA',  function (moleculeIndex, moleculeIDCoord, moleculeIDCode, moleculeName, moleculeData) {
;C$.$init$.apply(this);
this.moleculeIndex=moleculeIndex;
this.moleculeIDCoord=moleculeIDCoord;
this.moleculeIDCode=moleculeIDCode;
this.moleculeName=moleculeName;
this.moleculeData=moleculeData;
}, 1);

Clazz.newMeth(C$, 'c$$I$S$SA',  function (moleculeIndex, moleculeName, moleculeData) {
;C$.$init$.apply(this);
this.moleculeIndex=moleculeIndex;
this.moleculeName=moleculeName;
this.moleculeData=moleculeData;
this.moleculeIDCode=null;
this.moleculeIDCoord=null;
}, 1);

Clazz.newMeth(C$, 'setIDCode$S',  function (moleculeIDCode) {
this.moleculeIDCode=moleculeIDCode;
});

Clazz.newMeth(C$, 'setIDCoord$S',  function (moleculeIDCoord) {
this.moleculeIDCoord=moleculeIDCoord;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:42 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
