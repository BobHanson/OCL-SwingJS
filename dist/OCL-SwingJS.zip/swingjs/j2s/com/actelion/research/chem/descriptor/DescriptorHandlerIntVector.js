(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.descriptor.DescriptorEncoder','java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerIntVector", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['correctionFactor']]
,['O',['FAILED_OBJECT','int[]']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.correctionFactor=0.42;
}, 1);

Clazz.newMeth(C$, 'setCorrectionFactor$D',  function (correctionFactor) {
this.correctionFactor=correctionFactor;
});

Clazz.newMeth(C$, ['getSimilarity$IA$IA','getSimilarity$O$O'],  function (d1, d2) {
if (d1 == null  || d2 == null  ) return NaN;
var total=0;
var matching=0;
for (var i=0; i < d1.length; i++) {
total+=Math.max(d1[i], d2[i]);
matching+=Math.min(d1[i], d2[i]);
}
return p$1.normalizeValue$D.apply(this, [matching / total]);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, this.correctionFactor), 1.0 / this.correctionFactor));
}, p$1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_IntegerVector;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(1).DESCRIPTOR_IntegerVector.version;
});

Clazz.newMeth(C$, ['encode$IA','encode$O'],  function (d) {
return this.calculationFailed$IA(d) ? "Calculation Failed" :  String.instantialize(Clazz.new_($I$(2,1)).encodeIntArray$IA(d), $I$(3).UTF_8);
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return s == null  ? null : Clazz.new_($I$(2,1)).decodeIntArray$S(s);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
return bytes == null  ? null : Clazz.new_($I$(2,1)).decodeIntArray$BA(bytes);
});

Clazz.newMeth(C$, 'createDescriptor$O',  function (o) {
return o;
});

Clazz.newMeth(C$, ['calculationFailed$IA','calculationFailed$O'],  function (d) {
return d == null  || d.length == 0 ;
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.array(Integer.TYPE, [0]);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:40 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
