(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'com.actelion.research.util.datamodel.IntVec','com.actelion.research.chem.descriptor.DescriptorEncoder','java.nio.charset.StandardCharsets','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DistHistEncoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['iNBitsEntriesCountOneHistogram','iNBitsPos','iNBitsConsequentEntries','iNBitsCountOneField']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.DistHistEncoder']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
var iNumConf=200;
var iLenHist=80;
var maxNumEntriesOneHist=40;
this.iNBitsEntriesCountOneHistogram=1;
while (Math.pow(2, this.iNBitsEntriesCountOneHistogram) < maxNumEntriesOneHist ){
++this.iNBitsEntriesCountOneHistogram;
}
this.iNBitsConsequentEntries=this.iNBitsEntriesCountOneHistogram;
this.iNBitsPos=1;
while (Math.pow(2, this.iNBitsPos) < iLenHist ){
++this.iNBitsPos;
}
this.iNBitsCountOneField=1;
while (Math.pow(2, this.iNBitsCountOneField) < iNumConf ){
++this.iNBitsCountOneField;
}
}, p$1);

Clazz.newMeth(C$, 'encodeHistograms$com_actelion_research_chem_descriptor_flexophore_DistHist',  function (dh) {
var numPPNodes=dh.getNumPPNodes$();
if (dh.getNumPPNodes$() == 1) {
return "";
}var nApproxBitsNeeded=0;
for (var i=0; i < numPPNodes; i++) {
for (var j=i + 1; j < numPPNodes; j++) {
var arrHist=dh.getDistHist$I$I(i, j);
var iOccupied=0;
for (var k=0; k < arrHist.length; k++) {
if (arrHist[k] > 0) ++iOccupied;
}
nApproxBitsNeeded+=this.iNBitsEntriesCountOneHistogram + iOccupied * (this.iNBitsPos + this.iNBitsCountOneField + this.iNBitsConsequentEntries );
}
}
var arr=Clazz.array(Boolean.TYPE, [nApproxBitsNeeded]);
var posArray=0;
for (var i=0; i < numPPNodes; i++) {
for (var j=i + 1; j < numPPNodes; j++) {
var arrHist=dh.getDistHist$I$I(i, j);
var nFieldsOccupied=0;
for (var k=0; k < arrHist.length; k++) {
if (arrHist[k] > 0) ++nFieldsOccupied;
}
for (var k=0; k < this.iNBitsEntriesCountOneHistogram; k++) {
if ((nFieldsOccupied & 1) == 1) {
arr[posArray]=true;
}nFieldsOccupied>>>=1;
++posArray;
}
var histogramProcessed=false;
var k=0;
while (!histogramProcessed){
if (arrHist[k] > 0) {
var posInHist=k;
for (var l=0; l < this.iNBitsPos; l++) {
if ((posInHist & 1) == 1) {
arr[posArray]=true;
}posInHist>>>=1;
++posArray;
}
var nConsequentFieldsOcc=1;
for (var l=k + 1; l < arrHist.length; l++) {
if (arrHist[l] > 0) {
++nConsequentFieldsOcc;
} else {
break;
}}
var nConsequentFieldsOcc2Bit=nConsequentFieldsOcc;
for (var m=0; m < this.iNBitsConsequentEntries; m++) {
if ((nConsequentFieldsOcc2Bit & 1) == 1) {
arr[posArray]=true;
}nConsequentFieldsOcc2Bit>>>=1;
++posArray;
}
var startSet=k;
var endSet=k + nConsequentFieldsOcc;
for (var l=startSet; l < endSet; l++) {
var counts=arrHist[l];
for (var m=0; m < this.iNBitsCountOneField; m++) {
if ((counts & 1) == 1) {
arr[posArray]=true;
}counts>>>=1;
++posArray;
}
}
k+=nConsequentFieldsOcc;
}++k;
if (k >= arrHist.length) {
histogramProcessed=true;
}}
}
}
var arrTruncated=Clazz.array(Boolean.TYPE, [posArray]);
System.arraycopy$O$I$O$I$I(arr, 0, arrTruncated, 0, arrTruncated.length);
var iv=Clazz.new_($I$(1,1).c$$ZA,[arrTruncated]);
var s= String.instantialize(Clazz.new_($I$(2,1)).encode$IA(iv.get$()), $I$(3).UTF_8);
return s;
});

Clazz.newMeth(C$, 'decodeHistograms$S$com_actelion_research_chem_descriptor_flexophore_MolDistHist',  function (s, mdh) {
var iv=Clazz.new_([Clazz.new_($I$(2,1)).decode$S(s)],$I$(1,1).c$$IA);
var liHist=Clazz.new_($I$(4,1));
var decodeFinished=false;
var pos=0;
while (!decodeFinished){
var nEntriesInHistogram=C$.getDecodedValue$com_actelion_research_util_datamodel_IntVec$I$I(iv, pos, this.iNBitsEntriesCountOneHistogram);
if (nEntriesInHistogram == 0) {
break;
}pos+=this.iNBitsEntriesCountOneHistogram;
var arrHist=Clazz.array(Byte.TYPE, [80]);
var processedEntries=0;
while (processedEntries != nEntriesInHistogram){
var positionField=C$.getDecodedValue$com_actelion_research_util_datamodel_IntVec$I$I(iv, pos, this.iNBitsPos);
pos+=this.iNBitsPos;
var consequentCounts=C$.getDecodedValue$com_actelion_research_util_datamodel_IntVec$I$I(iv, pos, this.iNBitsConsequentEntries);
pos+=this.iNBitsConsequentEntries;
for (var j=0; j < consequentCounts; j++) {
var counts=C$.getDecodedValue$com_actelion_research_util_datamodel_IntVec$I$I(iv, pos, this.iNBitsCountOneField);
pos+=this.iNBitsCountOneField;
arrHist[positionField++]=(counts|0);
}
processedEntries+=consequentCounts;
}
liHist.add$O(arrHist);
if (pos + this.iNBitsEntriesCountOneHistogram >= iv.sizeBits$()) {
break;
}}
var size=C$.getNumNodes$I(liHist.size$());
if (size == 0) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Number of pharmacophore points is 0."]);
}var cc=0;
for (var i=0; i < size; i++) {
for (var j=i + 1; j < size; j++) {
mdh.setDistHist$I$I$BA(i, j, liHist.get$I(cc++));
}
}
});

Clazz.newMeth(C$, 'getNumNodes$I',  function (nHistogramms) {
var nNodes=0;
var cc=0;
while (cc <= nHistogramms){
++nNodes;
cc+=nNodes;
}
return nNodes;
}, 1);

Clazz.newMeth(C$, 'getDecodedValue$com_actelion_research_util_datamodel_IntVec$I$I',  function (iv, posStart, widthInBits) {
var posEnd=posStart + widthInBits;
var value=0;
for (var i=posEnd - 1; i >= posStart; i--) {
value<<=1;
if (iv.isBitSet$I(i)) {
value|=1;
}}
return value;
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
