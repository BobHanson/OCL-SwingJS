(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[[0,'com.actelion.research.chem.IDCodeParserWithoutCoordinateInvention','com.actelion.research.chem.conf.Conformer','java.nio.charset.StandardCharsets','com.actelion.research.util.ArrayUtils','StringBuilder','com.actelion.research.chem.Canonizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ConformerSet", null, 'java.util.TreeSet');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$S.apply(this, [null]);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (s) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
if (s != null ) {
var confString=s.split$S(" ");
if (confString.length >= 2) {
var parser=Clazz.new_($I$(1,1));
var mol=parser.getCompactMolecule$S$S(confString[0], confString[1]);
var firstConformer=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.add$O(firstConformer);
for (var i=2; i < confString.length; i++) {
var conf=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_conf_Conformer,[firstConformer]);
try {
parser.parseCoordinates$BA$I$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CoordinatesA(confString[i].getBytes$java_nio_charset_Charset($I$(3).UTF_8), 0, mol, conf.getCoordinates$());
this.add$O(conf);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
}}}, 1);

Clazz.newMeth(C$, 'c$$BA$BA',  function (idcode, coords) {
;C$.superclazz.c$.apply(this,[]);C$.$init$.apply(this);
if (idcode != null  && coords != null  ) {
var parser=Clazz.new_($I$(1,1));
var mol=parser.getCompactMolecule$BA$BA(idcode, coords);
var firstConformer=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.add$O(firstConformer);
var index=$I$(4).indexOf$BA$B$I(coords, 32, 0);
while (index != -1){
var conf=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_conf_Conformer,[firstConformer]);
try {
parser.parseCoordinates$BA$I$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_CoordinatesA(coords, index + 1, mol, conf.getCoordinates$());
this.add$O(conf);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}
}}, 1);

Clazz.newMeth(C$, 'getSubset$I',  function (size) {
var treeSet=Clazz.new_(C$);
this.stream$().limit$J(size).forEach$java_util_function_Consumer(((P$.ConformerSet$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "ConformerSet$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_conf_Conformer','accept$O'],  function (c) { return (this.$finals$.treeSet.add$O.apply(this.$finals$.treeSet, [c]));});
})()
), Clazz.new_(P$.ConformerSet$lambda1.$init$,[this, {treeSet:treeSet}])));
return treeSet;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(5,1));
if (!this.isEmpty$()) {
var iterator=this.iterator$();
var mol=iterator.next$().toMolecule$();
var can=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule$I,[mol, 64]);
sb.append$S(can.getIDCode$());
sb.append$S(" ");
sb.append$S(can.getEncodedCoordinates$Z(true));
while (iterator.hasNext$()){
can.invalidateCoordinates$();
iterator.next$().toMolecule$com_actelion_research_chem_StereoMolecule(mol);
sb.append$S(" ");
sb.append$S(can.getEncodedCoordinates$Z(true));
}
}return sb.toString();
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
