(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.type"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.type.Bond']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Charge");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getFormalCharges$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (mol) {
var charges=Clazz.array(Double.TYPE, [mol.getAllAtoms$()]);
var conj;
 overatoms : for (var atom=0; atom < charges.length; atom++) {
var type=mol.getAtomType$I(atom);
charges[atom]=0.0;
switch (type) {
case 32:
case 72:
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
var nbrType=mol.getAtomType$I(nbr);
var nSecNtoNbr=0;
var nTermOStoNbr=0;
for (var j=0; j < mol.getAllConnAtoms$I(nbr); j++) {
var nbr2=mol.getConnAtom$I$I(nbr, j);
if (mol.getAtomicNo$I(nbr2) == 7 && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 2  && !mol.isAromaticAtom$I(nbr2) ) ++nSecNtoNbr;
if ((mol.getAtomicNo$I(nbr2) == 8 || mol.getAtomicNo$I(nbr2) == 16 ) && C$.degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(mol, nbr2) == 1 ) ++nTermOStoNbr;
}
if (mol.getAtomicNo$I(nbr) == 16 && nTermOStoNbr == 2  && nSecNtoNbr == 1 ) nSecNtoNbr=0;
if (mol.getAtomicNo$I(nbr) == 6 && nTermOStoNbr > 0 ) {
charges[atom]=nTermOStoNbr == 1 ? -1.0 : -(nTermOStoNbr - 1) / nTermOStoNbr;
continue overatoms;
}if (nbrType == 45 && nTermOStoNbr == 3 ) {
charges[atom]=-0.3333333333333333;
continue overatoms;
}if (nbrType == 25 && nTermOStoNbr > 0 ) {
charges[atom]=nTermOStoNbr == 1 ? 0.0 : -(nTermOStoNbr - 1) / nTermOStoNbr;
continue overatoms;
}if (nbrType == 18 && nTermOStoNbr > 0 ) {
charges[atom]=nSecNtoNbr + nTermOStoNbr == 2 ? 0.0 : -(nSecNtoNbr + nTermOStoNbr - 2) / nTermOStoNbr;
continue overatoms;
}if (nbrType == 73 && nTermOStoNbr > 0 ) {
charges[atom]=nTermOStoNbr == 1 ? 0.0 : -(nTermOStoNbr - 1) / nTermOStoNbr;
continue overatoms;
}if (nbrType == 77 && nTermOStoNbr > 0 ) {
charges[atom]=-1.0 / nTermOStoNbr;
continue overatoms;
}}
break;
case 76:
var ring=0;
var rings=mol.getRingSet$();
for (var r=0; r < rings.getSize$(); r++) if (rings.isAtomMember$I$I(r, atom)) {
ring=r;
break;
}
if (ring < rings.getSize$()) {
var nNitrogensIn5Ring=0;
for (var a, $a = 0, $$a = rings.getRingAtoms$I(ring); $a<$$a.length&&((a=($$a[$a])),1);$a++) if (a > -1 && mol.getAtomType$I(a) == 76 ) ++nNitrogensIn5Ring;

if (nNitrogensIn5Ring > 0) {
charges[atom]=-1.0 / nNitrogensIn5Ring;
continue overatoms;
}}break;
case 55:
case 56:
case 81:
charges[atom]=mol.getAtomCharge$I(atom);
var nConj=1;
var old_nConj=0;
conj=Clazz.array(Boolean.TYPE, [mol.getAllAtoms$()]);
conj[atom]=true;
while (nConj > old_nConj){
old_nConj=nConj;
for (var i=0; i < mol.getAllAtoms$(); i++) {
if (!conj[i]) continue;
for (var j=0; j < mol.getAllConnAtoms$I(i); j++) {
var nbr=mol.getConnAtom$I$I(i, j);
var nbrType=mol.getAtomType$I(nbr);
if (nbrType != 57 && nbrType != 80 ) continue;
for (var k=0; k < mol.getAllConnAtoms$I(nbr); k++) {
var nbr2=mol.getConnAtom$I$I(nbr, k);
var nbr2type=mol.getAtomType$I(nbr2);
if (nbr2type != 55 && nbr2type != 56  && nbr2type != 81 ) continue;
if (conj[nbr2]) continue;
conj[nbr2]=true;
charges[atom]+=mol.getAtomCharge$I(nbr2);
++nConj;
}
}
}
}
charges[atom]/=nConj;
continue overatoms;
case 61:
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomType$I(nbr) == 42) {
charges[atom]=1.0;
continue overatoms;
}}
continue overatoms;
case 34:
case 49:
case 51:
case 54:
case 58:
case 92:
case 93:
case 94:
case 97:
charges[atom]=1.0;
continue overatoms;
case 87:
case 95:
case 96:
case 98:
case 99:
charges[atom]=2.0;
continue overatoms;
case 88:
charges[atom]=3.0;
continue overatoms;
case 35:
case 62:
case 89:
case 90:
case 91:
charges[atom]=-1.0;
continue overatoms;
}
charges[atom]=0.0;
}
return charges;
}, 1);

Clazz.newMeth(C$, 'getCharges$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (table, mol) {
var fcharges=C$.getFormalCharges$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(mol);
var charges=Clazz.array(Double.TYPE, [fcharges.length]);
for (var atom=0; atom < fcharges.length; atom++) {
var type=mol.getAtomType$I(atom);
var q0=fcharges[atom];
var v=table.chge.getFcadj$I(type);
var M=table.atom.crd$I(type);
var sumFormal=0.0;
var sumPartial=0.0;
if (Math.abs(v) < 1.0E-4 ) for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (fcharges[nbr] < 0.0 ) q0+=fcharges[nbr] / (2.0 * mol.getAllConnAtoms$I(nbr));
}
if (type == 62) for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
if (fcharges[nbr] > 0.0 ) q0-=fcharges[nbr] / 2.0;
}
for (var i=0; i < mol.getAllConnAtoms$I(atom); i++) {
var nbr=mol.getConnAtom$I$I(atom, i);
var bond=mol.getBond$I$I(atom, nbr);
var nbrType=mol.getAtomType$I(nbr);
var bondType=$I$(1).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I(table, mol, bond);
sumPartial+=table.chge.getPartial$I$I$I(bondType, type, nbrType);
sumFormal+=fcharges[nbr];
}
charges[atom]=(1.0 - M * v) * q0 + v * sumFormal + sumPartial;
}
return charges;
}, 1);

Clazz.newMeth(C$, 'degree$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (mol, atom) {
return mol.getAllConnAtoms$I(atom) + mol.getImplicitHydrogens$I(atom);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
