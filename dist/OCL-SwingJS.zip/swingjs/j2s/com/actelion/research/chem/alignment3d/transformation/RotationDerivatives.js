(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),p$1={},I$=[[0,'com.actelion.research.chem.alignment3d.transformation.ExponentialMap','com.actelion.research.chem.alignment3d.transformation.Quaternion']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "RotationDerivatives");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.sinp=Math.sin(0.5 * this.theta);
},1);

C$.$fields$=[['D',['theta','cosp','sinp'],'O',['v','double[]','q','com.actelion.research.chem.alignment3d.transformation.Quaternion']]]

Clazz.newMeth(C$, 'c$$DA',  function (v) {
;C$.$init$.apply(this);
this.v=v;
this.theta=Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
this.cosp=Math.cos(0.5 * this.theta);
this.sinp=Math.sin(0.5 * this.theta);
var em=Clazz.new_($I$(1,1).c$$D$D$D,[v[0], v[1], v[2]]);
this.q=em.toQuaternion$();
}, 1);

Clazz.newMeth(C$, 'dRdvi$com_actelion_research_chem_alignment3d_transformation_Quaternion$DAA',  function (dqdvi, dRdvi) {
var prod=Clazz.array(Double.TYPE, [9]);
prod[0]=-4 * this.q.getQ1$() * dqdvi.getQ1$() ;
prod[1]=-4 * this.q.getQ2$() * dqdvi.getQ2$() ;
prod[2]=-4 * this.q.getQ3$() * dqdvi.getQ3$() ;
prod[3]=2 * (this.q.getQ2$() * dqdvi.getQ1$() + this.q.getQ1$() * dqdvi.getQ2$());
prod[4]=2 * (this.q.getQ0$() * dqdvi.getQ3$() + this.q.getQ3$() * dqdvi.getQ0$());
prod[5]=2 * (this.q.getQ3$() * dqdvi.getQ1$() + this.q.getQ1$() * dqdvi.getQ3$());
prod[6]=2 * (this.q.getQ0$() * dqdvi.getQ2$() + this.q.getQ2$() * dqdvi.getQ0$());
prod[7]=2 * (this.q.getQ3$() * dqdvi.getQ2$() + this.q.getQ2$() * dqdvi.getQ3$());
prod[8]=2 * (this.q.getQ0$() * dqdvi.getQ1$() + this.q.getQ1$() * dqdvi.getQ0$());
dRdvi[0][0]=prod[1] + prod[2];
dRdvi[1][0]=prod[3] - prod[4];
dRdvi[2][0]=prod[5] + prod[6];
dRdvi[0][1]=prod[3] + prod[4];
dRdvi[1][1]=prod[0] + prod[2];
dRdvi[2][1]=prod[7] - prod[8];
dRdvi[0][2]=prod[5] - prod[6];
dRdvi[1][2]=prod[7] + prod[8];
dRdvi[2][2]=prod[0] + prod[1];
});

Clazz.newMeth(C$, 'dRdv$I$DAA',  function (i, dRdvi) {
var dqdvi;
var em=Clazz.new_($I$(1,1).c$$D$D$D,[this.v[0], this.v[1], this.v[2]]);
this.q=em.toQuaternion$();
dqdvi=p$1.dqdvi$I.apply(this, [i]);
this.dRdvi$com_actelion_research_chem_alignment3d_transformation_Quaternion$DAA(dqdvi, dRdvi);
});

Clazz.newMeth(C$, 'dqdvi$I',  function (i) {
var w;
var xyz=Clazz.array(Double.TYPE, [3]);
Clazz.assert(C$, this, function(){return (i >= 0 && i < 3 )});
if (this.theta < 1.0E-6 ) {
var i2=(i + 1) % 3;
var i3=(i + 2) % 3;
var Tsinc=0.5 - this.theta * this.theta / 48.0;
var vTerm=this.v[i] * (this.theta * this.theta / 40.0 - 1.0) / 24.0;
w=-0.5 * this.v[i] * Tsinc ;
xyz[i]=this.v[i] * vTerm + Tsinc;
xyz[i2]=this.v[i2] * vTerm;
xyz[i3]=this.v[i3] * vTerm;
} else {
var i2=(i + 1) % 3;
var i3=(i + 2) % 3;
var ang=1.0 / this.theta;
var ang2=ang * ang * this.v[i] ;
var sang=this.sinp * ang;
var cterm=ang2 * (0.5 * this.cosp - sang);
xyz[i]=cterm * this.v[i] + sang;
xyz[i2]=cterm * this.v[i2];
xyz[i3]=cterm * this.v[i3];
w=-0.5 * this.v[i] * sang ;
}return Clazz.new_($I$(2,1).c$$D$D$D$D,[w, xyz[0], xyz[1], xyz[2]]);
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:11 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
