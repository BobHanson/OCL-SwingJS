(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io"),p$1={},I$=[[0,'com.actelion.research.chem.io.CompoundFileHelper','com.actelion.research.chem.io.DWARFileParser','com.actelion.research.chem.io.SDFileParser','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.Canonizer','com.actelion.research.chem.IDCodeParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CompoundFileParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mStructureUpToDate','mIDCodeUpToDate'],'S',['mIDCode','mCoords'],'O',['mMol','com.actelion.research.chem.StereoMolecule','mDHFactory','com.actelion.research.chem.descriptor.DescriptorHandlerFactory','mReader','java.io.BufferedReader']]]

Clazz.newMeth(C$, 'createParser$S',  function (fileName) {
var parser=null;
var fileType=$I$(1).getFileType$S(fileName);
if (fileType == 1) parser=Clazz.new_($I$(2,1).c$$S,[fileName]);
 else if (fileType == 768) parser=Clazz.new_($I$(3,1).c$$S,[fileName]);
return parser.mReader == null  ? null : parser;
}, 1);

Clazz.newMeth(C$, 'isOpen$',  function () {
return this.mReader != null ;
});

Clazz.newMeth(C$, 'next$',  function () {
this.mStructureUpToDate=false;
this.mIDCodeUpToDate=false;
return this.advanceToNext$();
});

Clazz.newMeth(C$, 'close$',  function () {
if (this.mReader != null ) {
try {
this.mReader.close$();
} catch (ioe) {
if (Clazz.exceptionOf(ioe,"java.io.IOException")){
} else {
throw ioe;
}
}
}});

Clazz.newMeth(C$, 'getIDCode$',  function () {
p$1.updateIDCodeAndCoords.apply(this, []);
return this.mIDCode;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
p$1.updateIDCodeAndCoords.apply(this, []);
return this.mCoords;
});

Clazz.newMeth(C$, 'setDescriptorHandlerFactory$com_actelion_research_chem_descriptor_DescriptorHandlerFactory',  function (factory) {
this.mDHFactory=factory;
});

Clazz.newMeth(C$, 'getDescriptorHandlerFactory$',  function () {
return this.mDHFactory;
});

Clazz.newMeth(C$, 'getFieldIndex$S',  function (fieldName) {
var name=this.getFieldNames$();
if (name != null ) for (var i=0; i < name.length; i++) if (fieldName.equals$O(name[i])) return i;

return -1;
});

Clazz.newMeth(C$, 'getDescriptor$S',  function (shortName) {
if (this.mDHFactory != null ) {
var dh=this.mDHFactory.getDefaultDescriptorHandler$S(shortName);
var d=dh.createDescriptor$O(this.getMolecule$());
return dh.calculationFailed$O(d) ? null : d;
}return null;
});

Clazz.newMeth(C$, 'updateIDCodeAndCoords',  function () {
if (!this.mIDCodeUpToDate) {
try {
var mol=Clazz.new_([this.getMolecule$()],$I$(4,1).c$$com_actelion_research_chem_Molecule);
mol.normalizeAmbiguousBonds$();
mol.canonizeCharge$Z(true);
var canonizer=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
this.mIDCode=canonizer.getIDCode$();
this.mCoords=canonizer.getEncodedCoordinates$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
this.mIDCode=null;
this.mCoords=null;
} else {
throw e;
}
}
this.mIDCodeUpToDate=true;
}}, p$1);

Clazz.newMeth(C$, 'getMolecule$',  function () {
if (!this.mStructureUpToDate) {
var idcode=this.getIDCode$();
var coords=this.getCoordinates$();
this.mMol=null;
try {
this.mMol=Clazz.new_([coords == null ],$I$(6,1).c$$Z).getCompactMolecule$S$S(idcode, coords);
if (this.mMol != null ) this.mMol.setName$S(this.getMoleculeName$());
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}this.mStructureUpToDate=true;
return this.mMol;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-16 11:49:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
