(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.Arrays','com.actelion.research.chem.Canonizer','com.actelion.research.util.BurtleHasher','com.actelion.research.chem.descriptor.DescriptorEncoder','com.actelion.research.chem.descriptor.DescriptorHandler','java.nio.charset.StandardCharsets','com.actelion.research.chem.descriptor.DescriptorConstants']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerSkeletonSpheres", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['FAILED_OBJECT','byte[]','sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerSkeletonSpheres']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) {
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, ['calculationFailed$BA','calculationFailed$O'],  function (o) {
return o == null  || o.length == 0 ;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
if (mol == null ) return null;
mol.ensureHelperArrays$I(7);
var fragment=Clazz.new_([mol.getAtoms$(), mol.getBonds$()],$I$(1,1).c$$I$I);
var descriptor=Clazz.array(Byte.TYPE, [1024]);
var atomList=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var atomMask=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var rootAtom=0; rootAtom < mol.getAtoms$(); rootAtom++) {
if (rootAtom != 0) $I$(2).fill$ZA$Z(atomMask, false);
var min=0;
var max=0;
for (var sphere=0; sphere < 5 && max < mol.getAtoms$() ; sphere++) {
if (max == 0) {
atomList[0]=rootAtom;
atomMask[rootAtom]=true;
max=1;
} else {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < mol.getConnAtoms$I(atom); j++) {
var connAtom=mol.getConnAtom$I$I(atom, j);
if (!atomMask[connAtom]) {
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
}}
}
min=max;
max=newMax;
}mol.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragment, atomMask, true, null);
if (sphere < 4) {
var idcode=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$();
var h=$I$(4).hashlittle$S$J(idcode, 13);
h=(h & $I$(4).hashmask$I(10));
if (descriptor[h] < 63) (($b$[0]=++descriptor[h],descriptor[h]=$b$[0],$b$[0]));
}if (sphere < 5) {
for (var atom=0; atom < fragment.getAllAtoms$(); atom++) fragment.setAtomicNo$I$I(atom, 6);

var idcode=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[fragment]).getIDCode$();
var h=$I$(4).hashlittle$S$J(idcode, 13);
h=(h & $I$(4).hashmask$I(10));
if (descriptor[h] < 63) (($b$[0]=++descriptor[h],descriptor[h]=$b$[0],$b$[0]));
}}
}
return descriptor;
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return s == null  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : Clazz.new_($I$(5,1)).decodeCounts$S(s);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
return bytes == null  ? null : $I$(2,"equals$BA$BA",[bytes, $I$(6).FAILED_BYTES]) ? C$.FAILED_OBJECT : Clazz.new_($I$(5,1)).decodeCounts$BA(bytes);
});

Clazz.newMeth(C$, ['encode$BA','encode$O'],  function (o) {
return this.calculationFailed$BA(o) ? "Calculation Failed" :  String.instantialize(Clazz.new_($I$(5,1)).encodeCounts$BA(o), $I$(7).UTF_8);
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(8).DESCRIPTOR_SkeletonSpheres;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(8).DESCRIPTOR_SkeletonSpheres.version;
});

Clazz.newMeth(C$, ['getSimilarity$BA$BA','getSimilarity$O$O'],  function (d1, d2) {
if (d1 == null  || d2 == null  ) return NaN;
var total=0;
var matching=0;
for (var i=0; i < d1.length; i++) {
var i1=d1[i];
var i2=d2[i];
total+=Math.max(i1, i2);
matching+=Math.min(i1, i2);
}
return this.normalizeValue$D(matching / total);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.7), 1.4285714285714286));
});

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return this;
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.array(Byte.TYPE, [0]);
};
var $b$ = new Int8Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:20 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
