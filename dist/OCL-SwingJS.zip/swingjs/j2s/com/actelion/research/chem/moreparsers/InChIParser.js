(function(){var P$=Clazz.newPackage("com.actelion.research.chem.moreparsers"),I$=[[0,'com.actelion.research.chem.inchi.InChIJNI','com.actelion.research.chem.moreparsers.ParserUtils','com.actelion.research.chem.MolfileParser']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIParser");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mMode'],'S',['type']]]

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I.apply(this, [0]);
}, 1);

Clazz.newMeth(C$, 'c$$S',  function (type) {
;C$.$init$.apply(this);
this.mMode=0;
this.type=type;
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (mode) {
;C$.$init$.apply(this);
this.mMode=mode;
this.type="inchi";
}, 1);

Clazz.newMeth(C$, 'c$$I$S',  function (mode, type) {
;C$.$init$.apply(this);
this.mMode=mode;
this.type=type;
}, 1);

Clazz.newMeth(C$, 'parse$com_actelion_research_chem_StereoMolecule$S',  function (mol, code) {
var url;
switch (this.type) {
default:
case "inchi":
if (!code.startsWith$S("PubChem:")) {
return $I$(1).inchiToMolecule$S$com_actelion_research_chem_StereoMolecule(code, mol);
} else {
code=code.substring$I(8);
code=code.replaceAll$S$S("=", "%3D").replaceAll$S$S("/", "%2F").replaceAll$S$S("\\+", "%2B").replaceAll$S$S(",", "%2C").replaceAll$S$S("\\(", "%28").replaceAll$S$S("\\)", "%29");
url="https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchi/SDF?record_type=2d&inchi=" + code;
break;
}case "inchikey":
url="https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/inchikey/XX/SDF?record_type=2d".replace$CharSequence$CharSequence("XX", code);
break;
}
var molfile=$I$(2).getURLContentsAsString$S(url);
return molfile != null  && Clazz.new_($I$(3,1).c$$I,[this.mMode]).parse$com_actelion_research_chem_StereoMolecule$S(mol, molfile) ;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 18:19:44 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
