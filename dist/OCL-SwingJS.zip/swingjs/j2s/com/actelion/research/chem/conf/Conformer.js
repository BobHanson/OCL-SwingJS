(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','java.util.Arrays','com.actelion.research.chem.conf.TorsionDescriptorHelper']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Conformer", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mEnergy','mLikelihood'],'S',['mName'],'O',['mCoordinates','com.actelion.research.chem.Coordinates[]','mMol','com.actelion.research.chem.StereoMolecule','mBondTorsion','short[]','mTorsionDescriptor','com.actelion.research.chem.conf.TorsionDescriptor']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mCoordinates=Clazz.array($I$(1), [mol.getAllAtoms$()]);
for (var atom=0; atom < mol.getAllAtoms$(); atom++) this.mCoordinates[atom]=Clazz.new_([mol.getCoordinates$I(atom)],$I$(1,1).c$$com_actelion_research_chem_Coordinates);

this.mEnergy=NaN;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer',  function (c) {
C$.c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_StereoMolecule.apply(this, [c, c.mMol]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_StereoMolecule',  function (c, mol) {
;C$.$init$.apply(this);
this.mMol=mol;
this.mCoordinates=Clazz.array($I$(1), [c.mCoordinates.length]);
for (var i=0; i < this.mCoordinates.length; i++) this.mCoordinates[i]=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Coordinates,[c.mCoordinates[i]]);

if (c.mBondTorsion != null ) this.mBondTorsion=$I$(2).copyOf$HA$I(c.mBondTorsion, c.mBondTorsion.length);
this.mName=(c.mName == null  || c.mName.endsWith$S(" (copy)") ) ? c.mName : c.mName.concat$S(" (copy)");
this.mEnergy=NaN;
}, 1);

Clazz.newMeth(C$, 'center$',  function () {
var cog=Clazz.new_($I$(1,1));
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) cog.add$com_actelion_research_chem_Coordinates(this.mCoordinates[atom]);

cog.scale$D(1.0 / this.mMol.getAllAtoms$());
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) this.mCoordinates[atom].sub$com_actelion_research_chem_Coordinates(cog);

return this;
});

Clazz.newMeth(C$, 'translate$D$D$D',  function (dx, dy, dz) {
for (var atom=0; atom < this.mMol.getAllAtoms$(); atom++) this.mCoordinates[atom].add$D$D$D(dx, dy, dz);

return this;
});

Clazz.newMeth(C$, 'getSize$',  function () {
return this.mCoordinates.length;
});

Clazz.newMeth(C$, 'getX$I',  function (atom) {
return this.mCoordinates[atom].x;
});

Clazz.newMeth(C$, 'getY$I',  function (atom) {
return this.mCoordinates[atom].y;
});

Clazz.newMeth(C$, 'getZ$I',  function (atom) {
return this.mCoordinates[atom].z;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
return this.mCoordinates;
});

Clazz.newMeth(C$, 'getCoordinates$I',  function (atom) {
return this.mCoordinates[atom];
});

Clazz.newMeth(C$, 'setCoordinates$I$com_actelion_research_chem_Coordinates',  function (atom, coords) {
this.mCoordinates[atom].set$com_actelion_research_chem_Coordinates(coords);
});

Clazz.newMeth(C$, 'setCoordinatesReplace$I$com_actelion_research_chem_Coordinates',  function (atom, coords) {
this.mCoordinates[atom]=coords;
});

Clazz.newMeth(C$, 'setX$I$D',  function (atom, x) {
this.mCoordinates[atom].x=x;
});

Clazz.newMeth(C$, 'setY$I$D',  function (atom, y) {
this.mCoordinates[atom].y=y;
});

Clazz.newMeth(C$, 'setZ$I$D',  function (atom, z) {
this.mCoordinates[atom].z=z;
});

Clazz.newMeth(C$, 'deleteAtoms$ZA',  function (isToBeDeleted) {
var count=0;
for (var i=0; i < this.mCoordinates.length; i++) if (isToBeDeleted[i]) ++count;

if (count != 0) {
var newCoords=Clazz.array($I$(1), [this.mCoordinates.length - count]);
var newIndex=0;
for (var i=0; i < this.mCoordinates.length; i++) if (!isToBeDeleted[i]) newCoords[newIndex++]=this.mCoordinates[i];

this.mCoordinates=newCoords;
this.mBondTorsion=null;
}return count;
});

Clazz.newMeth(C$, 'calculateTorsion$IA',  function (atom) {
var c1=this.getCoordinates$I(atom[0]);
var c2=this.getCoordinates$I(atom[1]);
var c3=this.getCoordinates$I(atom[2]);
var c4=this.getCoordinates$I(atom[3]);
var v1=c2.subC$com_actelion_research_chem_Coordinates(c1);
var v2=c3.subC$com_actelion_research_chem_Coordinates(c2);
var v3=c4.subC$com_actelion_research_chem_Coordinates(c3);
var n1=v1.cross$com_actelion_research_chem_Coordinates(v2);
var n2=v2.cross$com_actelion_research_chem_Coordinates(v3);
return -Math.atan2(v2.getLength$() * v1.dot$com_actelion_research_chem_Coordinates(n2), n1.dot$com_actelion_research_chem_Coordinates(n2));
});

Clazz.newMeth(C$, 'getBondTorsion$I',  function (bond) {
return this.mBondTorsion == null  ? ($s$[0] = -1, $s$[0]) : this.mBondTorsion[bond];
});

Clazz.newMeth(C$, 'setBondTorsion$I$H',  function (bond, torsion) {
if (this.mBondTorsion == null ) {
this.mBondTorsion=Clazz.array(Short.TYPE, [this.mMol.getAllBonds$()]);
$I$(2).fill$HA$H(this.mBondTorsion, -1);
}while (torsion < 0)torsion=($s$[0] = torsion+(360), $s$[0]);

while (torsion >= 360)torsion=($s$[0] = torsion-(360), $s$[0]);

this.mBondTorsion[bond]=torsion;
});

Clazz.newMeth(C$, 'getMolecule$',  function () {
return this.mMol;
});

Clazz.newMeth(C$, 'copyFrom$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var atom=0; atom < mol.getAllAtoms$(); atom++) this.mCoordinates[atom].set$com_actelion_research_chem_Coordinates(mol.getCoordinates$I(atom));

});

Clazz.newMeth(C$, 'copyTo$com_actelion_research_chem_StereoMolecule',  function (mol) {
for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.getCoordinates$I(atom).set$com_actelion_research_chem_Coordinates(this.mCoordinates[atom]);

});

Clazz.newMeth(C$, 'copyFrom$com_actelion_research_chem_conf_Conformer',  function (conformer) {
for (var atom=0; atom < conformer.getSize$(); atom++) this.mCoordinates[atom].set$com_actelion_research_chem_Coordinates(conformer.mCoordinates[atom]);

if (conformer.mBondTorsion == null ) this.mBondTorsion=null;
 else this.mBondTorsion=$I$(2).copyOf$HA$I(conformer.mBondTorsion, conformer.mBondTorsion.length);
});

Clazz.newMeth(C$, 'toMolecule$',  function () {
return this.toMolecule$com_actelion_research_chem_StereoMolecule(this.mMol);
});

Clazz.newMeth(C$, 'toMolecule$com_actelion_research_chem_StereoMolecule',  function (mol) {
if (mol == null ) mol=this.mMol.getCompactCopy$();
for (var atom=0; atom < mol.getAllAtoms$(); atom++) mol.getCoordinates$I(atom).set$com_actelion_research_chem_Coordinates(this.mCoordinates[atom]);

if (this.mName != null ) mol.setName$S(this.mName);
return mol;
});

Clazz.newMeth(C$, 'getEnergy$',  function () {
return this.mEnergy;
});

Clazz.newMeth(C$, 'setEnergy$D',  function (energy) {
this.mEnergy=energy;
});

Clazz.newMeth(C$, 'getLikelihood$',  function () {
return this.mLikelihood;
});

Clazz.newMeth(C$, 'setLikelihood$D',  function (likelihood) {
this.mLikelihood=likelihood;
});

Clazz.newMeth(C$, 'getName$',  function () {
return this.mName == null  ? this.mMol.getName$() : this.mName;
});

Clazz.newMeth(C$, 'setName$S',  function (name) {
this.mName=name;
});

Clazz.newMeth(C$, 'equals$com_actelion_research_chem_conf_Conformer',  function (conformer) {
p$1.ensureDescriptors$com_actelion_research_chem_conf_Conformer.apply(this, [conformer]);
return this.mTorsionDescriptor.equals$com_actelion_research_chem_conf_TorsionDescriptor(conformer.mTorsionDescriptor);
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_conf_Conformer','compareTo$O'],  function (conformer) {
p$1.ensureDescriptors$com_actelion_research_chem_conf_Conformer.apply(this, [conformer]);
return this.mTorsionDescriptor.compareTo$com_actelion_research_chem_conf_TorsionDescriptor(conformer.mTorsionDescriptor);
});

Clazz.newMeth(C$, 'calculateDescriptor$IA',  function (rotatableBond) {
this.mTorsionDescriptor=Clazz.new_([this.getMolecule$(), rotatableBond],$I$(3,1).c$$com_actelion_research_chem_StereoMolecule$IA).getTorsionDescriptor$com_actelion_research_chem_conf_Conformer(this);
});

Clazz.newMeth(C$, 'ensureDescriptors$com_actelion_research_chem_conf_Conformer',  function (c) {
if (this.mTorsionDescriptor == null  || c.mTorsionDescriptor == null  ) {
var tdh=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[this.mMol]);
if (this.mTorsionDescriptor == null ) this.mTorsionDescriptor=tdh.getTorsionDescriptor$com_actelion_research_chem_conf_Conformer(this);
if (c.mTorsionDescriptor == null ) c.mTorsionDescriptor=tdh.getTorsionDescriptor$com_actelion_research_chem_conf_Conformer(c);
}}, p$1);
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-04 09:11:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
