(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "InchiUtils");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['inchiAveAtomicMass','int[]']]]

Clazz.newMeth(C$, 'getAtomicNumber$S',  function (sym) {
if (sym.length$() == 1) {
switch ((sym.charCodeAt$I(0))) {
case 72:
return 1;
case 66:
return 5;
case 67:
return 6;
case 79:
return 7;
case 70:
return 8;
case 80:
return 15;
case 83:
return 16;
}
}return ("xxH HeLiBeB C N O F NeNaMgAlSiP S ClArK CaScTiV CrMnFeCoNiCuZnGaGeAsSeBrKrRbSrY ZrNbMoTcRuRhPdAgCdInSnSbTeI XeCsBaLaCePrNdPmSmEuGdTbDyHoErTmYbLuHfTaW ReOsIrPtAuHgTlPbBiPoAtRnFrRaAcThPaU NpPuAmCmBkCfEsFmMdNoLrRfDbSgBhHsMtDsRgCnNhFlMcLvTsOg".indexOf$S(sym)/2|0);
}, 1);

Clazz.newMeth(C$, 'getActualMass$S$I',  function (sym, mass) {
if (mass < 900) {
return mass;
}var atno=C$.getAtomicNumber$S(sym);
return (mass - 10000) + C$.inchiAveAtomicMass[atno - 1];
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.inchiAveAtomicMass=Clazz.array(Integer.TYPE, -1, [1, 4, 7, 9, 11, 12, 14, 16, 19, 20, 23, 24, 27, 28, 31, 32, 35, 40, 39, 40, 45, 48, 51, 52, 55, 56, 59, 59, 64, 65, 70, 73, 75, 79, 80, 84, 85, 88, 89, 91, 93, 96, 98, 101, 103, 106, 108, 112, 115, 119, 122, 128, 127, 131, 133, 137, 139, 140, 141, 144, 145, 150, 152, 157, 159, 163, 165, 167, 169, 173, 175, 178, 181, 184, 186, 190, 192, 195, 197, 201, 204, 207, 209, 209, 210, 222, 223, 226, 227, 232, 231, 238, 237, 244, 243, 247, 247, 251, 252, 257, 258, 259, 260, 261, 270, 269, 270, 270, 278, 281, 281, 285, 278, 289, 289, 293, 297, 294]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
