(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'com.actelion.research.chem.properties.complexity.ContainerFragBondsSolutions','com.actelion.research.util.datamodel.IntArray','com.actelion.research.util.SizeOf','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ExhaustiveFragmentGeneratorBonds");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['fragmentsGenerated','capacityLimitBreakes'],'I',['nBondsMolecule','maximumNumberBondsInFrag','totalMaximumCapacity'],'J',['solutionAdded'],'O',['containerDataFragDefByBonds','com.actelion.research.chem.properties.complexity.ContainerFragBondsSolutions','mol','com.actelion.research.chem.ExtendedMolecule','arrIndexReachableNeighbours','com.actelion.research.util.datamodel.IntArray']]
,['Z',['ELUSIVE']]]

Clazz.newMeth(C$, 'c$$I$I',  function (bits, totalMaximumCapacity) {
;C$.$init$.apply(this);
$I$(1).ELUSIVE=C$.ELUSIVE;
this.totalMaximumCapacity=totalMaximumCapacity;
this.containerDataFragDefByBonds=Clazz.new_($I$(1,1).c$$I$I,[bits, totalMaximumCapacity]);
this.arrIndexReachableNeighbours=Clazz.new_($I$(2,1));
if (C$.ELUSIVE) System.out.println$S("ExhaustiveFragmentGeneratorBonds constructor finished, used mem " + Long.$s($I$(3).usedMemoryMB$()) + "[MB]." );
}, 1);

Clazz.newMeth(C$, 'set$com_actelion_research_chem_ExtendedMolecule$I',  function (mol, nMaximumNumberBonds) {
this.mol=mol;
this.nBondsMolecule=mol.getBonds$();
if (this.nBondsMolecule > this.containerDataFragDefByBonds.getSizeBinaryArray$()) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Maximum number of bonds exceeded."]);
}this.maximumNumberBondsInFrag=Math.min(nMaximumNumberBonds, this.containerDataFragDefByBonds.getMaximumCapacityBondsInFragment$());
this.fragmentsGenerated=false;
this.capacityLimitBreakes=false;
this.containerDataFragDefByBonds.setBondsMolecule$I(this.nBondsMolecule);
});

Clazz.newMeth(C$, 'initDataContainerAllSingleBonds',  function () {
this.containerDataFragDefByBonds.reset$();
for (var i=0; i < this.nBondsMolecule; i++) {
var f=this.containerDataFragDefByBonds.get$();
f.setBit$I(i);
this.containerDataFragDefByBonds.addFacultative$com_actelion_research_chem_properties_complexity_IBitArray(f);
}
}, p$1);

Clazz.newMeth(C$, 'initDataContainerOneSingleBond$I',  function (indexBond) {
this.containerDataFragDefByBonds.reset$();
var f=this.containerDataFragDefByBonds.get$();
f.setBit$I(indexBond);
this.containerDataFragDefByBonds.addFacultative$com_actelion_research_chem_properties_complexity_IBitArray(f);
}, p$1);

Clazz.newMeth(C$, 'generateFragmentsAllBonds$',  function () {
p$1.initDataContainerAllSingleBonds.apply(this, []);
p$1.generateFragments.apply(this, []);
});

Clazz.newMeth(C$, 'generateFragmentsForSingleBond$I',  function (indexBond) {
p$1.initDataContainerOneSingleBond$I.apply(this, [indexBond]);
p$1.generateFragments.apply(this, []);
});

Clazz.newMeth(C$, 'generateFragments',  function () {
var maxNumBondsFrag=Math.min(this.nBondsMolecule, this.maximumNumberBondsInFrag);
if (maxNumBondsFrag == 1) {
return;
}var neighboursTotal=0;
var addedTotal=0;
if (C$.ELUSIVE) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() start record capacity " + $I$(4,"group$Integer",[Integer.valueOf$I(this.containerDataFragDefByBonds.getAvailable$())]) + "." );
} maximumCapacityBreak : for (var i=1; i < maxNumBondsFrag; i++) {
var liParent=this.containerDataFragDefByBonds.getList$I(i);
if (C$.ELUSIVE) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() bonds  " + i + ". Parents " + $I$(4,"group$Integer",[Integer.valueOf$I(liParent.size$())]) + "." );
}var added=0;
var neighbours=0;
var neighboursSinceLastAdded=0;
for (var fParent, $fParent = liParent.iterator$(); $fParent.hasNext$()&&((fParent=($fParent.next$())),1);) {
var arrBondsReachable=p$1.getAllReachableNeighbourBonds$com_actelion_research_chem_ExtendedMolecule$com_actelion_research_chem_properties_complexity_IBitArray.apply(this, [this.mol, fParent]);
for (var j=0; j < arrBondsReachable.length$(); j++) {
var fChildAddedBond=this.containerDataFragDefByBonds.getWithCopy$com_actelion_research_chem_properties_complexity_IBitArray(fParent);
fChildAddedBond.setBit$I(arrBondsReachable.get$I(j));
if (this.containerDataFragDefByBonds.addFacultative$com_actelion_research_chem_properties_complexity_IBitArray(fChildAddedBond)) {
(added=Long.$inc(added,1));
(addedTotal=Long.$inc(addedTotal,1));
neighboursSinceLastAdded=0;
if (Long.$gt(addedTotal,this.totalMaximumCapacity )) {
if (C$.ELUSIVE) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() maximum capacity (" + this.totalMaximumCapacity + ") break." );
p$1.log$J$J$J$J$J.apply(this, [neighbours, neighboursTotal, added, addedTotal, neighboursSinceLastAdded]);
}this.containerDataFragDefByBonds.reset$I(fChildAddedBond.getBitsSet$());
break maximumCapacityBreak;
}}(neighbours=Long.$inc(neighbours,1));
(neighboursSinceLastAdded=Long.$inc(neighboursSinceLastAdded,1));
if (Long.$eq(Long.$mod(neighbours,50000000),0 )) {
if (C$.ELUSIVE) {
p$1.log$J$J$J$J$J.apply(this, [neighbours, neighboursTotal, added, addedTotal, neighboursSinceLastAdded]);
}}}
if (Long.$gt(neighboursSinceLastAdded,this.totalMaximumCapacity )) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments(). Break for fragments with " + i + " bonds. Generated  " + this.totalMaximumCapacity + " neighbours since last add to hash map." );
break;
}}
(neighboursTotal=Long.$add(neighboursTotal,(neighbours)));
if (C$.ELUSIVE) {
p$1.log$J$J$J$J$J.apply(this, [neighbours, neighboursTotal, added, addedTotal, neighboursSinceLastAdded]);
}}
this.fragmentsGenerated=true;
if (C$.ELUSIVE) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() getTotalSizeResultList() " + $I$(4,"group$Integer",[Integer.valueOf$I(this.containerDataFragDefByBonds.getTotalSizeResults$())]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() solutionAdded " + $I$(4,"group$Long",[Long.valueOf$J(this.solutionAdded)]) + "." );
}}, p$1);

Clazz.newMeth(C$, 'log$J$J$J$J$J',  function (neighbours, neighboursTotal, added, addedTotal, neighboursSinceLastAdded) {
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() " + Clazz.new_(java.util.Date).toString() + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() neighbours generated " + $I$(4,"group$Long",[Long.valueOf$J(neighbours)]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() neighbours generated total " + $I$(4,"group$Long",[Long.valueOf$J(neighboursTotal)]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() solutions added " + $I$(4,"group$Long",[Long.valueOf$J(added)]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() solutions added total " + $I$(4,"group$Long",[Long.valueOf$J(addedTotal)]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() available  " + $I$(4,"group$Integer",[Integer.valueOf$I(this.containerDataFragDefByBonds.getAvailable$())]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() capacity  " + $I$(4,"group$Integer",[Integer.valueOf$I(this.containerDataFragDefByBonds.getCapacity$())]) + "." );
System.out.println$S("ExhaustiveFragmentGeneratorBonds generateFragments() neighboursSinceLastAdded  " + $I$(4,"group$Long",[Long.valueOf$J(neighboursSinceLastAdded)]) + "." );
}, p$1);

Clazz.newMeth(C$, 'getFragments$I',  function (bonds) {
if (!this.fragmentsGenerated) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Fragments have to be generated first. Call generateFragments()."]);
}return this.containerDataFragDefByBonds.getList$I(bonds);
});

Clazz.newMeth(C$, 'getAllReachableNeighbourBonds$com_actelion_research_chem_ExtendedMolecule$com_actelion_research_chem_properties_complexity_IBitArray',  function (mol, livIndexBond) {
this.arrIndexReachableNeighbours.reset$();
for (var i=0; i < this.nBondsMolecule; i++) {
if (!livIndexBond.isBitSet$I(i)) {
continue;
}var indexBond=i;
var indexAtom1=mol.getBondAtom$I$I(0, indexBond);
var indexAtom2=mol.getBondAtom$I$I(1, indexBond);
var nConnected1=mol.getAllConnAtoms$I(indexAtom1);
for (var j=0; j < nConnected1; j++) {
var indexAtConn=mol.getConnAtom$I$I(indexAtom1, j);
var indexBondConnected=mol.getBond$I$I(indexAtom1, indexAtConn);
if (!livIndexBond.isBitSet$I(indexBondConnected)) {
(this.solutionAdded=Long.$inc(this.solutionAdded,1));
this.arrIndexReachableNeighbours.add$I(indexBondConnected);
}}
var nConnected2=mol.getAllConnAtoms$I(indexAtom2);
for (var j=0; j < nConnected2; j++) {
var indexAtConn=mol.getConnAtom$I$I(indexAtom2, j);
var indexBondConnected=mol.getBond$I$I(indexAtom2, indexAtConn);
if (!livIndexBond.isBitSet$I(indexBondConnected)) {
(this.solutionAdded=Long.$inc(this.solutionAdded,1));
this.arrIndexReachableNeighbours.add$I(indexBondConnected);
}}
}
return this.arrIndexReachableNeighbours;
}, p$1);

Clazz.newMeth(C$, 'isCapacityLimitBreakes$',  function () {
return this.capacityLimitBreakes;
});

Clazz.newMeth(C$, 'getSizeArrayLIV$',  function () {
var maxSizeIntVec=((this.containerDataFragDefByBonds.getSizeBinaryArray$() + 32 - 1)/32|0);
return maxSizeIntVec;
});

Clazz.newMeth(C$, 'getMaximumCapacityBondsInFragment$',  function () {
return this.containerDataFragDefByBonds.getMaximumCapacityBondsInFragment$();
});

Clazz.newMeth(C$, 'getMaximumNumberBondsInMolecule$',  function () {
return this.containerDataFragDefByBonds.getMaximumNumberBondsInMolecule$();
});

Clazz.newMeth(C$, 'isELUSIVE$',  function () {
return C$.ELUSIVE;
}, 1);

Clazz.newMeth(C$, 'setELUSIVE$Z',  function (elusive) {
C$.ELUSIVE=elusive;
$I$(1).ELUSIVE=C$.ELUSIVE;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.ELUSIVE=false;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:22 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
