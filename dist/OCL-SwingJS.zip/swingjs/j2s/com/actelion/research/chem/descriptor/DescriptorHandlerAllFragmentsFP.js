(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.DescriptorConstants','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.descriptor.SimpleFragmentGraph','com.actelion.research.util.SortedList','com.actelion.research.chem.descriptor.BondSet','com.actelion.research.chem.SSSearcherWithIndex']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerAllFragmentsFP", null, 'com.actelion.research.chem.descriptor.AbstractDescriptorHandlerLongFP');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMol','com.actelion.research.chem.StereoMolecule','mIsAtomMember','boolean[]','+mIsBondMember','mMemberBond','int[]','+mMemberAtom','mDescriptor','long[]','mBondSets','com.actelion.research.util.SortedList','mFragmentGraph','com.actelion.research.chem.descriptor.SimpleFragmentGraph']]
,['Z',['skipIDCodes'],'O',['sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerAllFragmentsFP']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) {
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(1).DESCRIPTOR_ALLFRAG;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(1).DESCRIPTOR_ALLFRAG.version;
});

Clazz.newMeth(C$, 'preprocessStructure$com_actelion_research_chem_StereoMolecule',  function (mol) {
if (mol.isFragment$()) {
mol.ensureHelperArrays$I(1);
var isBlockedAtom=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
for (var atom=0; atom < mol.getAtoms$(); atom++) isBlockedAtom[atom]=Long.$ne((Long.$and(mol.getAtomQueryFeatures$I(atom),(Long.$not(140733461823486)))),0 ) || mol.getAtomList$I(atom) != null  ;

var hasBlockedBond=false;
var includeBond=Clazz.array(Boolean.TYPE, [mol.getBonds$()]);
for (var bond=0; bond < mol.getBonds$(); bond++) {
includeBond[bond]=!isBlockedAtom[mol.getBondAtom$I$I(0, bond)] && !isBlockedAtom[mol.getBondAtom$I$I(1, bond)] && (mol.getBondQueryFeatures$I(bond) & ~6291840) == 0  ;
hasBlockedBond=!!(hasBlockedBond|(!includeBond[bond]));
}
if (hasBlockedBond) {
var query=Clazz.new_([mol.getAllBonds$(), mol.getAllBonds$()],$I$(2,1).c$$I$I);
mol.copyMoleculeByBonds$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(query, includeBond, true, null);
mol=query;
}}return mol;
}, p$1);

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
if (mol == null ) return null;
this.mMol=p$1.preprocessStructure$com_actelion_research_chem_StereoMolecule.apply(this, [mol]);
this.mMol.ensureHelperArrays$I(7);
this.mFragmentGraph=Clazz.new_($I$(3,1).c$$I,[6]);
this.mBondSets=Clazz.new_($I$(4,1));
this.mIsAtomMember=Clazz.array(Boolean.TYPE, [this.mMol.getAtoms$()]);
this.mIsBondMember=Clazz.array(Boolean.TYPE, [this.mMol.getBonds$()]);
this.mDescriptor=Clazz.array(Long.TYPE, [32]);
this.mMemberAtom=Clazz.array(Integer.TYPE, [this.mMol.getAtoms$()]);
this.mMemberBond=Clazz.array(Integer.TYPE, [this.mMol.getBonds$()]);
for (var rootBond=0; rootBond < this.mMol.getBonds$(); rootBond++) {
this.mMemberAtom[0]=this.mMol.getBondAtom$I$I(0, rootBond);
this.mMemberAtom[1]=this.mMol.getBondAtom$I$I(1, rootBond);
this.mMemberBond[0]=rootBond;
this.mIsAtomMember[this.mMemberAtom[0]]=true;
this.mIsAtomMember[this.mMemberAtom[1]]=true;
this.mIsBondMember[rootBond]=true;
p$1.setHashBitIfNew$I.apply(this, [1]);
this.processOneMoreBond$I$I(2, 1);
this.mIsAtomMember[this.mMemberAtom[0]]=false;
this.mIsAtomMember[this.mMemberAtom[1]]=false;
this.mIsBondMember[rootBond]=false;
}
for (var atom=0; atom < this.mMol.getAtoms$(); atom++) {
if (this.mMol.getConnAtoms$I(atom) == 0) {
var atomicNo=this.mMol.getAtomicNo$I(atom);
(this.mDescriptor[$k$=atomicNo < 64 ? 0 : 1]=Long.$or(this.mDescriptor[$k$],((Long.$sl(1,(atomicNo % 64))))));
}}
return this.mDescriptor;
});

Clazz.newMeth(C$, 'processOneMoreBond$I$I',  function (atomCount, bondCount) {
for (var i=0; i < atomCount; i++) {
for (var j=0; j < this.mMol.getConnAtoms$I(this.mMemberAtom[i]); j++) {
var candidateBond=this.mMol.getConnBond$I$I(this.mMemberAtom[i], j);
if (!this.mIsBondMember[candidateBond]) {
var candidateAtom=this.mMol.getConnAtom$I$I(this.mMemberAtom[i], j);
this.mMemberBond[bondCount]=candidateBond;
this.mIsBondMember[candidateBond]=true;
var isAtomMember=this.mIsAtomMember[candidateAtom];
if (!isAtomMember) {
this.mIsAtomMember[candidateAtom]=true;
this.mMemberAtom[atomCount]=candidateAtom;
++atomCount;
}++bondCount;
p$1.setHashBitIfNew$I.apply(this, [bondCount]);
if (bondCount < 6) this.processOneMoreBond$I$I(atomCount, bondCount);
--bondCount;
this.mIsBondMember[candidateBond]=false;
if (!isAtomMember) {
--atomCount;
this.mIsAtomMember[candidateAtom]=false;
}}}
}
});

Clazz.newMeth(C$, 'setHashBitIfNew$I',  function (bondCount) {
var bondSet=Clazz.new_([this.mMemberBond, bondCount, this.mMol.getBonds$()],$I$(5,1).c$$IA$I$I);
if (this.mBondSets.addIfNew$O(bondSet)) {
this.mFragmentGraph.set$com_actelion_research_chem_StereoMolecule$IA$I(this.mMol, this.mMemberBond, bondCount);
var hash=this.mFragmentGraph.createHashValue$I(11);
var high=32 - (hash/64|0) - 1;
var low=hash % 64;
(this.mDescriptor[$k$=high]=Long.$or(this.mDescriptor[$k$],((Long.$sl(1,low)))));
}}, p$1);

Clazz.newMeth(C$, ['getSimilarity$JA$JA','getSimilarity$O$O'],  function (o1, o2) {
return o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0  ? 0.0 : p$1.normalizeValue$D.apply(this, [$I$(6).getSimilarityTanimoto$JA$JA(o1, o2)]);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.68), 1.4705882352941175));
}, p$1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return Clazz.new_(C$);
});
var $k$;

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:50 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
