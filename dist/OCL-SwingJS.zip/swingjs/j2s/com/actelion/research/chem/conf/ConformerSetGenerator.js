(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[[0,'org.openmolecules.chem.conf.gen.RigidFragmentCache','com.actelion.research.chem.conf.ConformerSet','com.actelion.research.chem.Canonizer','org.openmolecules.chem.conf.gen.ConformerGenerator','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94','java.util.HashMap','org.openmolecules.chem.conf.so.ConformationSelfOrganizer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ConformerSetGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mUseFF'],'I',['mMaxNrConfs','mStrategy'],'J',['mSeed'],'O',['threadMaster','com.actelion.research.calc.ThreadMaster']]
,['J',['DEFAULT_SEED']]]

Clazz.newMeth(C$, 'c$$I$I$Z$J',  function (maxNrConfs, strategy, useFF, seed) {
;C$.$init$.apply(this);
this.mMaxNrConfs=maxNrConfs;
this.mStrategy=strategy;
this.mUseFF=useFF;
this.mSeed=seed;
var fragCache=$I$(1).getDefaultInstance$();
fragCache.loadDefaultCache$();
}, 1);

Clazz.newMeth(C$, 'c$$I',  function (maxConfs) {
C$.c$$I$I$Z$J.apply(this, [maxConfs, 3, false, C$.DEFAULT_SEED]);
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
C$.c$$I$I$Z$J.apply(this, [200, 3, false, C$.DEFAULT_SEED]);
}, 1);

Clazz.newMeth(C$, 'c$$Z',  function (useFF) {
C$.c$$I$I$Z$J.apply(this, [200, 3, useFF, C$.DEFAULT_SEED]);
}, 1);

Clazz.newMeth(C$, 'c$$Z$J',  function (useFF, seed) {
C$.c$$I$I$Z$J.apply(this, [200, 3, useFF, seed]);
}, 1);

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (tm) {
this.threadMaster=tm;
});

Clazz.newMeth(C$, 'generateConformerSet$com_actelion_research_chem_StereoMolecule',  function (mol) {
var confSet=Clazz.new_($I$(2,1));
var largestFragment=mol.getCompactCopy$();
largestFragment.stripSmallFragments$();
var canonicalFragment=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[largestFragment]).getCanMolecule$Z(true);
var maxTorsionSets=(Math.max(2 * this.mMaxNrConfs, (1000 * Math.sqrt(this.mMaxNrConfs)))|0);
var cg=Clazz.new_($I$(4,1).c$$J$Z,[this.mSeed, false]);
cg.setThreadMaster$com_actelion_research_calc_ThreadMaster(this.threadMaster);
var ffOptions=null;
if (this.mUseFF) {
$I$(5).initialize$S("MMFF94s+");
ffOptions=Clazz.new_($I$(6,1));
ffOptions.put$O$O("dielectric constant", Double.valueOf$D(4.0));
}if (cg.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(canonicalFragment, this.mStrategy, maxTorsionSets, false)) {
for (var i=0; i < this.mMaxNrConfs; i++) {
var conformer=cg.getNextConformer$();
if (conformer == null  && i == 0 ) {
var sampler=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_StereoMolecule$Z,[canonicalFragment, true]);
conformer=sampler.generateOneConformer$J(this.mSeed);
}if (conformer == null ) break;
if (this.mUseFF) {
conformer.copyTo$com_actelion_research_chem_StereoMolecule(canonicalFragment);
var mmff=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map,[canonicalFragment, "MMFF94s+", ffOptions]);
mmff.minimise$();
conformer.copyFrom$com_actelion_research_chem_StereoMolecule(canonicalFragment);
}confSet.add$O(conformer);
if (this.threadMaster != null  && this.threadMaster.threadMustDie$() ) break;
}
}return confSet;
});

C$.$static$=function(){C$.$static$=0;
C$.DEFAULT_SEED=12345;
};
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:02 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
