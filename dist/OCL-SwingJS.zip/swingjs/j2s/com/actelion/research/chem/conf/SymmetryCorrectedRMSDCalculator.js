(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.StereoMolecule','java.util.HashSet','java.util.Collections','com.actelion.research.chem.descriptor.pharmacophoretree.HungarianAlgorithm','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SymmetryCorrectedRMSDCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['conf1','com.actelion.research.chem.conf.Conformer','+conf2']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_conf_Conformer$com_actelion_research_chem_conf_Conformer',  function (conf1, conf2) {
;C$.$init$.apply(this);
this.conf1=conf1;
this.conf2=conf2;
}, 1);

Clazz.newMeth(C$, 'calculate$',  function () {
var assignments=p$1.getAssignments.apply(this, []);
var rmsd=0.0;
for (var pair, $pair = 0, $$pair = assignments; $pair<$$pair.length&&((pair=($$pair[$pair])),1);$pair++) {
var c1=this.conf1.getCoordinates$I(pair[0]);
var c2=this.conf2.getCoordinates$I(pair[1]);
rmsd+=c1.distanceSquared$com_actelion_research_chem_Coordinates(c2);
}
rmsd/=assignments.length;
rmsd=Math.sqrt(rmsd);
return rmsd;
});

Clazz.newMeth(C$, 'getAssignments',  function () {
var assignments=Clazz.new_($I$(1,1));
var mol1=Clazz.new_([this.conf1.getMolecule$()],$I$(2,1).c$$com_actelion_research_chem_Molecule);
var mol2=Clazz.new_([this.conf2.getMolecule$()],$I$(2,1).c$$com_actelion_research_chem_Molecule);
mol1.ensureHelperArrays$I(15);
mol2.ensureHelperArrays$I(15);
var atomTypes1=p$1.getAtomTypes$com_actelion_research_chem_StereoMolecule.apply(this, [mol1]);
var atomTypes2=p$1.getAtomTypes$com_actelion_research_chem_StereoMolecule.apply(this, [mol2]);
var uniqueAtomTypes1=Clazz.new_($I$(3,1));
$I$(4).addAll$java_util_Collection$OA(uniqueAtomTypes1, atomTypes1);
var uniqueAtomTypes2=Clazz.new_($I$(3,1));
$I$(4).addAll$java_util_Collection$OA(uniqueAtomTypes2, atomTypes2);
Clazz.assert(C$, this, function(){return (uniqueAtomTypes1.equals$O(uniqueAtomTypes2))});
for (var at, $at = uniqueAtomTypes1.iterator$(); $at.hasNext$()&&((at=($at.next$()).intValue$()),1);) {
var occurences1=Clazz.new_($I$(1,1));
var occurences2=Clazz.new_($I$(1,1));
for (var i=0; i < atomTypes1.length; i++) {
var at1=(atomTypes1[i]).$c();
if (at1 == at) occurences1.add$O(Integer.valueOf$I(i));
}
for (var i=0; i < atomTypes2.length; i++) {
var at2=(atomTypes2[i]).$c();
if (at2 == at) occurences2.add$O(Integer.valueOf$I(i));
}
Clazz.assert(C$, this, function(){return (occurences1.size$() == occurences2.size$())});
var costMatrix=Clazz.array(Double.TYPE, [occurences1.size$(), occurences2.size$()]);
var counter1=0;
for (var occ1, $occ1 = occurences1.iterator$(); $occ1.hasNext$()&&((occ1=($occ1.next$()).intValue$()),1);) {
var counter2=0;
for (var occ2, $occ2 = occurences2.iterator$(); $occ2.hasNext$()&&((occ2=($occ2.next$()).intValue$()),1);) {
var distSq=this.conf1.getCoordinates$I(occ1).distanceSquared$com_actelion_research_chem_Coordinates(this.conf2.getCoordinates$I(occ2));
costMatrix[counter1][counter2]=distSq;
++counter2;
}
++counter1;
}
var ass=$I$(5).hgAlgorithm$DAA$S(costMatrix, "min");
for (var pair, $pair = 0, $$pair = ass; $pair<$$pair.length&&((pair=($$pair[$pair])),1);$pair++) {
var p1=(occurences1.get$I(pair[0])).$c();
var p2=(occurences2.get$I(pair[1])).$c();
assignments.add$O(Clazz.array(Integer.TYPE, -1, [p1, p2]));
}
}
return assignments.toArray$OA(Clazz.array(Integer.TYPE, [assignments.size$(), 2]));
}, p$1);

Clazz.newMeth(C$, 'getAtomTypes$com_actelion_research_chem_StereoMolecule',  function (mol) {
var atomTypes=Clazz.array(Integer, [mol.getAtoms$()]);
for (var a=0; a < mol.getAtoms$(); a++) {
atomTypes[a]=Integer.valueOf$I($I$(6).getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, a));
}
return atomTypes;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
