(function(){var P$=Clazz.newPackage("com.actelion.research.chem.phesa"),I$=[[0,'java.nio.ByteBuffer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "EncodeFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'doubleToByteArray$D',  function (value) {
var bytes=Clazz.array(Byte.TYPE, [8]);
var buffer=$I$(1).allocate$I(bytes.length);
buffer.putDouble$D(value);
return buffer.array$();
}, 1);

Clazz.newMeth(C$, 'doubleArrayToByteArray$DA',  function (doubleArray) {
var buffer=$I$(1).allocate$I(8 * doubleArray.length);
buffer.asDoubleBuffer$().put$DA(doubleArray);
return buffer.array$();
}, 1);

Clazz.newMeth(C$, 'intArrayToByteArray$IA',  function (intArray) {
var buffer=$I$(1).allocate$I(4 * intArray.length);
buffer.asIntBuffer$().put$IA(intArray);
return buffer.array$();
}, 1);

Clazz.newMeth(C$, 'intToByteArray$I',  function (value) {
var bytes=Clazz.array(Byte.TYPE, [4]);
var buffer=$I$(1).allocate$I(bytes.length);
buffer.putInt$I(value);
return buffer.array$();
}, 1);

Clazz.newMeth(C$, 'byteArrayToDouble$BA',  function (bytes) {
return $I$(1).wrap$BA(bytes).getDouble$();
}, 1);

Clazz.newMeth(C$, 'byteArrayToDoubleArray$BA',  function (bytes) {
var times=8;
var doubles=Clazz.array(Double.TYPE, [(bytes.length/times|0)]);
for (var i=0; i < doubles.length; i++) {
doubles[i]=$I$(1).wrap$BA$I$I(bytes, i * times, times).getDouble$();
}
return doubles;
}, 1);

Clazz.newMeth(C$, 'byteArrayToIntArray$BA',  function (bytes) {
var times=4;
var ints=Clazz.array(Integer.TYPE, [(bytes.length/times|0)]);
for (var i=0; i < ints.length; i++) {
ints[i]=$I$(1).wrap$BA$I$I(bytes, i * times, times).getInt$();
}
return ints;
}, 1);

Clazz.newMeth(C$, 'byteArrayToInt$BA',  function (bytes) {
return $I$(1).wrap$BA(bytes).getInt$();
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
