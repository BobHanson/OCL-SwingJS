(function(){var P$=Clazz.newPackage("com.actelion.research.chem.optimization"),I$=[[0,'com.actelion.research.chem.optimization.OptimizerLBFGS']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Lnsrch");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'minimizeEnergyAroundDirection$com_actelion_research_chem_optimization_Evaluable$D$DA$DA$D',  function ($function, f0, grad, dir, fMove) {
var CAPPA=0.9;
var STPMIN=1.0E-6;
var STPMAX=0.1;
var fA=0;
var fB=0;
var fC=0;
var slopeA=0;
var slopeB=0;
var slopeC=0;
var cube=0;
var len=grad.length;
var sNorm=$I$(1).getNorm$DA(dir);
var slope=0;
for (var i=0; i < len ; i++) {
dir[i]/=sNorm;
slope+=dir[i] * grad[i];
}
var step=Math.min(2.0 * Math.abs(fMove / slope), sNorm);
if (step > 0.1 ) step=0.1;
 else if (step < 1.0E-6 ) step=1.0E-6;
var lambda=0;
var initial=$function.getState$();
var initialF=f0;
var v=Clazz.array(Double.TYPE, [initial.length]);
try {
for (var reSearch=0; reSearch < 2; reSearch++) {
fB=f0;
slopeB=slope;
for (var counter=0; counter < 20; counter++) {
fA=fB;
slopeA=slopeB;
lambda+=step;
C$.move$com_actelion_research_chem_optimization_Evaluable$DA$D$DA$DA($function, dir, lambda, initial, v);
fB=$function.getFGValue$DA(grad);
slopeB=0;
for (var i=0; i < len ; i++) slopeB+=dir[i] * grad[i];

if (Math.abs(slopeB / slope) <= 0.9  && fB <= fA  ) {
return Clazz.array(java.lang.Object, -1, [Double.valueOf$D(fB), grad, Boolean.TRUE]);
}if (fB >= fA  || slopeB * slopeA < 0  ) {
break;
}if (slopeB > slopeA ) {
var parab=(fA - fB) / (slopeB - slopeA);
if (parab > 2 * step ) step=2 * step;
 else if (parab < 2 * step ) step=step / 2;
 else step=parab;
} else {
step*=2;
}if (step > 0.1 ) step=0.1;
 else if (step < 1.0E-6 ) step=1.0E-6;
}
fC=fB;
var fL;
var sgL;
if (fA <= fB  && fA <= fC  ) {
fL=fA;
sgL=slopeA;
lambda+=cube - step;
} else if (fB <= fA  && fB <= fC  ) {
fL=fB;
sgL=slopeB;
lambda+=cube;
} else {
fL=fC;
sgL=slopeC;
}if (fL > f0 ) {
C$.move$com_actelion_research_chem_optimization_Evaluable$DA$D$DA$DA($function, dir, lambda, initial, v);
f0=$function.getFGValue$DA(grad);
return Clazz.array(java.lang.Object, -1, [Double.valueOf$D(f0), grad, Boolean.FALSE]);
}f0=fL;
if (sgL > 0 ) {
lambda=0;
for (var i=0; i < dir.length; i++) dir[i]=-dir[i];

slope-=-sgL;
} else {
slope=sgL;
}step=Math.max(1.0E-6, Math.max(cube, step - cube) / 10);
}
C$.move$com_actelion_research_chem_optimization_Evaluable$DA$D$DA$DA($function, dir, lambda, initial, v);
f0=$function.getFGValue$DA(grad);
if (f0 > initialF ) {
C$.move$com_actelion_research_chem_optimization_Evaluable$DA$D$DA$DA($function, dir, 0, initial, v);
f0=initialF;
}return Clazz.array(java.lang.Object, -1, [Double.valueOf$D(f0), grad, Boolean.FALSE]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
$function.setState$DA(initial);
f0=$function.getFGValue$DA(grad);
return Clazz.array(java.lang.Object, -1, [ new Double(f0), grad, Boolean.FALSE]);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'move$com_actelion_research_chem_optimization_Evaluable$DA$D$DA$DA',  function (eval, dir, lambda, transformOld, transform) {
for (var i=0; i < transform.length; i++) {
transform[i]=transformOld[i] + lambda * dir[i];
}
eval.setState$DA(transform);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
