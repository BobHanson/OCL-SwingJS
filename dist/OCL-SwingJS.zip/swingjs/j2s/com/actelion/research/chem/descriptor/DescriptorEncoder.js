(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'java.nio.charset.StandardCharsets']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorEncoder");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mByteIndex','mAvailableBits','mTempData','mByteMask','mTempDataLong'],'O',['mBytes','byte[]']]
,['O',['sCode','byte[]','+sCodeMultipleMin','+sCodeMultipleMax','sDecode','int[]','+sDecodeMultiple']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
if (C$.sDecode == null ) {
/*sync org.eclipse.jdt.core.dom.MethodInvocation*/(this.getClass$());
{
if (C$.sDecode == null ) {
var len=64;
Clazz.assert(C$, this, function(){return len <= C$.sCode.length}, function(){return "Error in encoding, not enough characters."});
C$.sDecode=Clazz.array(Integer.TYPE, [C$.sCode[C$.sCode.length - 1] + 1]);
for (var i=0; i < C$.sCode.length; i++) C$.sDecode[C$.sCode[i]]=i;

C$.sDecodeMultiple=Clazz.array(Integer.TYPE, [Math.max(C$.sCodeMultipleMin[C$.sCodeMultipleMin.length - 1], C$.sCodeMultipleMax[C$.sCodeMultipleMax.length - 1]) + 1]);
for (var i=0; i < C$.sCodeMultipleMin.length; i++) C$.sDecodeMultiple[C$.sCodeMultipleMin[i]]=-i - 2;

for (var i=0; i < C$.sCodeMultipleMax.length; i++) C$.sDecodeMultiple[C$.sCodeMultipleMax[i]]=i + 2;

}}}}, 1);

Clazz.newMeth(C$, 'encode$IA',  function (data) {
p$1.encodeStart$I.apply(this, [32 * data.length]);
for (var i=0; i < data.length; i++) p$1.encodeBits$I$I.apply(this, [data[i], 32]);

p$1.encodeBitsEnd.apply(this, []);
p$1.encodeDuplicateBytes.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'encodeIntArray2D$IAA',  function (data) {
var maxCount=data.length;
var maxValue=0;
var valueCount=0;
for (var i=0; i < data.length; i++) {
if (maxCount < data[i].length) maxCount=data[i].length;
for (var j=0; j < data[i].length; j++) if (maxValue < data[i][j]) maxValue=data[i][j];

valueCount+=data[i].length;
}
var countBits=p$1.getNeededBits$I.apply(this, [maxCount]);
var valueBits=p$1.getNeededBits$I.apply(this, [maxValue]);
p$1.encodeStart$I.apply(this, [10 + (1 + data.length) * countBits + valueCount * valueBits]);
p$1.encodeBits$I$I.apply(this, [countBits, 5]);
p$1.encodeBits$I$I.apply(this, [valueBits, 5]);
p$1.encodeBits$I$I.apply(this, [data.length, countBits]);
for (var i=0; i < data.length; i++) {
p$1.encodeBits$I$I.apply(this, [data[i].length, countBits]);
for (var j=0; j < data[i].length; j++) p$1.encodeBits$I$I.apply(this, [data[i][j], valueBits]);

}
p$1.encodeBitsEnd.apply(this, []);
p$1.encodeDuplicateBytes.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'decodeIntArray2D$BA',  function (bytes) {
if (bytes.length == 0) return null;
bytes=p$1.decodeDuplicateBytes$BA.apply(this, [bytes]);
p$1.decodeStart$BA.apply(this, [bytes]);
var countBits=p$1.decodeBits$I.apply(this, [5]);
var valueBits=p$1.decodeBits$I.apply(this, [5]);
var outerSize=p$1.decodeBits$I.apply(this, [countBits]);
var data=Clazz.array(Integer.TYPE, [outerSize, null]);
for (var i=0; i < outerSize; i++) {
var innerSize=p$1.decodeBits$I.apply(this, [countBits]);
data[i]=Clazz.array(Integer.TYPE, [innerSize]);
for (var j=0; j < innerSize; j++) data[i][j]=p$1.decodeBits$I.apply(this, [valueBits]);

}
return data;
});

Clazz.newMeth(C$, 'encodeLong$JA',  function (data) {
p$1.encodeStart$I.apply(this, [64 * data.length]);
for (var i=0; i < data.length; i++) p$1.encodeBits$J$I.apply(this, [data[i], 64]);

p$1.encodeBitsEnd.apply(this, []);
p$1.encodeDuplicateBytes.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return this.decode$BA(s.getBytes$java_nio_charset_Charset($I$(1).UTF_8));
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
if (bytes.length == 0) return null;
bytes=p$1.decodeDuplicateBytes$BA.apply(this, [bytes]);
p$1.decodeStart$BA.apply(this, [bytes]);
var data=Clazz.array(Integer.TYPE, [(6 * bytes.length/32|0)]);
for (var i=0; i < data.length; i++) data[i]=p$1.decodeBits$I.apply(this, [32]);

return data;
});

Clazz.newMeth(C$, 'decodeLong$S',  function (s) {
return this.decodeLong$BA(s.getBytes$java_nio_charset_Charset($I$(1).UTF_8));
});

Clazz.newMeth(C$, 'decodeLong$BA',  function (bytes) {
if (bytes.length == 0) return null;
bytes=p$1.decodeDuplicateBytes$BA.apply(this, [bytes]);
p$1.decodeStart$BA.apply(this, [bytes]);
var data=Clazz.array(Long.TYPE, [(6 * bytes.length/64|0)]);
for (var i=0; i < data.length; i++) data[i]=p$1.decodeBitsLong$I.apply(this, [64]);

return data;
});

Clazz.newMeth(C$, 'encodeCounts$BA',  function (data) {
p$1.encodeStart$I.apply(this, [6 * data.length]);
for (var i=0; i < data.length; i++) p$1.encodeBits$I$I.apply(this, [data[i], 6]);

p$1.encodeBitsEnd.apply(this, []);
p$1.encodeDuplicateBytes.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'decodeCounts$S',  function (s) {
return this.decodeCounts$BA(s.getBytes$java_nio_charset_Charset($I$(1).UTF_8));
});

Clazz.newMeth(C$, 'decodeCounts$BA',  function (bytes) {
if (bytes.length == 0) return null;
bytes=p$1.decodeDuplicateBytes$BA.apply(this, [bytes]);
p$1.decodeStart$BA.apply(this, [bytes]);
var data=Clazz.array(Byte.TYPE, [(6 * bytes.length/6|0)]);
for (var i=0; i < data.length; i++) data[i]=(p$1.decodeBits$I.apply(this, [6])|0);

return data;
});

Clazz.newMeth(C$, 'encodeIntArray$IA',  function (data) {
var max=0;
var sum=0;
for (var v, $v = 0, $$v = data; $v<$$v.length&&((v=($$v[$v])),1);$v++) {
sum+=p$1.getNeededBits$I.apply(this, [v]);
if (max < v) max=v;
}
var sizeBits=Math.min(31, p$1.getNeededBits$I.apply(this, [data.length]));
var dataBits=p$1.getNeededBits$I.apply(this, [p$1.getNeededBits$I.apply(this, [max])]);
p$1.encodeStart$I.apply(this, [1 + 5 + 3 + sizeBits + sum + dataBits * data.length ]);
p$1.encodeBits$I$I.apply(this, [0, 1]);
p$1.encodeBits$I$I.apply(this, [sizeBits, 5]);
p$1.encodeBits$I$I.apply(this, [data.length, sizeBits]);
p$1.encodeBits$I$I.apply(this, [dataBits, 3]);
for (var i=0; i < data.length; i++) {
var bits=p$1.getNeededBits$I.apply(this, [data[i]]);
p$1.encodeBits$I$I.apply(this, [bits, dataBits]);
p$1.encodeBits$I$I.apply(this, [data[i], bits]);
}
p$1.encodeBitsEnd.apply(this, []);
p$1.encodeDuplicateBytes.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'decodeIntArray$S',  function (s) {
return s == null  ? null : this.decodeIntArray$BA(s.getBytes$java_nio_charset_Charset($I$(1).UTF_8));
});

Clazz.newMeth(C$, 'decodeIntArray$BA',  function (bytes) {
if (bytes.length == 0) return null;
bytes=p$1.decodeDuplicateBytes$BA.apply(this, [bytes]);
p$1.decodeStart$BA.apply(this, [bytes]);
p$1.decodeBits$I.apply(this, [1]);
var sizeBits=p$1.decodeBits$I.apply(this, [5]);
var arraySize=p$1.decodeBits$I.apply(this, [sizeBits]);
var dataBits=p$1.decodeBits$I.apply(this, [3]);
var data=Clazz.array(Integer.TYPE, [arraySize]);
for (var i=0; i < arraySize; i++) {
var bits=p$1.decodeBits$I.apply(this, [dataBits]);
data[i]=p$1.decodeBits$I.apply(this, [bits]);
}
return data;
});

Clazz.newMeth(C$, 'encodePairs$IAA',  function (data) {
var maxID=0;
var maxCount=0;
for (var pair, $pair = 0, $$pair = data; $pair<$$pair.length&&((pair=($$pair[$pair])),1);$pair++) {
maxID=Math.max(maxID, pair[0]);
maxCount=Math.max(maxCount, pair[1]);
}
var idBits=p$1.getNeededBits$I.apply(this, [maxID]);
var countBits=p$1.getNeededBits$I.apply(this, [maxCount]);
var requiredBits=p$1.getNeededBits$I.apply(this, [6]) + 8 + data.length * (idBits + countBits);
p$1.encodeStart$I.apply(this, [requiredBits]);
p$1.encodeBits$I$I.apply(this, [this.mBytes.length * 6 - requiredBits, p$1.getNeededBits$I.apply(this, [6])]);
p$1.encodeBits$I$I.apply(this, [idBits, 4]);
p$1.encodeBits$I$I.apply(this, [countBits, 4]);
for (var pair, $pair = 0, $$pair = data; $pair<$$pair.length&&((pair=($$pair[$pair])),1);$pair++) {
p$1.encodeBits$I$I.apply(this, [pair[0], idBits]);
p$1.encodeBits$I$I.apply(this, [pair[1], countBits]);
}
p$1.encodeBitsEnd.apply(this, []);
return this.mBytes;
});

Clazz.newMeth(C$, 'decodePairs$BA',  function (bytes) {
if (bytes.length == 0) return null;
p$1.decodeStart$BA.apply(this, [bytes]);
var unusedBits=p$1.decodeBits$I.apply(this, [p$1.getNeededBits$I.apply(this, [6])]);
var idBits=p$1.decodeBits$I.apply(this, [4]);
var countBits=p$1.decodeBits$I.apply(this, [4]);
if (idBits + countBits == 0) return Clazz.array(Integer.TYPE, [0, 2]);
var length=((6 * bytes.length - p$1.getNeededBits$I.apply(this, [6]) - 8 - unusedBits)/(idBits + countBits)|0);
var data=Clazz.array(Integer.TYPE, [length, 2]);
for (var i=0; i < data.length; i++) {
data[i][0]=p$1.decodeBits$I.apply(this, [idBits]);
data[i][1]=p$1.decodeBits$I.apply(this, [countBits]);
}
return data;
});

Clazz.newMeth(C$, 'decodePairs$S',  function (s) {
return this.decodePairs$BA(s.getBytes$java_nio_charset_Charset($I$(1).UTF_8));
});

Clazz.newMeth(C$, 'getNeededBits$I',  function (no) {
var bits=0;
while (no > 0){
no>>=1;
++bits;
}
return bits;
}, p$1);

Clazz.newMeth(C$, 'encodeStart$I',  function (bitCount) {
this.mBytes=Clazz.array(Byte.TYPE, [((bitCount + 6 - 1)/6|0)]);
this.mAvailableBits=6;
this.mByteIndex=0;
}, p$1);

Clazz.newMeth(C$, 'encodeBits$I$I',  function (data, bits) {
var mask=(bits == 0) ? 0 : 1 << (bits - 1);
while (mask != 0){
if (this.mAvailableBits == 0) {
this.mBytes[this.mByteIndex]=C$.sCode[this.mBytes[this.mByteIndex]];
++this.mByteIndex;
this.mAvailableBits=6;
}this.mBytes[$k$=this.mByteIndex]=(this.mBytes[$k$]<<(1)|0);
if ((data & mask) != 0) this.mBytes[$k$=this.mByteIndex]=(this.mBytes[$k$]|(1)|0);
mask>>>=1;
--this.mAvailableBits;
}
}, p$1);

Clazz.newMeth(C$, 'encodeBits$J$I',  function (data, bits) {
var mask=(bits == 0) ? 0 : Long.$sl(1,(bits - 1));
while (Long.$ne(mask,0 )){
if (this.mAvailableBits == 0) {
this.mBytes[this.mByteIndex]=C$.sCode[this.mBytes[this.mByteIndex]];
++this.mByteIndex;
this.mAvailableBits=6;
}this.mBytes[$k$=this.mByteIndex]=(this.mBytes[$k$]<<(1)|0);
if (Long.$ne((Long.$and(data,mask)),0 )) this.mBytes[$k$=this.mByteIndex]=(this.mBytes[$k$]|(1)|0);
(mask=Long.$usr(mask,(1)));
--this.mAvailableBits;
}
}, p$1);

Clazz.newMeth(C$, 'encodeBitsEnd',  function () {
this.mBytes[$k$=this.mByteIndex]=(this.mBytes[$k$]<<(this.mAvailableBits)|0);
this.mBytes[this.mByteIndex]=C$.sCode[this.mBytes[this.mByteIndex]];
}, p$1);

Clazz.newMeth(C$, 'decodeStart$BA',  function (bytes) {
this.mBytes=bytes;
this.mByteIndex=0;
this.mTempData=C$.sDecode[this.mBytes[0]];
this.mTempDataLong=C$.sDecode[this.mBytes[0]];
this.mByteMask=32;
}, p$1);

Clazz.newMeth(C$, 'decodeBits$I',  function (bits) {
var data=0;
while (bits != 0){
if (this.mByteMask == 0) {
++this.mByteIndex;
this.mTempData=C$.sDecode[this.mBytes[this.mByteIndex]];
this.mByteMask=32;
}data<<=1;
if ((this.mTempData & this.mByteMask) != 0) data|=1;
this.mByteMask>>>=1;
--bits;
}
return data;
}, p$1);

Clazz.newMeth(C$, 'decodeBitsLong$I',  function (bits) {
var data=0;
while (bits != 0){
if (this.mByteMask == 0) {
++this.mByteIndex;
this.mTempDataLong=C$.sDecode[this.mBytes[this.mByteIndex]];
this.mByteMask=32;
}(data=Long.$sl(data,(1)));
if (Long.$ne((Long.$and(this.mTempDataLong,this.mByteMask)),0 )) (data=Long.$or(data,(1)));
this.mByteMask>>>=1;
--bits;
}
return data;
}, p$1);

Clazz.newMeth(C$, 'decodeDuplicateBytes$BA',  function (bytes) {
var length=bytes.length;
for (var i=0; i < bytes.length; i++) {
if (C$.sDecodeMultiple[bytes[i]] != 0) length+=Math.abs(C$.sDecodeMultiple[bytes[i]]) - 1;
}
if (length == bytes.length) return bytes;
var newBytes=Clazz.array(Byte.TYPE, [length]);
var oldIndex=0;
var newIndex=0;
while (oldIndex < bytes.length){
if (C$.sDecodeMultiple[bytes[oldIndex]] != 0) {
var count=Math.abs(C$.sDecodeMultiple[bytes[oldIndex]]);
var code=(C$.sDecodeMultiple[bytes[oldIndex]] < 0) ? C$.sCode[0] : C$.sCode[C$.sCode.length - 1];
for (var i=0; i < count; i++) newBytes[newIndex++]=code;

++oldIndex;
} else newBytes[newIndex++]=bytes[oldIndex++];
}
return newBytes;
}, p$1);

Clazz.newMeth(C$, 'encodeDuplicateBytes',  function () {
var length=p$1.encodeDuplicateBytes$B$BA$I.apply(this, [C$.sCode[0], C$.sCodeMultipleMin, this.mBytes.length]);
length=p$1.encodeDuplicateBytes$B$BA$I.apply(this, [C$.sCode[C$.sCode.length - 1], C$.sCodeMultipleMax, length]);
var oldBytes=this.mBytes;
this.mBytes=Clazz.array(Byte.TYPE, [length]);
for (var i=0; i < length; i++) this.mBytes[i]=oldBytes[i];

}, p$1);

Clazz.newMeth(C$, 'encodeDuplicateBytes$B$BA$I',  function (code, replacement, length) {
var oldIndex=0;
var newIndex=0;
while (oldIndex < length){
if (this.mBytes[oldIndex] == code) {
var count=1;
for (var i=oldIndex + 1; i < length && this.mBytes[i] == code ; i++) ++count;

while (count > replacement.length + 1){
this.mBytes[newIndex++]=replacement[replacement.length - 1];
oldIndex+=replacement.length + 1;
count-=replacement.length + 1;
}
if (count > 1) {
this.mBytes[newIndex++]=replacement[count - 2];
oldIndex+=count;
continue;
}}this.mBytes[newIndex++]=this.mBytes[oldIndex++];
}
return newIndex;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.sCode="0123456789@ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz".getBytes$java_nio_charset_Charset($I$(1).UTF_8);
C$.sCodeMultipleMin="!#$%&()*+,-./".getBytes$java_nio_charset_Charset($I$(1).UTF_8);
C$.sCodeMultipleMax=":;<=>?[]^{|}~".getBytes$java_nio_charset_Charset($I$(1).UTF_8);
};
var $k$;
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:16 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
