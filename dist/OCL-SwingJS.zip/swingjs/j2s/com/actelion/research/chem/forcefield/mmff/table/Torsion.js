(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv',['com.actelion.research.chem.forcefield.mmff.table.Torsion','.Kb'],'com.actelion.research.chem.forcefield.mmff.Search','com.actelion.research.chem.forcefield.mmff.type.Torsion','com.actelion.research.chem.forcefield.mmff.PeriodicTable']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Torsion", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');
C$.$classes$=[['Kb',17]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','Object[][]','t','com.actelion.research.chem.forcefield.mmff.Tables']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readFile$S(csvpath);
this.t=t;
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return (this.table[row][col]).intValue$();
});

Clazz.newMeth(C$, 's$O$O',  function (a, b) {
return a;
}, 1);

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'get$I',  function (index) {
return Clazz.new_($I$(2,1).c$$I,[this, null, index]);
});

Clazz.newMeth(C$, 'index$I$I$I$I$I',  function (a1t, a2t, a3t, a4t, tort) {
return $I$(3,"binary$IA$IA$com_actelion_research_chem_forcefield_mmff_Searchable",[Clazz.array(Integer.TYPE, -1, [2, 3, 1, 4, 0]), Clazz.array(Integer.TYPE, -1, [a2t, a3t, a1t, a4t, tort]), this]);
});

Clazz.newMeth(C$, 'getForceConstants$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (mol, a1, a2, a3, a4) {
var a1t=mol.getAtomType$I(a1);
var a2t=mol.getAtomType$I(a2);
var a3t=mol.getAtomType$I(a3);
var a4t=mol.getAtomType$I(a4);
var tort=$I$(4).getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(this.t, mol, a1, a2, a3, a4);
var tort1=tort > 10 ? (tort/10|0) : tort;
var tort2=tort > 10 ? tort - tort1 * 10 : 0;
var idx=-1;
var iter=0;
var iWildCard=0;
var lWildCard=0;
var canTorType=tort1;
var maxIter=5;
while ((iter < maxIter && (idx == -1 || maxIter == 4 ) ) || (iter == 4 && tort1 == 5  && tort2 > 0 ) ){
if (maxIter == 5 && iter == 4 ) {
maxIter=4;
iter=0;
canTorType=tort2;
}if (iter == 1) {
iWildCard=1;
lWildCard=3;
} else if (iter == 2) {
iWildCard=3;
lWildCard=1;
} else {
iWildCard=iter;
lWildCard=iter;
}var canIAtomType=this.t.def.table[a1t - 1][Math.min(iWildCard + 1, 4)];
var canJAtomType=a2t;
var canKAtomType=a3t;
var canLAtomType=this.t.def.table[a4t - 1][Math.min(lWildCard + 1, 4)];
if (canJAtomType > canKAtomType) {
canKAtomType=(C$.s$O$O(Integer.valueOf$I(canJAtomType), Integer.valueOf$I(canJAtomType=canKAtomType))).$c();
canLAtomType=(C$.s$O$O(Integer.valueOf$I(canIAtomType), Integer.valueOf$I(canIAtomType=canLAtomType))).$c();
} else if (canJAtomType == canKAtomType && canIAtomType > canLAtomType ) {
canLAtomType=(C$.s$O$O(Integer.valueOf$I(canIAtomType), Integer.valueOf$I(canIAtomType=canLAtomType))).$c();
}idx=this.index$I$I$I$I$I(canIAtomType, canJAtomType, canKAtomType, canLAtomType, canTorType);
if (idx != -1 && maxIter == 4 ) break;
++iter;
}
if (idx >= 0) return Clazz.new_($I$(2,1).c$$I,[this, null, idx]);
var bond=mol.getBond$I$I(a2, a3);
var U=Clazz.array(Double.TYPE, -1, [0.0, 0.0]);
var V=Clazz.array(Double.TYPE, -1, [0.0, 0.0]);
var W=Clazz.array(Double.TYPE, -1, [0.0, 0.0]);
var atno=Clazz.array(Integer.TYPE, -1, [mol.getAtomicNo$I(a2), mol.getAtomicNo$I(a3)]);
var N_jk=(this.t.atom.crd$I(a2t) - 1) * (this.t.atom.crd$I(a3t) - 1);
for (var i=0; i < 2; i++) {
switch (atno[i]) {
case 6:
U[i]=2.0;
V[i]=2.12;
break;
case 7:
U[i]=2.0;
V[i]=1.5;
break;
case 8:
U[i]=2.0;
V[i]=0.2;
W[i]=2.0;
break;
case 14:
U[i]=1.25;
V[i]=1.22;
break;
case 15:
U[i]=1.25;
V[i]=2.4;
break;
case 16:
U[i]=1.25;
V[i]=0.49;
W[i]=8.0;
break;
}
}
if (this.t.atom.linear$I(a2t) || this.t.atom.linear$I(a3t) ) return Clazz.new_($I$(2,1).c$$D$D$D,[this, null, 0.0, 0.0, 0.0]);
if (this.t.atom.arom$I(a2t) && this.t.atom.arom$I(a3t) && mol.isAromaticBond$I(bond)  ) {
var beta=(this.t.atom.val$I(a2t) == 3 && this.t.atom.val$I(a3t) == 4 ) || (this.t.atom.val$I(a2t) == 4 && this.t.atom.val$I(a3t) == 3 )  ? 3.0 : 6.0;
var pi_jk=this.t.atom.pilp$I(a2t) == 0 && this.t.atom.pilp$I(a3t) == 0  ? 0.5 : 0.3;
return Clazz.new_([this, null, 0.0, beta * pi_jk * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
}if (mol.getBondOrder$I(bond) == 2) {
var beta=6.0;
var pi_jk=this.t.atom.mltb$I(a2t) == 2 && this.t.atom.mltb$I(a3t) == 2  ? 1.0 : 0.4;
return Clazz.new_([this, null, 0.0, beta * pi_jk * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
}if (this.t.atom.crd$I(a2t) == 4 && this.t.atom.crd$I(a3t) == 4 ) return Clazz.new_([this, null, 0.0, 0.0, Math.sqrt(V[0] * V[1]) / N_jk],$I$(2,1).c$$D$D$D);
if (this.t.atom.crd$I(a2t) == 4 && this.t.atom.crd$I(a3t) != 4 ) {
if (((this.t.atom.crd$I(a3t) == 3) && (((this.t.atom.val$I(a3t) == 4) || (this.t.atom.val$I(a3t) == 34) ) || this.t.atom.mltb$I(a3t) > 0 ) ) || ((this.t.atom.crd$I(a3t) == 2) && ((this.t.atom.val$I(a3t) == 3) || this.t.atom.mltb$I(a3t) > 0 ) ) ) return Clazz.new_($I$(2,1),[this, null]);
 else return Clazz.new_([this, null, 0.0, 0.0, Math.sqrt(V[0] * V[1]) / N_jk],$I$(2,1).c$$D$D$D);
}if ((this.t.atom.crd$I(a3t) == 4) && (this.t.atom.crd$I(a2t) != 4) ) {
if (((this.t.atom.crd$I(a2t) == 3) && (((this.t.atom.val$I(a2t) == 4) || (this.t.atom.val$I(a2t) == 34) ) || this.t.atom.mltb$I(a2t) > 0 ) ) || ((this.t.atom.crd$I(a2t) == 2) && ((this.t.atom.val$I(a2t) == 3) || this.t.atom.mltb$I(a2t) > 0 ) ) ) return Clazz.new_($I$(2,1),[this, null]);
 else return Clazz.new_([this, null, 0.0, 0.0, Math.sqrt(V[0] * V[1]) / N_jk],$I$(2,1).c$$D$D$D);
}if (((mol.getBondOrder$I(bond) == 1) && this.t.atom.mltb$I(a2t) > 0  && this.t.atom.mltb$I(a3t) > 0 ) || (this.t.atom.mltb$I(a2t) > 0 && this.t.atom.pilp$I(a3t) > 0 ) || (this.t.atom.pilp$I(a2t) > 0 && this.t.atom.mltb$I(a3t) > 0 )  ) {
if (this.t.atom.pilp$I(a2t) > 0 && this.t.atom.pilp$I(a3t) > 0 ) return Clazz.new_($I$(2,1),[this, null]);
if (this.t.atom.pilp$I(a2t) > 0 && this.t.atom.mltb$I(a3t) > 0 ) {
var beta=6.0;
var pi_jk=0.0;
if (this.t.atom.mltb$I(a2t) == 1) pi_jk=0.5;
 else if ($I$(5).row$I(atno[0]) == 2 && $I$(5).row$I(atno[1]) == 2 ) pi_jk=0.3;
 else if ($I$(5).row$I(atno[0]) != 2 || $I$(5).row$I(atno[1]) != 2 ) pi_jk=0.15;
return Clazz.new_([this, null, 0.0, beta * pi_jk * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
}if (this.t.atom.pilp$I(a3t) > 0 && this.t.atom.mltb$I(a2t) > 0 ) {
var beta=6.0;
var pi_jk=0.0;
if (this.t.atom.mltb$I(a3t) == 1) pi_jk=0.5;
 else if ($I$(5).row$I(atno[0]) == 2 && $I$(5).row$I(atno[1]) == 2 ) pi_jk=0.3;
 else if ($I$(5).row$I(atno[0]) != 2 || $I$(5).row$I(atno[1]) != 2 ) pi_jk=0.15;
return Clazz.new_([this, null, 0.0, beta * pi_jk * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
}if ((this.t.atom.mltb$I(a2t) == 1 || this.t.atom.mltb$I(a3t) == 1 ) && (atno[0] != 6 || atno[1] != 6 ) ) return Clazz.new_([this, null, 0.0, 6.0 * 0.4 * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
return Clazz.new_([this, null, 0.0, 6.0 * 0.15 * Math.sqrt(U[0] * U[1]) , 0.0],$I$(2,1).c$$D$D$D);
}if ((atno[0] == 8 || atno[0] == 16 ) && (atno[1] == 8 || atno[1] == 16 ) ) return Clazz.new_([this, null, 0.0, -Math.sqrt(W[0] * W[1]), 0.0],$I$(2,1).c$$D$D$D);
return Clazz.new_([this, null, 0.0, 0.0, Math.sqrt(V[0] * V[1]) / N_jk],$I$(2,1).c$$D$D$D);
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.Torsion, "Kb", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['v1','v2','v3']]]

Clazz.newMeth(C$, 'c$$I',  function (index) {
;C$.$init$.apply(this);
this.v1=(this.b$['com.actelion.research.chem.forcefield.mmff.table.Torsion'].table[index][5]).doubleValue$();
this.v2=(this.b$['com.actelion.research.chem.forcefield.mmff.table.Torsion'].table[index][6]).doubleValue$();
this.v3=(this.b$['com.actelion.research.chem.forcefield.mmff.table.Torsion'].table[index][7]).doubleValue$();
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.v1=0.0;
this.v2=0.0;
this.v3=0.0;
}, 1);

Clazz.newMeth(C$, 'c$$D$D$D',  function (v1, v2, v3) {
;C$.$init$.apply(this);
this.v1=v1;
this.v2=v2;
this.v3=v3;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return new Double(this.v1).toString() + "," + new Double(this.v2).toString() + "," + new Double(this.v3).toString() ;
});
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:43 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
