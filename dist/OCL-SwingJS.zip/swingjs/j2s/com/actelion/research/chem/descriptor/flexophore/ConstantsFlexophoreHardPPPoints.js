(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ConstantsFlexophoreHardPPPoints");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'toStringPPPoints$I',  function (type) {
var s="";
if (type == $I$(1).ACCEPTOR.getIndex$()) {
s="a";
} else if (type == $I$(1).DONOR.getIndex$()) {
s="d";
} else if (type == $I$(1).NEG_CHARGE.getIndex$()) {
s="-";
} else if (type == $I$(1).POS_CHARGE.getIndex$()) {
s="+";
} else if (type == $I$(1).AROM_RING.getIndex$()) {
s="r";
} else if (type == 5) {
s="l";
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown pharmacophore point type: " + type + "!" ]);
}return s;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:16 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
