(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "UniqueStringList", null, 'com.actelion.research.chem.SortedStringList', 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mOriginalOrder=Clazz.new_($I$(1,1));
this.mIndexList=Clazz.new_($I$(1,1));
},1);

C$.$fields$=[['O',['mOriginalOrder','java.util.ArrayList','+mIndexList']]]

Clazz.newMeth(C$, 'getSortedListIndex$S',  function (s) {
return C$.superclazz.prototype.getListIndex$S.apply(this, [s]);
});

Clazz.newMeth(C$, 'getListIndex$S',  function (s) {
var index=C$.superclazz.prototype.getListIndex$S.apply(this, [s]);
if (index == -1) return -1;
return this.mIndexList.get$I(index).intValue$();
});

Clazz.newMeth(C$, 'addString$S',  function (theString) {
var index=C$.superclazz.prototype.addString$S.apply(this, [theString]);
if (index == -1) return -1;
var position=this.mOriginalOrder.size$();
this.mOriginalOrder.add$O(theString);
this.mIndexList.add$I$O(index,  new Integer(position));
return position;
});

Clazz.newMeth(C$, 'getStringAt$I',  function (i) {
return this.mOriginalOrder.get$I(i);
});

Clazz.newMeth(C$, 'getSortedStringAt$I',  function (i) {
return C$.superclazz.prototype.getStringAt$I.apply(this, [i]);
});

Clazz.newMeth(C$, 'toArray$',  function () {
return this.mOriginalOrder.toArray$OA(Clazz.array(String, [0]));
});

Clazz.newMeth(C$, 'toSortedArray$',  function () {
return C$.superclazz.prototype.toArray$.apply(this, []);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:21 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
