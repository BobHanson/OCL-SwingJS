(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf.torsionstrain"),p$1={},I$=[[0,'java.util.ArrayList','java.util.concurrent.ConcurrentHashMap','com.actelion.research.chem.conf.TorsionDB','java.io.BufferedReader','java.io.InputStreamReader','java.nio.charset.StandardCharsets','java.util.stream.IntStream','java.util.HashMap','com.actelion.research.chem.interactionstatistics.SplineFunction','java.util.stream.Collectors','java.util.concurrent.atomic.AtomicInteger','java.util.Arrays','com.actelion.research.util.SmoothingSplineInterpolator']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['torsionPotentials','java.util.Map','+torsionStatistics','torsionIDs','java.util.List']]
,['S',['database'],'O',['instance','com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential']]]

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.instance == null ) {
{
if (C$.instance == null ) {
C$.instance=Clazz.new_(C$);
}}}return C$.instance;
}, 1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.torsionIDs=Clazz.new_($I$(1,1));
this.torsionStatistics=Clazz.new_($I$(2,1));
$I$(3).initialize$I(2);
if (C$.database == null ) {
var is=Clazz.getClass($I$(3)).getResourceAsStream$S("/resources/csd/torsionBins.txt");
if (is != null ) {
C$.database="csd/";
} else {
C$.database="cod/";
}}p$1.initialize.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'initialize',  function () {
var torsionIDReader=Clazz.new_([Clazz.new_([Clazz.getClass($I$(3)).getResourceAsStream$S("/resources/" + C$.database + "torsionID.txt" ), $I$(6).UTF_8],$I$(5,1).c$$java_io_InputStream$java_nio_charset_Charset)],$I$(4,1).c$$java_io_Reader);
try {
p$1.readTorsionIDs$java_io_BufferedReader.apply(this, [torsionIDReader]);
p$1.initBins.apply(this, []);
} catch (e) {
if (Clazz.exceptionOf(e,"java.io.IOException")){
throw Clazz.new_(Clazz.load('RuntimeException'));
} else {
throw e;
}
}
p$1.calculatePotentials.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'calculatePotentials',  function () {
p$1.splineCalculation.apply(this, []);
}, p$1);

Clazz.newMeth(C$, 'readTorsionIDs$java_io_BufferedReader',  function (reader) {
try {
var line;
while ((line=reader.readLine$()) != null  && line.length$() != 0 ){
var s=line.trim$();
this.torsionIDs.add$O(s);
}
reader.close$();
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
throw Clazz.new_(Clazz.load('RuntimeException').c$$Throwable,[e]);
} else {
throw e;
}
}
}, p$1);

Clazz.newMeth(C$, 'initBins',  function () {
for (var torsionID, $torsionID = this.torsionIDs.iterator$(); $torsionID.hasNext$()&&((torsionID=($torsionID.next$())),1);) {
var counts=$I$(3).getTorsionBinCounts$S(torsionID);
var occurences=Clazz.array(Integer.TYPE, [counts.length]);
$I$(7).range$I$I(0, occurences.length).forEach$java_util_function_IntConsumer(((P$.StatisticalTorsionPotential$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.occurences[i]=(this.$finals$.counts[i]|0));});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda1.$init$,[this, {occurences:occurences,counts:counts}])));
this.torsionStatistics.putIfAbsent$O$O(torsionID, occurences);
}
}, p$1);

Clazz.newMeth(C$, 'getFunction$S',  function (torsionID) {
return this.torsionPotentials.get$O(torsionID);
});

Clazz.newMeth(C$, 'splineCalculation',  function () {
this.torsionPotentials=Clazz.new_($I$(8,1));
var referenceSum=Clazz.array(Double.TYPE, [72]);
this.torsionStatistics.entrySet$().stream$().forEach$java_util_function_Consumer(((P$.StatisticalTorsionPotential$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map_Entry','accept$O'],  function (e) /*block*/{
var potential=Clazz.new_($I$(9,1));
potential.setOccurencesArray$IA.apply(potential, [e.getValue$.apply(e, [])]);
this.b$['com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential'].torsionPotentials.putIfAbsent$O$O.apply(this.b$['com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential'].torsionPotentials, [e.getKey$.apply(e, []), potential]);
});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda2.$init$,[this, null])));
var discreteFunctions=this.torsionStatistics.entrySet$().stream$().collect$java_util_stream_Collector($I$(10,"toMap$java_util_function_Function$java_util_function_Function",[((P$.StatisticalTorsionPotential$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (e.getKey$.apply(e, []));});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda3.$init$,[this, null])), ((P$.StatisticalTorsionPotential$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$java_util_Map_Entry','apply$O'],  function (e) { return (p$1.normalization$IA.apply(this.b$['com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential'], [e.getValue$.apply(e, [])]));});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda4.$init$,[this, null]))]));
var runCount=Clazz.new_($I$(11,1).c$$I,[0]);
discreteFunctions.entrySet$().stream$().forEach$java_util_function_Consumer(((P$.StatisticalTorsionPotential$lambda5||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda5", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$java_util_Map_Entry','accept$O'],  function (statistics) /*block*/{
this.$finals$.runCount.getAndIncrement$.apply(this.$finals$.runCount, []);
$I$(7,"range$I$I",[0, statistics.getValue$.apply(statistics, []).length]).forEach$java_util_function_IntConsumer.apply($I$(7,"range$I$I",[0, statistics.getValue$.apply(statistics, []).length]), [((P$.StatisticalTorsionPotential$lambda5$6||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda5$6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) /*block*/{
this.$finals$.referenceSum[i]+=this.$finals$.statistics.getValue$.apply(this.$finals$.statistics, [])[i];
});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda5$6.$init$,[this, {statistics:statistics,referenceSum:this.$finals$.referenceSum}]))]);
});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda5.$init$,[this, {runCount:runCount,referenceSum:referenceSum}])));
for (var i=0; i < referenceSum.length; i++) {
referenceSum[i]/=runCount.get$();
}
discreteFunctions.replaceAll$java_util_function_BiFunction(((P$.StatisticalTorsionPotential$lambda6||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda6", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.BiFunction', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$S$DA','apply$O$O'],  function (k, v) { return (p$1.normalize$DA$DA.apply(this.b$['com.actelion.research.chem.conf.torsionstrain.StatisticalTorsionPotential'], [v, this.$finals$.referenceSum]));});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda6.$init$,[this, {referenceSum:referenceSum}])));
var X=Clazz.array(Double.TYPE, [referenceSum.length]);
$I$(7).range$I$I(0, X.length).forEach$java_util_function_IntConsumer(((P$.StatisticalTorsionPotential$lambda7||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda7", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.X[i]=(i + 0.5) * 5.0);});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda7.$init$,[this, {X:X}])));
for (var l, $l = discreteFunctions.keySet$().iterator$(); $l.hasNext$()&&((l=($l.next$())),1);) {
var sigma=Clazz.array(Double.TYPE, [X.length]);
$I$(12).fill$DA$D(sigma, 1);
var interpolator=Clazz.new_($I$(13,1));
interpolator.setLambda$D(0.005);
interpolator.setSigma$DA(sigma);
var ff=interpolator.interpolate$DA$DA(X, discreteFunctions.get$O(l));
var Y=Clazz.array(Double.TYPE, [X.length]);
for (var i=0; i < X.length; i++) {
try {
Y[i]=ff.value$D(X[i]);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
Y[i]=0;
} else {
throw e;
}
}
}
var potential=this.torsionPotentials.get$O(l);
potential.setSplineFunction$com_actelion_research_util_FastSpline(ff);
potential.setDiscreteFunction$DA(discreteFunctions.get$O(l));
}
}, p$1);

Clazz.newMeth(C$, 'normalize$DA$DA',  function (arr, reference) {
$I$(7).range$I$I(0, arr.length).forEach$java_util_function_IntConsumer(((P$.StatisticalTorsionPotential$lambda8||
(function(){/*m*/var C$=Clazz.newClass(P$, "StatisticalTorsionPotential$lambda8", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.arr[i]=-Math.log((this.$finals$.arr[i] + 1.0E-4) / (this.$finals$.reference[i] + 1.0E-4)));});
})()
), Clazz.new_(P$.StatisticalTorsionPotential$lambda8.$init$,[this, {arr:arr,reference:reference}])));
return arr;
}, p$1);

Clazz.newMeth(C$, 'normalization$IA',  function (Y) {
var YNorm=Clazz.array(Double.TYPE, [Y.length]);
var normalizedSum=0;
for (var index=0; index < Y.length; index++) {
normalizedSum+=Y[index];
}
if (normalizedSum == 0 ) return YNorm;
for (var index=0; index < Y.length; index++) {
YNorm[index]=(Y[index] / normalizedSum);
}
return YNorm;
}, p$1);

Clazz.newMeth(C$, 'getFunction$J',  function (l) {
return this.torsionPotentials.get$O(Long.valueOf$J(l));
});
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
