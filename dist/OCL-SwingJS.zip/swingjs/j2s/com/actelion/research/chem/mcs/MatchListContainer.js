(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'com.actelion.research.chem.mcs.MatchList','java.util.LinkedList','java.util.HashSet','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatchListContainer");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrMatchList','com.actelion.research.chem.mcs.MatchList[]','hsMatchList','java.util.HashSet','liIndexAvailable','java.util.LinkedList','+liIndexUsed','liMatches','java.util.List']]]

Clazz.newMeth(C$, 'c$$I',  function (maxNumAtomsMolecule) {
;C$.$init$.apply(this);
var maximumCapacity=((maxNumAtomsMolecule * 0.25)|0);
this.arrMatchList=Clazz.array($I$(1), [maximumCapacity]);
this.liIndexAvailable=Clazz.new_($I$(2,1));
this.liIndexUsed=Clazz.new_($I$(2,1));
var nInteger=((maxNumAtomsMolecule + 32 - 1)/32|0);
for (var i=0; i < this.arrMatchList.length; i++) {
this.arrMatchList[i]=Clazz.new_($I$(1,1).c$$I,[nInteger]);
this.liIndexAvailable.add$O(Integer.valueOf$I(i));
}
this.hsMatchList=Clazz.new_($I$(3,1));
this.liMatches=Clazz.new_($I$(4,1));
}, 1);

Clazz.newMeth(C$, 'reset$',  function () {
this.hsMatchList.clear$();
for (var index, $index = this.liIndexUsed.iterator$(); $index.hasNext$()&&((index=($index.next$()).intValue$()),1);) {
this.arrMatchList[index].reset$();
this.liIndexAvailable.add$O(Integer.valueOf$I(index));
}
this.liIndexUsed.clear$();
this.liMatches=Clazz.new_($I$(4,1));
});

Clazz.newMeth(C$, 'add$IA',  function (arrMatchListFragment) {
this.liMatches.add$O(arrMatchListFragment);
});

Clazz.newMeth(C$, 'getMatchList$',  function () {
return this.liMatches;
});

Clazz.newMeth(C$, 'isMaxCapacityReached$',  function () {
return this.liIndexAvailable.isEmpty$();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:11 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
