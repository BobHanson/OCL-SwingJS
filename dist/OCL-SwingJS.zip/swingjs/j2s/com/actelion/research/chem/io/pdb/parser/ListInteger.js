(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "ListInteger");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id'],'O',['li','java.util.List']]]

Clazz.newMeth(C$, 'c$$java_util_List$I',  function (li, id) {
;C$.$init$.apply(this);
this.id=id;
this.li=li;
}, 1);

Clazz.newMeth(C$, 'getId$',  function () {
return this.id;
});

Clazz.newMeth(C$, 'setId$I',  function (id) {
this.id=id;
});

Clazz.newMeth(C$, 'getLi$',  function () {
return this.li;
});

Clazz.newMeth(C$, 'setLi$java_util_List',  function (li) {
this.li=li;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:55 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
