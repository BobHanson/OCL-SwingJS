(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.flexophore.generator.ConstantsFlexophoreGenerator','com.actelion.research.util.BurtleHasher','com.actelion.research.calc.ArrayUtilsCalc',['com.actelion.research.chem.descriptor.flexophore.PPNode','.InterActionTypeFreq'],'com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','java.util.ArrayList','java.util.Collections','StringBuilder','com.actelion.research.chem.descriptor.flexophore.ConstantsFlexophoreHardPPPoints']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPNode", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, ['Comparable', 'com.actelion.research.chem.descriptor.flexophore.IPPNode']);
C$.$classes$=[['InterActionTypeFreq',10]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['heteroAtom'],'B',['size','modeFlexophore'],'O',['arrInteractionType','byte[]']]
,['I',['BUFFER_SIZE']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
;C$.$init$.apply(this);
this.copy$com_actelion_research_chem_descriptor_flexophore_PPNode(node);
}, 1);

Clazz.newMeth(C$, 'add$I',  function (interactionType) {
if (interactionType >= $I$(1).MAX_VAL_INTERACTION_TYPE) throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Interaction type " + interactionType + " larger than " + $I$(1).MAX_VAL_INTERACTION_TYPE + "." ]);
var addedByIncrement=false;
for (var i=($b$[0] = 0, $b$[0]); i < this.size; ($b$[0]=i,i=(++$b$[0],$b$[0]))) {
var interactionTypeNode=this.getInteractionType$I(i);
if (interactionType == interactionTypeNode) {
p$1.incrementAtomTypeCount$I.apply(this, [i]);
addedByIncrement=true;
break;
}}
if (!addedByIncrement) {
p$1.initInteractionType$I.apply(this, [interactionType]);
}});

Clazz.newMeth(C$, 'addAtoms$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
for (var i=0; i < node.getInteractionTypeCount$(); i++) {
if (!this.containsInteractionID$I(node.getInteractionType$I(i))) {
this.add$I(node.getInteractionType$I(i));
}}
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_flexophore_PPNode','compareTo$O'],  function (o) {
var cmp=0;
var size1=this.getInteractionTypeCount$();
var size2=o.getInteractionTypeCount$();
var max1=C$.getMaximumInteractionType$com_actelion_research_chem_descriptor_flexophore_PPNode(this);
var max2=C$.getMaximumInteractionType$com_actelion_research_chem_descriptor_flexophore_PPNode(o);
if (max1 > max2) cmp=1;
 else if (max1 < max2) cmp=-1;
 else {
if (size1 > size2) cmp=1;
 else if (size1 < size2) cmp=-1;
 else {
for (var i=0; i < size1; i++) {
var id1=this.getInteractionType$I(i);
var id2=o.getInteractionType$I(i);
if (id1 > id2) {
cmp=1;
} else if (id1 < id2) {
cmp=-1;
}}
}}return cmp;
});

Clazz.newMeth(C$, 'containsInteractionID$I',  function (interactid) {
var contains=false;
if (this.arrInteractionType == null ) return contains;
var size=this.getInteractionTypeCount$();
for (var i=0; i < size; i++) {
if (this.getInteractionType$I(i) == interactid) {
contains=true;
break;
}}
return contains;
});

Clazz.newMeth(C$, 'copy$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
this.arrInteractionType=Clazz.array(Byte.TYPE, [node.arrInteractionType.length]);
System.arraycopy$O$I$O$I$I(node.arrInteractionType, 0, this.arrInteractionType, 0, node.arrInteractionType.length);
this.size=node.size;
this.modeFlexophore=node.modeFlexophore;
});

Clazz.newMeth(C$, 'getCopy$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_descriptor_flexophore_PPNode,[this]);
});

Clazz.newMeth(C$, 'equals$O',  function (o) {
var n=o;
return this.equalAtoms$com_actelion_research_chem_descriptor_flexophore_PPNode(n);
});

Clazz.newMeth(C$, 'hashCode$',  function () {
return $I$(2).hashlittle$BA$J(this.arrInteractionType, 13);
});

Clazz.newMeth(C$, 'realize$',  function () {
var sizeBytes=this.size * C$.getNumBytesEntry$();
this.arrInteractionType=$I$(3).resize$BA$I(this.arrInteractionType, sizeBytes);
this.sortInteractionTypes$();
p$1.calcHasHeteroAtom.apply(this, []);
});

Clazz.newMeth(C$, 'equalAtoms$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
var b=true;
var size1=this.getInteractionTypeCount$();
var size2=node.getInteractionTypeCount$();
if (size1 != size2) b=false;
 else {
for (var i=0; i < size1; i++) {
var id1=this.getInteractionType$I(i);
var id2=node.getInteractionType$I(i);
if (id1 != id2) {
b=false;
break;
}}
}return b;
});

Clazz.newMeth(C$, 'get$',  function () {
return this.arrInteractionType;
});

Clazz.newMeth(C$, 'getInteractionTypeCount$',  function () {
return this.size;
});

Clazz.newMeth(C$, 'getInteractionType$I',  function (i) {
var index=p$1.getIndexInteractionTypeInArray$I.apply(this, [i]);
return C$.getInteractionTypeFromByteArray$B$B$B(this.arrInteractionType[index], this.arrInteractionType[index + 1], this.arrInteractionType[index + 2]);
});

Clazz.newMeth(C$, 'getIndexInteractionTypeInArray$I',  function (i) {
return i * C$.getNumBytesEntry$();
}, p$1);

Clazz.newMeth(C$, 'incrementAtomTypeCount$I',  function (i) {
var index=p$1.getIndexInteractionTypeInArray$I.apply(this, [i]);
(($b$[0]=++this.arrInteractionType[$k$=index + 3],this.arrInteractionType[$k$]=$b$[0],$b$[0]));
return this.arrInteractionType[index + 3];
}, p$1);

Clazz.newMeth(C$, 'getInteractionTypeFromByteArray$B$B$B',  function (low, med, high) {
var v=(high & 255) << 16;
v=v | (med & 255) << 8;
v=v | (low & 255);
return v;
}, 1);

Clazz.newMeth(C$, 'getInteraction$I',  function (i) {
var index=p$1.getIndexInteractionTypeInArray$I.apply(this, [i]);
var iaf=Clazz.new_([this.getInteractionType$I(i), this.arrInteractionType[index + 3]],$I$(4,1).c$$I$B);
return iaf;
});

Clazz.newMeth(C$, 'getAtomicNo$I',  function (i) {
return $I$(5,"getAtomicNumber$I",[this.getInteractionType$I(i)]);
});

Clazz.newMeth(C$, 'isAromatic$I',  function (i) {
return $I$(5,"isAromatic$I",[this.getInteractionType$I(i)]);
});

Clazz.newMeth(C$, 'getAtomicNoFromInteractionType$I',  function (interactionType) {
return $I$(5).getAtomicNumber$I(interactionType);
}, 1);

Clazz.newMeth(C$, 'getDummy$',  function () {
var node=Clazz.new_(C$);
node.add$I(37);
return node;
}, 1);

Clazz.newMeth(C$, 'hasHeteroAtom$',  function () {
return this.heteroAtom;
});

Clazz.newMeth(C$, 'calcHasHeteroAtom',  function () {
this.heteroAtom=false;
var size=this.getInteractionTypeCount$();
for (var i=0; i < size; i++) {
if (this.getAtomicNo$I(i) != 6) {
this.heteroAtom=true;
break;
}}
}, p$1);

Clazz.newMeth(C$, 'isCarbonExclusiveNode$',  function () {
var carbon=true;
var size=this.getInteractionTypeCount$();
for (var i=0; i < size; i++) {
if (this.getAtomicNo$I(i) != 6) {
carbon=false;
break;
}}
return carbon;
});

Clazz.newMeth(C$, 'containsHetero$',  function () {
return this.heteroAtom;
});

Clazz.newMeth(C$, 'init',  function () {
this.arrInteractionType=Clazz.array(Byte.TYPE, [C$.BUFFER_SIZE]);
this.modeFlexophore=0;
}, p$1);

Clazz.newMeth(C$, 'set$BA$B',  function (arrInteractionType, size) {
this.arrInteractionType=arrInteractionType;
this.size=size;
});

Clazz.newMeth(C$, 'getModeFlexophore$',  function () {
return this.modeFlexophore;
});

Clazz.newMeth(C$, 'setModeFlexophore$B',  function (modeFlexophore) {
this.modeFlexophore=modeFlexophore;
});

Clazz.newMeth(C$, 'initInteractionType$I',  function (interactionType) {
if (interactionType > $I$(1).MAX_VAL_INTERACTION_TYPE) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Interaction type to large for PPNode!"]);
}var index=p$1.getIndexInteractionTypeInArray$I.apply(this, [this.size]);
p$1.setInterActionType$I$I$B.apply(this, [interactionType, index, 1]);
(($b$[0]=++this.size,this.size=$b$[0],$b$[0]));
var l=this.size * C$.getNumBytesEntry$();
if (l == this.arrInteractionType.length) {
this.arrInteractionType=$I$(3).resize$BA$I(this.arrInteractionType, this.arrInteractionType.length + C$.BUFFER_SIZE);
}}, p$1);

Clazz.newMeth(C$, 'setInterActionType$I$I$B',  function (interactionType, indexInArray, frequency) {
var low=($b$[0] = (interactionType & 255), $b$[0]);
var med=($b$[0] = (interactionType >> 8), $b$[0]);
var high=($b$[0] = (interactionType >> 16), $b$[0]);
this.arrInteractionType[indexInArray]=low;
this.arrInteractionType[indexInArray + 1]=med;
this.arrInteractionType[indexInArray + 2]=high;
this.arrInteractionType[indexInArray + 3]=frequency;
}, p$1);

Clazz.newMeth(C$, 'sortInteractionTypes$',  function () {
var li=Clazz.new_($I$(6,1));
for (var i=($b$[0] = 0, $b$[0]); i < this.size; ($b$[0]=i,i=(++$b$[0],$b$[0]))) {
li.add$O(this.getInteraction$I(i));
}
var c=((P$.PPNode$1||
(function(){/*a*/var C$=Clazz.newClass(P$, "PPNode$1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.Comparator', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, ['compare$com_actelion_research_chem_descriptor_flexophore_PPNode_InterActionTypeFreq$com_actelion_research_chem_descriptor_flexophore_PPNode_InterActionTypeFreq','compare$O$O'],  function (o1, o2) {
var cmp=0;
if (o1.interactionType > o2.interactionType) {
cmp=1;
} else if (o1.interactionType < o2.interactionType) {
cmp=-1;
}return cmp;
});
})()
), Clazz.new_(P$.PPNode$1.$init$,[this, null]));
$I$(7).sort$java_util_List$java_util_Comparator(li, c);
for (var i=0; i < li.size$(); i++) {
var iaf=li.get$I(i);
var index=p$1.getIndexInteractionTypeInArray$I.apply(this, [i]);
p$1.setInterActionType$I$I$B.apply(this, [iaf.interactionType, index, iaf.frequency]);
}
});

Clazz.newMeth(C$, 'getFractionCarbonInteractions$',  function () {
var carbons=0;
var sumFreq=0;
for (var i=0; i < this.getInteractionTypeCount$(); i++) {
var iaf=this.getInteraction$I(i);
var interactionTypeQuery=iaf.interactionType;
if ($I$(5).isCarbonInteraction$I(interactionTypeQuery)) {
carbons+=iaf.frequency;
}sumFreq+=iaf.frequency;
}
var fractionCarbonQuery=carbons / sumFreq;
return fractionCarbonQuery;
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(8,1));
sb.append$S("(");
var size=this.getInteractionTypeCount$();
for (var i=0; i < size; i++) {
if (i > 0) {
sb.append$S(",");
}var iaf=this.getInteraction$I(i);
sb.append$I(iaf.interactionType);
if (iaf.frequency > 1) {
sb.append$S("*");
sb.append$I(iaf.frequency);
}}
sb.append$S(")");
return sb.toString();
});

Clazz.newMeth(C$, 'getHeteroOnlyNode$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
var nodeHetero=Clazz.new_(C$);
var nQuery=node.getInteractionTypeCount$();
for (var i=0; i < nQuery; i++) {
var interactionType=node.getInteractionType$I(i);
if ($I$(5).getAtomicNumber$I(interactionType) != 6) {
nodeHetero.add$I(interactionType);
}}
nodeHetero.realize$();
return nodeHetero;
}, 1);

Clazz.newMeth(C$, 'toStringText$',  function () {
var sb=Clazz.new_($I$(8,1));
sb.append$S("(");
for (var i=0; i < this.size; i++) {
if (i > 0) {
sb.append$S(",");
}var iaf=this.getInteraction$I(i);
var s=$I$(5).getString$I(iaf.interactionType);
sb.append$S(s);
if (iaf.frequency > 1) {
sb.append$S("*");
sb.append$I(iaf.frequency);
}}
sb.append$S(")");
return sb.toString();
});

Clazz.newMeth(C$, 'toStringElusive$',  function () {
var sb=Clazz.new_($I$(8,1));
sb.append$S("(");
for (var i=0; i < this.size; i++) {
if (i > 0) {
sb.append$S(",");
}var iaf=this.getInteraction$I(i);
var s=$I$(5).getString$I(iaf.interactionType);
sb.append$I(iaf.interactionType);
sb.append$S(":");
sb.append$S(s);
if (iaf.frequency > 1) {
sb.append$S("*");
sb.append$I(iaf.frequency);
}}
sb.append$S(")");
return sb.toString();
});

Clazz.newMeth(C$, 'toStringLongHardPPPoint$',  function () {
var sb=Clazz.new_($I$(8,1));
sb.append$S("(");
for (var i=0; i < this.size; i++) {
if (i > 0) {
sb.append$S(",");
}var iaf=this.getInteraction$I(i);
var s=$I$(9).toStringPPPoints$I(iaf.interactionType);
sb.append$S(s);
if (iaf.frequency > 1) {
sb.append$S("*");
sb.append$I(iaf.frequency);
}}
sb.append$S(")");
return sb.toString();
});

Clazz.newMeth(C$, 'read$S',  function (strNode) {
if (strNode.length$() == 0) {
return Clazz.new_(C$);
}var arr=strNode.split$S(",");
var n=Clazz.new_(C$);
for (var i=0; i < arr.length; i++) {
var strAtomType=arr[i];
if (strAtomType.contains$CharSequence("*")) {
var arrAtType=strAtomType.split$S("\\*");
var type=Integer.parseInt$S(arrAtType[0]);
var freq=Integer.parseInt$S(arrAtType[1]);
for (var j=0; j < freq; j++) {
n.add$I(type);
}
} else {
var type=Integer.parseInt$S(strAtomType);
n.add$I(type);
}}
n.realize$();
return n;
}, 1);

Clazz.newMeth(C$, 'getMaximumInteractionType$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (n) {
var max=0;
var size=n.getInteractionTypeCount$();
for (var i=0; i < size; i++) {
var id=n.getInteractionType$I(i);
if (id < max) {
max=id;
}}
return max;
}, 1);

Clazz.newMeth(C$, 'getNumBytesEntry$',  function () {
return 4;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.BUFFER_SIZE=3 * C$.getNumBytesEntry$();
};
var $b$ = new Int8Array(1);
var $k$;
;
(function(){/*c*/var C$=Clazz.newClass(P$.PPNode, "InterActionTypeFreq", function(){
Clazz.newInstance(this, arguments[0],false,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['B',['frequency'],'I',['interactionType']]]

Clazz.newMeth(C$, 'c$$I$B',  function (interactionType, frequency) {
;C$.$init$.apply(this);
this.interactionType=interactionType;
this.frequency=frequency;
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
return "InterActionTypeFreq{interactionType=" + this.interactionType + ", frequency=" + this.frequency + '}' ;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-08 23:06:21 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
