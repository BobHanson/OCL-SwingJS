(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.SSSearcher']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubstructureFilter", null, null, 'com.actelion.research.chem.MoleculeFilter');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['mMatchMode'],'O',['mSearcher','com.actelion.research.chem.SSSearcher']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (substructure) {
C$.c$$com_actelion_research_chem_StereoMolecule$I.apply(this, [substructure, 8]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$I',  function (substructure, matchMode) {
;C$.$init$.apply(this);
this.mSearcher=Clazz.new_($I$(1,1));
this.mSearcher.setFragment$com_actelion_research_chem_StereoMolecule(substructure);
this.mMatchMode=matchMode;
}, 1);

Clazz.newMeth(C$, 'moleculeQualifies$com_actelion_research_chem_StereoMolecule',  function (mol) {
this.mSearcher.setMolecule$com_actelion_research_chem_StereoMolecule(mol);
return this.mSearcher.isFragmentInMolecule$I(this.mMatchMode);
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
