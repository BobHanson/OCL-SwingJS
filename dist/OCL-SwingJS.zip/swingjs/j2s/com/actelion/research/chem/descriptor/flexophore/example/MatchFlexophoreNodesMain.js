(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.example"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorHandlerFlexophore','com.actelion.research.chem.IDCodeParser','java.util.ArrayList','com.actelion.research.util.ArrayUtils','com.actelion.research.util.Formatter']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MatchFlexophoreNodesMain");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var idcode="ffchb@DXXJWb`dLbbRbrrTTRRMNRUGL@QSPPQQ@@@";
var idcodeQuery="fi{iA@IJcdn`Xa@cHhhdmDeDdmDjfBM[MXHHZj`bJp@@@";
C$.pairMatch$S$S(idcode, idcodeQuery);
}, 1);

Clazz.newMeth(C$, 'pairMatch$S$S',  function (idcodeBase, idcodeQuery) {
var dhFlexophore=Clazz.new_($I$(1,1));
var objectiveBlurFlexophoreHardMatchUncovered=dhFlexophore.getObjectiveCompleteGraph$();
var parser=Clazz.new_($I$(2,1));
var mdhvBase=C$.create$com_actelion_research_chem_IDCodeParser$com_actelion_research_chem_descriptor_DescriptorHandlerFlexophore$S(parser, dhFlexophore, idcodeBase);
System.out.println$S("Num pp nodes base " + mdhvBase.getNumPPNodes$());
var liBaseArrayIndexAtom=Clazz.new_($I$(3,1));
for (var i=0; i < mdhvBase.getNumPPNodes$(); i++) {
var arrIndexAt=mdhvBase.getNode$I(i).getArrayIndexOriginalAtoms$();
liBaseArrayIndexAtom.add$O(arrIndexAt);
}
var mdhvQuery=C$.create$com_actelion_research_chem_IDCodeParser$com_actelion_research_chem_descriptor_DescriptorHandlerFlexophore$S(parser, dhFlexophore, idcodeQuery);
System.out.println$S("Num pp nodes query " + mdhvQuery.getNumPPNodes$());
var liQueryArrayIndexAtom=Clazz.new_($I$(3,1));
for (var i=0; i < mdhvQuery.getNumPPNodes$(); i++) {
var arrIndexAt=mdhvQuery.getNode$I(i).getArrayIndexOriginalAtoms$();
liQueryArrayIndexAtom.add$O(arrIndexAt);
}
System.out.println$S(mdhvBase.toString());
System.out.println$S(mdhvQuery.toString());
var mdhBase=mdhvBase.getMolDistHist$();
var mdhQuery=mdhvQuery.getMolDistHist$();
var modelSolutionSimilarity=dhFlexophore.getBestMatch$com_actelion_research_chem_descriptor_flexophore_MolDistHist$com_actelion_research_chem_descriptor_flexophore_MolDistHist(mdhBase, mdhQuery);
var heap=modelSolutionSimilarity.getSizeHeap$();
objectiveBlurFlexophoreHardMatchUncovered.setBase$com_actelion_research_chem_descriptor_flexophore_IMolDistHist(mdhBase);
objectiveBlurFlexophoreHardMatchUncovered.setQuery$com_actelion_research_chem_descriptor_flexophore_IMolDistHist(mdhQuery);
for (var i=0; i < heap; i++) {
var indexQuery=modelSolutionSimilarity.getIndexQueryFromHeap$I(i);
var indexBase=modelSolutionSimilarity.getIndexBaseFromHeap$I(i);
var ppvBase=mdhvBase.getNode$I(indexBase);
var arrAtomIndexBase=liBaseArrayIndexAtom.get$I(indexBase);
var ppvQuery=mdhvQuery.getNode$I(indexQuery);
var arrAtomIndexQuery=liQueryArrayIndexAtom.get$I(indexQuery);
System.out.println$S(ppvBase.toString());
System.out.println$S($I$(4).toString$IA(arrAtomIndexBase));
System.out.println$S(ppvQuery.toString());
System.out.println$S($I$(4).toString$IA(arrAtomIndexQuery));
var simHistogram=objectiveBlurFlexophoreHardMatchUncovered.getSimilarityHistogramsForNode$com_actelion_research_util_graph_complete_SolutionCompleteGraph$I(modelSolutionSimilarity, i);
System.out.println$S("Node similarity " + $I$(5,"format3$Double",[Double.valueOf$D(modelSolutionSimilarity.getSimilarityNode$I(indexQuery))]) + ", histogram similarity " + $I$(5,"format3$Double",[Double.valueOf$D(simHistogram)]) + "." );
System.out.println$();
}
System.out.println$S("Un-normalized similarity " + $I$(5,"format3$Double",[Double.valueOf$D(modelSolutionSimilarity.getSimilarity$())]));
}, 1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_IDCodeParser$com_actelion_research_chem_descriptor_DescriptorHandlerFlexophore$S',  function (parser, dh, idcode) {
var mol=parser.getCompactMolecule$S(idcode);
mol.ensureHelperArrays$I(7);
return dh.createVisualDescriptor$com_actelion_research_chem_StereoMolecule(mol);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-02 04:52:41 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
