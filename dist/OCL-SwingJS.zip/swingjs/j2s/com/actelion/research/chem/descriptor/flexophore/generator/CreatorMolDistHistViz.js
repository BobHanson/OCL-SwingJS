(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphExtractor','org.openmolecules.chem.conf.gen.ConformerGenerator','org.openmolecules.chem.conf.gen.RigidFragmentCache','com.actelion.research.chem.MoleculeStandardizer','com.actelion.research.chem.Molecule3D','com.actelion.research.chem.interactionstatistics.InteractionAtomTypeCalculator','java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.generator.MultCoordFragIndex','com.actelion.research.chem.Canonizer','com.actelion.research.chem.descriptor.flexophore.ExceptionConformationGenerationFailed','java.util.HashSet','com.actelion.research.chem.ExtendedMoleculeFunctions','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphIndices','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','com.actelion.research.chem.descriptor.flexophore.PPNodeViz','com.actelion.research.chem.ExtendedMolecule']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CreatorMolDistHistViz");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['onlyOneConformer'],'I',['conformationMode'],'J',['seed'],'O',['subGraphExtractor','com.actelion.research.chem.descriptor.flexophore.redgraph.SubGraphExtractor','conformerGenerator','org.openmolecules.chem.conf.gen.ConformerGenerator','arrIndexAtomNewTmp','int[]']]
,['O',['INSTANCE','com.actelion.research.chem.descriptor.flexophore.generator.CreatorMolDistHistViz']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.seed=123456789;
this.subGraphExtractor=Clazz.new_($I$(1,1));
this.conformerGenerator=Clazz.new_($I$(2,1).c$$J$Z,[this.seed, false]);
$I$(3).getDefaultInstance$().loadDefaultCache$();
this.conformationMode=0;
this.arrIndexAtomNewTmp=Clazz.array(Integer.TYPE, [1000]);
}, 1);

Clazz.newMeth(C$, 'setThreadMaster$com_actelion_research_calc_ThreadMaster',  function (threadMaster) {
this.conformerGenerator.setThreadMaster$com_actelion_research_calc_ThreadMaster(threadMaster);
});

Clazz.newMeth(C$, 'setConformationMode$I',  function (conformationMode) {
this.conformationMode=conformationMode;
});

Clazz.newMeth(C$, 'create$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var mdhv=null;
switch (this.conformationMode) {
case 0:
mdhv=this.createMultipleConformations$com_actelion_research_chem_StereoMolecule$I(molOrig, 250);
break;
case 1:
mdhv=this.createFromGivenConformation$com_actelion_research_chem_StereoMolecule(molOrig);
break;
case 2:
mdhv=this.createMultipleConformations$com_actelion_research_chem_StereoMolecule$I(molOrig, 1);
break;
default:
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Invalid conformation mode"]);
}
return mdhv;
});

Clazz.newMeth(C$, 'createMultipleConformations$com_actelion_research_chem_StereoMolecule$I',  function (molOrig, nConformations) {
var molStand=molOrig.getCompactCopy$();
$I$(4).standardize$com_actelion_research_chem_StereoMolecule$I(molStand, 1);
molStand.ensureHelperArrays$I(7);
var molInPlace=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[molStand]);
molInPlace.ensureHelperArrays$I(7);
this.conformerGenerator.initializeConformers$com_actelion_research_chem_StereoMolecule$I$I$Z(molInPlace, 3, 10000, false);
$I$(6).setInteractionTypes$com_actelion_research_chem_Molecule3D(molInPlace);
var liSubGraphIndices=this.subGraphExtractor.extract$com_actelion_research_chem_StereoMolecule(molInPlace);
liSubGraphIndices=C$.handleCarbonConnected2Hetero$java_util_List$com_actelion_research_chem_StereoMolecule(liSubGraphIndices, molInPlace);
if (false) {
this.injectNewSeed$();
}var nAtoms=molInPlace.getAtoms$();
var liMultCoordFragIndex=Clazz.new_($I$(7,1));
for (var subGraphIndices, $subGraphIndices = liSubGraphIndices.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([subGraphIndices.getAtomIndices$()],$I$(8,1).c$$IA));
}
var molViz=C$.createConformations$com_actelion_research_chem_Molecule3D$java_util_List$I$org_openmolecules_chem_conf_gen_ConformerGenerator(molInPlace, liMultCoordFragIndex, nConformations, this.conformerGenerator);
var nPotentialConformers=this.conformerGenerator.getPotentialConformerCount$();
this.onlyOneConformer=false;
if ((nPotentialConformers > 1) && (liMultCoordFragIndex.get$I(0).getCoordinates$().size$() == 1) ) {
if (false) {
System.out.println$S("CreatorCompleteGraph: only one conformer generated.");
System.out.println$S("Seed " + Long.$s(this.seed));
System.out.println$S("Potential conformer count " + nPotentialConformers);
var can=Clazz.new_($I$(9,1).c$$com_actelion_research_chem_StereoMolecule,[molInPlace]);
System.out.println$S(can.getIDCode$());
}this.onlyOneConformer=true;
}var mdhv=C$.create$java_util_List$com_actelion_research_chem_Molecule3D(liMultCoordFragIndex, molViz);
return mdhv;
});

Clazz.newMeth(C$, 'createConformations$com_actelion_research_chem_Molecule3D$java_util_List$I$org_openmolecules_chem_conf_gen_ConformerGenerator',  function (molInPlace, liMultCoordFragIndex, nConformations, conformerGenerator) {
var nAtoms=molInPlace.getAtoms$();
var ccConformationsGenerated=0;
var molViz=null;
for (var i=0; i < nConformations; i++) {
var conformerGenerated=C$.generateConformerAndSetCoordinates$org_openmolecules_chem_conf_gen_ConformerGenerator$I$com_actelion_research_chem_Molecule3D(conformerGenerator, nAtoms, molInPlace);
if (!conformerGenerated) {
break;
}++ccConformationsGenerated;
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molInPlace, liMultCoordFragIndex);
if (i == 0) {
molViz=C$.createPharmacophorePoints$com_actelion_research_chem_Molecule3D$java_util_List(molInPlace, liMultCoordFragIndex);
}}
if (ccConformationsGenerated == 0) {
throw Clazz.new_($I$(10,1).c$$S,["Impossible to generate one conformer!"]);
}return molViz;
}, 1);

Clazz.newMeth(C$, 'handleCarbonConnected2Hetero$java_util_List$com_actelion_research_chem_StereoMolecule',  function (liSubGraphIndices, molInPlace) {
var liSubGraphIndicesProcessed=Clazz.new_($I$(7,1));
for (var sgi, $sgi = liSubGraphIndices.iterator$(); $sgi.hasNext$()&&((sgi=($sgi.next$())),1);) {
var arrIndexAtomFragment=sgi.getAtomIndices$();
var hsIndexAtom2Remove=Clazz.new_($I$(11,1));
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if ($I$(12).isCarbonConnected2Hetero$com_actelion_research_chem_StereoMolecule$I(molInPlace, indexAtFrag)) {
if ($I$(12).isIsolatedCarbon$com_actelion_research_chem_StereoMolecule$I$IA(molInPlace, indexAtFrag, arrIndexAtomFragment)) {
hsIndexAtom2Remove.add$O(Integer.valueOf$I(indexAtFrag));
}}}
var sgiProcessed=Clazz.new_($I$(13,1));
if (hsIndexAtom2Remove.size$() > 0) {
for (var indexAtFrag, $indexAtFrag = 0, $$indexAtFrag = arrIndexAtomFragment; $indexAtFrag<$$indexAtFrag.length&&((indexAtFrag=($$indexAtFrag[$indexAtFrag])),1);$indexAtFrag++) {
if (!hsIndexAtom2Remove.contains$O(Integer.valueOf$I(indexAtFrag))) {
sgiProcessed.addIndex$I(indexAtFrag);
}}
} else {
sgiProcessed.addIndex$IA(arrIndexAtomFragment);
}if (sgiProcessed.getNumIndices$() > 0) liSubGraphIndicesProcessed.add$O(sgiProcessed);
}
return liSubGraphIndicesProcessed;
}, 1);

Clazz.newMeth(C$, 'create$java_util_List$com_actelion_research_chem_Molecule3D',  function (liMultCoordFragIndex, molecule3D) {
var molDistHistViz=Clazz.new_([liMultCoordFragIndex.size$(), molecule3D],$I$(14,1).c$$I$com_actelion_research_chem_Molecule3D);
var liPPNodeViz=Clazz.new_($I$(7,1));
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
var mcfi=liMultCoordFragIndex.get$I(i);
var arrIndexAtomFrag=mcfi.getArrIndexFrag$();
var ppNodeViz=Clazz.new_($I$(15,1));
ppNodeViz.setIndex$I(i);
ppNodeViz.setCoordinates$com_actelion_research_chem_Coordinates(liMultCoordFragIndex.get$I(i).getCoordinates$().get$I(0));
for (var index, $index = 0, $$index = arrIndexAtomFrag; $index<$$index.length&&((index=($$index[$index])),1);$index++) {
var interactionType=molecule3D.getInteractionAtomType$I(index);
ppNodeViz.add$I(interactionType);
ppNodeViz.addIndexOriginalAtom$I(index);
}
liPPNodeViz.add$O(ppNodeViz);
}
molDistHistViz.set$java_util_List(liPPNodeViz);
for (var i=0; i < liMultCoordFragIndex.size$(); i++) {
for (var j=i + 1; j < liMultCoordFragIndex.size$(); j++) {
var arrDistHist=$I$(8,"getDistHist$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex",[liMultCoordFragIndex.get$I(i), liMultCoordFragIndex.get$I(j)]);
molDistHistViz.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
molDistHistViz.realize$();
return molDistHistViz;
}, 1);

Clazz.newMeth(C$, 'createPharmacophorePoints$com_actelion_research_chem_Molecule3D$java_util_List',  function (molecule3D, liMultCoordFragIndex) {
var molCenter=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_Molecule3D,[molecule3D]);
molCenter.ensureHelperArrays$I(7);
for (var multCoordFragIndex, $multCoordFragIndex = liMultCoordFragIndex.iterator$(); $multCoordFragIndex.hasNext$()&&((multCoordFragIndex=($multCoordFragIndex.next$())),1);) {
var arrAtomIndexList=multCoordFragIndex.getArrIndexFrag$();
var coordCenter=$I$(16).getCenterGravity$com_actelion_research_chem_ExtendedMolecule$IA(molCenter, arrAtomIndexList);
for (var at=0; at < arrAtomIndexList.length; at++) {
var interactionType=molCenter.getInteractionAtomType$I(arrAtomIndexList[at]);
if (interactionType == -1) {
continue;
}var iAtomicNo=molCenter.getAtomicNo$I(arrAtomIndexList[at]);
molCenter.setAtomFlag$I$I$Z(arrAtomIndexList[at], 8, true);
var indexOriginalAtom=arrAtomIndexList[at];
var indexAtm=molCenter.addAtom$I(iAtomicNo);
molCenter.setInteractionAtomType$I$I(indexAtm, interactionType);
var sOrigIndex=Integer.toString$I(indexOriginalAtom);
molCenter.setAtomChainId$I$S(indexAtm, sOrigIndex);
molCenter.setCoordinates$I$com_actelion_research_chem_Coordinates(indexAtm, coordCenter);
molCenter.setAtomFlag$I$I$Z(indexAtm, 16, true);
molCenter.setPPP$I$IA(indexAtm, arrAtomIndexList);
}
}
molCenter.ensureHelperArrays$I(7);
return molCenter;
}, 1);

Clazz.newMeth(C$, 'injectNewSeed$',  function () {
this.seed=Clazz.new_(java.util.Date).getTime$();
this.conformerGenerator=Clazz.new_($I$(2,1).c$$J$Z,[this.seed, false]);
});

Clazz.newMeth(C$, 'isOnlyOneConformer$',  function () {
return this.onlyOneConformer;
});

Clazz.newMeth(C$, 'createFromGivenConformation$com_actelion_research_chem_StereoMolecule',  function (molOrig) {
var molStart=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule,[molOrig]);
molStart.ensureHelperArrays$I(7);
$I$(6).setInteractionTypes$com_actelion_research_chem_Molecule3D(molStart);
var molInPlace=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_Molecule3D,[molStart]);
molInPlace.ensureHelperArrays$I(7);
var liSubGraphIndices=this.subGraphExtractor.extract$com_actelion_research_chem_StereoMolecule(molInPlace);
liSubGraphIndices=C$.handleCarbonConnected2Hetero$java_util_List$com_actelion_research_chem_StereoMolecule(liSubGraphIndices, molInPlace);
var liMultCoordFragIndex=Clazz.new_($I$(7,1));
for (var subGraphIndices, $subGraphIndices = liSubGraphIndices.iterator$(); $subGraphIndices.hasNext$()&&((subGraphIndices=($subGraphIndices.next$())),1);) {
liMultCoordFragIndex.add$O(Clazz.new_([subGraphIndices.getAtomIndices$()],$I$(8,1).c$$IA));
}
C$.calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List(molStart, liMultCoordFragIndex);
var mdhv=C$.create$java_util_List$com_actelion_research_chem_Molecule3D(liMultCoordFragIndex, molStart);
return mdhv;
});

Clazz.newMeth(C$, 'generateConformerAndSetCoordinates$org_openmolecules_chem_conf_gen_ConformerGenerator$I$com_actelion_research_chem_Molecule3D',  function (conformerGenerator, nAtoms, molInPlace) {
var nextConformerAvailable=false;
var conformer=conformerGenerator.getNextConformer$();
if (conformer != null ) {
for (var i=0; i < nAtoms; i++) {
var x=conformer.getX$I(i);
var y=conformer.getY$I(i);
var z=conformer.getZ$I(i);
molInPlace.setAtomX$I$D(i, x);
molInPlace.setAtomY$I$D(i, y);
molInPlace.setAtomZ$I$D(i, z);
}
nextConformerAvailable=true;
}return nextConformerAvailable;
}, 1);

Clazz.newMeth(C$, 'calcFragmentCenter$com_actelion_research_chem_Molecule3D$java_util_List',  function (molecule3D, liMultCoordFragIndex) {
for (var multCoordFragIndex, $multCoordFragIndex = liMultCoordFragIndex.iterator$(); $multCoordFragIndex.hasNext$()&&((multCoordFragIndex=($multCoordFragIndex.next$())),1);) {
var arrAtomIndexList=multCoordFragIndex.getArrIndexFrag$();
var coordCenter=$I$(16).getCenterGravity$com_actelion_research_chem_ExtendedMolecule$IA(molecule3D, arrAtomIndexList);
multCoordFragIndex.addCoord$com_actelion_research_chem_Coordinates(coordCenter);
}
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.INSTANCE == null ) {
C$.INSTANCE=Clazz.new_(C$);
}return C$.INSTANCE;
}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 23:12:39 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
