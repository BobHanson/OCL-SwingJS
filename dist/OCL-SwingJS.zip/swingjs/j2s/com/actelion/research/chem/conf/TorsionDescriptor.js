(function(){var P$=Clazz.newPackage("com.actelion.research.chem.conf"),I$=[[0,'com.actelion.research.chem.conf.TorsionRelevanceHelper','com.actelion.research.util.Angle','StringBuilder','com.actelion.research.util.DoubleFormat']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "TorsionDescriptor", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mTorsion','float[]','+mMaxTorsion']]]

Clazz.newMeth(C$, 'c$$FA$FA',  function (torsion, maxTorsion) {
;C$.$init$.apply(this);
this.mTorsion=torsion;
this.mMaxTorsion=maxTorsion;
}, 1);

Clazz.newMeth(C$, 'equals$com_actelion_research_chem_conf_TorsionDescriptor',  function (td) {
for (var i=0; i < this.mTorsion.length; i++) {
var dif=Math.abs(this.mTorsion[i] - td.mTorsion[i]);
if (dif > 0.2617994  && dif < this.mMaxTorsion[i] - 0.2617994  ) return false;
}
return true;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_conf_TorsionDescriptor','compareTo$O'],  function (td) {
for (var i=0; i < this.mTorsion.length; i++) {
var dif=Math.abs(this.mTorsion[i] - td.mTorsion[i]);
if (dif > 0.2617994  && dif < this.mMaxTorsion[i] - 0.2617994  ) return !!((dif < this.mMaxTorsion[i] / 2 ) ^ (this.mTorsion[i] < td.mTorsion[i] )) ? 1 : -1;
}
return 0;
});

Clazz.newMeth(C$, 'getRotatableBondWeights$com_actelion_research_chem_StereoMolecule$IA',  function (mol, rotatableBond) {
return $I$(1).getRelevance$com_actelion_research_chem_StereoMolecule$IA(mol, rotatableBond);
}, 1);

Clazz.newMeth(C$, 'getDissimilarity$com_actelion_research_chem_conf_TorsionDescriptor$FA',  function (td, bondWeight) {
Clazz.assert(C$, this, function(){return (this.mTorsion.length == td.mTorsion.length)});
if (this.mTorsion.length == 0) return 0.0;
var meanAngleDiff=0.0;
var weightSum=0.0;
for (var i=0; i < this.mTorsion.length; i++) {
meanAngleDiff+=bondWeight[i] * Math.abs($I$(2).difference$D$D(this.mTorsion[i], td.mTorsion[i]));
weightSum+=bondWeight[i];
}
return meanAngleDiff / (3.1415927 * weightSum);
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(3,1));
for (var i=0; i < this.mTorsion.length; i++) {
sb.append$S(i == 0 ? "Torsions: " : ", ");
sb.append$S($I$(4).toString$D$I(this.mTorsion[i], 3) + "(" + Math.round(this.mMaxTorsion[i] + 0.5) + ")" );
}
return sb.toString();
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:03 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
