(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),p$1={},I$=[[0,'com.actelion.research.chem.reaction.FunctionalGroupClassifier','com.actelion.research.chem.descriptor.DescriptorEncoder','java.util.Arrays','com.actelion.research.chem.descriptor.DescriptorHandler','java.nio.charset.StandardCharsets','com.actelion.research.chem.descriptor.DescriptorConstants','java.util.TreeSet',['com.actelion.research.chem.descriptor.DescriptorHandlerFunctionalGroups','.Match']]],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "DescriptorHandlerFunctionalGroups", function(){
Clazz.newInstance(this, arguments,0,C$);
}, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');
C$.$classes$=[['Match',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['FAILED_OBJECT','int[][]','sDefaultInstance','com.actelion.research.chem.descriptor.DescriptorHandlerFunctionalGroups']]]

Clazz.newMeth(C$, 'getDefaultInstance$',  function () {
{
if (C$.sDefaultInstance == null ) {
C$.sDefaultInstance=Clazz.new_(C$);
}}return C$.sDefaultInstance;
}, 1);

Clazz.newMeth(C$, ['calculationFailed$IAA','calculationFailed$O'],  function (d) {
return d == null  || d.length == 1 && d[0][1] == 0  ;
});

Clazz.newMeth(C$, ['createDescriptor$com_actelion_research_chem_StereoMolecule','createDescriptor$O'],  function (mol) {
if (mol == null ) return null;
var fgc=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
return fgc.getOrganicFunctionalGroupCounts$();
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return s == null  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : Clazz.new_($I$(2,1)).decodePairs$S(s);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
return bytes == null  ? null : $I$(3,"equals$BA$BA",[bytes, $I$(4).FAILED_BYTES]) ? C$.FAILED_OBJECT : Clazz.new_($I$(2,1)).decodePairs$BA(bytes);
});

Clazz.newMeth(C$, ['encode$IAA','encode$O'],  function (d) {
return this.calculationFailed$IAA(d) ? "Calculation Failed" :  String.instantialize(Clazz.new_($I$(2,1)).encodePairs$IAA(d), $I$(5).UTF_8);
});

Clazz.newMeth(C$, 'getInfo$',  function () {
return $I$(6).DESCRIPTOR_OrganicFunctionalGroups;
});

Clazz.newMeth(C$, 'getVersion$',  function () {
return $I$(6).DESCRIPTOR_OrganicFunctionalGroups.version;
});

Clazz.newMeth(C$, ['getSimilarity$IAA$IAA','getSimilarity$O$O'],  function (dl1, dl2) {
if (dl1 == null  || dl2 == null  ) return NaN;
if (dl1.length == 0 && dl2.length == 0 ) return 1.0;
if (dl1.length == 0 || dl2.length == 0 ) return 0.0;
var matchList=Clazz.new_($I$(7,1));
var i1=0;
var i2=-1;
for (var d1, $d1 = 0, $$d1 = dl1; $d1<$$d1.length&&((d1=($$d1[$d1])),1);$d1++) {
i2=0;
for (var d2, $d2 = 0, $$d2 = dl2; $d2<$$d2.length&&((d2=($$d2[$d2])),1);$d2++) {
var matchLevel=$I$(1).getFunctionalGroupEquivalenceLevel$I$I(d1[0], d2[0]);
if (matchLevel != -1) {
for (var i=0; i < d1[1]; i++) {
for (var j=0; j < d2[1]; j++) {
matchList.add$O(Clazz.new_($I$(8,1).c$$I$I$I,[this, null, i1 + i, i2 + j, matchLevel]));
}
}
}i2+=d2[1];
}
i1+=d1[1];
}
var total=i1 + i2;
var matching=0;
var used1=Clazz.array(Boolean.TYPE, [i1]);
var used2=Clazz.array(Boolean.TYPE, [i2]);
for (var match, $match = matchList.iterator$(); $match.hasNext$()&&((match=($match.next$())),1);) {
if (!used1[match.fg1] && !used2[match.fg2] ) {
var m=1.0 - 0.1 * match.level;
matching+=m;
total-=m;
used1[match.fg1]=true;
used2[match.fg2]=true;
}}
return p$1.normalizeValue$D.apply(this, [matching / total]);
});

Clazz.newMeth(C$, 'normalizeValue$D',  function (value) {
return value <= 0.0  ? 0.0 : value >= 1.0  ? 1.0 : (1.0 - Math.pow(1 - Math.pow(value, 0.7), 1.4285714285714286));
}, p$1);

Clazz.newMeth(C$, 'getThreadSafeCopy$',  function () {
return Clazz.new_(C$);
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.array(Integer.TYPE, -2, [Clazz.array(Integer.TYPE, -1, [1, 0])]);
};
;
(function(){/*c*/var C$=Clazz.newClass(P$.DescriptorHandlerFunctionalGroups, "Match", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['fg1','fg2','level']]]

Clazz.newMeth(C$, 'c$$I$I$I',  function (fg1, fg2, level) {
;C$.$init$.apply(this);
this.fg1=fg1;
this.fg2=fg2;
this.level=level;
}, 1);

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_descriptor_DescriptorHandlerFunctionalGroups_Match','compareTo$O'],  function (o) {
if (this.level != o.level) return (this.level < o.level) ? -1 : 1;
var v=(this.fg1 < this.fg2) ? (this.fg1 << 10) + this.fg2 : (this.fg2 << 10) + this.fg1;
var ov=(o.fg1 < o.fg2) ? (o.fg1 << 10) + o.fg2 : (o.fg2 << 10) + o.fg1;
return (v < ov) ? -1 : (v > ov) ? 1 : 0;
});

Clazz.newMeth(C$);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
