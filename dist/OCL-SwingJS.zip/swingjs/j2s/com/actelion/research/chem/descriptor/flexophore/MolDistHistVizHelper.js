(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.descriptor.flexophore.MolDistHistViz','java.util.ArrayList','com.actelion.research.chem.descriptor.flexophore.generator.MultCoordFragIndex','com.actelion.research.chem.Molecule3D','com.actelion.research.util.ArrayUtils']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MolDistHistVizHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'centerNodes$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var barycenter=C$.getBarycenter$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz(mdhv);
for (var i=0; i < mdhv.getNumPPNodes$(); i++) {
var node=mdhv.getNode$I(i);
node.getCoordinates$().x-=barycenter.x;
node.getCoordinates$().y-=barycenter.y;
node.getCoordinates$().z-=barycenter.z;
}
var m=mdhv.getMolecule$();
var arrCoordinates=m.getCoordinates$();
for (var i=0; i < arrCoordinates.length; i++) {
var c=arrCoordinates[i];
c.x-=barycenter.x;
c.y-=barycenter.y;
c.z-=barycenter.z;
m.setCoordinates$I$com_actelion_research_chem_Coordinates(i, c);
}
}, 1);

Clazz.newMeth(C$, 'getBarycenter$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz',  function (mdhv) {
var arrCoordinates=Clazz.array($I$(1), [mdhv.getNumPPNodes$()]);
for (var i=0; i < mdhv.getNumPPNodes$(); i++) {
var node=mdhv.getNode$I(i);
arrCoordinates[i]=node.getCoordinates$();
}
return $I$(1).createBarycenter$com_actelion_research_chem_CoordinatesA(arrCoordinates);
}, 1);

Clazz.newMeth(C$, 'create$java_util_List',  function (liPPNodeVizMultCoord) {
var molDistHistViz=Clazz.new_([liPPNodeVizMultCoord.size$(), null],$I$(2,1).c$$I$com_actelion_research_chem_Molecule3D);
var liPPNodeViz=Clazz.new_($I$(3,1));
for (var ppNodeViz, $ppNodeViz = liPPNodeVizMultCoord.iterator$(); $ppNodeViz.hasNext$()&&((ppNodeViz=($ppNodeViz.next$())),1);) {
liPPNodeViz.add$O(ppNodeViz);
}
molDistHistViz.set$java_util_List(liPPNodeViz);
for (var i=0; i < liPPNodeVizMultCoord.size$(); i++) {
for (var j=i + 1; j < liPPNodeVizMultCoord.size$(); j++) {
var arrDistHist=$I$(4,"getDistHist$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex$com_actelion_research_chem_descriptor_flexophore_generator_MultCoordFragIndex",[liPPNodeVizMultCoord.get$I(i).multCoordFragIndex, liPPNodeVizMultCoord.get$I(j).multCoordFragIndex]);
molDistHistViz.setDistHist$I$I$BA(i, j, arrDistHist);
}
}
molDistHistViz.realize$();
return molDistHistViz;
}, 1);

Clazz.newMeth(C$, 'setWeights$com_actelion_research_chem_descriptor_flexophore_MolDistHistViz$IA',  function (mdhv, arrWeightLabel) {
var m3D=Clazz.new_([mdhv.getMolecule$()],$I$(5,1).c$$com_actelion_research_chem_Molecule3D);
m3D.ensureHelperArrays$I(7);
m3D.stripSmallFragments$();
if (m3D.getAtoms$() != arrWeightLabel.length) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Weight vector differs in dimension to number of atoms!"]);
}for (var ppNodeViz, $ppNodeViz = mdhv.getNodes$().iterator$(); $ppNodeViz.hasNext$()&&((ppNodeViz=($ppNodeViz.next$())),1);) {
var a=ppNodeViz.getArrayIndexOriginalAtoms$();
var w=Clazz.array(Integer.TYPE, [a.length]);
for (var i=0; i < a.length; i++) {
w[i]=arrWeightLabel[a[i]];
}
var maxWeightLabel=$I$(6).max$IA(w);
if (maxWeightLabel < 2) {
maxWeightLabel=$I$(6).min$IA(w);
}if (3 == maxWeightLabel) {
mdhv.addMandatoryPharmacophorePoint$I(ppNodeViz.getIndex$());
mdhv.setNodeWeight$I$D(ppNodeViz.getIndex$(), 2.5);
} else if (2 == maxWeightLabel) {
mdhv.addMandatoryPharmacophorePoint$I(ppNodeViz.getIndex$());
mdhv.setNodeWeight$I$D(ppNodeViz.getIndex$(), 2.0);
} else if (0 == maxWeightLabel) {
mdhv.setNodeWeight$I$D(ppNodeViz.getIndex$(), 0.5);
}}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:04 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
