(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'java.util.ArrayList','java.util.Collections','com.actelion.research.chem.io.pdb.parser.StructureAssembler','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PDBCoordEntryFile");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['end'],'S',['classification','pdbID','obsolete','title','split','caveat','compound','source','keywords','model','resolution','expdata','nummdl','mdltyp','author','sprsde','cryst1','origX1','origX2','origX3','scale1','scale2','scale3','master'],'O',['dateDeposition','java.util.Date','liRevdat','java.util.List','+liJRNL','hmNo_Remark','java.util.HashMap','liDBRef','java.util.List','+liDBRef1DBRef2','+liSEQADV','+liSEQRES','+liModRes','+liHet','hmId_Name','java.util.HashMap','+hmId_Synonyms','+hmId_Formula','liHelix','java.util.List','+liSheet','+liSSBond','+liLink','+liCisPep','hmId_Site','java.util.HashMap','liMtrix1','java.util.List','+liMtrix2','+liMtrix3','+protAtomRecords','+hetAtomRecords','liConnect','com.actelion.research.util.SortedList']]]

Clazz.newMeth(C$, 'getClassification$',  function () {
return this.classification;
});

Clazz.newMeth(C$, 'setClassification$S',  function (classification) {
this.classification=classification;
});

Clazz.newMeth(C$, 'getID$',  function () {
return this.pdbID;
});

Clazz.newMeth(C$, 'setID$S',  function (pdbID) {
this.pdbID=pdbID;
});

Clazz.newMeth(C$, 'getDateDeposition$',  function () {
return this.dateDeposition;
});

Clazz.newMeth(C$, 'setDateDeposition$java_util_Date',  function (dateDeposition) {
this.dateDeposition=dateDeposition;
});

Clazz.newMeth(C$, 'getTitle$',  function () {
return this.title;
});

Clazz.newMeth(C$, 'setTitle$S',  function (title) {
this.title=title;
});

Clazz.newMeth(C$, 'getProtAtomRecords$',  function () {
return this.protAtomRecords;
});

Clazz.newMeth(C$, 'setProtAtomRecords$java_util_List',  function (protAtomRecords) {
this.protAtomRecords=protAtomRecords;
});

Clazz.newMeth(C$, 'getHetAtomRecords$',  function () {
return this.hetAtomRecords;
});

Clazz.newMeth(C$, 'setHetAtomRecords$java_util_List',  function (hetAtomRecords) {
this.hetAtomRecords=hetAtomRecords;
});

Clazz.newMeth(C$, 'getObsolete$',  function () {
return this.obsolete;
});

Clazz.newMeth(C$, 'setObsolete$S',  function (obsolete) {
this.obsolete=obsolete;
});

Clazz.newMeth(C$, 'getSplit$',  function () {
return this.split;
});

Clazz.newMeth(C$, 'setSplit$S',  function (split) {
this.split=split;
});

Clazz.newMeth(C$, 'getCaveat$',  function () {
return this.caveat;
});

Clazz.newMeth(C$, 'setCaveat$S',  function (caveat) {
this.caveat=caveat;
});

Clazz.newMeth(C$, 'getCompound$',  function () {
return this.compound;
});

Clazz.newMeth(C$, 'setCompound$S',  function (compound) {
this.compound=compound;
});

Clazz.newMeth(C$, 'getSource$',  function () {
return this.source;
});

Clazz.newMeth(C$, 'setSource$S',  function (source) {
this.source=source;
});

Clazz.newMeth(C$, 'getKeywords$',  function () {
return this.keywords;
});

Clazz.newMeth(C$, 'setKeywords$S',  function (keywords) {
this.keywords=keywords;
});

Clazz.newMeth(C$, 'getExpdata$',  function () {
return this.expdata;
});

Clazz.newMeth(C$, 'setExpdata$S',  function (expdata) {
this.expdata=expdata;
});

Clazz.newMeth(C$, 'getNummdl$',  function () {
return this.nummdl;
});

Clazz.newMeth(C$, 'setNummdl$S',  function (nummdl) {
this.nummdl=nummdl;
});

Clazz.newMeth(C$, 'getMdltyp$',  function () {
return this.mdltyp;
});

Clazz.newMeth(C$, 'setMdltyp$S',  function (mdltyp) {
this.mdltyp=mdltyp;
});

Clazz.newMeth(C$, 'getModel$',  function () {
return this.model;
});

Clazz.newMeth(C$, 'setModel$S',  function (model) {
this.model=model;
});

Clazz.newMeth(C$, 'getResolution$',  function () {
return this.resolution;
});

Clazz.newMeth(C$, 'setResolution$S',  function (resolution) {
this.resolution=resolution;
});

Clazz.newMeth(C$, 'getAuthor$',  function () {
return this.author;
});

Clazz.newMeth(C$, 'setAuthor$S',  function (author) {
this.author=author;
});

Clazz.newMeth(C$, 'getRevdat$',  function () {
return this.liRevdat;
});

Clazz.newMeth(C$, 'setRevdat$java_util_List',  function (liRevdat) {
this.liRevdat=liRevdat;
});

Clazz.newMeth(C$, 'getSprsde$',  function () {
return this.sprsde;
});

Clazz.newMeth(C$, 'setSprsde$S',  function (sprsde) {
this.sprsde=sprsde;
});

Clazz.newMeth(C$, 'getJrnl$',  function () {
return this.liJRNL;
});

Clazz.newMeth(C$, 'setJrnl$java_util_List',  function (jrnl) {
this.liJRNL=jrnl;
});

Clazz.newMeth(C$, 'getRemark0$',  function () {
return this.hmNo_Remark.get$O(Integer.valueOf$I(0));
});

Clazz.newMeth(C$, 'getRemark1$',  function () {
return this.hmNo_Remark.get$O(Integer.valueOf$I(1));
});

Clazz.newMeth(C$, 'getRemark2$',  function () {
return this.hmNo_Remark.get$O(Integer.valueOf$I(2));
});

Clazz.newMeth(C$, 'getRemark3$',  function () {
return this.hmNo_Remark.get$O(Integer.valueOf$I(3));
});

Clazz.newMeth(C$, 'setRemarks$java_util_HashMap',  function (hmNo_Remark) {
this.hmNo_Remark=hmNo_Remark;
});

Clazz.newMeth(C$, 'getRemark$I',  function (n) {
return this.hmNo_Remark.get$O(Integer.valueOf$I(n));
});

Clazz.newMeth(C$, 'getRemarks$',  function () {
var liRemarkNo=Clazz.new_([this.hmNo_Remark.keySet$()],$I$(1,1).c$$java_util_Collection);
$I$(2).sort$java_util_List(liRemarkNo);
return liRemarkNo;
});

Clazz.newMeth(C$, 'getDBRef$',  function () {
return this.liDBRef;
});

Clazz.newMeth(C$, 'setDBRef$java_util_List',  function (liDBRef) {
this.liDBRef=liDBRef;
});

Clazz.newMeth(C$, 'getDBRef1DBRef2$',  function () {
return this.liDBRef1DBRef2;
});

Clazz.newMeth(C$, 'setDBRef1DBRef2$java_util_List',  function (liDBRef1DBRef2) {
this.liDBRef1DBRef2=liDBRef1DBRef2;
});

Clazz.newMeth(C$, 'getSEQADV$',  function () {
return this.liSEQADV;
});

Clazz.newMeth(C$, 'setSEQADV$java_util_List',  function (liSEQADV) {
this.liSEQADV=liSEQADV;
});

Clazz.newMeth(C$, 'getSEQRES$',  function () {
return this.liSEQRES;
});

Clazz.newMeth(C$, 'setSEQRES$java_util_List',  function (liSEQRES) {
this.liSEQRES=liSEQRES;
});

Clazz.newMeth(C$, 'getModRes$',  function () {
return this.liModRes;
});

Clazz.newMeth(C$, 'setModRes$java_util_List',  function (liModRes) {
this.liModRes=liModRes;
});

Clazz.newMeth(C$, 'getHet$',  function () {
return this.liHet;
});

Clazz.newMeth(C$, 'setHet$java_util_List',  function (liHet) {
this.liHet=liHet;
});

Clazz.newMeth(C$, 'getHmId_Name$',  function () {
return this.hmId_Name;
});

Clazz.newMeth(C$, 'setHmId_Name$java_util_HashMap',  function (hmId_Name) {
this.hmId_Name=hmId_Name;
});

Clazz.newMeth(C$, 'getNameIDs$',  function () {
var li=Clazz.new_([this.hmId_Name.keySet$()],$I$(1,1).c$$java_util_Collection);
$I$(2).sort$java_util_List(li);
return li;
});

Clazz.newMeth(C$, 'getName$S',  function (nameId) {
return this.hmId_Name.get$O(nameId);
});

Clazz.newMeth(C$, 'setHmId_Synonyms$java_util_HashMap',  function (hm) {
this.hmId_Synonyms=hm;
});

Clazz.newMeth(C$, 'getSynonymIDs$',  function () {
var li=Clazz.new_([this.hmId_Synonyms.keySet$()],$I$(1,1).c$$java_util_Collection);
$I$(2).sort$java_util_List(li);
return li;
});

Clazz.newMeth(C$, 'getSynonyms$S',  function (synonymId) {
return this.hmId_Synonyms.get$O(synonymId);
});

Clazz.newMeth(C$, 'setHmId_Formula$java_util_HashMap',  function (hm) {
this.hmId_Formula=hm;
});

Clazz.newMeth(C$, 'getFormulaIDs$',  function () {
var li=Clazz.new_([this.hmId_Formula.keySet$()],$I$(1,1).c$$java_util_Collection);
$I$(2).sort$java_util_List(li);
return li;
});

Clazz.newMeth(C$, 'getFormula$S',  function (formulaId) {
return this.hmId_Formula.get$O(formulaId);
});

Clazz.newMeth(C$, 'getHelix$',  function () {
return this.liHelix;
});

Clazz.newMeth(C$, 'setHelix$java_util_List',  function (liHelix) {
this.liHelix=liHelix;
});

Clazz.newMeth(C$, 'getSheet$',  function () {
return this.liSheet;
});

Clazz.newMeth(C$, 'setSheet$java_util_List',  function (liSheet) {
this.liSheet=liSheet;
});

Clazz.newMeth(C$, 'getSSBond$',  function () {
return this.liSSBond;
});

Clazz.newMeth(C$, 'setSSBond$java_util_List',  function (liSSBond) {
this.liSSBond=liSSBond;
});

Clazz.newMeth(C$, 'getLink$',  function () {
return this.liLink;
});

Clazz.newMeth(C$, 'setLink$java_util_List',  function (liLink) {
this.liLink=liLink;
});

Clazz.newMeth(C$, 'getCisPep$',  function () {
return this.liCisPep;
});

Clazz.newMeth(C$, 'setCisPep$java_util_List',  function (liCisPep) {
this.liCisPep=liCisPep;
});

Clazz.newMeth(C$, 'setHmId_Site$java_util_HashMap',  function (hm) {
this.hmId_Site=hm;
});

Clazz.newMeth(C$, 'getSiteIDs$',  function () {
var li=Clazz.new_([this.hmId_Site.keySet$()],$I$(1,1).c$$java_util_Collection);
$I$(2).sort$java_util_List(li);
return li;
});

Clazz.newMeth(C$, 'getSite$S',  function (id) {
return this.hmId_Site.get$O(id);
});

Clazz.newMeth(C$, 'getCryst1$',  function () {
return this.cryst1;
});

Clazz.newMeth(C$, 'setCryst1$S',  function (cryst1) {
this.cryst1=cryst1;
});

Clazz.newMeth(C$, 'getOrigX1$',  function () {
return this.origX1;
});

Clazz.newMeth(C$, 'setOrigX1$S',  function (origX1) {
this.origX1=origX1;
});

Clazz.newMeth(C$, 'getOrigX2$',  function () {
return this.origX2;
});

Clazz.newMeth(C$, 'setOrigX2$S',  function (origX2) {
this.origX2=origX2;
});

Clazz.newMeth(C$, 'getOrigX3$',  function () {
return this.origX3;
});

Clazz.newMeth(C$, 'setOrigX3$S',  function (origX3) {
this.origX3=origX3;
});

Clazz.newMeth(C$, 'getScale1$',  function () {
return this.scale1;
});

Clazz.newMeth(C$, 'setScale1$S',  function (scale1) {
this.scale1=scale1;
});

Clazz.newMeth(C$, 'getScale2$',  function () {
return this.scale2;
});

Clazz.newMeth(C$, 'setScale2$S',  function (scale2) {
this.scale2=scale2;
});

Clazz.newMeth(C$, 'getScale3$',  function () {
return this.scale3;
});

Clazz.newMeth(C$, 'setScale3$S',  function (scale3) {
this.scale3=scale3;
});

Clazz.newMeth(C$, 'getMtrix1$',  function () {
return this.liMtrix1;
});

Clazz.newMeth(C$, 'setMtrix1$java_util_List',  function (liMtrix1) {
this.liMtrix1=liMtrix1;
});

Clazz.newMeth(C$, 'getMtrix2$',  function () {
return this.liMtrix2;
});

Clazz.newMeth(C$, 'setMtrix2$java_util_List',  function (liMtrix2) {
this.liMtrix2=liMtrix2;
});

Clazz.newMeth(C$, 'getMtrix3$',  function () {
return this.liMtrix3;
});

Clazz.newMeth(C$, 'setMtrix3$java_util_List',  function (liMtrix3) {
this.liMtrix3=liMtrix3;
});

Clazz.newMeth(C$, 'getLiConnect$',  function () {
return this.liConnect;
});

Clazz.newMeth(C$, 'setLiConnect$com_actelion_research_util_SortedList',  function (liConnect) {
this.liConnect=liConnect;
});

Clazz.newMeth(C$, 'getMaster$',  function () {
return this.master;
});

Clazz.newMeth(C$, 'setMaster$S',  function (master) {
this.master=master;
});

Clazz.newMeth(C$, 'isEnd$',  function () {
return this.end;
});

Clazz.newMeth(C$, 'setEnd$Z',  function (end) {
this.end=end;
});

Clazz.newMeth(C$, 'extractMols$',  function () {
return this.extractMols$Z(false);
});

Clazz.newMeth(C$, 'extractMols$Z',  function (detachCovalentLigands) {
var assembler=Clazz.new_($I$(3,1).c$$com_actelion_research_util_SortedList$java_util_List$java_util_List,[this.liConnect, this.protAtomRecords, this.hetAtomRecords]);
assembler.setDetachCovalentLigands$Z(detachCovalentLigands);
return assembler.assemble$();
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(4,1).c$$S,["PDBCoordEntryFile{"]);
sb.append$S("classification=\'").append$S(this.classification).append$C("\'");
sb.append$S(", pdbID\'").append$S(this.pdbID).append$C("\'");
sb.append$S(", dateDeposition=").append$O(this.dateDeposition);
sb.append$S(", obsolete=\'").append$S(this.obsolete).append$C("\'");
sb.append$S(", title=\'").append$S(this.title).append$C("\'");
sb.append$S(", split=\'").append$S(this.split).append$C("\'");
sb.append$S(", caveat=\'").append$S(this.caveat).append$C("\'");
sb.append$S(", compound=\'").append$S(this.compound).append$C("\'");
sb.append$S(", source=\'").append$S(this.source).append$C("\'");
sb.append$S(", keywords=\'").append$S(this.keywords).append$C("\'");
sb.append$S(", expdata=\'").append$S(this.expdata).append$C("\'");
sb.append$S(", nummdl=\'").append$S(this.nummdl).append$C("\'");
sb.append$S(", mdltyp=\'").append$S(this.mdltyp).append$C("\'");
sb.append$S(", author=\'").append$S(this.author).append$C("\'");
sb.append$S(", revdat=\'").append$O(this.liRevdat).append$C("\'");
sb.append$S(", sprsde=\'").append$S(this.sprsde).append$C("\'");
sb.append$S(", jrnl=\'").append$O(this.liJRNL).append$C("\'");
var liKeyRemark=this.getRemarks$();
for (var key, $key = liKeyRemark.iterator$(); $key.hasNext$()&&((key=($key.next$()).intValue$()),1);) {
var s=this.getRemark$I(key);
sb.append$S(", remark");
sb.append$I(key);
sb.append$S("=\'").append$S(s).append$C("\'");
;}
sb.append$C("}");
return sb.toString();
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 21:29:22 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
