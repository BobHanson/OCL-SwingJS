(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore.generator"),I$=[[0,'com.actelion.research.chem.descriptor.flexophore.MolDistHist','com.actelion.research.chem.descriptor.flexophore.PPNode']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SubFlexophoreExtractorHelper");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getSubFragment$com_actelion_research_chem_descriptor_flexophore_MolDistHist$IA',  function (mdh, arrIndices) {
var frag=Clazz.new_($I$(1,1).c$$I,[arrIndices.length]);
for (var i=0; i < arrIndices.length; i++) {
var node=Clazz.new_([mdh.getNode$I(arrIndices[i])],$I$(2,1).c$$com_actelion_research_chem_descriptor_flexophore_PPNode);
frag.addNode$com_actelion_research_chem_descriptor_flexophore_PPNode(node);
}
for (var i=0; i < arrIndices.length; i++) {
for (var j=i + 1; j < arrIndices.length; j++) {
var arrHist=mdh.getDistHist$I$I(arrIndices[i], arrIndices[j]);
frag.setDistHist$I$I$BA(i, j, arrHist);
}
}
frag.realize$();
return frag;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-24 09:22:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
