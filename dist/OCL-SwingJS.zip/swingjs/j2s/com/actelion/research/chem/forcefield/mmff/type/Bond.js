(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.type"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "Bond");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (table, mol, bond) {
return C$.getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(table, mol, mol.getBondAtom$I$I(0, bond), mol.getBondAtom$I$I(1, bond));
}, 1);

Clazz.newMeth(C$, 'getType$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (table, mol, atom1, atom2) {
var a1t=mol.getAtomType$I(atom1);
var a2t=mol.getAtomType$I(atom2);
var bond=mol.getBond$I$I(atom1, atom2);
var notInAromaticRing=true;
var rings=mol.getRingSet$();
for (var r=0; r < rings.getSize$() && notInAromaticRing ; r++) {
for (var b, $b = 0, $$b = rings.getRingBonds$I(r); $b<$$b.length&&((b=($$b[$b])),1);$b++) {
if (b == bond && mol.ringIsMMFFAromatic$I(r) ) {
notInAromaticRing=false;
break;
}}
}
return (mol.getBondOrder$I(bond) == 1) && notInAromaticRing && (table.atom.arom$I(a1t) && table.atom.arom$I(a2t)  || table.atom.sbmb$I(a1t) && table.atom.sbmb$I(a2t)  )   ? 1 : 0;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 18:06:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
