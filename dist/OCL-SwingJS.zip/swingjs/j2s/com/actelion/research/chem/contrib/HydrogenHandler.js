(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.Molecule']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "HydrogenHandler");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['D',['cos30','sin30','cos330','sin330','cos60','sin60','cos300','sin300','cos45','sin45','cos315','sin315']]]

Clazz.newMeth(C$, 'addImplicitHydrogens$com_actelion_research_chem_StereoMolecule$I',  function (molecule, iAtom) {
var atomicNo=1;
var nHydrogens=molecule.getImplicitHydrogens$I(iAtom);
var x=molecule.getAtomX$I(iAtom);
var y=molecule.getAtomY$I(iAtom);
switch (nHydrogens) {
case 1:
{
var nNeighbours=molecule.getConnAtoms$I(iAtom);
var dx;
var dy;
var iNew;
if (nNeighbours == 0) {
var distMin=1.7976931348623157E308;
var iMin=-1;
for (var atm=0; atm < molecule.getAllAtoms$(); atm++) {
if (atm == iAtom) continue;
var deltaX=x - molecule.getAtomX$I(atm);
var deltaY=y - molecule.getAtomY$I(atm);
var currDist=Math.sqrt((deltaX * deltaX) + (deltaY * deltaY));
if (distMin > currDist ) {
distMin=currDist;
iMin=atm;
}}
dx=x - molecule.getAtomX$I(iMin);
dy=y - molecule.getAtomY$I(iMin);
} else {
dx=x - molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0));
dy=y - molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0));
}if (nNeighbours == 1) {
iNew=molecule.addAtom$D$D((x + C$.cos45 * dx + C$.sin45 * dy), (y - C$.sin45 * dx + C$.cos45 * dy));
} else if (nNeighbours == 2) {
dx=x - 0.5 * (molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1)));
dy=y - 0.5 * (molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1)));
iNew=molecule.addAtom$D$D((x + dx), (y + dy));
} else if (nNeighbours == 3) {
var stereoAtom1=molecule.getConnAtom$I$I(iAtom, 0);
for (var i=1; i < 3; i++) {
var bond=molecule.getConnBond$I$I(iAtom, i);
if ((molecule.getBondType$I(bond) == 129) || (molecule.getBondType$I(bond) == 257) ) {
stereoAtom1=molecule.getConnAtom$I$I(iAtom, i);
}}
var angle1=Math.abs($I$(1,"getAngleDif$D$D",[$I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0))]), $I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1))])]));
var angle2=Math.abs($I$(1,"getAngleDif$D$D",[$I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0))]), $I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 2)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 2))])]));
var angle3=Math.abs($I$(1,"getAngleDif$D$D",[$I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1))]), $I$(1,"getAngle$D$D$D$D",[molecule.getAtomX$I(iAtom), molecule.getAtomY$I(iAtom), molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 2)), molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 2))])]));
var normal=true;
if ((angle1 > angle2 ) && (angle1 > angle3 ) ) {
if ((angle2 + angle3) < 3.141592653589793 ) {
normal=false;
dx=x - 0.5 * (molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1)));
dy=y - 0.5 * (molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1)));
}} else if ((angle2 > angle1 ) && (angle2 > angle3 ) ) {
if ((angle1 + angle3) < 3.141592653589793 ) {
normal=false;
dx=x - 0.5 * (molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 2)));
dy=y - 0.5 * (molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0)) + molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 2)));
}} else {
if ((angle1 + angle2) < 3.141592653589793 ) {
normal=false;
dx=x - 0.5 * (molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1)) + molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 2)));
dy=y - 0.5 * (molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1)) + molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 2)));
}}if (normal) {
var stereoAtom2=molecule.getConnAtom$I$I(iAtom, 0);
var distance=1.7976931348623157E308;
for (var i=0; i < 3; i++) {
var atom=molecule.getConnAtom$I$I(iAtom, i);
if (atom != stereoAtom1) {
var currentDistance=Math.pow(molecule.getAtomX$I(iAtom) - molecule.getAtomX$I(atom), 2) + Math.pow(molecule.getAtomY$I(iAtom) - molecule.getAtomY$I(atom), 2);
if (currentDistance < distance ) {
stereoAtom2=atom;
distance=currentDistance;
System.out.println$S("Minimal distance: " + stereoAtom1 + " - " + stereoAtom2 + " - " + new Double(distance).toString() + " - " + molecule.getAtomicNo$I(stereoAtom2) );
}}}
iNew=molecule.addAtom$D$D((molecule.getAtomX$I(stereoAtom1) + molecule.getAtomX$I(stereoAtom2)) / 2, (molecule.getAtomY$I(stereoAtom1) + molecule.getAtomY$I(stereoAtom2)) / 2);
} else {
iNew=molecule.addAtom$D$D((x + dx), (y + dy));
}} else {
iNew=molecule.addAtom$D$D((x + dx), (y + dy));
}molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
}break;
case 2:
var nNeighbours=molecule.getConnAtoms$I(iAtom);
if (nNeighbours == 1) {
var dx=x - molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0));
var dy=y - molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0));
var iNew;
iNew=molecule.addAtom$D$D((x + (C$.cos60 * dx - C$.sin60 * dy) * 0.7), (y + (C$.sin60 * dx + C$.cos60 * dy) * 0.7));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
iNew=molecule.addAtom$D$D((x + (C$.cos300 * dx - C$.sin300 * dy) * 0.7), (y + (C$.sin300 * dx + C$.cos300 * dy) * 0.7));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
} else if (nNeighbours == 2) {
var iNew;
var dx1=x - molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0));
var dy1=y - molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0));
var dx2=x - molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 1));
var dy2=y - molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 1));
var length1=Math.sqrt(dx1 * dx1 + dy1 * dy1) * 0.7;
var length2=Math.sqrt(dx2 * dx2 + dy2 * dy2) * 0.7;
var dx=dx1 + dx2;
var dy=dy1 + dy2;
var length=Math.sqrt(dx * dx + dy * dy);
var averageLength=(length1 + length2) / 2;
dx=dx / length * averageLength;
dy=dy / length * averageLength;
var stereoBond=molecule.getStereoBond$I(iAtom);
iNew=molecule.addAtom$D$D((x + C$.cos30 * dx - C$.sin30 * dy), (y + C$.sin30 * dx + C$.cos30 * dy));
molecule.setAtomicNo$I$I(iNew, 1);
if (stereoBond > -1) {
molecule.addBond$I$I$I(iAtom, iNew, 1);
} else {
molecule.addBond$I$I$I(iAtom, iNew, 257);
}iNew=molecule.addAtom$D$D((x + C$.cos330 * dx - C$.sin330 * dy), (y + C$.sin330 * dx + C$.cos330 * dy));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
} else {
for (var iHydrogen=0; iHydrogen < nHydrogens; iHydrogen++) {
var iNew=molecule.addAtom$D$D(x, y);
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
}
}break;
case 3:
{
var iNew;
var dx;
var dy;
if (molecule.getConnAtoms$I(iAtom) > 0) {
dx=(x - molecule.getAtomX$I(molecule.getConnAtom$I$I(iAtom, 0))) * 0.7;
dy=(y - molecule.getAtomY$I(molecule.getConnAtom$I$I(iAtom, 0))) * 0.7;
iNew=molecule.addAtom$D$D((x + dx), (y + dy));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
iNew=molecule.addAtom$D$D((x - dy), (y + dx));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
iNew=molecule.addAtom$D$D((x + dy), (y - dx));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
} else {
dx=molecule.getAverageBondLength$Z(true);
dy=molecule.getAverageBondLength$Z(true);
iNew=molecule.addAtom$D$D((x + dx), (y + dy));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
iNew=molecule.addAtom$D$D((x - dy * C$.cos60), (y + dx * C$.sin60));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
iNew=molecule.addAtom$D$D((x - dy * C$.cos60), (y - dx * C$.sin60));
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
}}break;
default:
{
for (var iHydrogen=0; iHydrogen < nHydrogens; iHydrogen++) {
var iNew=molecule.addAtom$D$D(x, y);
molecule.setAtomicNo$I$I(iNew, 1);
molecule.addBond$I$I$I(iAtom, iNew, 1);
}
break;
}}
}, 1);

Clazz.newMeth(C$, 'addImplicitHydrogens$com_actelion_research_chem_StereoMolecule',  function (molecule) {
molecule.ensureHelperArrays$I(1);
var nAtomsBefore=molecule.getAtoms$();
for (var iAtom=0; iAtom < nAtomsBefore; iAtom++) {
C$.addImplicitHydrogens$com_actelion_research_chem_StereoMolecule$I(molecule, iAtom);
}
}, 1);

Clazz.newMeth(C$, 'getNumberOfHydrogens$com_actelion_research_chem_StereoMolecule',  function (molecule) {
molecule.ensureHelperArrays$I(1);
var nbHydrogens=0;
for (var iAtom=0; iAtom < molecule.getAllAtoms$(); iAtom++) {
if (molecule.getAtomicNo$I(iAtom) == 1) ++nbHydrogens;
 else nbHydrogens+=molecule.getPlainHydrogens$I(iAtom);
}
return nbHydrogens;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.cos30=Math.cos(0.5235987755982988);
C$.sin30=Math.sin(0.5235987755982988);
C$.cos330=Math.cos(-0.5235987755982988);
C$.sin330=Math.sin(-0.5235987755982988);
C$.cos60=Math.cos(1.0471975511965976);
C$.sin60=Math.sin(1.0471975511965976);
C$.cos300=Math.cos(-1.0471975511965976);
C$.sin300=Math.sin(-1.0471975511965976);
C$.cos45=Math.cos(0.7853981633974483);
C$.sin45=Math.sin(0.7853981633974483);
C$.cos315=Math.cos(-0.7853981633974483);
C$.sin315=Math.sin(-0.7853981633974483);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:13 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
