(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondStretch", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['kb','r0'],'I',['a1','a2']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I',  function (table, mol, bond) {
C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I.apply(this, [table, mol, mol.getBondAtom$I$I(0, bond), mol.getBondAtom$I$I(1, bond)]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I',  function (table, mol, a1, a2) {
;C$.$init$.apply(this);
this.a1=a1;
this.a2=a2;
this.r0=table.bond.r0$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a1, a2);
this.kb=table.bond.kb$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I(mol, a1, a2);
}, 1);

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var c1=143.9325;
var cs=-2.0;
var c3=0.5833333333333334;
var dist=Clazz.new_($I$(1,1).c$$DA$I,[pos, this.a1]).distance$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_($I$(1,1).c$$DA$I,[pos, this.a2]));
var diff=(dist - this.r0) * (dist - this.r0);
return (0.5 * 143.9325 * this.kb * diff * (1.0 + -2.0 * (dist - this.r0) + 0.5833333333333334 * -2.0 * -2.0 * diff ) );
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var cs=-2.0;
var c1=143.9325;
var c3=0.5833333333333334;
var dist=Clazz.new_($I$(1,1).c$$DA$I,[pos, this.a1]).distance$com_actelion_research_chem_forcefield_mmff_Vector3(Clazz.new_($I$(1,1).c$$DA$I,[pos, this.a2]));
var distTerm=dist - this.r0;
var dE_dr=143.9325 * this.kb * distTerm * (1.0 + 1.5 * -2.0 * distTerm  + 2.0 * 0.5833333333333334 * -2.0 * -2.0 * distTerm * distTerm ) ;
if (dist > 0.0 ) {
for (var i=0; i < 3; i++) {
grad[3 * this.a1 + i]+=dE_dr * (pos[3 * this.a1 + i] - pos[3 * this.a2 + i]) / dist;
grad[3 * this.a2 + i]-=dE_dr * (pos[3 * this.a1 + i] - pos[3 * this.a2 + i]) / dist;
}
}});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (t, mol) {
var bstretches=Clazz.new_($I$(2,1));
for (var b=0; b < mol.getAllBonds$(); b++) bstretches.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I,[t, mol, b]));

return bstretches;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
