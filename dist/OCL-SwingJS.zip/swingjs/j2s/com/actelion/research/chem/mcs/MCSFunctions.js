(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),I$=[[0,'com.actelion.research.chem.mcs.MCS','com.actelion.research.chem.StereoMolecule','java.util.ArrayList']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MCSFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mcs','com.actelion.research.chem.mcs.MCS']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mcs=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'getRemainingStructure$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (molProduct, molEduct1) {
var arrBondProduct=Clazz.array(Boolean.TYPE, [molProduct.getBonds$()]);
var arrBondReactant2=null;
this.mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(molProduct, molEduct1);
this.mcs.getMCSBondArray$ZA$ZA(arrBondProduct, arrBondReactant2);
var molRemainingSubstituent=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Molecule,[molProduct]);
molRemainingSubstituent.ensureHelperArrays$I(7);
var arrBondProductInverse=Clazz.array(Boolean.TYPE, [molProduct.getBonds$()]);
for (var i=0; i < arrBondProduct.length; i++) {
if (!arrBondProduct[i]) {
arrBondProductInverse[i]=true;
}}
molProduct.copyMoleculeByBonds$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(molRemainingSubstituent, arrBondProductInverse, true, null);
molRemainingSubstituent.ensureHelperArrays$I(7);
return molRemainingSubstituent;
});

Clazz.newMeth(C$, 'getMaximumCommonSubstructure$java_util_List',  function (li) {
var molMCS=li.get$I(0);
var liMCS=Clazz.new_($I$(3,1));
liMCS.add$O(molMCS);
for (var i=1; i < li.size$(); i++) {
var mol=li.get$I(i);
this.mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol, molMCS);
molMCS=this.mcs.getMCS$();
if (molMCS == null ) {
System.err.println$S("No common substructure found. break!");
}}
return molMCS;
});

Clazz.newMeth(C$, 'getScore$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (mol, frag) {
this.mcs.set$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule(mol, frag);
if (this.mcs.getMCS$() == null ) {
return 0;
}return this.mcs.getScore$();
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:18 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
