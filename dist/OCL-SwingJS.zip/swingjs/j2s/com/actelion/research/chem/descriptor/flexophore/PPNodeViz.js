(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),p$1={},I$=[[0,'com.actelion.research.chem.descriptor.flexophore.PPNode','com.actelion.research.chem.Coordinates','java.util.HashSet','java.util.ArrayList','com.actelion.research.util.ArrayUtils','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PPNodeViz", null, 'com.actelion.research.chem.descriptor.flexophore.PPNode', 'java.io.Serializable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['marked'],'B',['index'],'F',['similarityMappingNodes'],'I',['mappingIndex','indexSphereViz'],'O',['hsIndexOriginalAtoms','java.util.HashSet','coordinates','com.actelion.research.chem.Coordinates']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_PPNode.apply(this,[Clazz.new_($I$(1,1))]);C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (node) {
Clazz.super_(C$, this);
this.copy$com_actelion_research_chem_descriptor_flexophore_PPNodeViz(node);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_descriptor_flexophore_PPNode',  function (node) {
;C$.superclazz.c$$com_actelion_research_chem_descriptor_flexophore_PPNode.apply(this,[node]);C$.$init$.apply(this);
p$1.init.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'init',  function () {
this.coordinates=Clazz.new_($I$(2,1));
this.hsIndexOriginalAtoms=Clazz.new_($I$(3,1));
this.mappingIndex=-1;
this.index=($b$[0] = -1, $b$[0]);
this.similarityMappingNodes=-1.0;
}, p$1);

Clazz.newMeth(C$, 'getIndex$',  function () {
return this.index;
});

Clazz.newMeth(C$, 'setIndex$I',  function (id) {
this.index=($b$[0] = id, $b$[0]);
});

Clazz.newMeth(C$, 'addAtoms$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (node) {
C$.superclazz.prototype.addAtoms$com_actelion_research_chem_descriptor_flexophore_PPNode.apply(this, [node]);
this.hsIndexOriginalAtoms.addAll$java_util_Collection(node.hsIndexOriginalAtoms);
});

Clazz.newMeth(C$, 'addIndexOriginalAtom$I',  function (index) {
if (this.hsIndexOriginalAtoms == null ) this.hsIndexOriginalAtoms=Clazz.new_($I$(3,1));
this.hsIndexOriginalAtoms.add$O(Integer.valueOf$I(index));
});

Clazz.newMeth(C$, 'copy$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (node) {
C$.superclazz.prototype.copy$com_actelion_research_chem_descriptor_flexophore_PPNode.apply(this, [node]);
this.coordinates=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_Coordinates,[node.coordinates]);
this.mappingIndex=node.mappingIndex;
this.hsIndexOriginalAtoms=Clazz.new_($I$(3,1));
this.hsIndexOriginalAtoms.addAll$java_util_Collection(node.hsIndexOriginalAtoms);
this.index=node.index;
this.indexSphereViz=node.indexSphereViz;
this.similarityMappingNodes=node.similarityMappingNodes;
this.marked=node.marked;
this.heteroAtom=node.heteroAtom;
});

Clazz.newMeth(C$, 'isMarked$',  function () {
return this.marked;
});

Clazz.newMeth(C$, 'setMarked$Z',  function (marked) {
this.marked=marked;
});

Clazz.newMeth(C$, 'getCopy$',  function () {
return Clazz.new_(C$.c$$com_actelion_research_chem_descriptor_flexophore_PPNodeViz,[this]);
});

Clazz.newMeth(C$, 'getListIndexOriginalAtoms$',  function () {
return Clazz.new_($I$(4,1).c$$java_util_Collection,[this.hsIndexOriginalAtoms]);
});

Clazz.newMeth(C$, 'getArrayIndexOriginalAtoms$',  function () {
return $I$(5).toIntArray$java_util_Collection(this.hsIndexOriginalAtoms);
});

Clazz.newMeth(C$, 'getIndexOriginalAtoms$',  function () {
return this.hsIndexOriginalAtoms;
});

Clazz.newMeth(C$, 'getMappingIndex$',  function () {
return this.mappingIndex;
});

Clazz.newMeth(C$, 'setMappingIndex$I',  function (info) {
this.mappingIndex=info;
});

Clazz.newMeth(C$, 'clearInfo$',  function () {
this.mappingIndex=-1;
});

Clazz.newMeth(C$, 'hasSamePosition$com_actelion_research_chem_descriptor_flexophore_PPNodeViz',  function (node) {
return p$1.equal$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates.apply(this, [this.coordinates, node.coordinates]);
});

Clazz.newMeth(C$, 'equal$com_actelion_research_chem_Coordinates$com_actelion_research_chem_Coordinates',  function (c1, c2) {
var bEq=true;
if (Math.abs(c1.x - c2.x) > 1.0E-5 ) bEq=false;
 else if (Math.abs(c1.y - c2.y) > 1.0E-5 ) bEq=false;
 else if (Math.abs(c1.z - c2.z) > 1.0E-5 ) bEq=false;
return bEq;
}, p$1);

Clazz.newMeth(C$, 'resetInfoColor$',  function () {
this.mappingIndex=-1;
});

Clazz.newMeth(C$, 'getCoordinates$',  function () {
return this.coordinates;
});

Clazz.newMeth(C$, 'setCoordinates$D$D$D',  function (x, y, z) {
this.coordinates.x=x;
this.coordinates.y=y;
this.coordinates.z=z;
});

Clazz.newMeth(C$, 'setCoordinates$com_actelion_research_chem_Coordinates',  function (c) {
this.coordinates.x=c.x;
this.coordinates.y=c.y;
this.coordinates.z=c.z;
});

Clazz.newMeth(C$, 'setCoordinatesNull$',  function () {
this.coordinates=null;
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.coordinates.x;
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.coordinates.y;
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.coordinates.z;
});

Clazz.newMeth(C$, 'setX$D',  function (x) {
this.coordinates.x=x;
});

Clazz.newMeth(C$, 'setY$D',  function (y) {
this.coordinates.y=y;
});

Clazz.newMeth(C$, 'setZ$D',  function (z) {
this.coordinates.z=z;
});

Clazz.newMeth(C$, 'getIndexSphereVisualization$',  function () {
return this.indexSphereViz;
});

Clazz.newMeth(C$, 'setIndexSphereVisualization$I',  function (indexSphereViz) {
this.indexSphereViz=indexSphereViz;
});

Clazz.newMeth(C$, 'getSimilarityMappingNodes$',  function () {
return this.similarityMappingNodes;
});

Clazz.newMeth(C$, 'setSimilarityMappingNodes$F',  function (similarityMappingNodes) {
this.similarityMappingNodes=similarityMappingNodes;
});

Clazz.newMeth(C$, 'toStringPPNodeText$',  function () {
return C$.superclazz.prototype.toStringText$.apply(this, []);
});

Clazz.newMeth(C$, 'toString',  function () {
var sb=Clazz.new_($I$(6,1));
sb.append$S("(");
if (this.modeFlexophore == 0) {
sb.append$S(C$.superclazz.prototype.toStringText$.apply(this, []));
} else if (this.modeFlexophore == 1) {
sb.append$S(C$.superclazz.prototype.toStringLongHardPPPoint$.apply(this, []));
} else {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unknown Flexophore mode " + this.modeFlexophore + "!" ]);
}sb.append$S(", coord ");
sb.append$S(this.coordinates.toString());
sb.append$S(", mapping color ");
sb.append$I(this.mappingIndex);
sb.append$S(", index ");
sb.append$I(this.index);
sb.append$S(", indexAtom viz ");
sb.append$I(this.indexSphereViz);
sb.append$S(")");
return sb.toString();
});

Clazz.newMeth(C$, 'toStringShort$',  function () {
return C$.superclazz.prototype.toString.apply(this, []);
});
var $b$ = new Int8Array(1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:41 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
