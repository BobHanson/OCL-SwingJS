(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "ForceField");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:53 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
