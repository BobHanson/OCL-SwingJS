(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mcs"),p$1={},I$=[[0,'java.util.ArrayList','com.actelion.research.chem.Canonizer','com.actelion.research.chem.shredder.Fragment','com.actelion.research.chem.StereoMolecule']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "BondVector2IdCode");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mol','com.actelion.research.chem.StereoMolecule','liRingSets','java.util.List']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule',  function (mol) {
;C$.$init$.apply(this);
this.mol=mol;
this.liRingSets=Clazz.new_($I$(1,1));
var rc=mol.getRingSet$();
var rings=rc.getSize$();
for (var i=0; i < rings; i++) {
var arrIndexBnd=rc.getRingBonds$I(i);
this.liRingSets.add$O(arrIndexBnd);
}
}, 1);

Clazz.newMeth(C$, 'containsFragmentOpenRing$com_actelion_research_chem_properties_complexity_IBitArray',  function (fragDefByBonds) {
var openRing=false;
for (var arrIndexBnd, $arrIndexBnd = this.liRingSets.iterator$(); $arrIndexBnd.hasNext$()&&((arrIndexBnd=($arrIndexBnd.next$())),1);) {
var ccOverlap=0;
for (var i=0; i < arrIndexBnd.length; i++) {
if (fragDefByBonds.isBitSet$I(arrIndexBnd[i])) {
++ccOverlap;
}}
if ((ccOverlap > 0) && ccOverlap < arrIndexBnd.length ) {
openRing=true;
break;
}}
return openRing;
});

Clazz.newMeth(C$, 'getFragmentIdCode$com_actelion_research_chem_properties_complexity_IBitArray',  function (fragDefByBonds) {
var frag=p$1.convert$com_actelion_research_chem_properties_complexity_IBitArray$Z.apply(this, [fragDefByBonds, false]);
var can=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[frag]);
var idcode=can.getIDCode$();
return idcode;
});

Clazz.newMeth(C$, 'getFragment$com_actelion_research_chem_properties_complexity_IBitArray',  function (fragDefByBonds) {
var frag=p$1.convert$com_actelion_research_chem_properties_complexity_IBitArray$Z.apply(this, [fragDefByBonds, false]);
var can=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[frag]);
var idcode=can.getIDCode$();
var fragment=Clazz.new_($I$(3,1).c$$S,[idcode]);
fragment.setMol$com_actelion_research_chem_StereoMolecule(frag);
fragment.setSize$I(frag.getBonds$());
return fragment;
});

Clazz.newMeth(C$, 'getFragment$com_actelion_research_chem_properties_complexity_IBitArray$Z',  function (fragDefByBonds, addWildcards) {
var frag=p$1.convert$com_actelion_research_chem_properties_complexity_IBitArray$Z.apply(this, [fragDefByBonds, addWildcards]);
var can=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[frag]);
var idcode=can.getIDCode$();
var fragment=Clazz.new_($I$(3,1).c$$S,[idcode]);
fragment.setMol$com_actelion_research_chem_StereoMolecule(frag);
fragment.setSize$I(frag.getBonds$());
return fragment;
});

Clazz.newMeth(C$, 'convert$com_actelion_research_chem_properties_complexity_IBitArray$Z',  function (fragDefByBonds, addWildcards) {
var bonds=this.mol.getBonds$();
var atoms=this.mol.getAtoms$();
var arrBonds=Clazz.array(Boolean.TYPE, [bonds]);
var arrAtoms=Clazz.array(Boolean.TYPE, [atoms]);
var bondsFragment=0;
for (var i=0; i < bonds; i++) {
if (fragDefByBonds.isBitSet$I(i)) {
arrBonds[i]=true;
++bondsFragment;
arrAtoms[this.mol.getBondAtom$I$I(0, i)]=true;
arrAtoms[this.mol.getBondAtom$I$I(1, i)]=true;
}}
var atomsFrag=0;
for (var i=0; i < arrAtoms.length; i++) {
if (arrAtoms[i]) {
++atomsFrag;
}}
var fragSubBonds=Clazz.new_($I$(4,1).c$$I$I,[atomsFrag, bondsFragment]);
var indexAtoms=this.mol.copyMoleculeByBonds$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(fragSubBonds, arrBonds, true, null);
var indexAtomNew=0;
for (var i=0; i < indexAtoms.length; i++) {
if (indexAtoms[i] > -1) {
if ((this.mol.getAtomQueryFeatures$I(indexAtoms[i]) & 8) > 0) {
fragSubBonds.setAtomQueryFeature$I$I$Z(indexAtomNew, 8, true);
}if ((this.mol.getAtomQueryFeatures$I(indexAtoms[i]) & 2) > 0) {
fragSubBonds.setAtomQueryFeature$I$I$Z(indexAtomNew, 2, true);
}++indexAtomNew;
}}
if (addWildcards) {
var arrAtomCopied2Fragment=Clazz.array(Boolean.TYPE, [this.mol.getAtoms$()]);
for (var i=0; i < indexAtoms.length; i++) {
if (indexAtoms[i] > -1) arrAtomCopied2Fragment[i]=true;
}
for (var i=0; i < indexAtoms.length; i++) {
if (indexAtoms[i] > -1) {
var atIndexOld=i;
var nConnected=this.mol.getConnAtoms$I(atIndexOld);
for (var j=0; j < nConnected; j++) {
var indexAtConn=this.mol.getConnAtom$I$I(atIndexOld, j);
if (!arrAtomCopied2Fragment[indexAtConn]) {
var atWildCard=fragSubBonds.addAtom$I(0);
var atIndexNew=indexAtoms[i];
fragSubBonds.addBond$I$I$I(atIndexNew, atWildCard, 1);
fragSubBonds.setAtomQueryFeature$I$I$Z(atWildCard, 1, true);
}}
}}
}fragSubBonds.ensureHelperArrays$I(7);
return fragSubBonds;
}, p$1);

Clazz.newMeth(C$, 'getFragmentIdCodeCarbonSkeleton$com_actelion_research_chem_properties_complexity_IBitArray',  function (fragDefByBonds) {
var frag=p$1.convert$com_actelion_research_chem_properties_complexity_IBitArray$Z.apply(this, [fragDefByBonds, false]);
for (var i=0; i < frag.getAtoms$(); i++) {
frag.setAtomicNo$I$I(i, 6);
}
var can=Clazz.new_($I$(2,1).c$$com_actelion_research_chem_StereoMolecule,[frag]);
var idcode=can.getIDCode$();
return idcode;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:08 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
