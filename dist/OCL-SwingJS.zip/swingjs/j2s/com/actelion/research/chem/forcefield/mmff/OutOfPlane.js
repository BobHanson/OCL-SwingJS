(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),I$=[[0,'com.actelion.research.chem.forcefield.mmff.Vector3','java.util.ArrayList','com.actelion.research.chem.forcefield.mmff.ForceFieldMMFF94']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "OutOfPlane", null, null, 'com.actelion.research.chem.forcefield.mmff.EnergyTerm');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['koop'],'I',['ac','a1','a2','a3']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I',  function (table, mol, ac, a1, a2, a3) {
;C$.$init$.apply(this);
this.ac=ac;
this.a1=a1;
this.a2=a2;
this.a3=a3;
this.koop=table.oop.getKoop$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I(mol, ac, a1, a2, a3);
}, 1);

Clazz.newMeth(C$, 'getKoop$',  function () {
return this.koop;
});

Clazz.newMeth(C$, 'getEnergy$DA',  function (pos) {
var rji=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a1]).normalise$();
var rjk=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a2]).normalise$();
var rjl=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a3]).normalise$();
var n=rji.cross$com_actelion_research_chem_forcefield_mmff_Vector3(rjk).normalise$();
var chi=57.29577951308232 * Math.asin(n.dot$com_actelion_research_chem_forcefield_mmff_Vector3(rjl));
var c2=0.043844346773450435;
return 0.5 * c2 * this.koop * chi * chi ;
});

Clazz.newMeth(C$, 'getGradient$DA$DA',  function (pos, grad) {
var rji=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a1]);
var rjk=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a2]);
var rjl=Clazz.new_($I$(1,1).c$$DA$I$I,[pos, this.ac, this.a3]);
var dji=rji.length$();
var djk=rjk.length$();
var djl=rjl.length$();
rji=rji.normalise$();
rjk=rjk.normalise$();
rjl=rjl.normalise$();
var n=rji.negate$().cross$com_actelion_research_chem_forcefield_mmff_Vector3(rjk).normalise$();
var c2=0.043844346773450435;
var sinChi=rjl.dot$com_actelion_research_chem_forcefield_mmff_Vector3(n);
var cosChiSq=1.0 - sinChi * sinChi;
var cosChi=Math.max(cosChiSq > 0.0  ? Math.sqrt(cosChiSq) : 0.0, 1.0E-8);
var chi=57.29577951308232 * Math.asin(sinChi);
var cosTheta=rji.dot$com_actelion_research_chem_forcefield_mmff_Vector3(rjk);
var sinThetaSq=Math.max(1.0 - cosTheta * cosTheta, 1.0E-8);
var sinTheta=Math.max(sinThetaSq > 0.0  ? Math.sqrt(sinThetaSq) : 0.0, 1.0E-8);
var dE_dChi=57.29577951308232 * 0.043844346773450435 * this.koop * chi ;
var t1=rjl.cross$com_actelion_research_chem_forcefield_mmff_Vector3(rjk);
var t2=rji.cross$com_actelion_research_chem_forcefield_mmff_Vector3(rjl);
var t3=rjk.cross$com_actelion_research_chem_forcefield_mmff_Vector3(rji);
var term1=cosChi * sinTheta;
var term2=sinChi / (cosChi * sinThetaSq);
var tg1=Clazz.array(Double.TYPE, -1, [(t1.x / term1 - (rji.x - rjk.x * cosTheta) * term2) / dji, (t1.y / term1 - (rji.y - rjk.y * cosTheta) * term2) / dji, (t1.z / term1 - (rji.z - rjk.z * cosTheta) * term2) / dji]);
var tg3=Clazz.array(Double.TYPE, -1, [(t2.x / term1 - (rjk.x - rji.x * cosTheta) * term2) / djk, (t2.y / term1 - (rjk.y - rji.y * cosTheta) * term2) / djk, (t2.z / term1 - (rjk.z - rji.z * cosTheta) * term2) / djk]);
var tg4=Clazz.array(Double.TYPE, -1, [(t3.x / term1 - rjl.x * sinChi / cosChi) / djl, (t3.y / term1 - rjl.y * sinChi / cosChi) / djl, (t3.z / term1 - rjl.z * sinChi / cosChi) / djl]);
for (var i=0; i < 3; i++) {
grad[3 * this.a1 + i]+=dE_dChi * tg1[i];
grad[3 * this.ac + i]+=-dE_dChi * (tg1[i] + tg3[i] + tg4[i] );
grad[3 * this.a2 + i]+=dE_dChi * tg3[i];
grad[3 * this.a3 + i]+=dE_dChi * tg4[i];
}
});

Clazz.newMeth(C$, 'equals$I$I$I$I',  function (ac, a1, a2, a3) {
return this.ac == ac && (this.a1 == a1 && this.a2 == a2  && this.a3 == a3  || this.a1 == a1 && this.a2 == a3  && this.a3 == a2   || this.a1 == a2 && this.a2 == a1  && this.a3 == a3   || this.a1 == a2 && this.a2 == a3  && this.a3 == a1   || this.a1 == a3 && this.a2 == a1  && this.a3 == a2   || this.a1 == a3 && this.a2 == a2  && this.a3 == a1  ) ;
});

Clazz.newMeth(C$, 'exactly$I$I$I$I',  function (ac, a1, a2, a3) {
return this.ac == ac && this.a1 == a1  && this.a2 == a2  && this.a3 == a3 ;
});

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (t, mol) {
var oops=Clazz.new_($I$(2,1));
for (var ac=0; ac < mol.getAllAtoms$(); ac++) {
if (mol.getAllConnAtoms$I(ac) != 3) continue;
var a1=mol.getConnAtom$I$I(ac, 0);
var a2=mol.getConnAtom$I$I(ac, 1);
var a3=mol.getConnAtom$I$I(ac, 2);
oops.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I,[t, mol, ac, a1, a2, a3]));
oops.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I,[t, mol, ac, a1, a3, a2]));
oops.add$O(Clazz.new_(C$.c$$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$I$I$I$I,[t, mol, ac, a2, a3, a1]));
}
return oops;
}, 1);

Clazz.newMeth(C$, 'findIn$com_actelion_research_chem_forcefield_mmff_MMFFMolecule',  function (mol) {
return C$.findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule($I$(3).table$S("MMFF94"), mol);
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v6');//Created 2025-03-12 17:48:27 Java2ScriptVisitor version 5.0.1-v6 net.sf.j2s.core.jar version 5.0.1-v6
