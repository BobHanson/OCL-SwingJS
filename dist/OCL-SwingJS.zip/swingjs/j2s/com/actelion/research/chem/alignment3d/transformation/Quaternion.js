(function(){var P$=Clazz.newPackage("com.actelion.research.chem.alignment3d.transformation"),I$=[[0,'com.actelion.research.calc.Matrix','java.util.Random']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Quaternion");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['q0','q1','q2','q3']]]

Clazz.newMeth(C$, 'c$$D$D$D$D',  function (q0, q1, q2, q3) {
;C$.$init$.apply(this);
this.q0=q0;
this.q1=q1;
this.q2=q2;
this.q3=q3;
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_Coordinates$D',  function (axis, angle) {
;C$.$init$.apply(this);
if (angle > 3.141592653589793 ) {
var n=(((angle) / 3.141592653589793)|0);
angle-=n * 3.141592653589793;
}if (angle < -3.141592653589793 ) {
var n=(((Math.abs(angle)) / 3.141592653589793)|0);
angle+=n * 3.141592653589793;
}var c=Math.cos(angle * 0.5);
var s=Math.sin(angle * 0.5);
this.q0=c;
this.q1=s * axis.x;
this.q2=s * axis.y;
this.q3=s * axis.z;
this.normalize$();
}, 1);

Clazz.newMeth(C$, 'normalize$',  function () {
var s=this.normSquared$();
var a=Math.sqrt(s);
this.q0=this.q0 * 1.0 / a;
this.q1=this.q1 * 1.0 / a;
this.q2=this.q2 * 1.0 / a;
this.q3=this.q3 * 1.0 / a;
});

Clazz.newMeth(C$, 'setQ0$D',  function (q0) {
this.q0=q0;
});

Clazz.newMeth(C$, 'setQ1$D',  function (q1) {
this.q1=q1;
});

Clazz.newMeth(C$, 'setQ2$D',  function (q2) {
this.q2=q2;
});

Clazz.newMeth(C$, 'setQ3$D',  function (q3) {
this.q3=q3;
});

Clazz.newMeth(C$, 'getQ0$',  function () {
return this.q0;
});

Clazz.newMeth(C$, 'getQ1$',  function () {
return this.q1;
});

Clazz.newMeth(C$, 'getQ2$',  function () {
return this.q2;
});

Clazz.newMeth(C$, 'getQ3$',  function () {
return this.q3;
});

Clazz.newMeth(C$, 'normSquared$',  function () {
return (this.q0 * this.q0 + this.q1 * this.q1 + this.q2 * this.q2 + this.q3 * this.q3);
});

Clazz.newMeth(C$, 'multiply$com_actelion_research_chem_alignment3d_transformation_Quaternion',  function (r) {
this.q0=r.q0 * this.q0 - r.q1 * this.q1 - r.q2 * this.q2 - r.q3 * this.q3;
this.q1=r.q0 * this.q1 + r.q1 * this.q0 - r.q2 * this.q3 + r.q3 * this.q2;
this.q2=r.q0 * this.q2 + r.q1 * this.q3 + r.q2 * this.q0 - r.q3 * this.q1;
this.q3=r.q0 * this.q3 - r.q1 * this.q2 + r.q2 * this.q1 + r.q3 * this.q0;
});

Clazz.newMeth(C$, 'getRotMatrix$',  function () {
var rotMat=Clazz.new_($I$(1,1).c$$I$I,[3, 3]);
var data=rotMat.getArray$();
var q1q1=this.q1 * this.q1;
var q2q2=this.q2 * this.q2;
var q0q1=this.q0 * this.q1;
var q1q2=this.q1 * this.q2;
var q3q3=this.q3 * this.q3;
var q0q3=this.q0 * this.q3;
var q1q3=this.q1 * this.q3;
var q0q2=this.q0 * this.q2;
var q2q3=this.q2 * this.q3;
data[0][0]=1.0 - 2 * (q2q2 + q3q3);
data[1][0]=2 * (q1q2 - q0q3);
data[2][0]=2 * (q1q3 + q0q2);
data[0][1]=2 * (q1q2 + q0q3);
data[1][1]=1.0 - 2 * (q1q1 + q3q3);
data[2][1]=2 * (q2q3 - q0q1);
data[0][2]=2 * (q1q3 - q0q2);
data[1][2]=2 * (q2q3 + q0q1);
data[2][2]=1.0 - 2 * (q1q1 + q2q2);
return rotMat;
});

Clazz.newMeth(C$, 'getRandomRotation$',  function () {
var r=Clazz.new_($I$(2,1));
var q0=0.0;
var q1=0.0;
var q2=0.0;
var q3=0.0;
var s1=0.0;
var s2=0.0;
var notFulfilled=true;
while (notFulfilled){
q0=-1 + 2 * r.nextDouble$();
q1=-1 + 2 * r.nextDouble$();
s1=q0 * q0 + q1 * q1;
if (s1 < 1.0 ) notFulfilled=false;
}
notFulfilled=true;
while (notFulfilled){
q2=-1 + 2 * r.nextDouble$();
q3=-1 + 2 * r.nextDouble$();
s2=q2 * q2 + q3 * q3;
if (s2 < 1.0 ) notFulfilled=false;
}
var s=Math.sqrt((1 - s1) / s2);
q2*=s;
q3*=s;
return Clazz.new_(C$.c$$D$D$D$D,[q0, q1, q2, q3]);
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
var s=new Double(this.q0).toString() + " " + new Double(this.q1).toString() + " " + new Double(this.q2).toString() + " " + new Double(this.q3).toString() ;
return s;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
