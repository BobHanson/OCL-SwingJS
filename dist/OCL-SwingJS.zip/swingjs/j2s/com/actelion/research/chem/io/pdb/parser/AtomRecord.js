(function(){var P$=Clazz.newPackage("com.actelion.research.chem.io.pdb.parser"),I$=[[0,'com.actelion.research.chem.PeriodicTable','StringBuilder']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomRecord");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['isTerminalC'],'D',['x','y','z','occupancy','tempFactor'],'I',['serialId','atomicNo','resNum'],'S',['atomName','altLoc','residueName','chainId','insertionCode','element','charge','anisou']]]

Clazz.newMeth(C$, 'c$$I$S$S$S$S$I$S$D$D$D$D$D$S',  function (serialId, atomName, altLoc, residueName, chainId, resNum, insertionCode, x, y, z, occupancy, tempFactor, element) {
;C$.$init$.apply(this);
this.serialId=serialId;
this.atomName=atomName;
this.altLoc=altLoc;
this.residueName=residueName;
this.chainId=chainId;
this.resNum=resNum;
this.insertionCode=insertionCode;
this.x=x;
this.y=y;
this.z=z;
this.occupancy=occupancy;
this.tempFactor=tempFactor;
this.element=element;
this.atomicNo=$I$(1).number$S(element);
this.isTerminalC=false;
}, 1);

Clazz.newMeth(C$, 'getSerialId$',  function () {
return this.serialId;
});

Clazz.newMeth(C$, 'getAnisou$',  function () {
return this.anisou;
});

Clazz.newMeth(C$, 'getAltLoc$',  function () {
return this.altLoc;
});

Clazz.newMeth(C$, 'getAtomName$',  function () {
return this.atomName;
});

Clazz.newMeth(C$, 'isTerminalC$',  function () {
return this.isTerminalC;
});

Clazz.newMeth(C$, 'getX$',  function () {
return this.x;
});

Clazz.newMeth(C$, 'getY$',  function () {
return this.y;
});

Clazz.newMeth(C$, 'getZ$',  function () {
return this.z;
});

Clazz.newMeth(C$, 'getInsertionCode$',  function () {
return this.insertionCode;
});

Clazz.newMeth(C$, 'getAtomicNo$',  function () {
return this.atomicNo;
});

Clazz.newMeth(C$, 'getResName$',  function () {
return this.residueName;
});

Clazz.newMeth(C$, 'getChainID$',  function () {
return this.chainId;
});

Clazz.newMeth(C$, 'getString$',  function () {
var sb=Clazz.new_($I$(2,1).c$$S,[this.residueName]);
sb.append$S(" ");
sb.append$I(this.resNum);
sb.append$S(this.insertionCode);
sb.append$S(" ");
sb.append$S(this.chainId);
return sb.toString();
});

Clazz.newMeth(C$, 'getResNum$',  function () {
return this.resNum;
});

Clazz.newMeth(C$, 'setAnisou$S',  function (anisou) {
this.anisou=anisou;
});

Clazz.newMeth(C$, 'setTerminalC$Z',  function (isTerminalC) {
this.isTerminalC=isTerminalC;
});

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-29 20:19:17 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
