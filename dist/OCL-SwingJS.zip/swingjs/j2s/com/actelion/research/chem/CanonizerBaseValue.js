(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.Arrays']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "CanonizerBaseValue", null, null, 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['id','mAtom','mIndex','mAvailableBits'],'O',['mValue','int[]']]
,['I',['test']]]

Clazz.newMeth(C$, 'c$$I',  function (size) {
;C$.$init$.apply(this);
this.mValue=Clazz.array(Integer.TYPE, [size * 2]);
this.id=++C$.test;
}, 1);

Clazz.newMeth(C$, 'init$I',  function (atom) {
this.mAtom=atom;
this.mIndex=0;
this.mAvailableBits=31;
$I$(1).fill$IA$I(this.mValue, 0);
});

Clazz.newMeth(C$, 'addInt$I',  function (data) {
this.mValue[this.mIndex]+=data;
});

Clazz.newMeth(C$, 'add$I$I',  function (bits, data) {
if (this.mAvailableBits == 0) {
++this.mIndex;
this.mAvailableBits=31;
}if (this.mAvailableBits == 31) {
this.mValue[this.mIndex]|=data;
this.mAvailableBits-=bits;
} else {
if (this.mAvailableBits >= bits) {
this.mValue[this.mIndex]<<=bits;
this.mValue[this.mIndex]|=data;
this.mAvailableBits-=bits;
} else {
this.mValue[this.mIndex]<<=this.mAvailableBits;
this.mValue[this.mIndex]|=(data >> (bits - this.mAvailableBits));
bits-=this.mAvailableBits;
++this.mIndex;
this.mAvailableBits=31 - bits;
this.mValue[this.mIndex]|=(data & ((1 << bits) - 1));
}}});

Clazz.newMeth(C$, 'getAtom$',  function () {
return this.mAtom;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_chem_CanonizerBaseValue','compareTo$O'],  function (b) {
Clazz.assert(C$, this, function(){return (this.mIndex == b.mIndex)});
for (var i=0; i < this.mIndex; i++) if (this.mValue[i] != b.mValue[i]) return (this.mValue[i] < b.mValue[i]) ? -1 : 1;

return (this.mValue[this.mIndex] == b.mValue[this.mIndex]) ? 0 : (this.mValue[this.mIndex] < b.mValue[this.mIndex]) ? -1 : 1;
});

C$.$static$=function(){C$.$static$=0;
C$.$_ASSERT_ENABLED_ = ClassLoader.getClassAssertionStatus$(C$);
C$.test=0;
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-03 17:38:37 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
