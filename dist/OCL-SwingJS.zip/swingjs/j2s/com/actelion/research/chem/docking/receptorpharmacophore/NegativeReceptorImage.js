(function(){var P$=Clazz.newPackage("com.actelion.research.chem.docking.receptorpharmacophore"),p$1={},I$=[[0,'com.actelion.research.chem.Coordinates','com.actelion.research.chem.io.pdb.converter.MoleculeGrid','java.util.HashSet','java.util.HashMap','com.actelion.research.chem.docking.scoring.ProbeScanning','java.util.ArrayList','com.actelion.research.chem.phesa.ShapeVolume',['com.actelion.research.chem.phesa.pharmacophore.pp.IPharmacophorePoint','.Functionality'],'com.actelion.research.chem.phesa.pharmacophore.pp.SimplePharmacophorePoint','com.actelion.research.chem.phesa.pharmacophore.pp.PPGaussian','com.actelion.research.chem.phesa.AtomicGaussian',['com.actelion.research.chem.docking.scoring.ProbeScanning','.Probe'],'java.util.stream.IntStream','smile.clustering.KMeans','java.util.Random','com.actelion.research.chem.docking.DockingUtils','com.actelion.research.chem.phesa.MolecularVolume','java.util.LinkedList']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "NegativeReceptorImage", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.chem.io.pdb.converter.MoleculeGrid');
C$.$classes$=[['InteractionProbe',25]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['bumpGrid','boolean[][][]','receptorAtoms','java.util.Set','receptor','com.actelion.research.chem.StereoMolecule','receptorInteractionSites','java.util.Map','probeScanning','com.actelion.research.chem.docking.scoring.ProbeScanning','receptorGrid','com.actelion.research.chem.io.pdb.converter.MoleculeGrid']]
,['D',['MIN_INTERACTION_POINT_DIST']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule',  function (ligand, receptor) {
C$.c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates.apply(this, [ligand, receptor, 0.4, Clazz.new_($I$(1,1).c$$D$D$D,[5.0, 5.0, 5.0])]);
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates',  function (ligand, receptor, gridWidth, extension) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates.apply(this,[ligand, gridWidth, extension]);C$.$init$.apply(this);
this.receptorGrid=Clazz.new_([receptor, gridWidth, Clazz.new_($I$(1,1).c$$D$D$D,[0.0, 0.0, 0.0])],$I$(2,1).c$$com_actelion_research_chem_StereoMolecule$D$com_actelion_research_chem_Coordinates);
this.receptor=receptor;
this.receptorAtoms=Clazz.new_($I$(3,1));
this.receptorInteractionSites=Clazz.new_($I$(4,1));
var recGridSize=this.receptorGrid.getGridSize$();
this.bumpGrid=Clazz.array(Boolean.TYPE, [recGridSize[0], recGridSize[1], recGridSize[2]]);
for (var i=0; i < receptor.getAllAtoms$(); i++) {
var gridC=this.getGridCoordinates$com_actelion_research_chem_Coordinates(receptor.getCoordinates$I(i));
var x=gridC[0];
var y=gridC[1];
var z=gridC[2];
if (x > 0 && x < this.grid.length ) {
if (y > 0 && y < this.grid[0].length ) {
if (z > 0 && z < this.grid[0][0].length ) {
this.receptorAtoms.add$O(Integer.valueOf$I(i));
}}}}
this.probeScanning=Clazz.new_($I$(5,1).c$$com_actelion_research_chem_StereoMolecule$java_util_Set$com_actelion_research_chem_io_pdb_converter_MoleculeGrid,[receptor, this.receptorAtoms, this]);
}, 1);

Clazz.newMeth(C$, 'calculate$',  function () {
var ppGaussians=Clazz.new_($I$(6,1));
var shapeGaussians=Clazz.new_($I$(6,1));
p$1.analyzeBindingSiteAtoms.apply(this, []);
var recVol=Clazz.new_($I$(7,1));
p$1.analyzeBumps.apply(this, []);
p$1.createPolarInteractionSites$java_util_List.apply(this, [ppGaussians]);
p$1.createShapeAtoms$java_util_List.apply(this, [shapeGaussians]);
var startingPoints=Clazz.new_($I$(6,1));
for (var a=0; a < this.mol.getAtoms$() && a < 10 ; a++) {
startingPoints.add$O(this.mol.getCoordinates$I(a));
}
p$1.prunePoints$java_util_List$java_util_List$java_util_List$D.apply(this, [startingPoints, ppGaussians, shapeGaussians, 2.0]);
for (var i=0; i < ppGaussians.size$(); i++) {
ppGaussians.get$I(i).setAtomId$I(i);
}
recVol.setAtomicGaussians$java_util_List(shapeGaussians);
recVol.setPPGaussians$java_util_List(ppGaussians);
return recVol;
});

Clazz.newMeth(C$, 'createPolarInteractionSites$java_util_List',  function (ppGaussians) {
for (var i, $i = this.receptorInteractionSites.keySet$().iterator$(); $i.hasNext$()&&((i=($i.next$()).intValue$()),1);) {
for (var type, $type = this.receptorInteractionSites.get$O(Integer.valueOf$I(i)).keySet$().iterator$(); $type.hasNext$()&&((type=($type.next$()).intValue$()),1);) {
for (var c, $c = this.receptorInteractionSites.get$O(Integer.valueOf$I(i)).get$O(Integer.valueOf$I(type)).iterator$(); $c.hasNext$()&&((c=($c.next$())),1);) {
var functionality=null;
var energyCutoff=0.0;
var coarseFactor=1;
switch (type) {
case 2:
functionality=$I$(8).POS_CHARGE;
energyCutoff=-1.0;
coarseFactor=2;
break;
case 3:
functionality=$I$(8).NEG_CHARGE;
energyCutoff=-1.0;
coarseFactor=2;
break;
case 0:
functionality=$I$(8).DONOR;
break;
case 1:
functionality=$I$(8).ACCEPTOR;
break;
default:
functionality=null;
}
if (functionality == null ) continue;
var centroids=p$1.scanProbe$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality$I$D$I.apply(this, [c, functionality, i, energyCutoff, coarseFactor]);
if (centroids != null ) {
for (var centroid, $centroid = 0, $$centroid = centroids; $centroid<$$centroid.length&&((centroid=($$centroid[$centroid])),1);$centroid++) {
var spp=Clazz.new_([-1, Clazz.new_($I$(1,1).c$$D$D$D,[centroid[0], centroid[1], centroid[2]]), functionality],$I$(9,1).c$$I$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality);
var ppg=Clazz.new_($I$(10,1).c$$I$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint,[6, spp]);
ppGaussians.add$O(ppg);
}
}}
}
}
}, p$1);

Clazz.newMeth(C$, 'createShapeAtoms$java_util_List',  function (shapeGaussians) {
var gaussians=Clazz.new_($I$(6,1));
var radiusSq=6.25;
var gaussDistSq=1.6900000000000002;
var cutoff=((2.5 / this.gridWidth)|0);
for (var x=cutoff; x < this.gridSize[0]; x++) {
for (var y=cutoff; y < this.gridSize[1]; y++) {
for (var z=cutoff; z < this.gridSize[2]; z++) {
var clash=false;
var probeCoords=this.getCartCoordinates$IA(Clazz.array(Integer.TYPE, -1, [x, y, z]));
for (var ag, $ag = gaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
var dx=(ag.getCenter$().x - probeCoords.x);
var dy=(ag.getCenter$().y - probeCoords.y);
var dz=(ag.getCenter$().z - probeCoords.z);
var rSq=dx * dx + dy * dy + dz * dz;
if (rSq > gaussDistSq ) {
continue;
} else {
var r=Math.sqrt(rSq);
if (r < 1.3 ) {
clash=true;
break;
}}}
if (!clash) {
for (var atom, $atom = this.receptorAtoms.iterator$(); $atom.hasNext$()&&((atom=($atom.next$()).intValue$()),1);) {
var c=this.receptor.getCoordinates$I(atom);
var dx=(c.x - probeCoords.x);
var dy=(c.y - probeCoords.y);
var dz=(c.z - probeCoords.z);
var rSq=dx * dx + dy * dy + dz * dz;
if (rSq > radiusSq ) {
continue;
} else {
var r=Math.sqrt(rSq);
if (r < 2.5 ) {
clash=true;
break;
}}}
}var isBuried=this.getBuriedness$IA(Clazz.array(Integer.TYPE, -1, [x, y, z]));
if (!clash && isBuried ) {
var ag=Clazz.new_($I$(11,1).c$$I$I$com_actelion_research_chem_Coordinates,[-1, 6, probeCoords]);
gaussians.add$O(ag);
}}
}
}
gaussians.stream$().forEach$java_util_function_Consumer(((P$.NegativeReceptorImage$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "NegativeReceptorImage$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Consumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$com_actelion_research_chem_phesa_AtomicGaussian','accept$O'],  function (ag) {
this.$finals$.shapeGaussians.add$O.apply(this.$finals$.shapeGaussians, [ag]);
});
})()
), Clazz.new_(P$.NegativeReceptorImage$lambda1.$init$,[this, {shapeGaussians:shapeGaussians}])));
}, p$1);

Clazz.newMeth(C$, 'scanProbe$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality$I$D$I',  function (c, functionality, receptorAtom, energyCutoff, coarseFactor) {
var probe=Clazz.new_([Clazz.new_($I$(1,1)), functionality],$I$(12,1).c$$com_actelion_research_chem_Coordinates$com_actelion_research_chem_phesa_pharmacophore_pp_IPharmacophorePoint_Functionality);
this.probeScanning.init$com_actelion_research_chem_docking_scoring_ProbeScanning_Probe(probe);
var interactionPoints=Clazz.new_($I$(6,1));
var interactionEnergies=Clazz.new_($I$(6,1));
var bound=coarseFactor;
var probeCenterCoords=this.getGridCoordinates$com_actelion_research_chem_Coordinates(c);
var cutoff=((3 / this.gridWidth)|0);
for (var dx=-bound; dx < bound + 1; dx++) {
for (var dy=-bound; dy < bound + 1; dy++) {
for (var dz=-bound; dz < bound + 1; dz++) {
var x=probeCenterCoords[0] + dx * coarseFactor;
var y=probeCenterCoords[1] + dy * coarseFactor;
var z=probeCenterCoords[2] + dz * coarseFactor;
if (x < cutoff || x > (this.gridSize[0] - cutoff) ) continue;
if (y < cutoff || y > (this.gridSize[1] - cutoff) ) continue;
if (z < cutoff || z > (this.gridSize[2] - cutoff) ) continue;
var isBuried=this.getBuriedness$IA(Clazz.array(Integer.TYPE, -1, [x, y, z]));
if (!isBuried) continue;
var probeCoords=this.getCartCoordinates$IA(Clazz.array(Integer.TYPE, -1, [x, y, z]));
probe.updateCoordinates$com_actelion_research_chem_Coordinates(probeCoords);
var score=this.probeScanning.getScore$();
if (score < energyCutoff ) {
interactionPoints.add$O(Clazz.array(Double.TYPE, -1, [probeCoords.x, probeCoords.y, probeCoords.z]));
interactionEnergies.add$O(Double.valueOf$D(score));
}}
}
}
var centroids;
if (interactionPoints.size$() == 0) centroids=null;
 else {
var data=Clazz.array(Double.TYPE, [interactionPoints.size$(), 3]);
$I$(13,"range$I$I",[0, interactionPoints.size$()]).forEach$java_util_function_IntConsumer(((P$.NegativeReceptorImage$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "NegativeReceptorImage$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (i) { return (this.$finals$.data[i]=this.$finals$.interactionPoints.get$I.apply(this.$finals$.interactionPoints, [i]));});
})()
), Clazz.new_(P$.NegativeReceptorImage$lambda2.$init$,[this, {interactionPoints:interactionPoints,data:data}])));
var minCentroidDistSq=C$.MIN_INTERACTION_POINT_DIST * C$.MIN_INTERACTION_POINT_DIST;
var maxNrPoints=Math.min(data.length, 8);
var k=maxNrPoints;
if (maxNrPoints == 1) {
centroids=Clazz.array(Double.TYPE, -2, [Clazz.array(Double.TYPE, -1, [data[0][0], data[0][1], data[0][2]])]);
} else {
var breakCondition=false;
for (var i=2; i < maxNrPoints + 1 && !breakCondition ; i++) {
var kmeans=Clazz.new_($I$(14,1).c$$DAA$I,[data, i]);
centroids=kmeans.centroids$();
for (var j=0; j < centroids.length && !breakCondition ; j++) {
var centroid1=centroids[j];
for (var l=j + 1; l < centroids.length && !breakCondition ; l++) {
var centroid2=centroids[l];
var dx=centroid1[0] - centroid2[0];
var dy=centroid1[1] - centroid2[1];
var dz=centroid1[2] - centroid2[2];
var distSq=dx * dx + dy * dy + dz * dz;
if (distSq > 0.001  && distSq < minCentroidDistSq  ) {
k=i - 1;
breakCondition=true;
}}
}
}
if (k == 1) {
var centroid=Clazz.array(Double.TYPE, -1, [0.0, 0.0, 0.0]);
var n=0;
for (var p, $p = 0, $$p = data; $p<$$p.length&&((p=($$p[$p])),1);$p++) {
centroid[0]+=p[0];
centroid[1]+=p[1];
centroid[2]+=p[2];
n+=1;
}
centroid[0]/=n;
centroid[1]/=n;
centroid[2]/=n;
centroids=Clazz.array(Double.TYPE, -2, [centroid]);
} else {
var kmeans=Clazz.new_($I$(14,1).c$$DAA$I,[data, k]);
centroids=kmeans.centroids$();
}}}return centroids;
}, p$1);

Clazz.newMeth(C$, 'analyzeBumps',  function () {
var radiusSq=4.0;
var xmax=Math.min(this.gridSize[0], this.bumpGrid.length);
var ymax=Math.min(this.gridSize[1], this.bumpGrid[0].length);
var zmax=Math.min(this.gridSize[2], this.bumpGrid[0][0].length);
for (var x=0; x < xmax; x++) {
for (var y=0; y < ymax; y++) {
for (var z=0; z < zmax; z++) {
var probeCoords=this.getCartCoordinates$IA(Clazz.array(Integer.TYPE, -1, [x, y, z]));
for (var atom=0; atom < this.receptor.getAtoms$(); atom++) {
var c=this.receptor.getCoordinates$I(atom);
var dx=(c.x - probeCoords.x);
var dy=(c.y - probeCoords.y);
var dz=(c.z - probeCoords.z);
var rSq=dx * dx + dy * dy + dz * dz;
if (rSq > radiusSq ) {
continue;
} else {
var r=Math.sqrt(rSq);
if (r < 2.0 ) {
this.bumpGrid[x][y][z]=true;
break;
}}}
}
}
}
}, p$1);

Clazz.newMeth(C$, 'getBuriedness$IA',  function (gridCoords) {
var rnd=Clazz.new_($I$(15,1).c$$J,[12345]);
var steps=((8.0 / this.gridWidth)|0);
var intersections=0;
var center=this.getCartCoordinates$IA(gridCoords);
for (var i=0; i < 120; i++) {
var ray=$I$(16).randomVectorInSphere$java_util_Random(rnd).scale$D(this.gridWidth);
for (var j=1; j < steps + 1; j++) {
var c=center.addC$com_actelion_research_chem_Coordinates(ray.scaleC$D(j));
var gridC=this.getGridCoordinates$com_actelion_research_chem_Coordinates(c);
try {
var intersect=this.bumpGrid[gridC[0]][gridC[1]][gridC[2]];
if (intersect) {
++intersections;
break;
}} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
continue;
} else {
throw e;
}
}
}
}
var buriedness=intersections / 120;
var isBuried=buriedness > 0.4  ? true : false;
return isBuried;
});

Clazz.newMeth(C$, 'analyzeBindingSiteAtoms',  function () {
var molVol=Clazz.new_($I$(17,1).c$$com_actelion_research_chem_StereoMolecule,[this.receptor]);
var hbondDistance=2.8;
for (var ppg, $ppg = molVol.getPPGaussians$().iterator$(); $ppg.hasNext$()&&((ppg=($ppg.next$())),1);) {
var a=ppg.getAtomId$();
var pp=ppg.getPharmacophorePoint$();
var funcIndex=pp.getFunctionalityIndex$();
this.receptorInteractionSites.putIfAbsent$O$O(Integer.valueOf$I(a), Clazz.new_($I$(4,1)));
var sites=this.receptorInteractionSites.get$O(Integer.valueOf$I(a));
sites.putIfAbsent$O$O(Integer.valueOf$I(funcIndex), Clazz.new_($I$(6,1)));
var siteCoords=sites.get$O(Integer.valueOf$I(funcIndex));
if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == $I$(8).ACCEPTOR.getIndex$()) {
if (this.receptor.getConnAtoms$I(a) == 1) {
if (this.receptor.getBondOrder$I(this.receptor.getBond$I$I(a, this.receptor.getConnAtom$I$I(a, 0))) == 2) {
if (siteCoords.size$() == 0) {
var v=this.receptor.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(this.receptor.getCoordinates$I(this.receptor.getConnAtom$I$I(a, 0))).unitC$();
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(v.scaleC$D(2.8));
siteCoords.add$O(c);
}}}var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(pp.getDirectionality$().scaleC$D(2.8));
siteCoords.add$O(c);
} else if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == $I$(8).NEG_CHARGE.getIndex$()) {
if (this.receptor.getConnAtoms$I(a) == 1) {
var v=this.receptor.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(this.receptor.getCoordinates$I(this.receptor.getConnAtom$I$I(a, 0))).unitC$();
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(v.scaleC$D(2.8));
siteCoords.add$O(c);
} else if (this.receptor.getConnAtoms$I(a) == 3) {
var aa=-1;
for (var i=0; i < this.receptor.getConnAtoms$I(a); i++) {
if (this.receptor.getAtomicNo$I(this.receptor.getConnAtom$I$I(a, i)) == 6) {
aa=this.receptor.getConnAtom$I$I(a, i);
break;
}}
if (aa != -1) {
var v=this.receptor.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(this.receptor.getCoordinates$I(aa)).unitC$();
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(v.scaleC$D(4.0));
siteCoords.add$O(c);
}}} else if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == $I$(8).POS_CHARGE.getIndex$()) {
if (this.receptor.getConnAtoms$I(a) == 1) {
var v=this.receptor.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(this.receptor.getCoordinates$I(this.receptor.getConnAtom$I$I(a, 0))).unitC$();
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(v.scaleC$D(4.0));
siteCoords.add$O(c);
} else if (this.receptor.getConnAtoms$I(a) == 3) {
var aa=-1;
for (var i=0; i < this.receptor.getConnAtoms$I(a); i++) {
var neighbour=this.receptor.getConnAtom$I$I(a, i);
if (this.receptor.getConnAtoms$I(neighbour) == 2) {
aa=neighbour;
}}
if (aa != -1) {
var v=this.receptor.getCoordinates$I(a).subC$com_actelion_research_chem_Coordinates(this.receptor.getCoordinates$I(aa)).unitC$();
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(v.scaleC$D(4.0));
siteCoords.add$O(c);
}}} else if (ppg.getPharmacophorePoint$().getFunctionalityIndex$() == $I$(8).DONOR.getIndex$()) {
var c=this.receptor.getCoordinates$I(a).addC$com_actelion_research_chem_Coordinates(pp.getDirectionality$().scaleC$D(1.7999999999999998));
siteCoords.add$O(c);
}}
}, p$1);

Clazz.newMeth(C$, 'prunePoints$java_util_List$java_util_List$java_util_List$D',  function (centers, ppGaussians, atomicGaussians, stepSize) {
var cavityPoints=Clazz.new_($I$(3,1));
var pq=Clazz.new_($I$(18,1));
var visited=Clazz.new_($I$(3,1));
var neighbours=Clazz.new_($I$(3,1));
for (var center, $center = centers.iterator$(); $center.hasNext$()&&((center=($center.next$())),1);) {
neighbours.addAll$java_util_Collection(p$1.getNeighbourPoints$com_actelion_research_chem_Coordinates$java_util_List$java_util_List$D.apply(this, [center, ppGaussians, atomicGaussians, stepSize]));
}
pq.addAll$java_util_Collection(neighbours);
cavityPoints.addAll$java_util_Collection(neighbours);
while (!pq.isEmpty$()){
var point=pq.poll$();
if (visited.contains$O(point)) continue;
visited.add$O(point);
neighbours=p$1.getNeighbourPoints$com_actelion_research_chem_Coordinates$java_util_List$java_util_List$D.apply(this, [point.getCenter$(), ppGaussians, atomicGaussians, stepSize]);
pq.addAll$java_util_Collection(neighbours);
cavityPoints.addAll$java_util_Collection(neighbours);
}
var ppgToDelete=Clazz.new_($I$(6,1));
for (var ppg, $ppg = ppGaussians.iterator$(); $ppg.hasNext$()&&((ppg=($ppg.next$())),1);) {
if (!cavityPoints.contains$O(ppg)) ppgToDelete.add$O(ppg);
}
ppGaussians.removeAll$java_util_Collection(ppgToDelete);
var agToDelete=Clazz.new_($I$(6,1));
for (var ag, $ag = atomicGaussians.iterator$(); $ag.hasNext$()&&((ag=($ag.next$())),1);) {
if (!cavityPoints.contains$O(ag)) agToDelete.add$O(ag);
}
atomicGaussians.removeAll$java_util_Collection(agToDelete);
}, p$1);

Clazz.newMeth(C$, 'getNeighbourPoints$com_actelion_research_chem_Coordinates$java_util_List$java_util_List$D',  function (center, ppGaussians, atomicGaussians, distCutoff) {
var distSqCutoff=distCutoff * distCutoff;
var neighbours=Clazz.new_($I$(3,1));
var allGauss=Clazz.new_($I$(3,1));
allGauss.addAll$java_util_Collection(atomicGaussians);
allGauss.addAll$java_util_Collection(ppGaussians);
for (var gauss2, $gauss2 = allGauss.iterator$(); $gauss2.hasNext$()&&((gauss2=($gauss2.next$())),1);) {
var distSq=gauss2.getCenter$().distSquareTo$com_actelion_research_chem_Coordinates(center);
if (distSq > distSqCutoff ) continue;
 else neighbours.add$O(gauss2);
}
return neighbours;
}, p$1);

C$.$static$=function(){C$.$static$=0;
C$.MIN_INTERACTION_POINT_DIST=1.5;
};
;
(function(){/*e*/var C$=Clazz.newClass(P$.NegativeReceptorImage, "InteractionProbe", function(){
Clazz.newInstance(this, arguments[0],false,C$);
}, 'Enum');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$static$=function(){C$.$static$=0;
$vals=Clazz.array(C$,[0]);
Clazz.newEnumConst($vals, C$.c$, "NEG_CHARGE", 0, []);
Clazz.newEnumConst($vals, C$.c$, "POS_CHARGE", 1, []);
Clazz.newEnumConst($vals, C$.c$, "HB_DONOR", 2, []);
Clazz.newEnumConst($vals, C$.c$, "HB_ACCEPTOR", 3, []);
};

Clazz.newMeth(C$);
var $vals=[];
Clazz.newMeth(C$, 'values$', function() { return $vals }, 1);
Clazz.newMeth(C$, 'valueOf$S', function(name) { for (var val in $vals){ if ($vals[val].name == name) return $vals[val]} return null }, 1);
})()

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:54 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
