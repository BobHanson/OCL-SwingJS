(function(){var P$=Clazz.newPackage("com.actelion.research.chem.chemicalspaces.synthon"),I$=[[0,'com.actelion.research.chem.reaction.Reaction','java.util.HashMap','java.util.ArrayList','java.util.HashSet','java.util.Arrays','com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.coords.CoordinateInventor','java.io.BufferedWriter','java.io.OutputStreamWriter','java.io.FileOutputStream','java.nio.charset.StandardCharsets','com.actelion.research.chem.io.RXNFileCreator']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SynthonCreator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'create$com_actelion_research_chem_reaction_Reaction',  function (rxn) {
if (rxn.getProducts$() > 1) throw Clazz.new_(Clazz.load('Exception').c$$S,["only reactions with one product are supported"]);
var synthonTransformations=Clazz.array($I$(1), [rxn.getReactants$()]);
var mappedAtomToReactant=Clazz.new_($I$(2,1));
for (var r=0; r < rxn.getReactants$(); r++) {
if (rxn.getReactants$() == 0) throw Clazz.new_(Clazz.load('Exception').c$$S,["cannot create Synthons for reactions with one reactant"]);
var reactant=rxn.getReactant$I(r);
for (var a=0; a < reactant.getAtoms$(); a++) {
var reactantMapNo=reactant.getAtomMapNo$I(a);
if (reactantMapNo != 0) mappedAtomToReactant.put$O$O(Integer.valueOf$I(reactantMapNo), Integer.valueOf$I(r));
}
}
var product=rxn.getProduct$I(0);
var rc=product.getRingSet$();
var homogeneousRingBonds=Clazz.new_($I$(3,1));
for (var ringNo=0; ringNo < rc.getSize$(); ringNo++) {
var ringReactant=Clazz.new_($I$(4,1));
var atoms=rc.getRingAtoms$I(ringNo);
for (var a, $a = 0, $$a = atoms; $a<$$a.length&&((a=($$a[$a])),1);$a++) {
var mappedA=product.getAtomMapNo$I(a);
if (mappedA != 0) ringReactant.add$O(mappedAtomToReactant.get$O(Integer.valueOf$I(mappedA)));
}
if (ringReactant.size$() == 1) {
var ringBonds=rc.getRingBonds$I(ringNo);
$I$(5).stream$IA(ringBonds).forEach$java_util_function_IntConsumer(((P$.SynthonCreator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "SynthonCreator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.IntConsumer', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['accept$I','accept$O'],  function (e) { return (this.$finals$.homogeneousRingBonds.add$O.apply(this.$finals$.homogeneousRingBonds, [Integer.valueOf$I(e)]));});
})()
), Clazz.new_(P$.SynthonCreator$lambda1.$init$,[this, {homogeneousRingBonds:homogeneousRingBonds}])));
}}
var bondsToCut=Clazz.new_($I$(3,1));
for (var b=0; b < product.getBonds$(); b++) {
if (homogeneousRingBonds.contains$O(Integer.valueOf$I(b))) continue;
var bondAtom1=product.getBondAtom$I$I(0, b);
var bondAtom2=product.getBondAtom$I$I(1, b);
var mappedBondAtom1=product.getAtomMapNo$I(bondAtom1);
var mappedBondAtom2=product.getAtomMapNo$I(bondAtom2);
if (mappedBondAtom1 == 0) {
if (mappedBondAtom2 != 0) bondsToCut.add$O(Integer.valueOf$I(b));
} else if (mappedBondAtom2 == 0) {
bondsToCut.add$O(Integer.valueOf$I(b));
} else if (!mappedAtomToReactant.get$O(Integer.valueOf$I(mappedBondAtom1)).equals$O(mappedAtomToReactant.get$O(Integer.valueOf$I(mappedBondAtom2)))) {
bondsToCut.add$O(Integer.valueOf$I(b));
}}
var decomposedProduct=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule,[product]);
decomposedProduct.ensureHelperArrays$I(31);
var counter=0;
for (var cutBond, $cutBond = bondsToCut.iterator$(); $cutBond.hasNext$()&&((cutBond=($cutBond.next$()).intValue$()),1);) {
var tmpMol=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_Molecule,[decomposedProduct]);
tmpMol.ensureHelperArrays$I(1);
tmpMol.setBondType$I$I(cutBond, 512);
tmpMol.deleteMarkedAtomsAndBonds$();
var tmpFrags=tmpMol.getFragments$();
var acceptCut=true;
for (var tmpFrag, $tmpFrag = 0, $$tmpFrag = tmpFrags; $tmpFrag<$$tmpFrag.length&&((tmpFrag=($$tmpFrag[$tmpFrag])),1);$tmpFrag++) {
tmpFrag.ensureHelperArrays$I(1);
var mapSum=0;
for (var a=0; a < tmpFrag.getAtoms$(); a++) {
mapSum+=tmpFrag.getAtomMapNo$I(a);
}
if (mapSum == 0) {
acceptCut=false;
break;
}}
if (acceptCut) {
var bondType=decomposedProduct.getBondType$I(cutBond);
decomposedProduct.setBondType$I$I(cutBond, 512);
var connector1=decomposedProduct.addAtom$I(92 + counter);
var connector2=decomposedProduct.addAtom$I(92 + counter);
var newBond1=decomposedProduct.addBond$I$I(decomposedProduct.getBondAtom$I$I(0, cutBond), connector1);
decomposedProduct.setBondType$I$I(newBond1, bondType);
var newBond2=decomposedProduct.addBond$I$I(connector2, decomposedProduct.getBondAtom$I$I(1, cutBond));
decomposedProduct.setBondType$I$I(newBond2, bondType);
++counter;
}}
decomposedProduct.deleteMarkedAtomsAndBonds$();
decomposedProduct.ensureHelperArrays$I(31);
var frags=decomposedProduct.getFragments$();
for (var frag, $frag = 0, $$frag = frags; $frag<$$frag.length&&((frag=($$frag[$frag])),1);$frag++) {
var inventor=Clazz.new_($I$(7,1));
inventor.setRandomSeed$J(78187493520);
inventor.invent$com_actelion_research_chem_StereoMolecule(frag);
var reaction=Clazz.new_($I$(1,1));
var reactantID=-1;
for (var a=0; a < frag.getAtoms$(); a++) {
if (frag.getAtomMapNo$I(a) != 0) {
reactantID=(mappedAtomToReactant.get$O(Integer.valueOf$I(frag.getAtomMapNo$I(a)))).$c();
}}
if (reactantID == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["could not process reaction"]);
frag.ensureHelperArrays$I(31);
reaction.addReactant$com_actelion_research_chem_StereoMolecule(rxn.getReactant$I(reactantID));
reaction.addProduct$com_actelion_research_chem_StereoMolecule(frag);
synthonTransformations[reactantID]=reaction;
var writer=Clazz.new_([Clazz.new_([Clazz.new_([rxn.getName$() + "_" + reactantID + ".rxn" ],$I$(10,1).c$$S), $I$(11).UTF_8],$I$(9,1).c$$java_io_OutputStream$java_nio_charset_Charset)],$I$(8,1).c$$java_io_Writer);
Clazz.new_($I$(12,1).c$$com_actelion_research_chem_reaction_Reaction,[reaction]).writeRXNfile$java_io_Writer(writer);
writer.close$();
}
return synthonTransformations;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-15 22:40:15 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
