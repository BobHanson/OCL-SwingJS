(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.flexophore"),I$=[];
/*i*/var C$=Clazz.newInterface(P$, "IPPNode");
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-02 09:47:14 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
