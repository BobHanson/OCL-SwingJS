(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff.table"),p$1={},I$=[[0,'com.actelion.research.chem.forcefield.mmff.Csv','com.actelion.research.chem.forcefield.mmff.Search']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Atom", null, null, 'com.actelion.research.chem.forcefield.mmff.Searchable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['table','int[][]']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_forcefield_mmff_Tables$S',  function (t, csvpath) {
;C$.$init$.apply(this);
this.table=$I$(1).readIntsFile$S(csvpath);
}, 1);

Clazz.newMeth(C$, 'get$I$I',  function (row, col) {
return this.table[row][col];
});

Clazz.newMeth(C$, 'length$',  function () {
return this.table.length;
});

Clazz.newMeth(C$, 'aspec$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][1];
});

Clazz.newMeth(C$, 'crd$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][2];
});

Clazz.newMeth(C$, 'val$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][3];
});

Clazz.newMeth(C$, 'pilp$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][4];
});

Clazz.newMeth(C$, 'mltb$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][5];
});

Clazz.newMeth(C$, 'arom$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][6] > 0;
});

Clazz.newMeth(C$, 'linear$I',  function (type) {
var idx=p$1.index$I.apply(this, [type]);
return idx >= 0 ? this.table[idx][7] > 0 : false;
});

Clazz.newMeth(C$, 'sbmb$I',  function (type) {
return this.table[p$1.index$I.apply(this, [type])][8] > 0;
});

Clazz.newMeth(C$, 'index$I',  function (type) {
return $I$(2).binary$I$I$com_actelion_research_chem_forcefield_mmff_Searchable(0, type, this);
}, p$1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:10 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
