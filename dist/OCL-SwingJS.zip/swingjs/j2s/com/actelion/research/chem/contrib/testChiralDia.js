(function(){var P$=Clazz.newPackage("com.actelion.research.chem.contrib"),I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.contrib.HydrogenHandler','com.actelion.research.chem.contrib.DiastereotopicAtomID']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "testChiralDia");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
var mol=Clazz.new_($I$(1,1));
var parser=Clazz.new_($I$(2,1));
try {
parser.parse$com_actelion_research_chem_StereoMolecule$S(mol, "C1CCCCC1C");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$S(e.toString());
} else {
throw e;
}
}
$I$(3).addImplicitHydrogens$com_actelion_research_chem_StereoMolecule(mol);
var ids=$I$(4).getAtomIds$com_actelion_research_chem_StereoMolecule(mol);
for (var id, $id = 0, $$id = ids; $id<$$id.length&&((id=($$id[$id])),1);$id++) {
System.out.println$S(id);
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-20 12:31:50 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
