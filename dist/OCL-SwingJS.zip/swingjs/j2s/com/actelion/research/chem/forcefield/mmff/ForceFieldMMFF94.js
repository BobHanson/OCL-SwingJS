(function(){var P$=Clazz.newPackage("com.actelion.research.chem.forcefield.mmff"),p$1={},I$=[[0,'java.util.HashMap','java.util.ArrayList','com.actelion.research.chem.forcefield.mmff.MMFFMolecule','com.actelion.research.chem.forcefield.mmff.Separation','com.actelion.research.chem.forcefield.mmff.AngleBend','com.actelion.research.chem.forcefield.mmff.BondStretch','com.actelion.research.chem.forcefield.mmff.Electrostatic','com.actelion.research.chem.forcefield.mmff.OutOfPlane','com.actelion.research.chem.forcefield.mmff.StretchBend','com.actelion.research.chem.forcefield.mmff.TorsionAngle','com.actelion.research.chem.forcefield.mmff.VanDerWaals','java.util.Arrays','com.actelion.research.chem.forcefield.mmff.Tables']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "ForceFieldMMFF94", null, 'com.actelion.research.chem.forcefield.AbstractForceField');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.mEnergies=Clazz.new_($I$(2,1));
},1);

C$.$fields$=[['O',['mMMFFMol','com.actelion.research.chem.forcefield.mmff.MMFFMolecule','mEnergies','java.util.List']]
,['O',['mTables','java.util.Map']]]

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map',  function (m, tablename, options) {
;C$.superclazz.c$$com_actelion_research_chem_StereoMolecule.apply(this,[m]);C$.$init$.apply(this);
this.mMMFFMol=Clazz.new_($I$(3,1).c$$com_actelion_research_chem_StereoMolecule,[m]);
this.mMol.ensureHelperArrays$I(7);
var table=C$.mTables.get$O(tablename);
var nonBondedThresh=options.containsKey$O("nonbonded cutoff") ? (options.get$O("nonbonded cutoff")).valueOf() : 100.0;
var dielConst=options.containsKey$O("dielectric constant") ? (options.get$O("dielectric constant")).valueOf() : 1.0;
var dielModel=options.containsKey$O("dielectric model") && (options.get$O("dielectric model")).equals$O("distance") ;
var sep=Clazz.new_($I$(4,1).c$$com_actelion_research_chem_forcefield_mmff_MMFFMolecule,[this.mMMFFMol]);
if (!options.containsKey$O("angle bend") || (options.get$O("angle bend")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(5).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, this.mMMFFMol));
if (!options.containsKey$O("bond stretch") || (options.get$O("bond stretch")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(6).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, this.mMMFFMol));
if (!options.containsKey$O("electrostatic") || (options.get$O("electrostatic")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(7).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation$D$Z$D(table, this.mMMFFMol, sep, nonBondedThresh, dielModel, dielConst));
if (!options.containsKey$O("out of plane") || (options.get$O("out of plane")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(8).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, this.mMMFFMol));
if (!options.containsKey$O("stretch bend") || (options.get$O("stretch bend")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(9).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, this.mMMFFMol));
if (!options.containsKey$O("torsion angle") || (options.get$O("torsion angle")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(10).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule(table, this.mMMFFMol));
if (!options.containsKey$O("van der waals") || (options.get$O("van der waals")).$c() ) this.mEnergies.addAll$java_util_Collection($I$(11).findIn$com_actelion_research_chem_forcefield_mmff_Tables$com_actelion_research_chem_forcefield_mmff_MMFFMolecule$com_actelion_research_chem_forcefield_mmff_Separation$D(table, this.mMMFFMol, sep, nonBondedThresh));
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_chem_StereoMolecule$S',  function (mol, tablename) {
C$.c$$com_actelion_research_chem_StereoMolecule$S$java_util_Map.apply(this, [mol, tablename, Clazz.new_($I$(1,1))]);
}, 1);

Clazz.newMeth(C$, 'size$',  function () {
return this.mMMFFMol.getAllAtoms$();
});

Clazz.newMeth(C$, 'updateGradient$',  function () {
this.mGrad=Clazz.array(Double.TYPE, [this.mDim]);
for (var engy, $engy = this.mEnergies.iterator$(); $engy.hasNext$()&&((engy=($engy.next$())),1);) engy.getGradient$DA$DA(this.mPos, this.mGrad);

var maxGrad=-1.0E8;
var gradScale=0.1;
for (var i=0; i < this.mDim; i++) {
this.mGrad[i]*=gradScale;
if (this.mGrad[i] > maxGrad ) maxGrad=this.mGrad[i];
}
if (maxGrad > 10.0 ) {
while (maxGrad * gradScale > 10.0 )gradScale*=0.5;

for (var i=0; i < this.mDim; i++) this.mGrad[i]*=gradScale;

}return gradScale;
});

Clazz.newMeth(C$, 'zeroGradient$',  function () {
if (this.mFixedAtoms != null ) {
var hydrogenMap=this.mMMFFMol.getHydrogenMap$();
for (var i, $i = 0, $$i = this.mFixedAtoms; $i<$$i.length&&((i=($$i[$i])),1);$i++) {
var mappedIndex=hydrogenMap[i];
this.mGrad[3 * mappedIndex]=0.0;
this.mGrad[3 * mappedIndex + 1]=0.0;
this.mGrad[3 * mappedIndex + 2]=0.0;
}
}});

Clazz.newMeth(C$, 'getCurrentPositions$',  function () {
var pos=$I$(12).copyOf$DA$I(this.mPos, this.mPos.length);
return p$1.getMappedPositions$DA.apply(this, [pos]);
});

Clazz.newMeth(C$, 'getMappedPositions$DA',  function (pos) {
var atomMap=this.mMMFFMol.getHydrogenMap$();
var mappedPos=$I$(12).copyOf$DA$I(pos, pos.length);
for (var i=0; i < atomMap.length; i++) {
mappedPos[3 * i]=pos[3 * atomMap[i]];
mappedPos[3 * i + 1]=pos[3 * atomMap[i] + 1];
mappedPos[3 * i + 2]=pos[3 * atomMap[i] + 2];
}
return mappedPos;
}, p$1);

Clazz.newMeth(C$, 'getTotalEnergy$DA',  function (pos) {
var total=0.0;
for (var term, $term = this.mEnergies.iterator$(); $term.hasNext$()&&((term=($term.next$())),1);) total+=term.getEnergy$DA(pos);

return total;
});

Clazz.newMeth(C$, 'getTotalEnergy$',  function () {
return this.getTotalEnergy$DA(this.mPos);
});

Clazz.newMeth(C$, 'initialize$S',  function (tableSet) {
C$.loadTable$S$com_actelion_research_chem_forcefield_mmff_Tables(tableSet, $I$(13).newMMFF94$S(tableSet));
}, 1);

Clazz.newMeth(C$, 'loadTable$S$com_actelion_research_chem_forcefield_mmff_Tables',  function (name, table) {
if (!C$.mTables.containsKey$O(name)) C$.mTables.put$O$O(name, table);
}, 1);

Clazz.newMeth(C$, 'table$S',  function (name) {
return C$.mTables.get$O(name);
}, 1);

Clazz.newMeth(C$, 'getMMFFMolecule$',  function () {
return this.mMMFFMol;
});

Clazz.newMeth(C$, 'addEnergyTerm$com_actelion_research_chem_forcefield_mmff_EnergyTerm',  function (term) {
this.mEnergies.add$O(term);
});

C$.$static$=function(){C$.$static$=0;
C$.mTables=Clazz.new_($I$(1,1));
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v7');//Created 2025-04-19 14:45:06 Java2ScriptVisitor version 5.0.1-v7 net.sf.j2s.core.jar version 5.0.1-v7
