(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor"),I$=[[0,'com.actelion.research.chem.descriptor.DescriptorEncoder','java.util.Arrays','com.actelion.research.chem.descriptor.DescriptorHandler','com.actelion.research.chem.SSSearcherWithIndex']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AbstractDescriptorHandlerFP", null, null, 'com.actelion.research.chem.descriptor.DescriptorHandler');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['FAILED_OBJECT','int[]']]]

Clazz.newMeth(C$, ['encode$IA','encode$O'],  function (o) {
return this.calculationFailed$IA(o) ? "Calculation Failed" :  String.instantialize(Clazz.new_($I$(1,1)).encode$IA(o));
});

Clazz.newMeth(C$, 'decode$S',  function (s) {
return s == null  ? null : s.equals$O("Calculation Failed") ? C$.FAILED_OBJECT : Clazz.new_($I$(1,1)).decode$S(s);
});

Clazz.newMeth(C$, 'decode$BA',  function (bytes) {
return bytes == null  ? null : $I$(2,"equals$BA$BA",[bytes, $I$(3).FAILED_BYTES]) ? C$.FAILED_OBJECT : Clazz.new_($I$(1,1)).decode$BA(bytes);
});

Clazz.newMeth(C$, ['calculationFailed$IA','calculationFailed$O'],  function (o) {
return o == null  || o.length == 0 ;
});

Clazz.newMeth(C$, ['getSimilarity$IA$IA','getSimilarity$O$O'],  function (o1, o2) {
return o1 == null  || o2 == null   || o1.length == 0  || o2.length == 0  ? 0.0 : $I$(4).getSimilarityTanimoto$IA$IA(o1, o2);
});

C$.$static$=function(){C$.$static$=0;
C$.FAILED_OBJECT=Clazz.array(Integer.TYPE, [0]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-17 14:00:09 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
