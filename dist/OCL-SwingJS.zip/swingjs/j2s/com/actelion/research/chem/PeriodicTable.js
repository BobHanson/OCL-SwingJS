(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'java.util.Hashtable','com.actelion.research.chem.Element']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PeriodicTable");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['arrAlkaline','boolean[]','htblDataAtNo','java.util.Hashtable','+htblDataName','+htblDataSymbol']]
,['O',['arrData','com.actelion.research.chem.Element[]','tbl','com.actelion.research.chem.PeriodicTable']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.htblDataAtNo=Clazz.new_($I$(1,1));
this.htblDataName=Clazz.new_($I$(1,1));
this.htblDataSymbol=Clazz.new_($I$(1,1));
C$.arrData=Clazz.array($I$(2), -1, [Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[1, "Hydrogen", "H", 1.008, 0.435, 1.185, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[2, "Helium", "He", 4.003, 0.93, 1.785, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[3, "Lithium", "Li", 6.94, 1.52, 0.0, 0.98]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[4, "Beryllium", "Be", 9.013, 1.143, 0.0, 1.57]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[5, "Boron", "B", 10.82, 0.975, 1.7, 2.04]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[6, "Carbon", "C", 12.011, 0.655, 1.75, 2.55]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[7, "Nitrogen", "N", 14.008, 0.75, 1.525, 3.04]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[8, "Oxygen", "O", 16.0, 0.73, 1.4, 3.44]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[9, "Fluorine", "F", 19.0, 0.72, 1.35, 3.98]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[10, "Neon", "Ne", 20.183, 0.71, 1.6, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[11, "Sodium", "Na", 22.991, 1.858, 0.0, 0.93]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[12, "Magnesium", "Mg", 24.32, 1.605, 0.0, 1.31]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[13, "Aluminum", "Al", 26.98, 1.432, 0.0, 1.61]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[14, "Silicon", "Si", 28.09, 1.176, 2.0, 1.9]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[15, "Phosphorus", "P", 30.975, 1.06, 1.9, 2.19]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[16, "Sulfur", "S", 32.066, 1.02, 1.85, 2.58]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[17, "Chlorine", "Cl", 35.457, 0.99, 1.78, 3.16]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[18, "Argon", "Ar", 39.944, 0.98, 1.9, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[19, "Potassium", "K", 39.1, 2.262, 0.0, 1.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[20, "Calcium", "Ca", 40.08, 1.976, 0.0, 1.36]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[21, "Scandium", "Sc", 44.96, 1.655, 0.0, 1.54]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[22, "Titanium", "Ti", 47.9, 1.476, 0.0, 1.63]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[23, "Vanadium", "V", 50.95, 1.309, 0.0, 1.66]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[24, "Chromium", "Cr", 52.01, 1.249, 0.0, 1.55]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[25, "Manganese", "Mn", 54.94, 1.35, 0.0, 1.83]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[26, "Iron", "Fe", 55.85, 1.241, 0.0, 1.88]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[27, "Cobalt", "Co", 58.94, 1.254, 0.0, 1.91]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[28, "Nickel", "Ni", 58.69, 1.246, 0.0, 1.9]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[29, "Copper", "Cu", 63.54, 1.278, 0.0, 1.65]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[30, "Zinc", "Zn", 65.38, 1.333, 0.0, 1.81]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[31, "Gallium", "Ga", 69.72, 1.35, 0.0, 2.01]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[32, "Germanium", "Ge", 72.6, 1.225, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[33, "Arsenic", "As", 74.91, 1.2, 2.1, 2.18]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[34, "Selenium", "Se", 78.96, 1.16, 2.0, 2.55]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[35, "Bromine", "Br", 79.916, 1.14, 1.97, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[36, "Krypton", "Kr", 83.8, 1.12, 2.0, 2.96]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[37, "Rubidium", "Rb", 85.48, 2.47, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[38, "Strontium", "Sr", 87.63, 2.151, 0.0, 0.82]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[39, "Yttrium", "Y", 88.92, 1.824, 0.0, 0.95]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[40, "Zirconium", "Zr", 91.22, 1.616, 0.0, 1.22]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[41, "Niobium", "Nb", 92.91, 1.432, 0.0, 1.33]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[42, "Molybdenum", "Mo", 95.95, 1.363, 0.0, 1.6]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[43, "Technetium", "Tc", 99.0, 1.367, 0.0, 2.16]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[44, "Ruthenium", "Ru", 101.1, 1.353, 0.0, 1.9]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[45, "Rhodium", "Rh", 102.91, 1.345, 0.0, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[46, "Palladium", "Pd", 106.7, 1.375, 0.0, 2.28]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[47, "Silver", "Ag", 107.88, 1.445, 0.0, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[48, "Cadmium", "Cd", 112.41, 1.489, 0.0, 1.93]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[49, "Indium", "In", 114.76, 1.666, 0.0, 1.69]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[50, "Tin", "Sn", 118.7, 1.538, 0.0, 1.78]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[51, "Antimony", "Sb", 121.76, 1.4, 2.2, 1.96]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[52, "Tellurium", "Te", 127.61, 1.36, 2.2, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[53, "Iodine", "I", 126.91, 1.33, 2.2, 2.05]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[54, "Xenon", "Xe", 131.3, 1.31, 2.2, 2.1]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[55, "Cesium", "Cs", 132.91, 2.632, 0.0, 2.66]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[56, "Barium", "Ba", 137.36, 2.171, 0.0, 2.6]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[57, "Lanthanum", "La", 138.92, 1.873, 0.0, 0.79]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[58, "Cerium", "Ce", 140.13, 1.824, 0.0, 0.89]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[59, "Praesodymium", "Pr", 140.92, 1.836, 0.0, 1.1]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[60, "Neodymium", "Nd", 144.27, 1.829, 0.0, 1.12]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[61, "Promethium", "Pm", 145.0, 1.809, 0.0, 1.13]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[62, "Samarium", "Sm", 150.43, 1.804, 0.0, 1.14]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[63, "Europium", "Eu", 152.0, 1.984, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[64, "Gadolinium", "Gd", 156.9, 1.818, 0.0, 1.17]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[65, "Terbium", "Tb", 158.93, 1.8, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[66, "Dyprosium", "Dy", 162.46, 1.795, 0.0, 1.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[67, "Holmium", "Ho", 164.94, 1.789, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[68, "Erbium", "Er", 167.2, 1.779, 0.0, 1.22]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[69, "Thulium", "Tm", 168.94, 1.769, 0.0, 1.23]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[70, "Ytterbium", "Yb", 173.04, 1.94, 0.0, 1.24]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[71, "Lutetium", "Lu", 174.99, 1.752, 0.0, 1.25]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[72, "Hafnium", "Hf", 178.6, 1.597, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[73, "Tantalium", "Ta", 180.95, 1.428, 0.0, 1.27]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[74, "Wolfram", "W", 183.92, 1.371, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[75, "Rhenium", "Re", 186.31, 1.38, 0.0, 1.5]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[76, "Osmium", "Os", 190.2, 1.368, 0.0, 2.36]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[77, "Iridium", "Ir", 192.2, 1.357, 0.0, 1.9]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[78, "Platinum", "Pt", 195.23, 1.387, 0.0, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[79, "Gold", "Au", 197.0, 1.442, 0.0, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[80, "Mercury", "Hg", 200.61, 1.502, 0.0, 2.28]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[81, "Thallium", "Tl", 204.39, 1.728, 0.0, 2.54]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[82, "Lead", "Pb", 207.21, 1.75, 0.0, 2.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[83, "Bismuth", "Bi", 209.0, 1.46, 0.0, 1.62]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[84, "Polonium", "Po", 210.0, 1.46, 0.0, 2.33]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[85, "Astatine", "At", 210.0, 1.45, 0.0, 2.02]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[86, "Radon", "Rn", 222.0, 1.43, 0.0, 2.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[87, "Francium", "Fr", 223.0, 2.5, 0.0, 2.2]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[88, "Radium", "Ra", 226.05, 2.14, 0.0, 0.0]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[89, "Actinium", "Ac", 227.0, 1.877, 0.0, 0.7]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[90, "Thorium", "Th", 232.05, 1.798, 0.0, 0.89]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[91, "Protactinium", "Pa", 231.0, 1.609, 0.0, 1.1]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[92, "Uranium", "U", 238.07, 1.568, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[93, "Neptunium", "Np", 237.0, 0.0, 0.0, 1.5]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[94, "Plutonium", "Pu", 242.0, 0.0, 0.0, 1.38]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[95, "Americium", "Am", 243.0, 0.0, 0.0, 1.36]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[96, "Curium", "Cm", 243.0, 0.0, 0.0, 1.28]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[97, "Berkelium", "Bk", 245.0, 0.0, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[98, "Californium", "Cf", 246.0, 0.0, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[99, "Einsteinium", "E", -999.0, 0.0, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[100, "Fermium", "Fm", -999.0, 0.0, 0.0, 1.3]), Clazz.new_($I$(2,1).c$$I$S$S$D$D$D$D,[101, "Mendelevium", "Mv", -999.0, 0.0, 0.0, 1.3])]);
for (var i=0; i < C$.arrData.length; i++) {
this.htblDataAtNo.put$O$O( new Integer(C$.arrData[i].getOrderNumber$()), C$.arrData[i]);
this.htblDataName.put$O$O(C$.arrData[i].getName$(), C$.arrData[i]);
this.htblDataSymbol.put$O$O(C$.arrData[i].getSymbol$(), C$.arrData[i]);
}
this.arrAlkaline=Clazz.array(Boolean.TYPE, [C$.arrData.length]);
this.arrAlkaline[3]=true;
this.arrAlkaline[11]=true;
this.arrAlkaline[19]=true;
this.arrAlkaline[37]=true;
this.arrAlkaline[55]=true;
this.arrAlkaline[87]=true;
}, 1);

Clazz.newMeth(C$, 'getInstance$',  function () {
if (C$.tbl == null ) {
C$.tbl=Clazz.new_(C$);
}return C$.tbl;
}, 1);

Clazz.newMeth(C$, 'isAlkaline$I',  function (atomicNo) {
return C$.getInstance$().arrAlkaline[atomicNo];
}, 1);

Clazz.newMeth(C$, 'number$S',  function (sNameOrSymbol) {
var iOrderNumber=0;
var el=C$.getInstance$().htblDataName.get$O(sNameOrSymbol);
if (el == null ) el=C$.getInstance$().htblDataSymbol.get$O(sNameOrSymbol);
if (el != null ) iOrderNumber=el.getOrderNumber$();
return iOrderNumber;
}, 1);

Clazz.newMeth(C$, 'symbol$I',  function (iOrderNumber) {
var sSymbol="";
var el=C$.getInstance$().htblDataAtNo.get$O(Integer.valueOf$I(iOrderNumber));
if (el != null ) sSymbol=el.getSymbol$();
return sSymbol;
}, 1);

Clazz.newMeth(C$, 'size$',  function () {
return C$.getInstance$().htblDataAtNo.size$();
}, 1);

Clazz.newMeth(C$, 'getWeight$I',  function (iOrderNumber) {
var el=C$.getInstance$().htblDataAtNo.get$O(Integer.valueOf$I(iOrderNumber));
return el.getWeight$();
}, 1);

Clazz.newMeth(C$, 'name$I',  function (iOrderNumber) {
var sName="";
var el=C$.getInstance$().htblDataAtNo.get$O(Integer.valueOf$I(iOrderNumber));
if (el != null ) sName=el.getName$();
return sName;
}, 1);

Clazz.newMeth(C$, 'getElement$I',  function (orderNumber) {
return C$.getInstance$().htblDataAtNo.get$O(Integer.valueOf$I(orderNumber));
}, 1);

Clazz.newMeth(C$, 'toString',  function () {
var sPeriodicTable="";
return sPeriodicTable;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-30 18:47:49 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
