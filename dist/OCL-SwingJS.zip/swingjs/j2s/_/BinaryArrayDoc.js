(function(){var P$=Clazz.newPackage("_");
/*c*/var C$=Clazz.newClass(P$, "BinaryArrayDoc", null, null, 'javajs.api.GenericBinaryDocumentReader');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'readByte$',  function () {
return $b$[0] = 0, $b$[0];
});

Clazz.newMeth(C$, 'readBytes$I',  function (n) {
return null;
});

Clazz.newMeth(C$, 'readUInt8$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readInt$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readShort$',  function () {
return $s$[0] = 0, $s$[0];
});

Clazz.newMeth(C$, 'readUnsignedShort$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readLong$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readFloat$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readDouble$',  function () {
return 0;
});

Clazz.newMeth(C$, 'readString$I',  function (i) {
return null;
});

Clazz.newMeth(C$, 'getPosition$',  function () {
return 0;
});

Clazz.newMeth(C$, 'seek$J',  function (i) {
});

Clazz.newMeth(C$, 'skip$I',  function (n) {
});

Clazz.newMeth(C$, 'setBigEndian$Z',  function (b) {
});
var $b$ = new Int8Array(1);
var $s$ = new Int16Array(1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2024-12-14 15:27:38 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
