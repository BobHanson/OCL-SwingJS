(function(){var P$=Clazz.newPackage("_"),I$=[];
/*c*/var C$=Clazz.newClass(P$, "JF");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'main$SA',  function (args) {
try {
System.out.println$S("HelloWorld!");
var o= Clazz.new_();
System.out.println$S("....");
o.wait$J(5000);
System.out.println$S("OK");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('3.3.1-v1');//Created 2021-01-04 17:06:28 Java2ScriptVisitor version 3.3.1-v1 net.sf.j2s.core.jar version 3.3.1-v1
