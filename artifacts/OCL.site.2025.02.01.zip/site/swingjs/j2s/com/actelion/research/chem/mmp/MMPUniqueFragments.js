(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','java.util.Arrays','com.actelion.research.chem.IDCodeParser','java.util.LinkedHashMap',['com.actelion.research.chem.mmp.MMPUniqueFragments','.MMPUniqueFragment']]],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPUniqueFragments", function(){
Clazz.newInstance(this, arguments,0,C$);
});
C$.$classes$=[['MMPUniqueFragment',1]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
this.fragmentMolecule=Clazz.new_($I$(1,1));
this.fragment=null;
this.biggestFragment=0;
this.idCodeParser=Clazz.new_($I$(3,1));
this.fragmentIndexes=0;
},1);

C$.$fields$=[['I',['biggestFragment','fragmentIndexes'],'O',['fragmentMolecule','com.actelion.research.chem.StereoMolecule','+fragment','uniqueFragments','java.util.LinkedHashMap','idCodeParser','com.actelion.research.chem.IDCodeParser']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.uniqueFragments=Clazz.new_($I$(4,1));
}, 1);

Clazz.newMeth(C$, 'getFragmentAtoms$S',  function (fragmentID) {
if (this.uniqueFragments.containsKey$O(fragmentID)) {
return Integer.valueOf$I(this.uniqueFragments.get$O(fragmentID).fragmentAtoms);
}return null;
});

Clazz.newMeth(C$, 'fragmentIDToFragment$SA',  function (fragmentsID) {
var fragmentID=fragmentsID[0];
if (fragmentsID.length == 2) {
fragmentID=fragmentsID[0] + "\t" + fragmentsID[1] ;
}return this.fragmentIDToFragment$S(fragmentID);
});

Clazz.newMeth(C$, 'fragmentIDToFragment$S',  function (fragmentID) {
var mmpUniqueFragment=null;
if (this.uniqueFragments.containsKey$O(fragmentID)) {
mmpUniqueFragment=this.uniqueFragments.get$O(fragmentID);
}if (mmpUniqueFragment == null ) {
this.addFragment$S(fragmentID);
}if (mmpUniqueFragment != null  && mmpUniqueFragment.fragmentFP == null  ) {
p$1.addFP$S.apply(mmpUniqueFragment, [fragmentID]);
}return mmpUniqueFragment;
});

Clazz.newMeth(C$, 'addFragment$S',  function (fragmentID) {
if (!this.uniqueFragments.containsKey$O(fragmentID)) {
var mmpFragment=Clazz.new_($I$(5,1).c$$S,[this, null, fragmentID]);
this.uniqueFragments.put$O$O(fragmentID, mmpFragment);
if (mmpFragment.fragmentAtoms > this.biggestFragment) {
this.biggestFragment=mmpFragment.fragmentAtoms;
}return mmpFragment.fragmentIndex;
} else {
return this.uniqueFragments.get$O(fragmentID).fragmentIndex;
}});

Clazz.newMeth(C$, 'addFragment$S$com_actelion_research_chem_mmp_MMPUniqueFragments_MMPUniqueFragment',  function (fragmentID, mmpFragment) {
if (!this.uniqueFragments.containsKey$O(fragmentID)) {
this.uniqueFragments.put$O$O(fragmentID, mmpFragment);
}});

Clazz.newMeth(C$, 'addFragment$S$I$SA',  function (fragmentID, fragmentAtoms, fragmentFP) {
if (!this.uniqueFragments.containsKey$O(fragmentID)) {
var mmpFragment=Clazz.new_($I$(5,1).c$$I$SA,[this, null, fragmentAtoms, fragmentFP]);
this.uniqueFragments.put$O$O(fragmentID, mmpFragment);
if (mmpFragment.fragmentAtoms > this.biggestFragment) {
this.biggestFragment=mmpFragment.fragmentAtoms;
}return mmpFragment.fragmentIndex;
} else {
return this.uniqueFragments.get$O(fragmentID).fragmentIndex;
}});

Clazz.newMeth(C$, 'writeUniqueFragments$java_io_PrintWriter',  function (printWriter) {
printWriter.println$S("<mmpUniqueFragments>");
printWriter.println$S("<column properties>");
printWriter.println$S("<columnName=\"fragmentID\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"fragmentAtoms\">");
printWriter.println$S("<columnName=\"fragmentFP1\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"fragmentFP2\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"fragmentFP3\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"fragmentFP4\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("<columnName=\"fragmentFP5\">");
printWriter.println$S("<columnProperty=\"specialType\tidcode\">");
printWriter.println$S("</column properties>");
printWriter.println$S("fragmentID\tfragmentAtoms\tfragmentFP1\tfragmentFP2\tfragmentFP3\tfragmentFP4\tfragmentFP5");
if (this.biggestFragment != 0) {
this.fragment=Clazz.new_($I$(1,1).c$$I$I,[this.biggestFragment + 1, this.biggestFragment + 1]);
}for (var entry, $entry = this.uniqueFragments.entrySet$().iterator$(); $entry.hasNext$()&&((entry=($entry.next$())),1);) {
var fragmentID=entry.getKey$();
var fragmentFP=entry.getValue$();
if (fragmentFP.fragmentFP == null ) {
p$1.addFP$S.apply(fragmentFP, [fragmentID]);
entry.setValue$O(fragmentFP);
}var printLine=fragmentID + "\t" + Integer.toString$I(fragmentFP.fragmentAtoms) + "\t" + fragmentFP.fragmentFP[0] + "\t" + fragmentFP.fragmentFP[1] + "\t" + fragmentFP.fragmentFP[2] + "\t" + fragmentFP.fragmentFP[3] + "\t" + fragmentFP.fragmentFP[4] ;
printWriter.println$S(printLine);
}
printWriter.println$S("</mmpUniqueFragments>");
});

Clazz.newMeth(C$, 'getUniqueFragmentsCount$',  function () {
return this.uniqueFragments.size$();
});
;
(function(){/*c*/var C$=Clazz.newClass(P$.MMPUniqueFragments, "MMPUniqueFragment", function(){
Clazz.newInstance(this, arguments[0],true,C$);
});

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['I',['fragmentIndex','fragmentAtoms'],'O',['fragmentFP','String[]']]]

Clazz.newMeth(C$, 'c$$S',  function (fragmentID) {
;C$.$init$.apply(this);
this.fragmentIndex=this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentIndexes++;
this.fragmentAtoms=this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].idCodeParser.getAtomCount$S(fragmentID) - 1;
this.fragmentFP=null;
}, 1);

Clazz.newMeth(C$, 'c$$I$SA',  function (fragmentAtoms, fragmentFP) {
;C$.$init$.apply(this);
this.fragmentIndex=this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentIndexes++;
this.fragmentAtoms=fragmentAtoms;
this.fragmentFP=fragmentFP;
}, 1);

Clazz.newMeth(C$, 'addFP$S',  function (fragmentID) {
if (this.fragmentFP == null ) {
this.fragmentFP=Clazz.array(String, [5]);
this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].idCodeParser.parse$com_actelion_research_chem_StereoMolecule$S(this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule, fragmentID);
this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.ensureHelperArrays$I(7);
if (this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragment == null ) {
this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragment=Clazz.new_([this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAllAtoms$(), this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAllBonds$()],$I$(1,1).c$$I$I);
}var atomList=Clazz.array(Integer.TYPE, [this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtoms$()]);
var atomMask=Clazz.array(Boolean.TYPE, [this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtoms$()]);
var atomMap=Clazz.array(Integer.TYPE, [this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtoms$()]);
$I$(2).fill$ZA$Z(atomMask, false);
var rGroupCounter=0;
for (var atom=0; atom < this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtoms$(); atom++) {
if (this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtomicNo$I(atom) == 0 || this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getAtomicNo$I(atom) >= 142 ) {
atomList[rGroupCounter]=atom;
atomMask[atom]=true;
++rGroupCounter;
}}
var min=0;
var max=rGroupCounter;
for (var sphere=0; sphere < 5; sphere++) {
var newMax=max;
for (var i=min; i < max; i++) {
var atom=atomList[i];
for (var j=0; j < this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getConnAtoms$I(atom); j++) {
var connAtom=this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.getConnAtom$I$I(atom, j);
if (!atomMask[connAtom]) {
atomMask[connAtom]=true;
atomList[newMax++]=connAtom;
}}
}
min=max;
max=newMax;
this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.copyMoleculeByAtoms$com_actelion_research_chem_ExtendedMolecule$ZA$Z$IA(this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragment, atomMask, true, atomMap);
for (var i=0; i < atomMap.length; i++) {
if (atomMap[i] != -1) {
if (this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragmentMolecule.isAromaticAtom$I(atomMap[i])) {
this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragment.setAtomQueryFeature$I$J$Z(i, 2, true);
}}}
this.fragmentFP[sphere]=this.b$['com.actelion.research.chem.mmp.MMPUniqueFragments'].fragment.getIDCode$();
}
}}, p$1);

Clazz.newMeth(C$, 'getFragmentIndex$',  function () {
return this.fragmentIndex;
});

Clazz.newMeth(C$, 'getFragmentAtoms$',  function () {
return this.fragmentAtoms;
});

Clazz.newMeth(C$, 'getFragmentFP$',  function () {
return this.fragmentFP;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-02 02:55:50 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
