(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'StringBuffer','com.actelion.research.chem.AtomFunctionAnalyzer']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "AtomTypeCalculator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['cAtomicNoCode','short[]','+cSimpleAtomicNoCode','cAtomicNoCodeString','String[]','+cSimpleAtomicNoCodeString']]]

Clazz.newMeth(C$, 'getAtomicNoCodeString$I',  function (atomicNoCode) {
return C$.cAtomicNoCodeString[atomicNoCode];
}, 1);

Clazz.newMeth(C$, 'getSimpleAtomicNoCodeString$I',  function (atomicNoCode) {
return C$.cSimpleAtomicNoCodeString[atomicNoCode];
}, 1);

Clazz.newMeth(C$, 'printAtomType$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
try {
C$.printAtomType$J(C$.getAtomType$com_actelion_research_chem_StereoMolecule$I(mol, atom));
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
System.out.println$O(e);
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getHeaderString$I',  function (mode) {
var sb=Clazz.new_($I$(1,1));
sb.append$S("AtomicNo-Code");
if ((mode & 2) != 0) sb.append$S("\tRingsize");
if ((mode & 1) != 0) sb.append$S("\tRingmember");
if ((mode & 4) != 0) sb.append$S("\tAromatic");
if ((mode & 8) != 0) sb.append$S("\tAllylic");
if ((mode & 16) != 0) sb.append$S("\tStabilized");
if ((mode & 4096) != 0) sb.append$S("\tCharged\tAmpholytic");
if ((mode & 8192) != 0) sb.append$S("\tRingCount");
for (var i=1; i <= 4; i++) {
if ((mode & 32) != 0) sb.append$S("\tConnBondType" + i);
if ((mode & 128) != 0) sb.append$S("\tConnAtomType" + i);
 else if ((mode & 64) != 0) sb.append$S("\tSimpleConnAtomType" + i);
if ((mode & 256) != 0) sb.append$S("\tConnMoreNeighbours" + i);
if ((mode & 1024) != 0) sb.append$S("\tConnIsSmallRingMember" + i);
if ((mode & 2048) != 0) sb.append$S("\tConnIsAromatic" + i);
if ((mode & 16384) != 0) sb.append$S("\tConnIsStabilized" + i);
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'getTypeString$J$I',  function (type, mode) {
var sb=Clazz.new_($I$(1,1));
sb.append$S(C$.getAtomicNoCodeString$I(Long.$ival((Long.$and(type,15)))));
if ((mode & 2) != 0) {
var ringSize=(Long.$sr((Long.$and(type,112)),4));
if (Long.$ne(ringSize,0 )) (ringSize=Long.$add(ringSize,(2)));
sb.append$S("\t" + Long.$s(ringSize));
}if ((mode & 1) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(type,64)),0 )) ? "yes" : "no"));
if ((mode & 4) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(type,1024)),0 )) ? "yes" : "no"));
if ((mode & 8) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(type,2048)),0 )) ? "yes" : "no"));
if ((mode & 16) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(type,4096)),0 )) ? "yes" : "no"));
if ((mode & 4096) != 0) {
sb.append$S("\t" + ((Long.$ne((Long.$and(type,8192)),0 )) ? "yes" : "no"));
sb.append$S("\t" + ((Long.$ne((Long.$and(type,16384)),0 )) ? "yes" : "no"));
}if ((mode & 8192) != 0) {
var ringCount=Long.$sr((Long.$and(type,896)),7);
sb.append$S("\t" + Long.$s(ringCount));
}(type=Long.$sr(type,(15)));
for (var i=1; i <= 4; i++) {
var neighbourType=Long.$and(type,2047);
if (Long.$ne(neighbourType,0 )) {
if ((mode & 32) != 0) sb.append$S("\t" + (Long.$s(Long.$sr((Long.$and(neighbourType,48)),4))));
if ((mode & 128) != 0) sb.append$S("\t" + C$.getAtomicNoCodeString$I(Long.$ival((Long.$and(neighbourType,15)))));
 else if ((mode & 64) != 0) sb.append$S("\t" + C$.getSimpleAtomicNoCodeString$I(Long.$ival((Long.$and(neighbourType,15)))));
if ((mode & 256) != 0) {
var otherNeighbours=(Long.$sr((Long.$and(neighbourType,192)),6));
if ((mode & 512) == 0) sb.append$S("\t" + (Long.$eq(otherNeighbours,0 ) ? "no" : "yes"));
 else sb.append$S("\t" + Long.$s(otherNeighbours));
}if ((mode & 1024) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(neighbourType,256)),0 )) ? "yes" : "no"));
if ((mode & 2048) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(neighbourType,512)),0 )) ? "yes" : "no"));
if ((mode & 16384) != 0) sb.append$S("\t" + ((Long.$ne((Long.$and(neighbourType,1024)),0 )) ? "yes" : "no"));
}(type=Long.$sr(type,(11)));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'toString$J',  function (type) {
return C$.toString$J$I(type, 32702);
}, 1);

Clazz.newMeth(C$, 'toString$J$I',  function (type, mode) {
var sb=Clazz.new_($I$(1,1));
sb.append$S(C$.getAtomicNoCodeString$I(Long.$ival((Long.$and(type,15)))) + ":");
if ((mode & 4096) != 0) {
if (Long.$ne((Long.$and(type,8192)),0 )) sb.append$S("Chg");
if (Long.$ne((Long.$and(type,16384)),0 )) sb.append$S("Amp");
}if ((mode & 8192) != 0) {
var ringCount=Long.$sr((Long.$and(type,896)),7);
sb.append$S("Rc" + Long.$s(ringCount));
}if ((mode & 2) != 0) {
var ringSize=(Long.$sr((Long.$and(type,112)),4));
if (Long.$ne(ringSize,0 )) (ringSize=Long.$add(ringSize,(2)));
sb.append$S("Rs" + Long.$s(ringSize));
}if ((mode & 4) != 0 && Long.$ne((Long.$and(type,1024)),0 ) ) sb.append$S("Ar");
if ((mode & 8) != 0 && Long.$ne((Long.$and(type,2048)),0 ) ) sb.append$S("Al");
if ((mode & 16) != 0 && Long.$ne((Long.$and(type,4096)),0 ) ) sb.append$S("St");
(type=Long.$sr(type,(15)));
for (var j=0; j < 4; j++) {
if (Long.$eq(type,0 )) break;
if ((mode & 32) != 0) {
var bondType=Long.$ival((Long.$sr((Long.$and(type,48)),4)));
switch (bondType) {
case 0:
sb.append$S(" *");
break;
case 1:
sb.append$S(" -");
break;
case 2:
sb.append$S(" =");
break;
case 3:
sb.append$S(" #");
break;
}
}sb.append$S("{");
if ((mode & 128) != 0) sb.append$S(C$.getAtomicNoCodeString$I(Long.$ival((Long.$and(type,15)))) + ":");
 else if ((mode & 64) != 0) sb.append$S(C$.getSimpleAtomicNoCodeString$I(Long.$ival((Long.$and(type,15)))) + ":");
var neighbours=Long.$add((Long.$sr((Long.$and(type,192)),6)),1);
if ((mode & 256) != 0) sb.append$S("N" + Long.$s(neighbours));
if ((mode & 1024) != 0 && Long.$ne((Long.$and(type,256)),0 ) ) sb.append$S("Ri");
if ((mode & 2048) != 0 && Long.$ne((Long.$and(type,512)),0 ) ) sb.append$S("Ar");
if ((mode & 16384) != 0 && Long.$ne((Long.$and(type,1024)),0 ) ) sb.append$S("St");
sb.append$S("}");
(type=Long.$sr(type,(11)));
}
return sb.toString();
}, 1);

Clazz.newMeth(C$, 'printAtomType$J',  function (type) {
System.out.println$S(C$.toString$J(type));
}, 1);

Clazz.newMeth(C$, 'getAtomType$com_actelion_research_chem_StereoMolecule$I',  function (mol, atom) {
return C$.getAtomType$com_actelion_research_chem_StereoMolecule$I$I(mol, atom, 32702);
}, 1);

Clazz.newMeth(C$, 'getAtomType$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, atom, mode) {
mol.ensureHelperArrays$I(7);
var neighbourType=Clazz.array(Long.TYPE, [mol.getConnAtoms$I(atom)]);
var neighbourCount=0;
for (var i=0; i < mol.getConnAtoms$I(atom); i++) {
var connAtom=mol.getConnAtom$I$I(atom, i);
if (mol.getAtomicNo$I(connAtom) == 1) continue;
var connType=0;
if ((mode & 32) != 0) {
var connBondOrder=mol.getConnBondOrder$I$I(atom, i);
if (mode == 32190) {
if (Long.$lt(connBondOrder,3 ) && mol.isDelocalizedBond$I(mol.getConnBond$I$I(atom, i))  && mol.getAtomPi$I(atom) == 1 ) connBondOrder=0;
} else {
if (Long.$lt(connBondOrder,3 ) && mol.isAromaticBond$I(mol.getConnBond$I$I(atom, i)) ) connBondOrder=0;
}(connType=Long.$or(connType,((Long.$sl(connBondOrder,4)))));
}if ((mode & 128) != 0) {
if (C$.cAtomicNoCode[mol.getAtomicNo$I(connAtom)] == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["unsupported atomicNo:" + mol.getAtomicNo$I(connAtom)]);
(connType=Long.$add(connType,(C$.cAtomicNoCode[mol.getAtomicNo$I(connAtom)])));
} else if ((mode & 64) != 0) {
if (C$.cSimpleAtomicNoCode[mol.getAtomicNo$I(connAtom)] == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["unsupported atomicNo:" + mol.getAtomicNo$I(connAtom)]);
(connType=Long.$add(connType,(C$.cSimpleAtomicNoCode[mol.getAtomicNo$I(connAtom)])));
}if ((mode & 256) != 0) {
var otherNeighbours=mol.getConnAtoms$I(connAtom) - 1;
if (otherNeighbours > 3) otherNeighbours=3;
if ((mode & 512) == 0) if (otherNeighbours > 1) otherNeighbours=1;
(connType=Long.$or(connType,((otherNeighbours << 6))));
}if ((mode & 1024) != 0) if (mol.isSmallRingAtom$I(connAtom)) (connType=Long.$or(connType,(256)));
if ((mode & 2048) != 0) if (mol.isAromaticAtom$I(connAtom)) (connType=Long.$or(connType,(512)));
if ((mode & 16384) != 0) if (mol.isStabilizedAtom$I(connAtom)) (connType=Long.$or(connType,(1024)));
var index=0;
while (Long.$lt(connType,neighbourType[index] ))++index;

for (var j=i; j > index; j--) neighbourType[j]=neighbourType[j - 1];

neighbourType[index]=connType;
++neighbourCount;
}
if (neighbourCount > 4) neighbourCount=4;
var atomType=0;
for (var i=0; i < neighbourCount; i++) {
(atomType=Long.$sl(atomType,(11)));
(atomType=Long.$or(atomType,(neighbourType[i])));
}
(atomType=Long.$sl(atomType,(15)));
if (C$.cAtomicNoCode[mol.getAtomicNo$I(atom)] == -1) throw Clazz.new_(Clazz.load('Exception').c$$S,["unsupported atomicNo:" + mol.getAtomicNo$I(atom)]);
(atomType=Long.$or(atomType,(C$.cAtomicNoCode[mol.getAtomicNo$I(atom)])));
if ((mode & 2) != 0) {
var ringSize=mol.getAtomRingSize$I(atom);
if (ringSize > 9) ringSize=9;
if (ringSize > 2) ringSize-=2;
(atomType=Long.$or(atomType,((ringSize << 4))));
} else if ((mode & 1) != 0) if (mol.isSmallRingAtom$I(atom)) (atomType=Long.$or(atomType,(64)));
if ((mode & 4) != 0) if (mol.isAromaticAtom$I(atom)) (atomType=Long.$or(atomType,(1024)));
if ((mode & 8) != 0) if (mol.isAllylicAtom$I(atom)) (atomType=Long.$or(atomType,(2048)));
if ((mode & 16) != 0) if (mol.isStabilizedAtom$I(atom)) (atomType=Long.$or(atomType,(4096)));
if ((mode & 4096) != 0) {
if ($I$(2).hasUnbalancedAtomCharge$com_actelion_research_chem_StereoMolecule$I(mol, atom)) (atomType=Long.$or(atomType,(8192)));
if ($I$(2).isBasicNitrogen$com_actelion_research_chem_StereoMolecule$I(mol, atom)) {
for (var i=0; i < mol.getAtoms$(); i++) {
if ($I$(2).isAcidicOxygen$com_actelion_research_chem_StereoMolecule$I(mol, i)) {
(atomType=Long.$or(atomType,(16384)));
break;
}}
}}if ((mode & 8192) != 0) {
var ringCount=mol.getAtomRingCount$I$I(atom, 10);
(atomType=Long.$or(atomType,((Long.$sl(ringCount,7)))));
}return atomType;
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.cAtomicNoCode=Clazz.array(Short.TYPE, -1, [-1, -1, -1, 0, 0, 1, 2, 3, 4, 5, -1, 0, 0, 0, 6, 7, 8, 9, -1, 0, 0, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 1, 11, 11, 12, 13, -1, 0, 0, 10, 10, 10, 10, 10, 10, 10, 10, 10, 10, 0, 0, 0, 11, 14, -1, 0, 0, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 10, 10, 10, 10, 10, 10, 10, 10, 1, 1, 1, 1, -1, -1, -1, -1, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]);
C$.cSimpleAtomicNoCode=Clazz.array(Short.TYPE, -1, [-1, -1, -1, 0, 0, 0, 2, 5, 5, 5, -1, 0, 0, 0, 0, 9, 9, 9, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 9, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]);
C$.cAtomicNoCodeString=Clazz.array(String, -1, ["MainGroupMetal", "Boron", "Carbon", "Nitrogen", "Oxygen", "Fluor", "Silicon", "Phosphorous", "Sulfur", "Chlorine", "Transition Metal", "MainGroupNonMetal", "Selene", "Bromine", "Iodine", "LanthanideOrActinide"]);
C$.cSimpleAtomicNoCodeString=Clazz.array(String, -1, ["Metal", "-", "Carbon", "-", "-", "Small Hetero", "-", "-", "-", "Large Hetero", "-", "-", "-", "-", "-", "-"]);
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-02 02:55:51 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
