(function(){var P$=Clazz.newPackage("com.actelion.research.chem"),I$=[[0,'com.actelion.research.chem.Molecule3D','java.util.HashSet','java.util.ArrayList','java.util.Collections','java.io.ByteArrayOutputStream','java.io.ObjectOutputStream','java.util.Base64','java.io.ObjectInputStream','java.io.ByteArrayInputStream']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "Molecule3DFunctions");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

Clazz.newMeth(C$, 'removeAllAtomsWithoutNeighbours$com_actelion_research_chem_Molecule3D',  function (mol) {
var molecule3D=Clazz.new_($I$(1,1).c$$com_actelion_research_chem_Molecule3D,[mol]);
molecule3D.ensureHelperArrays$I(7);
var hsAt2Del=Clazz.new_($I$(2,1));
for (var i=0; i < molecule3D.getAllAtoms$(); i++) {
if (molecule3D.getConnAtoms$I(i) == 0) hsAt2Del.add$O(Integer.valueOf$I(i));
}
var liAt2Del=Clazz.new_($I$(3,1).c$$java_util_Collection,[hsAt2Del]);
$I$(4).sort$java_util_List(liAt2Del);
$I$(4).reverse$java_util_List(liAt2Del);
for (var at, $at = liAt2Del.iterator$(); $at.hasNext$()&&((at=($at.next$())),1);) {
molecule3D.deleteAtom$I((at).$c());
}
molecule3D.ensureHelperArrays$I(7);
return molecule3D;
}, 1);

Clazz.newMeth(C$, 'toStringSerialized$com_actelion_research_chem_Molecule3D',  function (mol) {
var byteArrayOutputStream=Clazz.new_($I$(5,1));
var oos=Clazz.new_($I$(6,1).c$$java_io_OutputStream,[byteArrayOutputStream]);
oos.writeObject$O(mol);
oos.close$();
return $I$(7).getEncoder$().encodeToString$BA(byteArrayOutputStream.toByteArray$());
}, 1);

Clazz.newMeth(C$, 'readSerialized$S',  function (serMol) {
var arrByte=$I$(7).getDecoder$().decode$S(serMol);
var is=Clazz.new_([Clazz.new_($I$(9,1).c$$BA,[arrByte])],$I$(8,1).c$$java_io_InputStream);
var molecule3D=is.readObject$();
is.close$();
return molecule3D;
}, 1);

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-02 02:55:47 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
