(function(){var P$=Clazz.newPackage("com.actelion.research.chem.inchi"),p$1={},I$=[[0,'com.actelion.research.chem.StereoMolecule','com.actelion.research.chem.SmilesParser','com.actelion.research.chem.IsomericSmilesCreator','com.actelion.research.chem.inchi.InChIJS','com.actelion.research.chem.inchi.InChIJNI1','com.actelion.research.chem.MolfileParser','com.actelion.research.chem.MolfileCreator','com.actelion.research.chem.Molecule','java.util.HashMap','java.util.Arrays','com.actelion.research.chem.coords.CoordinateInventor']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "InChIOCL", null, null, 'org.iupac.InChIStructureProvider');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['getInchiModel','isInputInChI','getKey'],'S',['inchi'],'O',['mol','com.actelion.research.chem.StereoMolecule']]
,['Z',['isJS']]]

Clazz.newMeth(C$, 'init$',  function () {
C$.getPlatformSubclass$();
}, 1);

Clazz.newMeth(C$, 'getInChI$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getPlatformSubclass$(), [mol, null, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChI$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getPlatformSubclass$(), [null, molFileDataOrInChI, options, false]);
}, 1);

Clazz.newMeth(C$, 'getInChIFromSmiles$S$S',  function (smiles, options) {
var mol=Clazz.new_($I$(1,1));
try {
Clazz.new_($I$(2,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, smiles);
return C$.getInChI$com_actelion_research_chem_StereoMolecule$S(mol, options);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
return null;
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'getInChIKey$com_actelion_research_chem_StereoMolecule$S',  function (mol, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getPlatformSubclass$(), [mol, null, options, true]);
}, 1);

Clazz.newMeth(C$, 'getInChIKey$S$S',  function (molFileDataOrInChI, options) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getPlatformSubclass$(), [null, molFileDataOrInChI, options, true]);
}, 1);

Clazz.newMeth(C$, 'getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
try {
p$1.getOCLMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule.apply(C$.getPlatformSubclass$(), [inchi, mol]);
return true;
} catch (e) {
e.printStackTrace$();
return false;
}
}, 1);

Clazz.newMeth(C$, 'getSmilesFromInChI$S$S',  function (inchi, options) {
var mol=Clazz.new_($I$(1,1));
return (C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(inchi, mol) ? $I$(3).createSmiles$com_actelion_research_chem_StereoMolecule(mol) : null);
}, 1);

Clazz.newMeth(C$, 'getInChIModelJSON$S',  function (inchi) {
return p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(C$.getPlatformSubclass$(), [null, inchi, "model", false]);
}, 1);

Clazz.newMeth(C$, 'getPlatformSubclass$',  function () {
return (C$.isJS ? Clazz.new_($I$(4,1)) : Clazz.new_($I$(5,1)));
}, 1);

Clazz.newMeth(C$, 'getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (inputMol, molDataOrInChI, options, retKey) {
try {
if (inputMol == null  && molDataOrInChI == null  ) return null;
if (inputMol != null  && inputMol.getAllAtoms$() == 0 ) {
return "";
}options=p$1.setFieldsPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [inputMol, molDataOrInChI, options, retKey]);
if (options == null ) {
return null;
}if (this.mol != null ) molDataOrInChI=null;
if (this.inchi != null ) {
if (!this.getKey || this.inchi.length$() == 0 ) return this.inchi;
this.mol=null;
molDataOrInChI=this.inchi;
}var ret=this.getInchiImpl$com_actelion_research_chem_StereoMolecule$S$S(this.mol, molDataOrInChI, options);
if (ret != null  && options.length$() == 0  && ret.startsWith$S("InChI=")  && !ret.startsWith$S("InChI=1S/") ) {
this.reportInchicError$S("inchi C returned standard InChI without \'1S/\'! Fixing...");
ret="InChI=1S/" + ret.substring$I(8);
}return ret;
} catch (e) {
{
e = (e.getMessage$ ? e.getMessage$() : e);
}
System.err.println$S("InChIOCL exception: " + e);
return null;
}
}, p$1);

Clazz.newMeth(C$, 'reportInchicError$S',  function (msg) {
System.out.flush$();
System.err.println$S(msg);
System.err.flush$();
});

Clazz.newMeth(C$, 'setFieldsPvt$com_actelion_research_chem_StereoMolecule$S$S$Z',  function (mol, molDataOrInChI, options, getKey) {
if (options == null ) options="";
var lc=options.toLowerCase$().trim$();
var getInchiModel=(lc.indexOf$S("model") == 0);
var optionKey=(lc.indexOf$S("key") >= 0);
var inchi=this.inchi=null;
var isFixedH=(lc.indexOf$S("fixedh") >= 0);
var optionalFixedH=(lc.indexOf$S("fixedh?") >= 0);
if (lc.indexOf$S("fixedh") < 0) {
options=lc=lc.replace$CharSequence$CharSequence("standard", "");
}var inputInChI=(molDataOrInChI != null  && molDataOrInChI.startsWith$S("InChI=") );
if (!inputInChI) {
options=lc;
if (optionKey) {
options=options.replace$CharSequence$CharSequence("inchikey", "");
options=options.replace$CharSequence$CharSequence("key", "");
}}if (getInchiModel) {
optionKey=isFixedH=optionalFixedH=false;
options="";
}if (optionalFixedH) {
inchi=p$1.getInChIOptionallyFixedH$com_actelion_research_chem_StereoMolecule$S$Z$S.apply(this, [mol, molDataOrInChI, inputInChI, lc]);
mol=null;
molDataOrInChI=null;
if (inchi == null ) options=null;
} else if (inputInChI && isFixedH ) {
mol=Clazz.new_($I$(1,1));
C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(molDataOrInChI, mol);
inchi=null;
inputInChI=false;
}this.getInchiModel=getInchiModel;
this.isInputInChI=(inputInChI || inchi != null  );
this.inchi=inchi;
this.getKey=optionKey || getKey ;
this.mol=mol;
return (options == null  ? null : options.trim$());
}, p$1);

Clazz.newMeth(C$, 'getInChIOptionallyFixedH$com_actelion_research_chem_StereoMolecule$S$Z$S',  function (mol, molDataOrInChI, inputInChI, options) {
if (mol == null ) {
var useMolData=this.implementsMolDataToInChI$();
if (inputInChI) {
mol=Clazz.new_($I$(1,1));
C$.getMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule(molDataOrInChI, mol);
} else if (!useMolData) {
mol=Clazz.new_($I$(1,1));
Clazz.new_($I$(6,1)).parse$com_actelion_research_chem_StereoMolecule$S(mol, molDataOrInChI);
}if (mol != null ) {
if (useMolData) {
molDataOrInChI=Clazz.new_($I$(7,1).c$$com_actelion_research_chem_ExtendedMolecule,[mol]).getMolfile$();
mol=null;
} else {
molDataOrInChI=null;
}}}var fxd=p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options.replace$C$C("?", " "), false]);
if (fxd == null ) {
return null;
}options=options.replace$CharSequence$CharSequence("fixedh?", "");
var std=p$1.getInchiPvt$com_actelion_research_chem_StereoMolecule$S$S$Z.apply(this, [mol, molDataOrInChI, options, false]);
return (fxd.indexOf$S("/f") < 0 ? std : fxd);
}, p$1);

Clazz.newMeth(C$, 'getOCLMoleculeFromInChI$S$com_actelion_research_chem_StereoMolecule',  function (inchi, mol) {
this.initializeInchiModel$S(inchi);
var nAtoms=this.getNumAtoms$();
var nBonds=this.getNumBonds$();
var nStereo=this.getNumStereo0D$();
for (var i=0; i < nAtoms; i++) {
this.setAtom$I(i);
var sym=this.getElementType$();
var atom=mol.addAtom$I($I$(8).getAtomicNoFromLabel$S(sym));
mol.setAtomCharge$I$I(atom, this.getCharge$());
}
var doubleBonds=Clazz.new_($I$(9,1));
for (var i=0; i < nBonds; i++) {
this.setBond$I(i);
var i1=this.getIndexOriginAtom$();
var i2=this.getIndexTargetAtom$();
var bt=C$.getOCLSimpleBondType$S(this.getInchiBondType$());
var bond=mol.addBond$I$I$I(i1, i2, bt);
switch (bt) {
case 1:
break;
case 2:
doubleBonds.put$O$O(Integer.valueOf$I(C$.getBondKey$I$I(i1, i2)), Integer.valueOf$I(bond));
break;
}
}
for (var i=0; i < nStereo; i++) {
this.setStereo0D$I(i);
var centerAtom=this.getCenterAtom$();
var neighbors=this.getNeighbors$();
if (neighbors.length != 4) continue;
var p=-1;
switch (this.getStereoType$()) {
case "TETRAHEDRAL":
p=C$.getOCLAtomParity$S$Z(this.getParity$(), C$.isOrdered$IA(neighbors));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "DOUBLEBOND":
var ib=C$.findDoubleBond$java_util_Map$IA(doubleBonds, neighbors);
if (ib < 0) {
System.err.println$S("InChIJNI cannot find double bond for atoms " + $I$(10).toString$IA(neighbors));
continue;
}p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] < neighbors[3]));
mol.setBondParity$I$I$Z(ib, p, false);
break;
case "ALLENE":
p=C$.getOCLBondParity$S$Z(this.getParity$(), (neighbors[0] > neighbors[3]));
mol.setAtomParity$I$I$Z(centerAtom, p, false);
break;
case "NONE":
continue;
}
}
mol.setParitiesValid$I(0);
mol.setParitiesPreset$Z(true);
Clazz.new_($I$(11,1).c$$I,[64]);
mol.ensureHelperArrays$I(31);
}, p$1);

Clazz.newMeth(C$, 'getBondKey$I$I',  function (i1, i2) {
return (Math.min(i1, i2) << 16) + Math.max(i1, i2);
}, 1);

Clazz.newMeth(C$, 'findDoubleBond$java_util_Map$IA',  function (doubleBonds, neighbors) {
var ib=doubleBonds.get$O(Integer.valueOf$I(C$.getBondKey$I$I(neighbors[1], neighbors[2])));
return (ib == null  ? -1 : ib.intValue$());
}, 1);

Clazz.newMeth(C$, 'getOCLBondParity$S$Z',  function (parity, isReversed) {
switch (parity) {
case "ODD":
return (isReversed ? 2 : 1);
case "EVEN":
return (isReversed ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'isOrdered$IA',  function (list) {
var ok=true;
for (var i=0; i < list.length - 1; i++) {
var l1=list[i];
for (var j=i + 1; j < list.length; j++) {
var l2=list[j];
if (l1 > l2) {
list[j]=l1;
l1=list[i]=l2;
ok=!ok;
}}
}
return ok;
}, 1);

Clazz.newMeth(C$, 'getOCLAtomParity$S$Z',  function (parity, isOrdered) {
var isOdd=false;
switch (parity) {
case "ODD":
isOdd=true;
case "EVEN":
return (!!(isOdd ^ isOrdered) ? 1 : 2);
case "UNKNOWN":
return 3;
case "NONE":
default:
return 0;
}
}, 1);

Clazz.newMeth(C$, 'getOCLSimpleBondType$S',  function (type) {
switch (type) {
case "NONE":
return 0;
case "ALTERN":
return 8;
case "DOUBLE":
return 2;
case "TRIPLE":
return 4;
case "SINGLE":
default:
return 1;
}
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.isJS=true ||Boolean.FALSE.booleanValue$();
};

Clazz.newMeth(C$);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-02 02:55:50 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
