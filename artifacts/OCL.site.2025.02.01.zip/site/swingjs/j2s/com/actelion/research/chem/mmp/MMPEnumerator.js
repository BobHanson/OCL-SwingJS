(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'java.util.ArrayList','java.util.HashMap']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPEnumerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mMPEnumeration','java.util.HashMap']]]

Clazz.newMeth(C$, 'getMMPEnumeration$',  function () {
return this.mMPEnumeration;
});

Clazz.newMeth(C$, 'addMMP$S$SA',  function (values, data) {
var datas=Clazz.new_($I$(1,1));
if (this.mMPEnumeration.containsKey$O(values)) {
datas=this.mMPEnumeration.get$O(values);
}datas.add$O(data);
this.mMPEnumeration.put$O$O(values, datas);
}, p$1);

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'c$$IA$java_util_HashMap$java_util_HashMap$S',  function (combination, keysHash1, keysHash2, version) {
;C$.$init$.apply(this);
this.mMPEnumeration=Clazz.new_($I$(2,1));
if ((combination[0] == combination[1] && keysHash1 != null  ) || (combination[0] != combination[1] && keysHash1 != null   && keysHash2 != null  ) ) {
if (combination[0] != combination[1]) {
var it=keysHash1.keySet$().iterator$();
while (it.hasNext$()){
var keysString=it.next$();
if (keysHash2.containsKey$O(keysString)) {
var valuesList1=keysHash1.get$O(keysString);
var valuesList2=keysHash2.get$O(keysString);
var cutType=Integer.toString$I(keysString.split$S("\t").length);
for (var values1, $values1 = valuesList1.iterator$(); $values1.hasNext$()&&((values1=($values1.next$())),1);) {
for (var values2, $values2 = valuesList2.iterator$(); $values2.hasNext$()&&((values2=($values2.next$())),1);) {
p$1.addMMP$S$SA.apply(this, [Integer.toString$I(values1[0]) + "\t" + Integer.toString$I(combination[0]) + "\t" + Integer.toString$I(values2[0]) + "\t" + Integer.toString$I(combination[1]) + "\t" + cutType , Clazz.array(String, -1, [Integer.toString$I(values1[1]), Integer.toString$I(values2[1]), keysString])]);
if (version === "1.0" ) p$1.addMMP$S$SA.apply(this, [Integer.toString$I(values2[0]) + "\t" + Integer.toString$I(combination[1]) + "\t" + Integer.toString$I(values1[0]) + "\t" + Integer.toString$I(combination[0]) + "\t" + cutType , Clazz.array(String, -1, [Integer.toString$I(values2[1]), Integer.toString$I(values1[1]), keysString])]);
}
}
}}
} else {
var it=keysHash1.keySet$().iterator$();
while (it.hasNext$()){
var keysString=it.next$();
var valuesList=keysHash1.get$O(keysString);
var numberOfCuts=Integer.toString$I(keysString.split$S("\t").length);
if (valuesList.size$() > 1) {
for (var i=0; i < valuesList.size$() - 1; i++) {
for (var j=i + 1; j < valuesList.size$(); j++) {
var values1=valuesList.get$I(i);
var values2=valuesList.get$I(j);
if (values1[0] != values2[0]) {
p$1.addMMP$S$SA.apply(this, [Integer.toString$I(values1[0]) + "\t" + Integer.toString$I(combination[0]) + "\t" + Integer.toString$I(values2[0]) + "\t" + Integer.toString$I(combination[1]) + "\t" + numberOfCuts , Clazz.array(String, -1, [Integer.toString$I(values1[1]), Integer.toString$I(values2[1]), keysString])]);
p$1.addMMP$S$SA.apply(this, [Integer.toString$I(values2[0]) + "\t" + Integer.toString$I(combination[1]) + "\t" + Integer.toString$I(values1[0]) + "\t" + Integer.toString$I(combination[0]) + "\t" + numberOfCuts , Clazz.array(String, -1, [Integer.toString$I(values2[1]), Integer.toString$I(values1[1]), keysString])]);
}}
}
}}
}}}, 1);
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-31 13:45:28 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
