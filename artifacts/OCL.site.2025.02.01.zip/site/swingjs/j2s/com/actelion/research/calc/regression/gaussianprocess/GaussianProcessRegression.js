(function(){var P$=Clazz.newPackage("com.actelion.research.calc.regression.gaussianprocess"),I$=[[0,'com.actelion.research.calc.regression.gaussianprocess.ParameterGaussianProcess','smile.clustering.KMeans','smile.math.Math','smile.math.kernel.GaussianKernel','smile.regression.GaussianProcessRegression','com.actelion.research.calc.Matrix']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "GaussianProcessRegression", null, 'com.actelion.research.calc.regression.ARegressionMethod', 'Comparable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['gaussianProcessRegression','smile.regression.GaussianProcessRegression']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(Clazz.new_($I$(1,1)));
try {
System.setProperty$S$S("smile.threads", "1");
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
}, 1);

Clazz.newMeth(C$, 'c$$com_actelion_research_calc_regression_gaussianprocess_ParameterGaussianProcess',  function (parameterGaussianProcess) {
Clazz.super_(C$, this);
this.setParameterRegressionMethod$com_actelion_research_calc_regression_ParameterRegressionMethod(parameterGaussianProcess);
}, 1);

Clazz.newMeth(C$, 'setLambda$D',  function (lambda) {
this.getParameter$().setLambda$D(lambda);
});

Clazz.newMeth(C$, 'createModel$com_actelion_research_util_datamodel_ModelXYIndex',  function (modelXYIndexTrain) {
var YHat=null;
try {
var parameterGaussianProcess=this.getParameter$();
var rows=modelXYIndexTrain.X.rows$();
if (modelXYIndexTrain.Y.cols$() != 1) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Only one column for y is allowed!"]);
} else if (rows < 3) {
throw Clazz.new_(Clazz.load('RuntimeException').c$$S,["Unsufficient number of objects for regression."]);
}var X=modelXYIndexTrain.X.getArray$();
var y=modelXYIndexTrain.Y.getColAsDouble$I(0);
var k=(rows/10|0);
if (rows > 1000) {
k=(rows/100|0);
} else if (rows > 10000) {
k=(rows/1000|0);
}if (k < 3) {
k=3;
}var kmeans=Clazz.new_($I$(2,1).c$$DAA$I$I,[X, k, 10]);
var centers=kmeans.centroids$();
var r0=0.0;
for (var l=0; l < centers.length; l++) {
for (var j=0; j < l; j++) {
r0+=$I$(3).distance$DA$DA(centers[l], centers[j]);
}
}
r0/=(2 * centers.length);
var mercerKernel=Clazz.new_($I$(4,1).c$$D,[r0]);
this.gaussianProcessRegression=Clazz.new_([X, y, mercerKernel, parameterGaussianProcess.getLambda$()],$I$(5,1).c$$OA$DA$smile_math_kernel_MercerKernel$D);
YHat=this.calculateYHat$com_actelion_research_calc_Matrix(modelXYIndexTrain.X);
} catch (e) {
if (Clazz.exceptionOf(e,"Exception")){
e.printStackTrace$();
} else {
throw e;
}
}
return YHat;
});

Clazz.newMeth(C$, 'calculateYHat$com_actelion_research_calc_Matrix',  function (X) {
var arrY=Clazz.array(Double.TYPE, [X.rows$()]);
for (var i=0; i < X.rows$(); i++) {
var arrRow=X.getRow$I(i);
var y=this.gaussianProcessRegression.predict$O(arrRow);
arrY[i]=y;
}
return Clazz.new_($I$(6,1).c$$Z$DA,[false, arrY]);
});

Clazz.newMeth(C$, 'calculateYHat$DA',  function (arrRow) {
var yHat;
{
yHat=this.gaussianProcessRegression.predict$O(arrRow);
}return yHat;
});

Clazz.newMeth(C$, ['compareTo$com_actelion_research_calc_regression_gaussianprocess_GaussianProcessRegression','compareTo$O'],  function (o) {
return this.getParameter$().compareTo$com_actelion_research_calc_regression_ParameterRegressionMethod(o.getParameter$());
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-31 13:45:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
