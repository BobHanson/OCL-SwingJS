(function(){var P$=Clazz.newPackage("com.actelion.research.chem.mmp"),p$1={},I$=[[0,'java.util.HashMap','com.actelion.research.chem.mmp.MMPReader']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "MMPServices");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['O',['mmpReaders','java.util.Map']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
this.mmpReaders=Clazz.new_($I$(1,1));
}, 1);

Clazz.newMeth(C$, 'verifyDatasetname$S',  function (datasetName) {
return this.mmpReaders.containsKey$O(datasetName);
}, p$1);

Clazz.newMeth(C$, 'readMMPFile$java_io_BufferedReader$Z',  function (br, verbose) {
var mmpReader=Clazz.new_($I$(2,1).c$$java_io_BufferedReader$Z,[br, verbose]);
var datasetName=mmpReader.getWhat$S("datasetName");
this.mmpReaders.put$O$O(datasetName, mmpReader);
return datasetName;
});

Clazz.newMeth(C$, 'getChemicalSpaceSize$S$S',  function (datasetName, key) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.getChemicalSpaceSize$S$SA(datasetName, Clazz.array(String, -1, [key]));
}return -1;
});

Clazz.newMeth(C$, 'getChemicalSpaceSize$S$SA',  function (datasetName, keys) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getChemicalSpaceSize$SA(keys);
}return -1;
});

Clazz.newMeth(C$, 'getChemicalSpace$S$SA$S$S',  function (datasetName, keys, value, dataField) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getChemicalSpace$SA$S$S(keys, value, dataField);
}return null;
});

Clazz.newMeth(C$, 'getMMPsDWAR$S$S$SA$S$S$I$java_util_List',  function (datasetName, idCode, keys, value1, value2, replacementSize, properties) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getMMPsDWAR$S$SA$S$S$I$java_util_List(idCode, keys, value1, value2, replacementSize, properties);
}return null;
});

Clazz.newMeth(C$, 'getChemicalSpaceDWAR$S$S$SA$S',  function (datasetName, idCode, keys, dataField) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getChemicalSpaceDWAR$S$SA$S(idCode, keys, dataField);
}return null;
});

Clazz.newMeth(C$, 'getTransformationsSize$S$S$I$I',  function (datasetName, value1, minAtoms, maxAtoms) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getTransformationsSize$S$I$I(value1, minAtoms, maxAtoms);
}return -1;
});

Clazz.newMeth(C$, 'getTransformationsTable$S$SA$S$I$I',  function (datasetName, keys, value1, minAtoms, maxAtoms) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).transformationsListToTable$SA$S$I$I(keys, value1, minAtoms, maxAtoms);
}return null;
});

Clazz.newMeth(C$, 'getTransformationsJSON$S$S$SA$S$I$I$S',  function (datasetName, idCode, keys, value1, minAtoms, maxAtoms, sortBy) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getTransformationsJSON$S$SA$S$I$I$S(idCode, keys, value1, minAtoms, maxAtoms, sortBy);
}return null;
});

Clazz.newMeth(C$, 'getTransformationsDWAR$S$S$SA$S$I$I$I$java_util_List',  function (datasetName, idCode, keys, value1, minAtoms, maxAtoms, environmentSize, properties) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getTransformationsDWAR$S$SA$S$I$I$Integer$java_util_List(idCode, keys, value1, minAtoms, maxAtoms, Integer.valueOf$I(environmentSize), properties);
}return null;
});

Clazz.newMeth(C$, 'getIDCodeFromMolName$S$S',  function (datasetName, molName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getIDCodeFromMolName$S(molName);
}return null;
});

Clazz.newMeth(C$, 'getDataFields$S',  function (datasetName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getDataFields$S("fieldName");
}return null;
});

Clazz.newMeth(C$, 'getLongDataFields$S',  function (datasetName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getDataFields$S("longFieldName");
}return null;
});

Clazz.newMeth(C$, 'getCategoryNames$S',  function (datasetName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getDataFields$S("categoryName");
}return null;
});

Clazz.newMeth(C$, 'getPercentiles5$S',  function (datasetName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getDataFields$S("percentile5");
}return null;
});

Clazz.newMeth(C$, 'getPercentiles95$S',  function (datasetName) {
if (p$1.verifyDatasetname$S.apply(this, [datasetName])) {
return this.mmpReaders.get$O(datasetName).getDataFields$S("percentile95");
}return null;
});

Clazz.newMeth(C$, 'getDatasetInformations$java_util_ArrayList',  function (datasetNames) {
var retVal="";
for (var datasetName, $datasetName = datasetNames.iterator$(); $datasetName.hasNext$()&&((datasetName=($datasetName.next$())),1);) {
if (this.mmpReaders.containsKey$O(datasetName)) {
var date=this.mmpReaders.get$O(datasetName).getWhat$S("date");
var numberOfMolecules=this.mmpReaders.get$O(datasetName).getWhat$S("numberOfMolecules");
var randomMoleculeName=this.mmpReaders.get$O(datasetName).getWhat$S("randomMoleculeName");
if (retVal !== "" ) retVal+="\n";
retVal+=datasetName + "\t" + numberOfMolecules + "\t" + date + "\t" + randomMoleculeName ;
}}
return retVal;
});
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-31 13:45:28 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
