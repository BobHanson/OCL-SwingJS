(function(){var P$=Clazz.newPackage("com.actelion.research.calc"),p$1={},I$=[[0,'java.awt.Point','Runtime','java.util.concurrent.Executors',['com.actelion.research.calc.SelfOrganizedMap','.SOMWorker'],'java.awt.Rectangle','java.util.concurrent.CountDownLatch']],I$0=I$[0],$I$=function(i,n){return((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "SelfOrganizedMap", function(){
Clazz.newInstance(this, arguments,0,C$);
}, 'com.actelion.research.calc.DataProcessor');
C$.$classes$=[['SOMWorker',2]];

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['Z',['mFindBestMatchQuickly'],'D',['mMaxRange','mDiagonal'],'I',['mNX','mNY','mMode','mCycle','mCyclesPerNode','mConstantInfluenceCycles','mThreadCount','mInputVectorCount','mInputVectorIndex','mCorrectQuickBestMatches'],'O',['mController','com.actelion.research.calc.SOMController','mReferenceVector','Object[][]','mInfluence','double[][]','mLastBestMatch','java.awt.Point[]','mSMPSOMIndex','int[][]','+mSMPInfluenceIndex','mSMPInfluenceRect','java.awt.Rectangle','mExecutor','java.util.concurrent.ExecutorService','mSOMWorker','com.actelion.research.calc.SelfOrganizedMap.SOMWorker[]']]]

Clazz.newMeth(C$, 'c$',  function () {
Clazz.super_(C$, this);
p$1.initializeSMP.apply(this, []);
}, 1);

Clazz.newMeth(C$, 'c$$I$I$I',  function (nx, ny, mode) {
Clazz.super_(C$, this);
p$1.initializeSMP.apply(this, []);
this.initializeReferenceVectors$I$I$I(nx, ny, mode);
}, 1);

Clazz.newMeth(C$, 'initializeReferenceVectors$I$I$I',  function (nx, ny, mode) {
this.mNX=nx;
this.mNY=ny;
this.mMode=mode;
this.mReferenceVector=Clazz.array(java.lang.Object, [nx, ny]);
if (this.mThreadCount != 1) this.mSMPSOMIndex=p$1.getSMPArraySplitting$I$I.apply(this, [nx, ny]);
});

Clazz.newMeth(C$, 'initializeSMP',  function () {
this.mThreadCount=$I$(2).getRuntime$().availableProcessors$();
if (this.mThreadCount != 1) {
this.mExecutor=$I$(3).newFixedThreadPool$I(this.mThreadCount);
this.mSOMWorker=Clazz.array($I$(4), [this.mThreadCount]);
for (var t=0; t < this.mThreadCount; t++) this.mSOMWorker[t]=Clazz.new_($I$(4,1).c$$I,[this, null, t]);

}}, p$1);

Clazz.newMeth(C$, 'setController$com_actelion_research_calc_SOMController',  function (sc) {
this.mController=sc;
});

Clazz.newMeth(C$, 'getWidth$',  function () {
return this.mNX;
});

Clazz.newMeth(C$, 'getHeight$',  function () {
return this.mNY;
});

Clazz.newMeth(C$, 'getCreationMode$',  function () {
return this.mMode;
});

Clazz.newMeth(C$, 'organize$',  function () {
if (this.mController.getInputVectorCount$() == 0) return;
this.initializeNormalization$();
this.mDiagonal=Math.sqrt(((this.mNX - 1) * (this.mNX - 1) + (this.mNY - 1) * (this.mNY - 1)));
this.mCyclesPerNode=16;
this.mConstantInfluenceCycles=Math.max(1, (this.mNX * this.mNY * this.mCyclesPerNode /2560|0));
if ((this.mMode & 16) != 0) {
this.mNX=(this.mNX/(8)|0);
this.mNY=(this.mNY/(8)|0);
}this.mReferenceVector=Clazz.array(java.lang.Object, [this.mNX, this.mNY]);
for (var x=0; x < this.mNX; x++) for (var y=0; y < this.mNY; y++) this.mReferenceVector[x][y]=this.getRandomVector$();


this.mInputVectorCount=this.mController.getInputVectorCount$();
if (this.mInputVectorCount == -1) this.mMode&=~32;
if ((this.mMode & 32) != 0) {
this.mLastBestMatch=Clazz.array($I$(1), [this.mInputVectorCount]);
this.mFindBestMatchQuickly=false;
}if ((this.mMode & 16) != 0) {
var cyclesPhaseOne=this.mCyclesPerNode * this.mNX * this.mNY ;
var overallCycles=cyclesPhaseOne + (cyclesPhaseOne/3|0) * 4 + (cyclesPhaseOne/3|0) * 16 + (cyclesPhaseOne/3|0) * 64;
this.mCycle=0;
this.startProgress$S$I$I("Self-Organizing map...", 0, overallCycles);
p$1.optimize$I$I.apply(this, [0, cyclesPhaseOne]);
var cyclesInPhase=cyclesPhaseOne;
for (var phase=2; phase <= 4; phase++) {
p$1.grow.apply(this, []);
cyclesInPhase*=4;
p$1.optimize$I$I.apply(this, [cyclesInPhase - (cyclesInPhase/3|0), cyclesInPhase]);
}
this.stopProgress$S("Map completed.");
} else {
var overallCycles=this.mCyclesPerNode * this.mNX * this.mNY ;
this.mCycle=0;
this.startProgress$S$I$I("Self-Organizing map...", 0, overallCycles);
p$1.optimize$I$I.apply(this, [0, overallCycles]);
this.stopProgress$S("Map completed.");
}});

Clazz.newMeth(C$, 'getReferenceVector$I$I',  function (x, y) {
return this.mReferenceVector[x][y];
});

Clazz.newMeth(C$, 'getInfluence$',  function () {
return this.mInfluence;
});

Clazz.newMeth(C$, 'getChaos$',  function () {
var sum=0.0;
for (var x=0; x < this.mNX; x++) {
for (var y=0; y < this.mNY; y++) {
sum+=Math.sqrt((x == 0) ? this.getDissimilarity$O$O(this.mReferenceVector[0][y], this.mReferenceVector[this.mNX - 1][y]) : this.getDissimilarity$O$O(this.mReferenceVector[x][y], this.mReferenceVector[x - 1][y]));
sum+=Math.sqrt((y == 0) ? this.getDissimilarity$O$O(this.mReferenceVector[x][0], this.mReferenceVector[x][this.mNY - 1]) : this.getDissimilarity$O$O(this.mReferenceVector[x][y], this.mReferenceVector[x][y - 1]));
}
}
return sum / (this.mNX * this.mNY);
});

Clazz.newMeth(C$, 'getMatchScore$',  function () {
var randomCount=1;
var sum=0.0;
for (var i=0; i < 1; i++) {
var randomVector=this.getRandomVector$();
var bestMatch=null;
var minDissimilarity=Infinity;
for (var x=0; x < this.mNX; x++) {
for (var y=0; y < this.mNY; y++) {
var dissimilarity=this.getDissimilarity$O$O(this.mReferenceVector[x][y], randomVector);
if (minDissimilarity > dissimilarity ) {
minDissimilarity=dissimilarity;
bestMatch=this.mReferenceVector[x][y];
}}
}
sum+=Math.sqrt(this.getDissimilarity$O$O(randomVector, bestMatch));
}
return sum / 1.0;
});

Clazz.newMeth(C$, 'getTimeInfluence$D',  function (time) {
return 1.0 - time;
});

Clazz.newMeth(C$, 'getNeighbourInfluence$I$I$D',  function (dx, dy, time) {
var distance=Math.sqrt(dx * dx + dy * dy) / this.mDiagonal;
var f=0.0;
switch (this.mMode & 7) {
case 0:
f=Math.exp(distance * distance * Math.log(0.001)  / (this.mMaxRange * this.mMaxRange));
return (f < 0.001 ) ? 0.0 : f;
case 1:
f=1.0 - distance * distance / (this.mMaxRange * this.mMaxRange);
return (f < 0.0 ) ? 0.0 : f;
case 2:
f=1.0 - distance / this.mMaxRange;
return (f < 0.0 ) ? 0.0 : f;
}
return f;
});

Clazz.newMeth(C$, 'getSMPArraySplitting$I$I',  function (xCount, yCount) {
var nodeCount=xCount * yCount;
var nodesPerThread=(nodeCount/this.mThreadCount|0);
var remainingNodes=nodeCount % this.mThreadCount;
var index=Clazz.array(Integer.TYPE, [this.mThreadCount + 1, 2]);
for (var i=0; i < this.mThreadCount; i++) {
var nodes=(i < remainingNodes) ? nodesPerThread + 1 : nodesPerThread;
var dx=nodes % xCount;
var dy=(nodes/xCount|0);
if (index[i][0] + dx >= xCount) {
dx-=xCount;
++dy;
}index[i + 1][0]=index[i][0] + dx;
index[i + 1][1]=index[i][1] + dy;
}
return index;
}, p$1);

Clazz.newMeth(C$, 'optimize$I$I',  function (startCycle, cycles) {
this.mInfluence=null;
for (var cycle=startCycle; cycle < cycles; cycle++) {
if (((cycle - startCycle) % this.mConstantInfluenceCycles) == 0) this.calculateInfluences$D(cycle / cycles);
this.updateProgress$I(this.mCycle++);
if (this.threadMustDie$()) break;
var inputVector=this.normalizeVector$O(this.mController.getInputVector$I(this.mInputVectorIndex));
if ((this.mMode & 32) != 0) {
if (this.mFindBestMatchQuickly) this.mLastBestMatch[this.mInputVectorIndex]=this.findBestMatchLocationQuickly$O(inputVector);
 else {
var quickBestMatch=(this.mLastBestMatch[this.mInputVectorIndex] == null ) ? null : this.findBestMatchLocationQuickly$O(inputVector);
this.mLastBestMatch[this.mInputVectorIndex]=this.findBestMatchLocation$O(inputVector);
if (quickBestMatch != null  && quickBestMatch.equals$O(this.mLastBestMatch[this.mInputVectorIndex]) ) ++this.mCorrectQuickBestMatches;
 else this.mCorrectQuickBestMatches=0;
if (this.mCorrectQuickBestMatches == 2 * this.mInputVectorCount) this.mFindBestMatchQuickly=true;
}this.applyInfluences$O$java_awt_Point(inputVector, this.mLastBestMatch[this.mInputVectorIndex]);
} else {
this.applyInfluences$O$java_awt_Point(inputVector, this.findBestMatchLocation$O(inputVector));
}if (++this.mInputVectorIndex >= this.mInputVectorCount) this.mInputVectorIndex=0;
}
}, p$1);

Clazz.newMeth(C$, 'applyInfluences$O$java_awt_Point',  function (inputVector, location) {
var maxRange=((this.mDiagonal * this.mMaxRange)|0);
var x1=location.x - maxRange;
var x2=location.x + maxRange;
var y1=location.y - maxRange;
var y2=location.y + maxRange;
if ((this.mMode & 8) != 0) {
if (x2 - x1 >= this.mNX) {
x1=0;
x2=this.mNX;
}if (y2 - y1 >= this.mNY) {
y1=0;
y2=this.mNY;
}if (this.mThreadCount != 1 && maxRange != 0 ) {
if (this.mSMPInfluenceRect == null  || this.mSMPInfluenceRect.width != x2 - x1  || this.mSMPInfluenceRect.height != y2 - y1 ) this.mSMPInfluenceIndex=p$1.getSMPArraySplitting$I$I.apply(this, [x2 - x1, y2 - y1]);
this.mSMPInfluenceRect=Clazz.new_($I$(5,1).c$$I$I$I$I,[x1, y1, x2 - x1, y2 - y1]);
this.applyInfluencesSMP$O$java_awt_Point(inputVector, location);
} else {
for (var x=x1; x < x2; x++) {
for (var y=y1; y < y2; y++) {
var dx=Math.abs(location.x - x);
var dy=Math.abs(location.y - y);
if (dx > (this.mNX/2|0)) dx=this.mNX - dx;
if (dy > (this.mNY/2|0)) dy=this.mNY - dy;
if (this.mInfluence[dx][dy] > 0.0 ) this.updateReference$O$O$D(inputVector, this.mReferenceVector[x < 0 ? x + this.mNX : x < this.mNX ? x : x - this.mNX][y < 0 ? y + this.mNY : y < this.mNY ? y : y - this.mNY], this.mInfluence[dx][dy]);
}
}
}} else {
if (x1 < 0) x1=0;
if (x2 > this.mNX) x2=this.mNX;
if (y1 < 0) y1=0;
if (y2 > this.mNY) y2=this.mNY;
if (this.mThreadCount != 1 && maxRange != 0 ) {
this.mSMPInfluenceRect=Clazz.new_($I$(5,1).c$$I$I$I$I,[x1, y1, x2 - x1, y2 - y1]);
this.mSMPInfluenceIndex=p$1.getSMPArraySplitting$I$I.apply(this, [x2 - x1, y2 - y1]);
this.applyInfluencesSMP$O$java_awt_Point(inputVector, location);
} else {
for (var x=x1; x < x2; x++) {
for (var y=y1; y < y2; y++) {
var dx=Math.abs(location.x - x);
var dy=Math.abs(location.y - y);
if (this.mInfluence[dx][dy] > 0.0 ) this.updateReference$O$O$D(inputVector, this.mReferenceVector[x][y], this.mInfluence[dx][dy]);
}
}
}}});

Clazz.newMeth(C$, 'applyInfluencesSMP$O$java_awt_Point',  function (inputVector, location) {
var doneSignal=Clazz.new_($I$(6,1).c$$I,[this.mThreadCount]);
for (var worker, $worker = 0, $$worker = this.mSOMWorker; $worker<$$worker.length&&((worker=($$worker[$worker])),1);$worker++) {
worker.initApplyInfluences$O$java_awt_Point$java_util_concurrent_CountDownLatch(inputVector, location, doneSignal);
this.mExecutor.execute$Runnable(worker);
}
try {
doneSignal.await$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
});

Clazz.newMeth(C$, 'findBestMatchLocation$O',  function (inputVector) {
if (inputVector == null ) return null;
if (this.mThreadCount != 1) return this.findBestMatchLocationSMP$O(inputVector);
var minLocation=Clazz.new_($I$(1,1).c$$I$I,[-1, -1]);
var minDissimilarity=Infinity;
for (var x=0; x < this.mNX; x++) {
for (var y=0; y < this.mNY; y++) {
var dissimilarity=this.getDissimilarity$O$O(this.mReferenceVector[x][y], inputVector);
if (minDissimilarity > dissimilarity ) {
minDissimilarity=dissimilarity;
minLocation.x=x;
minLocation.y=y;
}}
}
return minLocation;
});

Clazz.newMeth(C$, 'findBestMatchLocationSMP$O',  function (inputVector) {
if (inputVector == null ) return null;
var doneSignal=Clazz.new_($I$(6,1).c$$I,[this.mThreadCount]);
for (var worker, $worker = 0, $$worker = this.mSOMWorker; $worker<$$worker.length&&((worker=($$worker[$worker])),1);$worker++) {
worker.initFindBestMatch$O$java_util_concurrent_CountDownLatch(inputVector, doneSignal);
this.mExecutor.execute$Runnable(worker);
}
try {
doneSignal.await$();
} catch (e) {
if (Clazz.exceptionOf(e,"InterruptedException")){
} else {
throw e;
}
}
var minLocation=Clazz.new_($I$(1,1).c$$I$I,[-1, -1]);
var minDissimilarity=Infinity;
for (var worker, $worker = 0, $$worker = this.mSOMWorker; $worker<$$worker.length&&((worker=($$worker[$worker])),1);$worker++) {
var dissimilarity=worker.getBestMatchDissimilarity$();
if (minDissimilarity > dissimilarity ) {
minDissimilarity=dissimilarity;
minLocation=worker.getBestMatchLocation$();
}}
return minLocation;
});

Clazz.newMeth(C$, 'findBestMatchLocationQuickly$O',  function (inputVector) {
if (inputVector == null ) return null;
var minLocation=this.mLastBestMatch[this.mInputVectorIndex];
var minDissimilarity=this.getDissimilarity$O$O(this.mReferenceVector[minLocation.x][minLocation.y], inputVector);
var locationChecked=Clazz.array(Boolean.TYPE, [this.mNX, this.mNY]);
locationChecked[minLocation.x][minLocation.y]=true;
var found;
do {
var p=minLocation;
found=false;
for (var xdif=-1; xdif < 2; xdif++) {
var x=p.x + xdif;
if ((this.mMode & 8) != 0) {
if (x < 0) x=this.mNX - 1;
 else if (x >= this.mNX) x=0;
} else if (x < 0 || x >= this.mNX ) continue;
for (var ydif=-1; ydif < 2; ydif++) {
var y=p.y + ydif;
if ((this.mMode & 8) != 0) {
if (y < 0) y=this.mNY - 1;
 else if (y >= this.mNY) y=0;
} else if (y < 0 || y >= this.mNY ) continue;
if (!locationChecked[x][y]) {
locationChecked[x][y]=true;
var dissimilarity=this.getDissimilarity$O$O(this.mReferenceVector[x][y], inputVector);
if (minDissimilarity > dissimilarity ) {
minDissimilarity=dissimilarity;
minLocation=Clazz.new_($I$(1,1).c$$I$I,[x, y]);
found=true;
}}}
}
} while (found);
return minLocation;
});

Clazz.newMeth(C$, 'findExactMatchLocation$O',  function (inputVector) {
if (inputVector == null ) return null;
var p=this.findBestMatchLocation$O(inputVector);
var location=Clazz.array(Double.TYPE, [3]);
location[0]=p.x;
location[1]=p.y;
var x1=p.x - 1;
var x2=p.x + 1;
var y1=p.y - 1;
var y2=p.y + 1;
if ((this.mMode & 8) != 0) {
if (x1 == -1) x1+=this.mNX;
if (x2 == this.mNX) x2=0;
if (y1 == -1) y1+=this.mNY;
if (y2 == this.mNY) y2=0;
}var dis0=Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[p.x][p.y], inputVector));
if (dis0 > 0.0 ) {
if (x1 == -1) location[0]+=0.5 * dis0 / Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[x2][p.y], inputVector));
 else if (x2 == this.mNX) location[0]-=0.5 * dis0 / Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[x1][p.y], inputVector));
 else {
var dis1=Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[x1][p.y], inputVector)) - dis0;
var dis2=Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[x2][p.y], inputVector)) - dis0;
if (dis1 + dis2 != 0 ) location[0]+=dis1 / (dis1 + dis2) - 0.5;
}if (y1 == -1) location[1]+=0.5 * dis0 / Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[p.x][y2], inputVector));
 else if (y2 == this.mNY) location[1]-=0.5 * dis0 / Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[p.x][y1], inputVector));
 else {
var dis1=Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[p.x][y1], inputVector)) - dis0;
var dis2=Math.sqrt(this.getDissimilarity$O$O(this.mReferenceVector[p.x][y2], inputVector)) - dis0;
if (dis1 + dis2 != 0 ) location[1]+=dis1 / (dis1 + dis2) - 0.5;
}}location[2]=dis0;
return location;
});

Clazz.newMeth(C$, 'grow',  function () {
var oldReferenceVector=this.mReferenceVector;
this.mReferenceVector=Clazz.array(java.lang.Object, [this.mNX * 2, this.mNY * 2]);
for (var x=0; x < this.mNX; x++) {
for (var y=0; y < this.mNY; y++) {
var nextX=(x == this.mNX - 1) ? 0 : x + 1;
var nextY=(y == this.mNY - 1) ? 0 : y + 1;
this.mReferenceVector[x * 2][y * 2]=oldReferenceVector[x][y];
this.mReferenceVector[x * 2 + 1][y * 2]=this.getMeanVector$O$O(oldReferenceVector[x][y], oldReferenceVector[nextX][y]);
this.mReferenceVector[x * 2][y * 2 + 1]=this.getMeanVector$O$O(oldReferenceVector[x][y], oldReferenceVector[x][nextY]);
this.mReferenceVector[x * 2 + 1][y * 2 + 1]=this.getMeanVector$O$O(oldReferenceVector[x][y], oldReferenceVector[nextX][nextY]);
}
}
this.mNX*=2;
this.mNY*=2;
if ((this.mMode & 32) != 0) {
for (var i=0; i < this.mLastBestMatch.length; i++) {
if (this.mLastBestMatch[i] != null ) {
this.mLastBestMatch[i].x*=2;
this.mLastBestMatch[i].y*=2;
}}
}}, p$1);

Clazz.newMeth(C$, 'calculateInfluences$D',  function (time) {
var cStartRange=1.0;
var cFinalRange=0.05;
this.mMaxRange=1.0 * Math.exp(Math.log(0.05) * Math.pow(time, 0.3));
var timeInfluence=this.getTimeInfluence$D(time);
var dxmax=Math.min(1 + ((this.mDiagonal * this.mMaxRange)|0), this.mNX);
var dymax=Math.min(1 + ((this.mDiagonal * this.mMaxRange)|0), this.mNY);
this.mInfluence=Clazz.array(Double.TYPE, [dxmax, dymax]);
for (var dx=0; dx < dxmax; dx++) for (var dy=0; dy < dymax; dy++) this.mInfluence[dx][dy]=0.5 * timeInfluence * this.getNeighbourInfluence$I$I$D(dx, dy, time) ;


});

Clazz.newMeth(C$, 'write$java_io_BufferedWriter',  function (writer) {
writer.write$S("<width=\"" + this.mNX + "\">" );
writer.newLine$();
writer.write$S("<height=\"" + this.mNY + "\">" );
writer.newLine$();
writer.write$S("<creationMode=\"" + this.mMode + "\">" );
writer.newLine$();
this.startProgress$S$I$I("Writing SOM Vectors...", 0, this.mNY);
for (var y=0; y < this.mNY; y++) {
this.updateProgress$I(y);
for (var x=0; x < this.mNX; x++) {
writer.write$S("<reference[" + x + "][" + y + "]=\"" + this.referenceVectorToString$I$I(x, y) + "\">" );
writer.newLine$();
}
}
this.stopProgress$S("SOM Vectors Written");
});

Clazz.newMeth(C$, 'read$java_io_BufferedReader',  function (reader) {
var theLine=reader.readLine$();
var error=!theLine.startsWith$S("<width=");
if (!error) {
this.mNX=Integer.parseInt$S(C$.extractValue$S(theLine));
theLine=reader.readLine$();
error=!theLine.startsWith$S("<height=");
}if (!error) {
this.mNY=Integer.parseInt$S(C$.extractValue$S(theLine));
theLine=reader.readLine$();
error=!theLine.startsWith$S("<creationMode=");
}if (!error) {
this.mMode=Integer.parseInt$S(C$.extractValue$S(theLine));
}if (!error && this.mThreadCount != 1 ) this.mSMPSOMIndex=p$1.getSMPArraySplitting$I$I.apply(this, [this.mNX, this.mNY]);
this.mReferenceVector=Clazz.array(java.lang.Object, [this.mNX, this.mNY]);
this.startProgress$S$I$I("Reading SOM Vectors...", 0, this.mNY);
for (var y=0; y < this.mNY && !error ; y++) {
this.updateProgress$I(y);
for (var x=0; x < this.mNX && !error ; x++) {
theLine=reader.readLine$();
error=!theLine.startsWith$S("<reference[" + x + "][" + y + "]=" );
if (!error) this.setReferenceVector$I$I$S(x, y, C$.extractValue$S(theLine));
}
}
this.stopProgress$S("SOM Vectors Reading Done");
if (error) throw Clazz.new_(Clazz.load('java.io.IOException').c$$S,["Invalid SOM file format"]);
});

Clazz.newMeth(C$, 'extractValue$S',  function (theLine) {
var index1=theLine.indexOf$S("=\"") + 2;
var index2=theLine.indexOf$S$I("\"", index1);
return theLine.substring$I$I(index1, index2);
}, 1);
;
(function(){/*c*/var C$=Clazz.newClass(P$.SelfOrganizedMap, "SOMWorker", function(){
Clazz.newInstance(this, arguments[0],true,C$);
}, null, 'Runnable');

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[['D',['mMinDissimilarity'],'I',['mThreadIndex','mWhatToDo'],'O',['mDoneSignal','java.util.concurrent.CountDownLatch','mInputVector','java.lang.Object','mLocation','java.awt.Point']]]

Clazz.newMeth(C$, 'c$$I',  function (threadIndex) {
;C$.$init$.apply(this);
this.mThreadIndex=threadIndex;
}, 1);

Clazz.newMeth(C$, 'initFindBestMatch$O$java_util_concurrent_CountDownLatch',  function (inputVector, doneSignal) {
this.mWhatToDo=1;
this.mInputVector=inputVector;
this.mDoneSignal=doneSignal;
});

Clazz.newMeth(C$, 'initApplyInfluences$O$java_awt_Point$java_util_concurrent_CountDownLatch',  function (inputVector, location, doneSignal) {
this.mWhatToDo=2;
this.mInputVector=inputVector;
this.mLocation=location;
this.mDoneSignal=doneSignal;
});

Clazz.newMeth(C$, 'run$',  function () {
switch (this.mWhatToDo) {
case 1:
this.mLocation=Clazz.new_($I$(1,1).c$$I$I,[-1, -1]);
this.mMinDissimilarity=Infinity;
var y1=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPSOMIndex[this.mThreadIndex][1];
var y2=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPSOMIndex[this.mThreadIndex + 1][1];
for (var y=y1; y <= y2; y++) {
var x1=(y == y1) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPSOMIndex[this.mThreadIndex][0] : 0;
var x2=(y == y2) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPSOMIndex[this.mThreadIndex + 1][0] : this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX;
for (var x=x1; x < x2; x++) {
var dissimilarity=this.b$['com.actelion.research.calc.SelfOrganizedMap'].getDissimilarity$O$O.apply(this.b$['com.actelion.research.calc.SelfOrganizedMap'], [this.b$['com.actelion.research.calc.SelfOrganizedMap'].mReferenceVector[x][y], this.mInputVector]);
if (this.mMinDissimilarity > dissimilarity ) {
this.mMinDissimilarity=dissimilarity;
this.mLocation.x=x;
this.mLocation.y=y;
}}
}
break;
case 2:
if ((this.b$['com.actelion.research.calc.SelfOrganizedMap'].mMode & 8) != 0) {
y1=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex][1];
y2=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex + 1][1];
for (var yy=y1; yy <= y2; yy++) {
var x1=(yy == y1) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex][0] : 0;
var x2=(yy == y2) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex + 1][0] : this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.width;
var y=yy + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.y;
for (var xx=x1; xx < x2; xx++) {
var x=xx + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.x;
var dx=Math.abs(this.mLocation.x - x);
var dy=Math.abs(this.mLocation.y - y);
if (dx > (this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX/2|0)) dx=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX - dx;
if (dy > (this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNY/2|0)) dy=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNY - dy;
if (this.b$['com.actelion.research.calc.SelfOrganizedMap'].mInfluence[dx][dy] > 0.0 ) this.b$['com.actelion.research.calc.SelfOrganizedMap'].updateReference$O$O$D.apply(this.b$['com.actelion.research.calc.SelfOrganizedMap'], [this.mInputVector, this.b$['com.actelion.research.calc.SelfOrganizedMap'].mReferenceVector[x < 0 ? x + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX : x < this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX ? x : x - this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNX][y < 0 ? y + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNY : y < this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNY ? y : y - this.b$['com.actelion.research.calc.SelfOrganizedMap'].mNY], this.b$['com.actelion.research.calc.SelfOrganizedMap'].mInfluence[dx][dy]]);
}
}
} else {
y1=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex][1];
y2=this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex + 1][1];
for (var yy=y1; yy <= y2; yy++) {
var x1=(yy == y1) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex][0] : 0;
var x2=(yy == y2) ? this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceIndex[this.mThreadIndex + 1][0] : this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.width;
var y=yy + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.y;
for (var xx=x1; xx < x2; xx++) {
var x=xx + this.b$['com.actelion.research.calc.SelfOrganizedMap'].mSMPInfluenceRect.x;
var dx=Math.abs(this.mLocation.x - x);
var dy=Math.abs(this.mLocation.y - y);
if (this.b$['com.actelion.research.calc.SelfOrganizedMap'].mInfluence[dx][dy] > 0.0 ) this.b$['com.actelion.research.calc.SelfOrganizedMap'].updateReference$O$O$D.apply(this.b$['com.actelion.research.calc.SelfOrganizedMap'], [this.mInputVector, this.b$['com.actelion.research.calc.SelfOrganizedMap'].mReferenceVector[x][y], this.b$['com.actelion.research.calc.SelfOrganizedMap'].mInfluence[dx][dy]]);
}
}
}break;
}
this.mDoneSignal.countDown$();
});

Clazz.newMeth(C$, 'getBestMatchLocation$',  function () {
return this.mLocation;
});

Clazz.newMeth(C$, 'getBestMatchDissimilarity$',  function () {
return this.mMinDissimilarity;
});

Clazz.newMeth(C$);
})()
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-01-31 13:45:23 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
