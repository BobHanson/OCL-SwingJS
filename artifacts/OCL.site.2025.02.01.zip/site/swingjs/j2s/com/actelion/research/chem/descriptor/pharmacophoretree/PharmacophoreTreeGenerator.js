(function(){var P$=Clazz.newPackage("com.actelion.research.chem.descriptor.pharmacophoretree"),I$=[[0,'java.util.HashSet','java.util.Arrays','java.util.HashMap','java.util.ArrayList','org.openmolecules.chem.conf.gen.ConformerGenerator','com.actelion.research.chem.descriptor.pharmacophoretree.FeatureCalculator','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreNode',['com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','.BiGramInt'],'com.actelion.research.chem.descriptor.pharmacophoretree.TreeUtils','java.util.stream.Collectors','com.actelion.research.chem.descriptor.pharmacophoretree.Graph','com.actelion.research.chem.descriptor.pharmacophoretree.PharmacophoreTree','java.util.LinkedList','com.actelion.research.chem.Molecule','com.actelion.research.chem.RingCollection','com.actelion.research.chem.conf.VDWRadii','com.actelion.research.chem.conf.BondLengthSet']],I$0=I$[0],$I$=function(i,n,m){return m?$I$(i)[n].apply(null,m):((i=(I$[i]||(I$[i]=Clazz.load(I$0[i])))),!n&&i.$load$&&Clazz.load(i,2),i)};
/*c*/var C$=Clazz.newClass(P$, "PharmacophoreTreeGenerator");

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);

C$.$fields$=[[]
,['O',['RGROUPS','java.util.Set']]]

Clazz.newMeth(C$, 'c$',  function () {
;C$.$init$.apply(this);
}, 1);

Clazz.newMeth(C$, 'generate$com_actelion_research_chem_StereoMolecule',  function (mol) {
return C$.generate$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List(mol, Clazz.new_($I$(3,1)), Clazz.new_($I$(4,1)));
}, 1);

Clazz.newMeth(C$, 'generate$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List',  function (mol, atomToNodes, rings) {
mol.ensureHelperArrays$I(31);
$I$(5).addHydrogenAtoms$com_actelion_research_chem_StereoMolecule(mol);
mol.ensureHelperArrays$I(31);
var atomVolumes=C$.getAtomVolumes$com_actelion_research_chem_StereoMolecule(mol);
var ppNodes=Clazz.new_($I$(4,1));
var nodeEdges=Clazz.new_($I$(4,1));
var ringNodes=Clazz.new_($I$(4,1));
var ringNodeEdges=Clazz.new_($I$(4,1));
C$.createRingGraphs$com_actelion_research_chem_StereoMolecule$java_util_List$java_util_List$java_util_List(mol, ringNodes, ringNodeEdges, rings);
var calculator=Clazz.new_($I$(6,1).c$$com_actelion_research_chem_StereoMolecule,[mol]);
calculator.calculate$();
var functionalities=calculator.getAtomFunctionalities$();
for (var i=0; i < ringNodes.size$(); i++) {
var ring=ringNodes.get$I(i);
var node=Clazz.new_([Clazz.new_($I$(4,1).c$$java_util_Collection,[ring]), functionalities, atomVolumes, false, false],$I$(7,1).c$$java_util_List$IAA$DA$Z$Z);
C$.addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
}
for (var i=0; i < ringNodeEdges.size$(); i++) {
var newEdge=Clazz.new_([ringNodeEdges.get$I(i)],$I$(8,1).c$$IA);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}
C$.treeWalk$I$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List$java_util_List$IAA$DA(0, mol, atomToNodes, ppNodes, nodeEdges, functionalities, atomVolumes);
var adj=$I$(9,"getAdjacencyList$I$java_util_List",[ppNodes.size$(), nodeEdges.stream$().map$java_util_function_Function((P$.PharmacophoreTreeGenerator$lambda1$||(P$.PharmacophoreTreeGenerator$lambda1$=(((P$.PharmacophoreTreeGenerator$lambda1||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTreeGenerator$lambda1", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree_BiGramInt','apply$O'],  function (e) { return (e.edge);});
})()
), Clazz.new_(P$.PharmacophoreTreeGenerator$lambda1.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(10).toList$())]);
var g=Clazz.new_($I$(11,1).c$$java_util_Map,[adj]);
var edgesToDelete=Clazz.new_($I$(1,1));
var bccs=g.bcc$();
for (var bcc, $bcc = bccs.iterator$(); $bcc.hasNext$()&&((bcc=($bcc.next$())),1);) {
if (bcc.size$() > 1) {
var bccNodes=Clazz.new_($I$(1,1));
for (var c, $c = bcc.iterator$(); $c.hasNext$()&&((c=($c.next$())),1);) {
bccNodes.add$O(Integer.valueOf$I(c[0]));
bccNodes.add$O(Integer.valueOf$I(c[1]));
edgesToDelete.add$O(Clazz.new_($I$(8,1).c$$IA,[c]));
}
var node=Clazz.new_([Clazz.new_($I$(4,1)), functionalities, atomVolumes, 1, false, false],$I$(7,1).c$$java_util_List$IAA$DA$I$Z$Z);
C$.addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
var index=ppNodes.size$() - 1;
for (var connNode, $connNode = bccNodes.iterator$(); $connNode.hasNext$()&&((connNode=($connNode.next$())),1);) {
nodeEdges.add$O(Clazz.new_([Clazz.array(Integer.TYPE, -1, [(connNode).valueOf(), index])],$I$(8,1).c$$IA));
}
}}
nodeEdges.removeAll$java_util_Collection(edgesToDelete);
for (var ppNode, $ppNode = ppNodes.iterator$(); $ppNode.hasNext$()&&((ppNode=($ppNode.next$())),1);) ppNode.updateWeights$java_util_Map(atomToNodes);

return Clazz.new_([ppNodes, nodeEdges.stream$().map$java_util_function_Function((P$.PharmacophoreTreeGenerator$lambda2$||(P$.PharmacophoreTreeGenerator$lambda2$=(((P$.PharmacophoreTreeGenerator$lambda2||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTreeGenerator$lambda2", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Function', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['apply$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreTree_BiGramInt','apply$O'],  function (e) { return (e.edge);});
})()
), Clazz.new_(P$.PharmacophoreTreeGenerator$lambda2.$init$,[this, null])))))).collect$java_util_stream_Collector($I$(10).toList$())],$I$(12,1).c$$java_util_List$java_util_List);
}, 1);

Clazz.newMeth(C$, 'treeWalk$I$com_actelion_research_chem_StereoMolecule$java_util_Map$java_util_List$java_util_List$IAA$DA',  function (atom, mol, atomToNodes, ppNodes, nodeEdges, functionalities, atomVolumes) {
var visited=Clazz.array(Boolean.TYPE, [mol.getAtoms$()]);
var parents=Clazz.array(Integer.TYPE, [mol.getAtoms$()]);
var atoms=Clazz.new_($I$(13,1));
atoms.add$O(Integer.valueOf$I(atom));
parents[atom]=-1;
visited[atom]=true;
while (!atoms.isEmpty$()){
var currentAtom=(atoms.poll$()).$c();
visited[currentAtom]=true;
if (!mol.isRingAtom$I(currentAtom) && atomToNodes.get$O(Integer.valueOf$I(currentAtom)) == null  ) {
var label=mol.getAtomLabel$I(currentAtom);
var node;
if (C$.RGROUPS.contains$O(label)) {
node=Clazz.new_([$I$(2,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(currentAtom)])]), functionalities, atomVolumes, 7, false, false],$I$(7,1).c$$java_util_List$IAA$DA$I$Z$Z);
node.getFunctionalities$()[0]=$I$(14).getAtomicNoFromLabel$S(label) + 1 - 92;
} else node=Clazz.new_([$I$(2,"asList$OA",[Clazz.array(Integer, -1, [Integer.valueOf$I(currentAtom)])]), functionalities, atomVolumes, false, false],$I$(7,1).c$$java_util_List$IAA$DA$Z$Z);
C$.addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map(node, ppNodes, atomToNodes);
var index=ppNodes.size$() - 1;
if (parents[currentAtom] != -1) {
var connNodes=atomToNodes.get$O(Integer.valueOf$I(parents[currentAtom]));
for (var connNode, $connNode = connNodes.iterator$(); $connNode.hasNext$()&&((connNode=($connNode.next$()).intValue$()),1);) {
var newEdge=Clazz.new_([Clazz.array(Integer.TYPE, -1, [connNode, index])],$I$(8,1).c$$IA);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}
}} else {
var nodes=atomToNodes.get$O(Integer.valueOf$I(currentAtom));
if (parents[currentAtom] != -1) {
var connNodes=atomToNodes.get$O(Integer.valueOf$I(parents[currentAtom]));
for (var node, $node = nodes.iterator$(); $node.hasNext$()&&((node=($node.next$()).intValue$()),1);) {
for (var connNode, $connNode = connNodes.iterator$(); $connNode.hasNext$()&&((connNode=($connNode.next$()).intValue$()),1);) {
if (connNode != node) {
var newEdge=Clazz.new_([Clazz.array(Integer.TYPE, -1, [connNode, node])],$I$(8,1).c$$IA);
if (!nodeEdges.contains$O(newEdge)) nodeEdges.add$O(newEdge);
}}
}
}}for (var a=0; a < mol.getConnAtoms$I(currentAtom); a++) {
var nextAtom=mol.getConnAtom$I$I(currentAtom, a);
if (visited[nextAtom]) continue;
 else {
atoms.add$O(Integer.valueOf$I(nextAtom));
parents[nextAtom]=currentAtom;
}}
}
}, 1);

Clazz.newMeth(C$, 'addNode$com_actelion_research_chem_descriptor_pharmacophoretree_PharmacophoreNode$java_util_List$java_util_Map',  function (node, nodes, atomToNodes) {
var index=nodes.size$();
nodes.add$O(node);
for (var atom, $atom = node.getAtoms$().iterator$(); $atom.hasNext$()&&((atom=($atom.next$()).intValue$()),1);) {
atomToNodes.putIfAbsent$O$O(Integer.valueOf$I(atom), Clazz.new_($I$(4,1)));
atomToNodes.get$O(Integer.valueOf$I(atom)).add$O(Integer.valueOf$I(index));
}
}, 1);

Clazz.newMeth(C$, 'createRingGraphs$com_actelion_research_chem_StereoMolecule$java_util_List$java_util_List$java_util_List',  function (mol, ringNodes, ringNodeEdges, rings) {
var rc=Clazz.new_($I$(15,1).c$$com_actelion_research_chem_ExtendedMolecule$I$I,[mol, 3, 50]);
var ringEdges=Clazz.new_($I$(4,1));
for (var atom=0; atom < mol.getAtoms$(); atom++) {
var smallestRings=C$.getSmallestRingsOfAtom$com_actelion_research_chem_RingCollection$I(rc, atom);
for (var smallRingIndex, $smallRingIndex = smallestRings.iterator$(); $smallRingIndex.hasNext$()&&((smallRingIndex=($smallRingIndex.next$())),1);) {
var smallRing=$I$(2,"stream$IA",[rc.getRingAtoms$I((smallRingIndex).$c())]).boxed$().collect$java_util_stream_Collector($I$(10).toSet$());
if (!rings.contains$O(smallRing)) rings.add$O(smallRing);
}
}
for (var r1=0; r1 < rings.size$(); r1++) {
var ring1=rings.get$I(r1);
for (var r2=r1 + 1; r2 < rings.size$(); r2++) {
var ring2=rings.get$I(r2);
var commonElements=ring1.stream$().filter$java_util_function_Predicate(((P$.PharmacophoreTreeGenerator$lambda3||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTreeGenerator$lambda3", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$Integer','test$O'],  function (e) { return (this.$finals$.ring2.contains$O.apply(this.$finals$.ring2, [e]));});
})()
), Clazz.new_(P$.PharmacophoreTreeGenerator$lambda3.$init$,[this, {ring2:ring2}]))).count$();
if (Long.$gt(commonElements,0 )) {
ringEdges.add$O(Clazz.array(Integer.TYPE, -1, [r1, r2]));
}}
}
var adj=$I$(9,"getAdjacencyList$I$java_util_List",[rings.size$(), ringEdges]);
var g=Clazz.new_($I$(11,1).c$$java_util_Map,[adj]);
var bccs=g.bcc$();
var toDelete=Clazz.new_($I$(4,1));
for (var bcc, $bcc = bccs.iterator$(); $bcc.hasNext$()&&((bcc=($bcc.next$())),1);) {
if (bcc.size$() > 1) {
var ring=Clazz.new_($I$(1,1));
for (var edge, $edge = bcc.iterator$(); $edge.hasNext$()&&((edge=($edge.next$())),1);) {
ring.addAll$java_util_Collection(rings.get$I(edge[0]));
ring.addAll$java_util_Collection(rings.get$I(edge[1]));
toDelete.add$O(rings.get$I(edge[0]));
toDelete.add$O(rings.get$I(edge[1]));
}
ringNodes.add$O(ring);
}}
rings.removeAll$java_util_Collection(toDelete);
for (var ring, $ring = rings.iterator$(); $ring.hasNext$()&&((ring=($ring.next$())),1);) {
ringNodes.add$O(ring);
}
for (var r1=0; r1 < ringNodes.size$(); r1++) {
var ring1=ringNodes.get$I(r1);
for (var r2=r1 + 1; r2 < ringNodes.size$(); r2++) {
var ring2=ringNodes.get$I(r2);
var commonElements=ring1.stream$().filter$java_util_function_Predicate(((P$.PharmacophoreTreeGenerator$lambda4||
(function(){/*m*/var C$=Clazz.newClass(P$, "PharmacophoreTreeGenerator$lambda4", function(){Clazz.newInstance(this, arguments[0],1,C$);}, null, 'java.util.function.Predicate', 1);

C$.$clinit$=2;

Clazz.newMeth(C$, '$init$', function () {
},1);
/*lambda_E*/
Clazz.newMeth(C$, ['test$Integer','test$O'],  function (e) { return (this.$finals$.ring2.contains$O.apply(this.$finals$.ring2, [e]));});
})()
), Clazz.new_(P$.PharmacophoreTreeGenerator$lambda4.$init$,[this, {ring2:ring2}]))).count$();
if (Long.$gt(commonElements,0 )) {
ringNodeEdges.add$O(Clazz.array(Integer.TYPE, -1, [r1, r2]));
}}
}
}, 1);

Clazz.newMeth(C$, 'getSmallestRingsOfAtom$com_actelion_research_chem_RingCollection$I',  function (rc, atom) {
var rings=Clazz.new_($I$(4,1));
var smallestRingSize=rc.getAtomRingSize$I(atom);
for (var r=0; r < rc.getSize$(); r++) {
var ringAtoms=$I$(2,"stream$IA",[rc.getRingAtoms$I(r)]).boxed$().collect$java_util_stream_Collector($I$(10).toSet$());
if (ringAtoms.size$() > smallestRingSize) continue;
if (ringAtoms.contains$O(Integer.valueOf$I(atom))) rings.add$O(Integer.valueOf$I(r));
}
return rings;
}, 1);

Clazz.newMeth(C$, 'getAtomVolumes$com_actelion_research_chem_StereoMolecule',  function (mol) {
var atomVolumes=Clazz.array(Double.TYPE, [mol.getAtoms$()]);
for (var a=0; a < mol.getAtoms$(); a++) {
atomVolumes[a]=C$.getAtomicVdWVolume$I(mol.getAtomicNo$I(a));
}
for (var b=0; b < mol.getBonds$(); b++) {
var a1=mol.getBondAtom$I$I(0, b);
var a2=mol.getBondAtom$I$I(1, b);
var capCorrection=C$.calculateCapVolumesIntersectingAtomSpheres$com_actelion_research_chem_StereoMolecule$I$I(mol, a1, a2);
atomVolumes[a1]-=capCorrection[0];
atomVolumes[a2]-=capCorrection[1];
}
return atomVolumes;
}, 1);

Clazz.newMeth(C$, 'getAtomicVdWVolume$I',  function (atomicNo) {
var r=0;
if (atomicNo < $I$(16).VDW_RADIUS.length) r=$I$(16).VDW_RADIUS[atomicNo];
return (1.3333333333333333) * 3.141592653589793 * Math.pow(r, 3) ;
}, 1);

Clazz.newMeth(C$, 'calculateCapVolumesIntersectingAtomSpheres$com_actelion_research_chem_StereoMolecule$I$I',  function (mol, a, b) {
var r1=0.0;
var r2=0.0;
var v1=0.0;
var v2=0.0;
if (mol.getAtomicNo$I(a) < $I$(16).VDW_RADIUS.length && mol.getAtomicNo$I(b) < $I$(16).VDW_RADIUS.length ) {
r1=$I$(16).VDW_RADIUS[mol.getAtomicNo$I(a)];
r2=$I$(16).VDW_RADIUS[mol.getAtomicNo$I(b)];
var bond=mol.getBond$I$I(a, b);
var d=$I$(17).lookupBondLength$com_actelion_research_chem_StereoMolecule$I(mol, bond);
var x=(d * d - r1 * r1 + r2 * r2) / (2 * d);
var d1=x;
var d2=d - x;
var h1=r1 - d1;
var h2=r2 - d2;
v1=(0.3333333333333333) * 3.141592653589793 * h1 * h1  + (3 * r1 - h1);
v2=(0.3333333333333333) * 3.141592653589793 * h2 * h2  + (3 * r2 - h2);
}return Clazz.array(Double.TYPE, -1, [v1, v2]);
}, 1);

C$.$static$=function(){C$.$static$=0;
C$.RGROUPS=Clazz.new_([$I$(2,"asList$OA",[Clazz.array(String, -1, ["U", "Np", "Pu", "Am"])])],$I$(1,1).c$$java_util_Collection);
};
})();
;Clazz.setTVer('5.0.1-v4');//Created 2025-02-02 02:55:46 Java2ScriptVisitor version 5.0.1-v4 net.sf.j2s.core.jar version 5.0.1-v4
